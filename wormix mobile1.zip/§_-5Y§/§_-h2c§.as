package §_-5Y§
{
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-h2c§
   {
      
      public static const COMMON_CHAT:String = "COMMON_CHAT";
      
      public static const TEAM_CHAT:String = "TEAM_CHAT";
      
      public static const GLOBAL_CHAT:String = "GLOBAL_CHAT";
      
      public static const CLAN_CHAT:String = "CLAN_CHAT";
      
      public static const BATTLE_CHAT:String = "BATTLE_CHAT";
      
      public function §_-h2c§()
      {
         super();
      }
   }
}


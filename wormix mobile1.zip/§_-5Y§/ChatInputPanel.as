package §_-5Y§
{
   import §_-62§.§_-G1p§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-DJ§.§_-J2l§;
   import §_-Ly§.§_-81L§;
   import §_-hO§.§_-03k§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-v2t§.§_-73F§;
   import §_-z1g§.§_-F4§;
   import com.distriqt.extension.inappbilling.Purchase;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.VerticalAlign;
   import feathers.skins.ImageSkin;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.events.Event;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.clans.response.QuitClanResponse;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillMissile;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillStanding;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.SystemUtil;
   
   public class ChatInputPanel extends LayoutGroup
   {
      
      public static const §_-V2g§:int = 128;
      
      private var binder:Binder;
      
      private var chatType:String;
      
      public function ChatInputPanel(param1:String)
      {
         var chatType:String = param1;
         super();
         this.chatType = chatType;
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("chat_input_field"),true,this.binder);
         addChild(this.binder._inputPanel);
         this.layout = new AnchorLayout();
         this.binder._inputPanel.layoutData = new AnchorLayoutData(NaN,0,NaN,0);
         this.binder._buttonGroup.buttonProperties.styleName = AlternateButtonsStyles.BUTTON_QUAD_GREY;
         this.binder._buttonGroup.buttonProperties.width = 50;
         this.binder._buttonGroup.buttonProperties.height = 50;
         this.binder._buttonGroup.verticalAlign = VerticalAlign.MIDDLE;
         this.binder._buttonGroup.distributeButtonSizes = false;
         this.binder._buttonGroup.gap = 10;
         this.binder._buttonGroup.dataProvider = new ListCollection([{
            "label":"",
            "icon":"icon_message_new",
            "triggered":this.§_-Ft§
         },{
            "label":"",
            "icon":"icon_stickers_new",
            "triggered":this.§_-f1a§
         }]);
         this.binder._buttonGroup.buttonInitializer = function(param1:Button, param2:Object):void
         {
            var _loc3_:Texture = Application.assetManager.getTexture(param2.icon);
            var _loc4_:ImageSkin = new ImageSkin(_loc3_);
            _loc4_.width = 25;
            _loc4_.height = 25;
            param1.defaultIcon = _loc4_;
            param1.addEventListener(starling.events.Event.TRIGGERED,param2.triggered);
         };
         this.binder._textInput.maxChars = §_-V2g§;
         this.binder._textInput.addEventListener(FeathersEventType.ENTER,this.§_-Ft§);
         this.binder._textInput.addEventListener(FeathersEventType.FOCUS_IN,this.§_-J2t§);
         this.binder._textInput.addEventListener(FeathersEventType.FOCUS_OUT,this.§_-B3S§);
         §_-X1j§.localizationService.§_-I2k§(this.binder._textInput,"prompt",§_-s2a§.INPUT_MESSAGE);
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            if(this.chatType == §_-h2c§.GLOBAL_CHAT)
            {
               if(§_-F4§.§_-s1p§)
               {
                  this.binder._textInput.text = "";
                  this.isEnabled = true;
               }
               else
               {
                  this.binder._textInput.text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.PVP_WAGER_AVAILABLE_FOR),{"level":§_-F4§.§_-02R§});
                  this.isEnabled = false;
               }
            }
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-X1j§.localizationService.removeObject(this.binder._textInput);
      }
      
      private function §_-Ft§(param1:starling.events.Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         var _loc2_:String = §_-X1j§.§_-sO§.§_-gO§(this.binder._textInput.text);
         if(_loc2_)
         {
            dispatchEventWith(§_-t2O§.SEND_MESSAGE,true,_loc2_);
            this.binder._textInput.text = "";
         }
      }
      
      private function §_-f1a§(param1:starling.events.Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         this.binder._textInput.clearFocus();
         dispatchEventWith(§_-t2O§.TOGGLE_STICKERS_PANEL,true);
      }
      
      private function §_-J2t§(param1:starling.events.Event) : void
      {
         dispatchEventWith(FeathersEventType.FOCUS_IN,true);
      }
      
      private function §_-B3S§(param1:starling.events.Event) : void
      {
         dispatchEventWith(FeathersEventType.FOCUS_OUT,true);
      }
      
      override public function set isEnabled(param1:Boolean) : void
      {
         super.isEnabled = param1;
         this.binder._textInput.isEnabled = param1;
         this.binder._buttonGroup.touchable = param1;
         this.binder._buttonGroup.alpha = param1 ? 1 : 0.5;
      }
      
      override protected function layoutGroup_addedToStageHandler(param1:starling.events.Event) : void
      {
         super.layoutGroup_addedToStageHandler(param1);
      }
      
      public function setFocus() : void
      {
         if(Boolean(this.binder) && Boolean(this.binder._textInput.isEnabled) && SystemUtil.isDesktop)
         {
            this.binder._textInput.setFocus();
         }
      }
   }
}

import feathers.controls.ButtonGroup;
import feathers.controls.LayoutGroup;
import feathers.controls.TextInput;

class Binder
{
   
   public var _inputPanel:LayoutGroup;
   
   public var _textInput:TextInput;
   
   public var _buttonGroup:ButtonGroup;
   
   public function Binder()
   {
      super();
   }
}

package §_-5Y§
{
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-U1i§.§_-81M§;
   import §_-dS§.§_-D3a§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import starling.events.Event;
   
   public class §_-91y§
   {
      
      public var message:String;
      
      public var action:int;
      
      public function §_-91y§(param1:String, param2:int)
      {
         super();
         this.message = param1;
         this.action = param2;
      }
   }
}


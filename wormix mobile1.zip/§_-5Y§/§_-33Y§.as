package §_-5Y§
{
   import §_-31W§.§_-r26§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-7u§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-02k§;
   import §_-CR§.§_-72p§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.§_-a2W§;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-S18§;
   import §_-L1H§.§_-b2K§;
   import §_-P1B§.§_-b21§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.*;
   import §_-YF§.§_-N3§;
   import §_-YF§.§_-g2W§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-c2E§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-sQ§.§_-H3D§;
   import §_-u2J§.§_-T1K§;
   import com.amanitadesign.steam.SteamConstants;
   import com.amanitadesign.steam.SteamEvent;
   import com.greensock.events.TweenEvent;
   import com.hurlant.crypto.tls.§_-e1A§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.IListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalLayout;
   import feathers.utils.textures.TextureCache;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.utils.id.GetAuthKeyEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.NotInClanChatScreen;
   import ru.pragmatix.wormix.gui.menu.clans.chat.§_-D2t§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-z1x§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.BurningOil;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.render.IRenderer;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   public class §_-33Y§ extends LayoutGroup
   {
      
      protected static const §_-Z2f§:int = §_-Ma§.§_-UX§;
      
      protected var §_-C20§:List;
      
      protected var §_-B2S§:Dictionary;
      
      protected var §_-OU§:§_-72p§;
      
      private var §_-OC§:String;
      
      private var textureCache:TextureCache;
      
      private var renderers:Vector.<DefaultListItemRenderer>;
      
      private var §_-m18§:Boolean = true;
      
      private var §_-d2H§:Boolean;
      
      private var §_-2L§:§_-Ma§;
      
      public function §_-33Y§(param1:Array, param2:String, param3:TextureCache = null)
      {
         var _loc4_:String = null;
         super();
         this.textureCache = param3;
         this.§_-B2S§ = new Dictionary();
         for each(_loc4_ in param1)
         {
            this.§_-B2S§[_loc4_] = new §_-91F§();
         }
         this.§_-OC§ = param2;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.§_-o1t§();
         this.§_-C3§();
         this.§_-C20§.clipContent = true;
         this.§_-C20§.dataProvider = this.§_-a2u§(this.§_-OC§).listCollection;
         this.§_-C20§.addEventListener(FeathersEventType.RENDERER_ADD,this.§_-f1O§);
         this.§_-C20§.addEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-u2M§);
         this.§_-C20§.addEventListener(FeathersEventType.SCROLL_COMPLETE,this.§_-J3i§);
         this.renderers = new Vector.<DefaultListItemRenderer>(0);
         if(this.§_-OU§)
         {
            this.§_-OU§.addEventListener(starling.events.Event.ADDED_TO_STAGE,this.§_-K2§);
            this.§_-OU§.addEventListener(starling.events.Event.REMOVED_FROM_STAGE,this.§_-d1y§);
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-C20§.removeEventListener(FeathersEventType.RENDERER_ADD,this.§_-f1O§);
         this.§_-C20§.removeEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-u2M§);
         this.§_-C20§.removeEventListener(FeathersEventType.SCROLL_COMPLETE,this.§_-J3i§);
         if(this.§_-OU§)
         {
            this.§_-OU§.removeEventListener(starling.events.Event.ADDED_TO_STAGE,this.§_-K2§);
            this.§_-OU§.removeEventListener(starling.events.Event.REMOVED_FROM_STAGE,this.§_-d1y§);
            this.§_-OU§.dispose();
            this.§_-OU§ = null;
         }
      }
      
      private function §_-K2§(param1:starling.events.Event) : void
      {
         var _loc2_:§_-S18§ = §_-S18§(param1.target);
         var _loc3_:§_-02k§ = §_-02k§(_loc2_.parent);
         var _loc4_:LayoutGroup = LayoutGroup(_loc3_.origin);
         var _loc5_:§_-Ma§ = §_-Ma§(_loc4_.parent);
         this.§_-2L§ = _loc5_;
         this.§_-2L§.§_-R2w§(true);
      }
      
      private function §_-d1y§(param1:starling.events.Event) : void
      {
         if(this.§_-2L§)
         {
            this.§_-2L§.§_-R2w§(false);
            this.§_-2L§ = null;
         }
      }
      
      private function §_-f1O§(param1:starling.events.Event) : void
      {
         var _loc2_:DefaultListItemRenderer = param1.data as DefaultListItemRenderer;
         this.renderers.push(_loc2_);
      }
      
      private function §_-u2M§(param1:starling.events.Event) : void
      {
         var _loc2_:DefaultListItemRenderer = param1.data as DefaultListItemRenderer;
         var _loc3_:int = int(this.renderers.indexOf(_loc2_));
         if(_loc3_ > -1)
         {
            this.renderers.removeAt(_loc3_);
         }
      }
      
      private function §_-J3i§(param1:starling.events.Event) : void
      {
         this.§_-m18§ = this.§_-C20§.verticalScrollPosition == this.§_-C20§.maxVerticalScrollPosition;
      }
      
      override protected function draw() : void
      {
         var _loc1_:DefaultListItemRenderer = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE))
         {
            for each(_loc1_ in this.renderers)
            {
               _loc1_.invalidate(INVALIDATION_FLAG_SIZE);
            }
         }
      }
      
      protected function §_-C3§() : void
      {
         this.§_-C20§.layout = this.§_-y2P§();
         this.initList(this.§_-C20§);
         this.§_-C20§.itemRendererProperties.textureCache = this.textureCache;
         this.§_-C20§.itemRendererType = this.§_-w1T§();
      }
      
      protected function §_-y2P§() : ILayout
      {
         var _loc1_:VerticalLayout = new VerticalLayout();
         _loc1_.useVirtualLayout = false;
         _loc1_.hasVariableItemDimensions = true;
         _loc1_.horizontalAlign = HorizontalAlign.LEFT;
         return _loc1_;
      }
      
      protected function initList(param1:List) : void
      {
         param1.snapScrollPositionsToPixels = true;
         param1.autoHideBackground = true;
      }
      
      override public function set height(param1:Number) : void
      {
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         if(!isNaN(param1) && Boolean(this.§_-C20§))
         {
            if(this.§_-C20§.maxVerticalScrollPosition > 0)
            {
               _loc2_ = height - param1;
               _loc3_ = this.§_-C20§.verticalScrollPosition + _loc2_;
               this.§_-C20§.verticalScrollPosition = _loc3_;
            }
         }
         super.height = param1;
      }
      
      protected function §_-o1t§() : void
      {
         throw new Error("Must be overrided in child class");
      }
      
      protected function §_-w1T§() : Class
      {
         throw new Error("Must be overrided in child class");
      }
      
      public function §_-t2Y§(param1:Object, param2:String, param3:int = -1) : void
      {
         var _loc4_:§_-91F§ = this.§_-a2u§(param2);
         if(param3 == -1)
         {
            _loc4_.listCollection.addItem(param1);
         }
         else
         {
            _loc4_.listCollection.addItemAt(param1,param3);
         }
         this.§_-th§(param2);
      }
      
      public function §_-th§(param1:String) : void
      {
         if(param1 == this.§_-OC§)
         {
            if(this.§_-m18§)
            {
               this.§_-v1d§();
            }
         }
      }
      
      private function §_-v1d§() : void
      {
         if(!this.§_-C20§.isEnabled)
         {
            return;
         }
         if(this.§_-C20§.isScrolling)
         {
            return;
         }
         try
         {
            if(!this.§_-d2H§)
            {
               this.§_-C20§.validate();
               this.§_-C20§.scrollToPosition(0,this.§_-C20§.maxVerticalScrollPosition,0);
            }
         }
         catch(e:Error)
         {
         }
      }
      
      public function §_-tL§(param1:Object, param2:String) : void
      {
         var _loc3_:§_-91F§ = this.§_-a2u§(param2);
         _loc3_.listCollection.removeItem(param1);
         if(param2 == this.§_-OC§)
         {
            this.§_-v1d§();
         }
      }
      
      public function §_-e1S§(param1:String, param2:Array) : void
      {
         var _loc3_:§_-91F§ = this.§_-a2u§(this.§_-OC§);
         _loc3_.listCollection.removeAll();
         _loc3_.listCollection.data = param2;
         if(param1 == this.§_-OC§)
         {
            this.§_-v1d§();
         }
      }
      
      public function §_-C2Q§(param1:String, param2:Array) : void
      {
         var _loc3_:§_-91F§ = this.§_-a2u§(this.§_-OC§);
         var _loc4_:int = int(param2.length);
         var _loc5_:int = _loc3_.listCollection.length;
         var _loc6_:IListCollection = _loc3_.listCollection;
         if(_loc5_ > _loc4_)
         {
            _loc6_.removeAll();
            _loc5_ = 0;
         }
         var _loc7_:int = 0;
         while(_loc7_ < _loc4_)
         {
            if(_loc7_ < _loc5_)
            {
               _loc6_.setItemAt(param2[_loc7_],_loc7_);
            }
            else
            {
               _loc6_.addItem(param2[_loc7_]);
            }
            _loc7_++;
         }
         if(param1 == this.§_-OC§)
         {
            this.§_-v1d§();
         }
      }
      
      public function §_-j1A§(param1:String) : void
      {
         if(this.§_-OC§ != param1)
         {
            this.§_-OC§ = param1;
            this.§_-C20§.dataProvider = this.§_-B2S§[this.§_-OC§].listCollection;
            this.§_-v1d§();
         }
      }
      
      public function §_-Px§() : String
      {
         return this.§_-OC§;
      }
      
      private function §_-a2u§(param1:String) : §_-91F§
      {
         return this.§_-B2S§[param1] as §_-91F§;
      }
   }
}


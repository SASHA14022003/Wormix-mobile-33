package §_-5Y§
{
   import §_-S§.*;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-ZP§.§_-H1H§;
   import §_-zI§.§_-8D§;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.social.§_-N1V§;
   
   public class §_-t2O§
   {
      
      public static const SEND_MESSAGE:String = "SEND_MESSAGE";
      
      public static const SEND_STICKER:String = "SEND_STICKER";
      
      public static const TOGGLE_STICKERS_PANEL:String = "TOGGLE_STICKERS_PANEL";
      
      public function §_-t2O§()
      {
         super();
      }
   }
}


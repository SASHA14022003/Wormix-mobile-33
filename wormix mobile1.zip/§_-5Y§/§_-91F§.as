package §_-5Y§
{
   import §_-Vg§.ClanSearchView;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-j1w§.§_-B2i§;
   import §_-zI§.§_-F3q§;
   import feathers.data.ListCollection;
   import flash.errors.IllegalOperationError;
   import ru.pragmatix.wormix.objects.§_-01J§;
   
   public class §_-91F§
   {
      
      public var listCollection:ListCollection = new ListCollection();
      
      public function §_-91F§()
      {
         super();
      }
   }
}


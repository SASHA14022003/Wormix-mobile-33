package §_-5Y§
{
   import §_-73d§.§_-V19§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-D3A§.§_-TZ§;
   import §_-Y1O§.*;
   import §_-j1w§.§_-B2i§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderStatus;
   import feathers.controls.LayoutGroup;
   import feathers.events.FeathersEventType;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.ProgressEvent;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.messages.server.RepeatPvpBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.AmmoPhysicModel;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.events.Event;
   
   public class §_-81g§
   {
      
      private var §_-7s§:Boolean = false;
      
      private var §_-h1C§:Boolean = false;
      
      private var §_-x1k§:LayoutGroup;
      
      private var §_-Zn§:StickerPanel;
      
      public function §_-81g§(param1:LayoutGroup, param2:StickerPanel)
      {
         super();
         this.§_-x1k§ = param1;
         this.§_-Zn§ = param2;
         this.§_-Zn§.visible = false;
         param1.addEventListener(§_-t2O§.TOGGLE_STICKERS_PANEL,this.§_-e12§);
         param1.addEventListener(FeathersEventType.FOCUS_IN,this.§_-q2y§);
      }
      
      public function dispose() : void
      {
         this.§_-x1k§.removeEventListener(§_-t2O§.TOGGLE_STICKERS_PANEL,this.§_-e12§);
         this.§_-x1k§.removeEventListener(FeathersEventType.FOCUS_IN,this.§_-q2y§);
         Starling.juggler.removeTweens(StickerPanel);
      }
      
      private function §_-e12§(param1:starling.events.Event) : void
      {
         this.§_-Zn§.visible = true;
         if(!this.§_-7s§)
         {
            this.changeState();
         }
      }
      
      private function §_-q2y§(param1:starling.events.Event) : void
      {
         if(!this.§_-7s§ && this.§_-h1C§)
         {
            this.changeState();
         }
      }
      
      private function changeState() : void
      {
         this.§_-h1C§ = !this.§_-h1C§;
         var _loc1_:Number = this.§_-h1C§ ? this.§_-Zn§.§_-yu§() : 0;
         this.§_-7s§ = true;
         Starling.juggler.removeTweens(this.§_-Zn§);
         var _loc2_:Tween = new Tween(this.§_-Zn§,0.2);
         _loc2_.animate("height",_loc1_);
         _loc2_.onComplete = this.refreshState;
         Starling.juggler.add(_loc2_);
      }
      
      private function refreshState() : void
      {
         this.§_-7s§ = false;
         Starling.juggler.removeTweens(StickerPanel);
         this.§_-Zn§.visible = this.§_-h1C§;
      }
   }
}


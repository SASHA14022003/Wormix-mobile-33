package §_-5Y§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-a3§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-C3f§.§_-Z1Y§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-P2i§.§_-G3J§;
   import §_-k1u§.§_-52D§;
   import §_-m2s§.§_-R11§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.display.Display;
   import com.distriqt.extension.application.display.DisplayCutout;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.ToggleButton;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import feathers.utils.textures.TextureCache;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.ExpelFromClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.clans.structures.*;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   import starlingbuilder.engine.UIBuilder;
   
   public class StickerPanel extends LayoutGroup
   {
      
      private var container:LayoutGroup;
      
      private var binder:Binder;
      
      private var §_-A2a§:Button;
      
      private var textureCache:TextureCache;
      
      private var §_-5u§:Boolean = true;
      
      private var availableStickersListCollection:ListCollection;
      
      private var §_-Z2x§:Number;
      
      private var §_-h2M§:§_-52D§;
      
      public function StickerPanel(param1:TextureCache, param2:Number = 2)
      {
         super();
         this.textureCache = param1;
         this.§_-Z2x§ = param2;
         this.§_-h2M§ = Application.userProfile.§_-p2c§();
         this.availableStickersListCollection = new ListCollection(this.§_-h2M§.§_-C11§());
         this.§_-h2M§.addEventListener(Event.CHANGE,this.§_-Q1n§);
      }
      
      override protected function initialize() : void
      {
         var uiBuilder:UIBuilder;
         var am:AssetManager;
         var clip:LayoutGroup;
         var listCollection:ListCollection;
         var anchorLayoutData:AnchorLayoutData = null;
         var stickerPack:§_-a3§ = null;
         var listLayout:HorizontalLayout = null;
         super.initialize();
         this._layout = new AnchorLayout();
         this.container = new LayoutGroup();
         addChild(this.container);
         this.container.layout = new AnchorLayout();
         anchorLayoutData = new AnchorLayoutData();
         anchorLayoutData.percentWidth = 100;
         this.container.layoutData = anchorLayoutData;
         this.binder = new Binder();
         uiBuilder = Application.uiBuilder;
         am = Application.assetManager;
         clip = uiBuilder.create(am.getObject("chat_sticker_panel"),false,this.binder).getChildAt(0) as LayoutGroup;
         this.container.addChild(this.binder._container);
         anchorLayoutData = new AnchorLayoutData(0,0,0,0);
         clip.layoutData = anchorLayoutData;
         anchorLayoutData = new AnchorLayoutData(5,5,5,5);
         anchorLayoutData.topAnchorDisplayObject = this.binder._buyContainer;
         this.binder._stickersList.layoutData = anchorLayoutData;
         this.binder._stickersList.customHorizontalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         this.binder._tabBar.tabInitializer = function(param1:ToggleButton, param2:Object):void
         {
            var _loc3_:ImageLoader = new ImageLoader();
            _loc3_.scaleContent = true;
            _loc3_.maintainAspectRatio = true;
            _loc3_.width = 100;
            _loc3_.height = 50;
            _loc3_.source = (param2.pack as §_-a3§).§_-oz§();
            _loc3_.textureCache = textureCache;
            var _loc4_:Boolean = availableStickersListCollection.getItemIndex(param2.pack.getId()) != -1;
            if(_loc4_)
            {
               §_-MN§.§_-6G§(_loc3_);
            }
            else
            {
               §_-MN§.§_-lM§(_loc3_,false);
            }
            param1.defaultIcon = _loc3_;
         };
         listCollection = new ListCollection();
         for each(stickerPack in §_-G1p§.§_-M1n§())
         {
            listCollection.addItem({
               "label":"",
               "pack":stickerPack
            });
         }
         this.binder._tabBar.dataProvider = listCollection;
         this.binder._tabBar.distributeTabSizes = false;
         this.binder._tabBar.gap = 5;
         this.binder._tabBar.addEventListener(Event.CHANGE,this.§_-L1v§);
         listLayout = new HorizontalLayout();
         listLayout.gap = 10;
         listLayout.horizontalAlign = HorizontalAlign.LEFT;
         listLayout.verticalAlign = VerticalAlign.MIDDLE;
         listLayout.useVirtualLayout = true;
         this.binder._stickersList.layout = listLayout;
         this.binder._stickersList.verticalScrollPolicy = ScrollPolicy.OFF;
         this.binder._stickersList.dataProvider = listCollection;
         this.binder._stickersList.itemRendererProperties.iconSourceField = "iconPath";
         this.binder._stickersList.itemRendererProperties.width = 160;
         this.binder._stickersList.itemRendererProperties.height = 125;
         this.binder._stickersList.dataProvider = new ListCollection();
         this.binder._stickersList.itemRendererFactory = function():IListItemRenderer
         {
            var _loc1_:DefaultListItemRenderer = new DefaultListItemRenderer();
            var _loc2_:ImageLoader = new ImageLoader();
            _loc2_.width = 160;
            _loc2_.height = 125;
            _loc2_.scaleContent = false;
            _loc2_.scaleMode = ScaleMode.SHOW_ALL;
            _loc2_.maintainAspectRatio = true;
            _loc2_.delayTextureCreation = true;
            _loc2_.textureCache = textureCache;
            _loc1_.defaultIcon = _loc2_;
            return _loc1_;
         };
         this.binder._stickersList.addEventListener(FeathersEventType.RENDERER_ADD,this.§_-11o§);
         this.binder._stickersList.addEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-Q1i§);
         this.binder._listPanel.width = Starling.current.stage.stageWidth;
         this.§_-A2a§ = §_-YQ§.§_-L1A§("RealMoneyButton") as Button;
         this.§_-A2a§.addEventListener(Event.TRIGGERED,this.§_-h1d§);
         this.binder._buyContainer.addChild(this.§_-A2a§);
         this.binder._buyContainer.width = NaN;
         this.§_-L1v§();
      }
      
      private function §_-11o§(param1:Event) : void
      {
         (param1.data as DefaultListItemRenderer).addEventListener(Event.TRIGGERED,this.§_-12e§);
      }
      
      private function §_-Q1i§(param1:Event) : void
      {
         (param1.data as DefaultListItemRenderer).removeEventListener(Event.TRIGGERED,this.§_-12e§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-A2a§.removeEventListener(Event.TRIGGERED,this.§_-h1d§);
         this.§_-h2M§.removeEventListener(Event.CHANGE,this.§_-Q1n§);
         this.binder._tabBar.removeEventListener(Event.CHANGE,this.§_-L1v§);
         this.binder._stickersList.removeEventListener(FeathersEventType.RENDERER_ADD,this.§_-11o§);
         this.binder._stickersList.removeEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-Q1i§);
      }
      
      private function §_-L1v§(param1:Event = null) : void
      {
         var _loc2_:§_-a3§ = null;
         var _loc3_:Boolean = false;
         var _loc4_:Boolean = false;
         var _loc5_:PaymentOption = null;
         if(param1)
         {
            §_-h2B§.play(§_-81L§.§_-o1Z§);
         }
         if(Boolean(this.binder._tabBar.selectedItem) && Boolean(this.binder._tabBar.selectedItem.hasOwnProperty("pack")))
         {
            this.binder._stickersList.scrollToPosition(0,0);
            _loc2_ = this.binder._tabBar.selectedItem.pack as §_-a3§;
            _loc3_ = this.availableStickersListCollection.getItemIndex(_loc2_.getId()) != -1;
            _loc4_ = this.§_-h2M§.§_-O29§().indexOf(_loc2_.getId()) != -1;
            (this.binder._stickersList.dataProvider as ListCollection).data = _loc2_.§_-H3c§();
            if(!_loc4_)
            {
               _loc5_ = §_-N1V§.§_-42k§.§_-L2T§(_loc2_.productId);
               this.§_-A2a§.label = _loc5_.price + " " + §_-N1V§.§_-42k§.§_-71P§();
               this.binder._buyContainer.addChild(this.§_-A2a§);
            }
            else
            {
               this.§_-A2a§.removeFromParent();
            }
            this.§_-13f§(_loc3_ && this.§_-5u§);
         }
      }
      
      private function §_-13f§(param1:Boolean) : void
      {
         if(!param1)
         {
            §_-MN§.§_-lM§(this.binder._stickersList,false);
         }
         else
         {
            §_-MN§.§_-6G§(this.binder._stickersList);
         }
      }
      
      private function §_-h1d§(param1:Event) : void
      {
         var _loc2_:§_-a3§ = null;
         if(this.binder._tabBar.selectedItem)
         {
            §_-h2B§.play(§_-81L§.§_-o1Z§);
            _loc2_ = this.binder._tabBar.selectedItem.pack as §_-a3§;
            if(_loc2_)
            {
               §_-N1V§.§_-42k§.§_-F1I§(_loc2_.productId);
            }
         }
      }
      
      private function §_-12e§(param1:Event) : void
      {
         var _loc3_:§_-a3§ = null;
         var _loc2_:Object = (param1.target as DefaultListItemRenderer).data;
         if(Boolean(_loc2_) && this.§_-5u§)
         {
            _loc3_ = this.binder._tabBar.selectedItem.pack as §_-a3§;
            if(this.availableStickersListCollection.getItemIndex(_loc3_.getId()) != -1)
            {
               §_-h2B§.play(§_-81L§.§_-o1Z§);
               dispatchEventWith(§_-t2O§.SEND_STICKER,true,§_-R11§.§_-8E§(_loc3_.getId(),_loc2_.id));
               this.§_-5u§ = false;
               Starling.juggler.delayCall(this.§_-82r§,this.§_-Z2x§);
               this.§_-13f§(this.§_-5u§);
            }
         }
      }
      
      private function §_-82r§() : void
      {
         var _loc1_:§_-a3§ = null;
         this.§_-5u§ = true;
         if(this.binder._tabBar.selectedItem)
         {
            _loc1_ = this.binder._tabBar.selectedItem.pack as §_-a3§;
            if(this.availableStickersListCollection.getItemIndex(_loc1_.getId()) != -1)
            {
               this.§_-13f§(this.§_-5u§);
            }
         }
      }
      
      private function §_-Q1n§(param1:Event) : void
      {
         if(this.binder._tabBar)
         {
            this.availableStickersListCollection.data = param1.data;
            this.binder._tabBar.invalidate(INVALIDATION_FLAG_DATA);
            SystemUtil.executeWhenApplicationIsActive(this.§_-L1v§);
         }
      }
      
      public function §_-yu§() : Number
      {
         return this.container.height;
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.TabBar;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _listPanel:LayoutGroup;
   
   public var _buyContainer:LayoutGroup;
   
   public var _tabBar:TabBar;
   
   public var _stickersList:List;
   
   public var _templateBtn:ContainerButtonWithStates;
   
   public function Binder()
   {
      super();
   }
}

package §_-5Y§
{
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-Y1b§.§_-jH§;
   import §_-b1R§.§_-Bx§;
   import §_-k1u§.§_-Oi§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Color;
   
   public class §_-Ma§ extends DefaultListItemRenderer
   {
      
      public static const §_-UX§:int = 4;
      
      private var bg:Sprite;
      
      public function §_-Ma§()
      {
         super();
         isQuickHitAreaEnabled = true;
         itemHasLabel = false;
         itemHasIcon = false;
         itemHasAccessory = false;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         iconPosition = RelativePosition.BOTTOM;
         accessoryPosition = RelativePosition.BOTTOM;
         this.horizontalAlign = HorizontalAlign.LEFT;
         this.verticalAlign = VerticalAlign.MIDDLE;
         paddingTop = §_-UX§ * 2;
         paddingBottom = §_-UX§ * 2;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(_owner))
         {
            this.resize();
         }
      }
      
      protected function resize() : void
      {
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      public function §_-K3t§() : String
      {
         var _loc1_:ChatMessage = _data as ChatMessage;
         return _loc1_ ? _loc1_.message : null;
      }
      
      public function §_-R2w§(param1:Boolean) : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Error type: IndexOutOfBoundsException (Index -1 out of bounds for length 0)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      protected function get highlightBgColor() : uint
      {
         return Color.GRAY;
      }
   }
}


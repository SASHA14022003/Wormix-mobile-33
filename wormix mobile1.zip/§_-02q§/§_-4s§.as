package §_-02q§
{
   import §_-03T§.§_-2p§;
   import §_-12W§.*;
   import §_-12a§.§_-lc§;
   import §_-21p§.§_-4w§;
   import §_-2U§.Alchemist;
   import §_-2U§.AncientGhost;
   import §_-2U§.Archbot;
   import §_-2U§.Assassin;
   import §_-2U§.DarkKnight;
   import §_-2U§.Emperor;
   import §_-2U§.Engineer;
   import §_-2U§.Scientist;
   import §_-2U§.Symbiote;
   import §_-2U§.Yakuza;
   import §_-2U§.§_-217§;
   import §_-2U§.§_-cH§;
   import §_-2U§.§_-d1J§;
   import §_-2U§.§_-t2u§;
   import §_-52L§.§_-u2x§;
   import §_-5P§.§_-52y§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-ou§;
   import §_-62§.§_-zF§;
   import §_-63U§.SafetyArea;
   import §_-73I§.§_-q15§;
   import §_-82a§.*;
   import §_-91A§.*;
   import §_-91B§.§_-z2l§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.Cookie;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E29§.*;
   import §_-F39§.§_-i1i§;
   import §_-G16§.§_-33h§;
   import §_-G2H§.*;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-P1z§.*;
   import §_-R2S§.Farmer;
   import §_-R2S§.Hunter;
   import §_-R2S§.Maniacs;
   import §_-R2S§.Miner;
   import §_-R2S§.Sergeant;
   import §_-R2S§.§_-M2x§;
   import §_-R2S§.§_-P1U§;
   import §_-R2S§.§_-z2x§;
   import §_-RE§.*;
   import §_-T1t§.§_-P1F§;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-U16§;
   import §_-Ub§.Vikings;
   import §_-Ub§.VoodooShaman;
   import §_-Ub§.WindMaster;
   import §_-Ub§.§_-W1E§;
   import §_-Ub§.§_-v1t§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-fo§.§_-21L§;
   import §_-fo§.§_-r5§;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.*;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-e1k§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-n1w§.*;
   import §_-p14§.§_-A3Y§;
   import §_-qH§.§_-AC§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-U2p§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-u1T§.§_-33B§;
   import §_-u2J§.§_-T1K§;
   import §_-v2t§.§_-73F§;
   import §_-y1s§.§_-P9§;
   import §_-z1g§.§_-y1S§;
   import §_-z20§.§_-I3q§;
   import §_-z20§.§_-pl§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.distriqt.extension.pushnotifications.events.AuthorisationEvent;
   import com.greensock.events.TweenEvent;
   import com.hurlant.math.*;
   import com.hurlant.util.der.§_-p1B§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.Label;
   import feathers.controls.NumericStepper;
   import feathers.controls.Panel;
   import feathers.controls.ProgressBar;
   import feathers.controls.ToggleButton;
   import feathers.core.ITextRenderer;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.events.MouseEvent;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.system.ApplicationDomain;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.gui.controls.§_-yf§;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-P1h§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.client.PumpReactionRate;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import ru.pragmatix.wormix.utils.§_-t2B§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import ru.pragmatix.wormix.weapons.ammo.cloud.GasCloud;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   
   public class §_-4s§
   {
      
      public function §_-4s§()
      {
         super();
      }
      
      public static function §_-Se§(param1:flash.display.DisplayObject, param2:Number) : void
      {
         param1.y = param2 - param1.height;
      }
      
      public static function §_-YU§(param1:flash.display.DisplayObject) : void
      {
         §_-J3S§(param1,§_-81L§.stageWidth,§_-81L§.stageHeight);
      }
      
      public static function §_-A1Z§(param1:§_-yf§) : void
      {
         §_-P28§(param1,§_-81L§.stageWidth,§_-81L§.stageHeight);
      }
      
      public static function §_-k1B§(param1:flash.display.DisplayObject) : void
      {
         §_-J3S§(param1,param1.parent.width,param1.parent.height);
      }
      
      public static function §_-yp§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject) : void
      {
         §_-p2m§(param1,param2);
         §_-am§(param1,param2);
      }
      
      public static function centerY(param1:flash.display.DisplayObject, param2:Number, param3:Number) : void
      {
         param1.y = (param2 + param3 - param1.height) / 2;
      }
      
      public static function centerX(param1:flash.display.DisplayObject, param2:Number, param3:Number) : void
      {
         param1.x = (param2 + param3 - param1.width) / 2;
      }
      
      public static function §_-l15§(param1:flash.display.DisplayObject) : void
      {
         centerX(param1,0,param1.parent.width);
      }
      
      public static function §_-r17§(param1:§_-yf§) : void
      {
         §_-l15§(param1.getContainer());
      }
      
      public static function §_-p2m§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject) : void
      {
         centerX(param1,param2.x,param2.x + param2.width);
      }
      
      public static function §_-am§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject) : void
      {
         centerY(param1,param2.y,param2.y + param2.height);
      }
      
      public static function §_-72e§(param1:§_-yf§, param2:Number, param3:Number) : void
      {
         param1.x = (param2 + param3 - param1.width) / 2;
      }
      
      public static function §_-JK§(param1:flash.display.DisplayObject, param2:Number, param3:Number, param4:Number, param5:Number) : void
      {
         centerX(param1,param2,param4);
         centerY(param1,param3,param5);
      }
      
      private static function §_-J3S§(param1:flash.display.DisplayObject, param2:Number, param3:Number) : void
      {
         param1.x = (param2 - param1.width) / 2;
         param1.y = (param3 - param1.height) / 2;
      }
      
      private static function §_-P28§(param1:§_-yf§, param2:Number, param3:Number) : void
      {
         param1.x = (param2 - param1.width) / 2;
         param1.y = (param3 - param1.height) / 2;
      }
      
      public static function §_-1a§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject, param3:Number = 0) : void
      {
         param1.x = param2.x - param1.width - param3;
      }
      
      public static function §_-42m§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject, param3:Number = 0) : void
      {
         param1.x = param2.x + param2.width + param3;
      }
      
      public static function §_-cI§(param1:§_-yf§, param2:flash.display.DisplayObject, param3:Number = 0) : void
      {
         param1.x = param2.x + param2.width + param3;
      }
      
      public static function §_-w2M§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject, param3:Number = 0) : void
      {
         param1.y = param2.y - param1.height - param3;
      }
      
      public static function §_-i2S§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject, param3:Number = 0) : void
      {
         param1.y = param2.y + param2.height + param3;
      }
      
      public static function §_-O4§(param1:§_-yf§, param2:flash.display.DisplayObject, param3:Number = 0) : void
      {
         param1.y = param2.y + param2.height + param3;
      }
      
      public static function §_-Wx§(param1:flash.display.DisplayObject, param2:Number, param3:Number) : Number
      {
         var _loc4_:Number = param2 / param1.width;
         var _loc5_:Number = param3 / param1.height;
         return Math.min(_loc4_,_loc5_);
      }
      
      public static function §_-v2D§(param1:flash.display.DisplayObject, param2:Number, param3:Number) : Number
      {
         var _loc4_:Number = param2 / param1.width;
         var _loc5_:Number = param3 / param1.height;
         return Math.max(_loc4_,_loc5_);
      }
      
      public static function §_-Y2L§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject) : void
      {
         §_-F21§(param1,param2.width,param2.height);
      }
      
      public static function §_-2w§(param1:flash.display.DisplayObject, param2:flash.display.DisplayObject) : void
      {
         §_-p1n§(param1,param2.width,param2.height);
      }
      
      public static function §_-F21§(param1:flash.display.DisplayObject, param2:Number, param3:Number) : void
      {
         var _loc4_:Number = §_-Wx§(param1,param2,param3);
         param1.width *= _loc4_;
         param1.height *= _loc4_;
      }
      
      public static function §_-p1n§(param1:flash.display.DisplayObject, param2:Number, param3:Number) : void
      {
         var _loc4_:Number = §_-v2D§(param1,param2,param3);
         param1.width *= _loc4_;
         param1.height *= _loc4_;
      }
      
      public static function getChildByName(param1:flash.display.DisplayObjectContainer, param2:String) : flash.display.DisplayObject
      {
         var _loc4_:Number = NaN;
         var _loc5_:String = null;
         var _loc3_:flash.display.DisplayObjectContainer = param1;
         while(true)
         {
            _loc4_ = Number(param2.indexOf("."));
            if(_loc4_ == -1)
            {
               break;
            }
            _loc5_ = param2.substr(0,_loc4_);
            param2 = param2.substr(_loc4_ + 1);
            _loc3_ = _loc3_.getChildByName(_loc5_) as flash.display.DisplayObjectContainer;
         }
         return _loc3_.getChildByName(param2);
      }
      
      public static function §_-2P§(param1:flash.display.DisplayObjectContainer, param2:String) : flash.text.TextField
      {
         return §_-4s§.getChildByName(param1,param2) as flash.text.TextField;
      }
   }
}


package §_-02q§
{
   import §_-23P§.§_-u1z§;
   import §_-931§.§_-02O§;
   import §_-931§.§_-i2r§;
   import §_-A2F§.§_-4B§;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-S1N§.§_-zk§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-dS§.§_-D3a§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Zd§;
   import dragonBones.animation.WorldClock;
   import feathers.core.ITextRenderer;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.controller.ISocialPaymentController;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import ru.pragmatix.wormix.weapons.ammo.type.shuriken.Shuriken;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.textures.TextureSmoothing;
   import starling.utils.ScaleMode;
   
   public class §_-11O§
   {
      
      public function §_-11O§()
      {
         super();
      }
      
      public static function §_-S1U§(param1:§_-zk§, param2:§_-02O§) : void
      {
         if(Boolean(param1) && Boolean(param2))
         {
            if(param2.text)
            {
               param1.setText(param2.text);
            }
            else if(param2.stringId)
            {
               param1.§_-r1M§(param2.stringId);
            }
            else if(param2.template)
            {
               param1.§_-iq§(param2.template,param2.§_-73o§);
            }
         }
      }
      
      public static function §_-JO§(param1:§_-i2r§, param2:§_-02O§) : void
      {
         if(Boolean(param1) && Boolean(param2))
         {
            if(param2.text)
            {
               param1.setText(param2.text);
            }
            else if(param2.stringId)
            {
               param1.setStringID(param2.stringId);
            }
            else if(param2.template)
            {
               param1.setTemplate(param2.template,param2.§_-73o§);
            }
            if(param2.format)
            {
               param1.setFormat(param2.format);
            }
         }
      }
      
      public static function §_-U27§(param1:§_-02O§) : Boolean
      {
         return Boolean(param1.text) || Boolean(param1.stringId) || Boolean(param1.template);
      }
   }
}


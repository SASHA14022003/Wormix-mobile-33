package §_-02q§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.*;
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-73I§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-DJ§.§_-j15§;
   import §_-H2g§.§_-di§;
   import §_-P1z§.*;
   import §_-SP§.§_-M4§;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-Zi§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-aM§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-m2s§.§_-R11§;
   import §_-r1C§.§_-t1R§;
   import §_-s20§.§_-J2g§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.SimpleScrollBar;
   import feathers.layout.Direction;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getQualifiedClassName;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.flox.gui.controls.§_-a1t§;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-U2a§
   {
      
      private static var §_-Q1W§:Object = {};
      
      private static var count:int = 0;
      
      public static var §_-3n§:Boolean = false;
      
      public function §_-U2a§()
      {
         super();
      }
      
      public static function created(param1:§_-a1t§) : void
      {
         var _loc2_:String = null;
         if(§_-3n§)
         {
            _loc2_ = getId(param1);
            if(§_-Q1W§[_loc2_])
            {
               ++§_-Q1W§[_loc2_];
            }
            else
            {
               §_-Q1W§[_loc2_] = 1;
            }
            ++count;
         }
      }
      
      public static function §_-R22§(param1:§_-a1t§) : void
      {
         var _loc2_:String = null;
         if(§_-3n§)
         {
            _loc2_ = getId(param1);
            if(Boolean(§_-Q1W§[_loc2_]) && §_-Q1W§[_loc2_] > 1)
            {
               --§_-Q1W§[_loc2_];
            }
            else
            {
               delete §_-Q1W§[_loc2_];
            }
            --count;
         }
      }
      
      public static function getCount() : int
      {
         return count;
      }
      
      public static function §_-n1V§() : void
      {
         var _loc1_:String = null;
         for(_loc1_ in §_-Q1W§)
         {
            trace(_loc1_ + " = " + §_-Q1W§[_loc1_]);
         }
      }
      
      private static function getId(param1:§_-a1t§) : String
      {
         return getQualifiedClassName(param1) + "->" + param1.id;
      }
   }
}


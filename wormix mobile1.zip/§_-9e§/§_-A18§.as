package §_-9e§
{
   public class §_-A18§
   {
      
      public static const §_-J24§:§_-A18§ = new §_-A18§();
      
      public static const PVP:§_-A18§ = new §_-A18§(20,7,-1);
      
      public var §_-C1V§:uint = 0;
      
      public var §_-8n§:int = -1;
      
      public var §_-f2A§:int = -1;
      
      public function §_-A18§(param1:uint = 0, param2:int = -1, param3:int = -1)
      {
         super();
         this.§_-C1V§ = param1;
         this.§_-8n§ = param2;
         this.§_-f2A§ = param3;
      }
      
      public function copy() : §_-A18§
      {
         return new §_-A18§(this.§_-C1V§,this.§_-8n§,this.§_-f2A§);
      }
   }
}


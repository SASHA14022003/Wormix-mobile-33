package §_-9e§
{
   import §_-v2t§.§_-43O§;
   import §_-v2t§.§_-73F§;
   import §_-v2t§.§_-v1K§;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.social.§_-N1V§;
   
   public class §_-73e§
   {
      
      private static var §_-J1I§:§_-73e§;
      
      private static var §_-n1L§:§_-73e§;
      
      private static var §_-P2g§:§_-73e§;
      
      public var §_-nA§:Boolean = false;
      
      public var §_-z2U§:Boolean = false;
      
      public var §_-v17§:Boolean = false;
      
      public var timer:§_-8O§ = §_-8O§.DEFAULT;
      
      public var online:Boolean = false;
      
      public var achievements:Boolean = false;
      
      public var backpackEnabled:Boolean = true;
      
      public var water:§_-A18§ = §_-A18§.§_-J24§;
      
      public var §_-b2i§:§_-v1K§;
      
      public var §_-f2m§:Boolean = false;
      
      public var §_-724§:Boolean = false;
      
      public var §_-32V§:Boolean = true;
      
      public var §_-93U§:Boolean = false;
      
      public var §_-G1u§:Boolean = false;
      
      public var §_-52M§:Boolean = true;
      
      public var §_-31H§:Vector.<WeaponStructure> = new Vector.<WeaponStructure>(0);
      
      public var §_-z1z§:uint = 40;
      
      public function §_-73e§()
      {
         super();
      }
      
      public static function §_-GK§() : §_-73e§
      {
         if(!§_-J1I§)
         {
            §_-J1I§ = new §_-73e§();
            §_-J1I§.online = false;
            §_-J1I§.§_-v17§ = true;
            §_-J1I§.§_-f2m§ = false;
            §_-J1I§.§_-724§ = false;
            §_-J1I§.§_-52M§ = false;
            §_-J1I§.§_-z2U§ = true;
            §_-J1I§.§_-nA§ = false;
            §_-J1I§.timer = §_-8O§.§_-R1M§;
            §_-J1I§.§_-b2i§ = §_-43O§.§_-i1N§;
         }
         return §_-J1I§;
      }
      
      public static function §_-U5§() : §_-73e§
      {
         if(!§_-n1L§)
         {
            §_-n1L§ = new §_-73e§();
            §_-n1L§.online = false;
            §_-n1L§.§_-v17§ = true;
            §_-n1L§.§_-f2m§ = true;
            §_-n1L§.§_-724§ = false;
            §_-n1L§.§_-z2U§ = true;
            §_-n1L§.§_-nA§ = true;
            §_-n1L§.timer = §_-8O§.DEFAULT;
            §_-n1L§.achievements = §_-N1V§.settings.§_-l9§();
            §_-n1L§.§_-b2i§ = §_-43O§.§_-i1N§;
         }
         return §_-n1L§;
      }
      
      public static function §_-G1§(param1:Boolean) : §_-73e§
      {
         if(!§_-P2g§)
         {
            §_-P2g§ = new §_-73e§();
            §_-P2g§.online = true;
            §_-P2g§.§_-v17§ = true;
            §_-P2g§.§_-f2m§ = false;
            §_-P2g§.§_-724§ = true;
            §_-P2g§.§_-z2U§ = true;
            §_-P2g§.§_-nA§ = false;
            §_-P2g§.§_-G1u§ = true;
            §_-P2g§.timer = §_-8O§.PVP;
            §_-P2g§.water = §_-A18§.PVP;
            §_-P2g§.§_-b2i§ = §_-73F§.§_-i1N§;
         }
         §_-P2g§.achievements = §_-N1V§.settings.§_-l9§() && param1;
         return §_-P2g§;
      }
      
      public static function §_-1y§() : §_-73e§
      {
         var _loc1_:§_-73e§ = new §_-73e§();
         _loc1_.online = false;
         _loc1_.§_-v17§ = false;
         _loc1_.§_-f2m§ = false;
         _loc1_.§_-724§ = false;
         _loc1_.§_-z2U§ = false;
         _loc1_.§_-nA§ = false;
         _loc1_.achievements = §_-N1V§.settings.§_-l9§();
         _loc1_.water = §_-A18§.§_-J24§;
         _loc1_.timer = §_-8O§.DEFAULT;
         _loc1_.§_-b2i§ = §_-43O§.§_-i1N§;
         _loc1_.§_-32V§ = false;
         return _loc1_;
      }
      
      public static function §_-l2s§(param1:§_-73e§, param2:§_-73e§) : void
      {
         var _loc3_:§_-73e§ = §_-1y§();
         if(param2.online != _loc3_.online)
         {
            param1.online = param2.online;
         }
         if(param2.§_-v17§ != _loc3_.§_-v17§)
         {
            param1.§_-v17§ = param2.§_-v17§;
         }
         if(param2.§_-f2m§ != _loc3_.§_-f2m§)
         {
            param1.§_-f2m§ = param2.§_-f2m§;
         }
         if(param2.§_-724§ != _loc3_.§_-724§)
         {
            param1.§_-724§ = param2.§_-724§;
         }
         if(param2.§_-z2U§ != _loc3_.§_-z2U§)
         {
            param1.§_-z2U§ = param2.§_-z2U§;
         }
         if(param2.§_-nA§ != _loc3_.§_-nA§)
         {
            param1.§_-nA§ = param2.§_-nA§;
         }
         if(param2.achievements != _loc3_.achievements)
         {
            param1.achievements = param2.achievements;
         }
         if(param2.water != _loc3_.water)
         {
            param1.water = param2.water;
         }
         if(param2.timer != _loc3_.timer)
         {
            param1.timer = param2.timer;
         }
         if(param2.§_-b2i§ != _loc3_.§_-b2i§)
         {
            param1.§_-b2i§ = param2.§_-b2i§;
         }
         if(param2.§_-32V§ != _loc3_.§_-32V§)
         {
            param1.§_-32V§ = param2.§_-32V§;
         }
      }
      
      public static function §_-H2v§(param1:§_-73e§) : void
      {
         param1.online = true;
         param1.§_-b2i§ = §_-73F§.§_-i1N§;
         param1.§_-93U§ = true;
      }
   }
}


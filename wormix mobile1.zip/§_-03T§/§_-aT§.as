package §_-03T§
{
   import flash.events.IEventDispatcher;
   
   public interface §_-aT§ extends IEventDispatcher
   {
      
      function destroy() : void;
   }
}


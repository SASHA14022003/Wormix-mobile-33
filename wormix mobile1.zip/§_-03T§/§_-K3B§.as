package §_-03T§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-52L§.§_-u2x§;
   import §_-73I§.§_-K2s§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.*;
   import §_-B2z§.§_-82u§;
   import §_-H2g§.§_-di§;
   import §_-Yk§.§_-Dh§;
   import §_-Yk§.§_-m2w§;
   import §_-aM§.*;
   import §_-b1F§.§_-H3Z§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-w2i§.§_-Zd§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import flash.display.Shape;
   import flash.errors.IllegalOperationError;
   import flash.events.EventDispatcher;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.server.AchieveLoginError;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.scene.ObjectType;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-K3B§ extends EventDispatcher implements §_-aT§
   {
      
      private var handlers:Object = {};
      
      public function §_-K3B§()
      {
         super();
      }
      
      override public function removeEventListener(param1:String, param2:Function, param3:Boolean = false) : void
      {
         §_-ts§.remove(this.§_-m1W§(param1),param2);
         super.removeEventListener(param1,param2,param3);
      }
      
      override public function addEventListener(param1:String, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void
      {
         this.§_-m1W§(param1).push(param2);
         super.addEventListener(param1,param2,param3,param4,param5);
      }
      
      public function destroy() : void
      {
         var _loc1_:String = null;
         var _loc2_:Function = null;
         for each(_loc1_ in this.handlers)
         {
            for each(_loc2_ in this.handlers[_loc1_])
            {
               super.removeEventListener(_loc1_,_loc2_);
            }
         }
         this.handlers = {};
      }
      
      private function §_-m1W§(param1:String) : Array
      {
         if(!this.handlers[param1])
         {
            this.handlers[param1] = [];
         }
         return this.handlers[param1];
      }
   }
}


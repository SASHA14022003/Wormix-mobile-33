package §_-03T§
{
   import §_-12W§.*;
   import §_-12a§.§_-E1Q§;
   import §_-12a§.§_-G2l§;
   import §_-51M§.Dragon;
   import §_-82a§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2F§.§_-4B§;
   import §_-B1y§.§_-ts§;
   import §_-C3f§.§_-4I§;
   import §_-C3f§.§_-Z1Y§;
   import §_-D3A§.§_-DI§;
   import §_-DJ§.§_-fH§;
   import §_-P2i§.§_-b7§;
   import §_-RE§.§_-w0§;
   import §_-TF§.§_-y2n§;
   import §_-Vu§.MD5;
   import §_-aM§.*;
   import §_-k1u§.§_-2m§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-lp§;
   import com.greensock.*;
   import com.greensock.core.*;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.layout.VerticalLayout;
   import feathers.layout.VerticalLayoutData;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getQualifiedClassName;
   import org.swiftsuspenders.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.weapons.ammo.type.RopeHook;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.SystemUtil;
   
   public class §_-2p§
   {
      
      private var §_-ES§:Array = [];
      
      private var listeners:Array = [];
      
      public function §_-2p§()
      {
         super();
      }
      
      public function removeEventListener(param1:IEventDispatcher, param2:String, param3:Function, param4:Boolean = false) : void
      {
         var _loc5_:int = int(this.§_-ES§.indexOf(param1));
         if(_loc5_ == -1)
         {
            return;
         }
         var _loc6_:Array = this.listeners[_loc5_];
         if(!_loc6_[param2])
         {
            return;
         }
         §_-ts§.remove(this.listeners[_loc5_][param2],param3);
         if(!this.§_-91C§(_loc5_))
         {
            this.§_-ES§.splice(_loc5_,1);
            this.listeners.splice(_loc5_,1);
         }
         param1.removeEventListener(param2,param3,param4);
      }
      
      private function §_-91C§(param1:int) : Boolean
      {
         var _loc2_:String = null;
         for(_loc2_ in this.listeners[param1])
         {
            if(this.listeners[param1][_loc2_].length > 0)
            {
               return true;
            }
         }
         return false;
      }
      
      public function addEventListener(param1:IEventDispatcher, param2:String, param3:Function, param4:Boolean = false, param5:int = 0, param6:Boolean = false) : void
      {
         this.§_-B3r§(param1,param2).push(param3);
         param1.addEventListener(param2,param3,param4,param5,param6);
      }
      
      public function §_-RY§() : void
      {
         var _loc2_:String = null;
         var _loc3_:Function = null;
         var _loc1_:int = 0;
         while(_loc1_ < this.listeners.length)
         {
            for(_loc2_ in this.listeners[_loc1_])
            {
               for each(_loc3_ in this.listeners[_loc1_][_loc2_])
               {
                  this.§_-ES§[_loc1_].removeEventListener(_loc2_,_loc3_);
               }
            }
            _loc1_++;
         }
         this.listeners = [];
         this.§_-ES§ = [];
      }
      
      public function destroy() : void
      {
         this.§_-RY§();
      }
      
      private function §_-B3r§(param1:IEventDispatcher, param2:String) : Array
      {
         var _loc3_:int = int(this.§_-ES§.indexOf(param1));
         if(_loc3_ == -1)
         {
            _loc3_ = int(this.§_-ES§.length);
            this.§_-ES§[_loc3_] = param1;
            this.listeners[_loc3_] = [];
         }
         var _loc4_:Array = this.listeners[_loc3_];
         if(!_loc4_[param2])
         {
            _loc4_[param2] = [];
         }
         return _loc4_[param2];
      }
   }
}


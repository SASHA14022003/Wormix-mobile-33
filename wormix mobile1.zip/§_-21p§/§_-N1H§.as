package §_-21p§
{
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-Y1l§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-P1z§.*;
   import §_-Y1O§.*;
   import §_-YF§.§_-Zi§;
   import §_-YF§.§_-q2v§;
   import §_-d26§.§_-d1H§;
   import §_-fo§.§_-r5§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-sQ§.§_-H3D§;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import §_-y1s§.§_-O1z§;
   import §_-zI§.§_-X1q§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.text.BitmapFontTextRenderer;
   import feathers.controls.text.CustomTextFieldTextRenderer;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.core.ITextRenderer;
   import feathers.text.BitmapFontTextFormat;
   import flash.geom.Rectangle;
   import flash.text.AntiAliasType;
   import flash.text.GridFitType;
   import flash.text.TextFormat;
   import flash.utils.clearInterval;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.text.BitmapFont;
   import starling.text.TextField;
   
   public class §_-N1H§
   {
      
      public static const RACE:String = "RACE";
      
      public static const HAT:String = "HAT";
      
      public static const OFF_HAND:String = "OFF_HAND";
      
      public static const BOOSTER:String = "BOOSTER";
      
      public static const NONE:String = "NONE";
      
      private var §_-k2§:String;
      
      private var bonuses:Vector.<§_-4w§>;
      
      public function §_-N1H§(param1:String)
      {
         super();
         this.§_-k2§ = param1;
         this.bonuses = new Vector.<§_-4w§>();
      }
      
      public function addItem(param1:§_-4w§) : void
      {
         this.bonuses[this.bonuses.length] = param1;
      }
      
      public function §_-b2I§() : Vector.<§_-4w§>
      {
         return this.bonuses;
      }
      
      public function §_-C3p§() : String
      {
         return this.§_-k2§;
      }
      
      public function §_-yQ§(param1:§_-x2M§) : Boolean
      {
         var _loc2_:§_-4w§ = null;
         for each(_loc2_ in this.bonuses)
         {
            if(_loc2_.getType() == param1)
            {
               return true;
            }
         }
         return false;
      }
      
      public function §_-k2Q§(param1:§_-x2M§) : §_-4w§
      {
         var _loc2_:§_-4w§ = null;
         for each(_loc2_ in this.bonuses)
         {
            if(_loc2_.getType() == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public function §_-F1e§(param1:§_-x2M§) : int
      {
         var _loc2_:§_-4w§ = this.§_-k2Q§(param1);
         return _loc2_ ? _loc2_.getValue() : 0;
      }
   }
}


package §_-21p§
{
   import §_-3D§.§_-E3x§;
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-F1P§;
   import §_-C3f§.*;
   import §_-DJ§.§_-fH§;
   import §_-K3q§.*;
   import §_-L1H§.§_-C3e§;
   import §_-P1z§.*;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.*;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-T2N§;
   import §_-m0§.§_-X1F§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import feathers.themes.FontColor;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.treasury.ChangeClanMedalPriceRequest;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   import starling.textures.Texture;
   import starling.utils.Color;
   
   public class §_-4w§
   {
      
      private var bonus:§_-x2M§;
      
      private var §_-IK§:§_-TA§;
      
      public function §_-4w§(param1:§_-x2M§, param2:int)
      {
         super();
         this.bonus = param1;
         this.§_-IK§ = new §_-TA§(param2);
      }
      
      public function getType() : §_-x2M§
      {
         return this.bonus;
      }
      
      public function getValue() : int
      {
         return this.§_-IK§.value;
      }
      
      public function setValue(param1:int) : void
      {
         this.§_-IK§.value = param1;
      }
      
      public function §_-I2a§(param1:Boolean = false) : String
      {
         var _loc2_:String = this.getValue() >= 0 ? "+" : "";
         return this.bonus.§_-p1§() != "" ? §_-F1P§.format(this.bonus.§_-p1§(param1),{
            "value":this.getValue(),
            "sign":_loc2_
         }) : "";
      }
      
      public function §_-Q1l§(param1:int, param2:int) : String
      {
         var _loc3_:String = param1 >= 0 ? "+" : "";
         return this.bonus.§_-p1§() != "" ? §_-F1P§.format(this.bonus.§_-p1§(),{
            "value":(param2 ? param1 + "+" + param2 : param1),
            "sign":_loc3_
         }) : "";
      }
      
      public function §_-23r§(param1:int = 0) : String
      {
         var _loc2_:int = param1 == 0 ? this.getValue() : param1;
         return §_-F1P§.format(this.bonus.§_-23r§(),{"value":_loc2_});
      }
      
      public function §_-61R§() : Boolean
      {
         return this.bonus.§_-p1§() != "";
      }
      
      public function §_-e1f§(param1:Boolean = true) : String
      {
         var _loc2_:String = param1 && this.getValue() >= 0 ? "+" : "";
         return this.§_-61R§() ? §_-F1P§.format(this.bonus.§_-p1§(),{
            "value":this.getValue(),
            "sign":_loc2_
         }) : "";
      }
   }
}


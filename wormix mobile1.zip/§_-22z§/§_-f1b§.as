package §_-22z§
{
   import §_-12a§.§_-6p§;
   import §_-21p§.§_-4w§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-L1r§;
   import §_-931§.§_-sz§;
   import §_-B1y§.§_-Y2R§;
   import §_-B1y§.§_-bs§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.*;
   import §_-Ly§.§_-81L§;
   import §_-Ta§.*;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-d2p§.*;
   import §_-fo§.*;
   import §_-j22§.§_-5g§;
   import §_-k13§.§_-j23§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-T1K§;
   import §_-zI§.§_-F3q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.hurlant.util.der.§_-p1B§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.core.PopUpManager;
   import feathers.data.ListCollection;
   import flash.display.MovieClip;
   import flash.events.*;
   import flash.system.LoaderContext;
   import flash.ui.Keyboard;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.SetHotkeys;
   import ru.pragmatix.wormix.messages.server.SendWipeConfirmCodeResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-f1b§
   {
      
      public static const §_-T1g§:Array = [§_-Y2R§.Z,§_-Y2R§.X,§_-Y2R§.C,§_-Y2R§.V,§_-Y2R§.B,§_-Y2R§.N,§_-Y2R§.M,Keyboard.NUMPAD_1,Keyboard.NUMPAD_2,Keyboard.NUMPAD_3,Keyboard.NUMPAD_4,Keyboard.NUMPAD_5,Keyboard.NUMPAD_6,Keyboard.NUMPAD_7,Keyboard.NUMPAD_8,Keyboard.NUMPAD_9,Keyboard.NUMBER_1,Keyboard.NUMBER_2,Keyboard.NUMBER_3,Keyboard.NUMBER_4,Keyboard.NUMBER_5,Keyboard.NUMBER_6,Keyboard.NUMBER_7,Keyboard.NUMBER_8,Keyboard.NUMBER_9,Keyboard.NUMBER_0,-1,-1,§_-Y2R§.E,-1,§_-Y2R§.T,§_-Y2R§.Y,§_-Y2R§.U,-1,§_-Y2R§.O,§_-Y2R§.P,-1,-1,-1,-1,§_-Y2R§.G,§_-Y2R§.H,§_-Y2R§.J,§_-Y2R§.K,§_-Y2R§.L,Keyboard.NUMPAD_0];
      
      public static const §_-X5§:Array = ["Z","X","C","V","B","N","M","N1","N2","N3","N4","N5","N6","N7","N8","N9","1","2","3","4","5","6","7","8","9","0","Q","W","E","R","T","Y","U","I","O","P","A","S","D","F","G","H","J","K","L","N0"];
      
      private static const §_-OZ§:Array = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1];
      
      private static var §_-Mv§:Boolean = false;
      
      public function §_-f1b§()
      {
         super();
      }
      
      public static function init(param1:Array) : void
      {
         var _loc2_:uint = uint(Math.min(§_-OZ§.length,param1.length));
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_)
         {
            §_-OZ§[_loc3_] = param1[_loc3_];
            _loc3_++;
         }
      }
      
      public static function §_-81G§(param1:uint, param2:uint) : Boolean
      {
         var _loc4_:int = 0;
         var _loc3_:int = int(§_-T1g§.indexOf(param1));
         if(_loc3_ != -1)
         {
            _loc4_ = int(§_-OZ§.indexOf(param2));
            if(_loc4_ != -1)
            {
               §_-OZ§[_loc4_] = -1;
            }
            §_-OZ§[_loc3_] = param2;
            §_-Mv§ = true;
         }
         return _loc3_ != -1;
      }
      
      public static function §_-Ju§(param1:uint) : void
      {
         var _loc2_:int = int(§_-T1g§.indexOf(param1));
         if(_loc2_ != -1)
         {
            §_-OZ§[_loc2_] = -1;
            §_-Mv§ = true;
         }
      }
      
      public static function §_-H2u§(param1:uint) : int
      {
         var _loc2_:int = int(§_-T1g§.indexOf(param1));
         return _loc2_ != -1 ? int(§_-OZ§[_loc2_]) : -1;
      }
      
      public static function §_-d2Y§(param1:uint) : String
      {
         var _loc2_:int = int(§_-T1g§.indexOf(param1));
         if(_loc2_ != -1)
         {
            return §_-X5§[_loc2_];
         }
         return "";
      }
      
      public static function getKey(param1:uint) : int
      {
         var _loc2_:int = §_-215§(param1);
         return _loc2_ != -1 ? int(§_-T1g§[_loc2_]) : -1;
      }
      
      public static function §_-215§(param1:uint) : int
      {
         return §_-OZ§.indexOf(param1);
      }
      
      public static function §_-r1K§() : void
      {
         if(§_-Mv§)
         {
            §_-J2g§.§_-i1N§.send(new SetHotkeys(§_-OZ§));
            §_-Mv§ = false;
         }
      }
      
      public static function §_-id§(param1:uint) : void
      {
         var _loc2_:int = 0;
         var _loc3_:§_-eX§ = null;
         var _loc4_:§_-01J§ = null;
         var _loc5_:Weapon = null;
         if(§_-42c§(param1))
         {
            _loc2_ = §_-H2u§(param1);
            _loc3_ = §_-X1j§.§_-12n§.gameMaster;
            if(Boolean(_loc3_) && Boolean(_loc3_.activeUnit))
            {
               _loc4_ = _loc3_.activeUnit;
               _loc5_ = _loc4_.weapon;
               if(_loc4_.§_-vp§ && _loc3_.§_-E3b§() && _loc2_ >= 0 && _loc3_.§_-91D§(_loc2_) && (_loc5_ == null || _loc5_.recordId.value != _loc2_))
               {
                  §_-Q2v§.§_-01z§(_loc2_);
               }
            }
         }
      }
      
      public static function §_-42c§(param1:uint) : Boolean
      {
         var _loc2_:int = §_-H2u§(param1);
         return _loc2_ != -1;
      }
   }
}


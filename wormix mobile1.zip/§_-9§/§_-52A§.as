package §_-9§
{
   import §_-2k§.*;
   import §_-31W§.AchievLevelUpMessage;
   import §_-31W§.§_-8§;
   import §_-31W§.§_-c2J§;
   import §_-5Y§.§_-h2c§;
   import §_-82l§.§_-A2Y§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.*;
   import §_-B2z§.§_-82u§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.§_-T2G§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-b2K§;
   import §_-N8§.§_-o2w§;
   import §_-RE§.§_-qW§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-22N§;
   import §_-YF§.*;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-C3P§;
   import §_-fo§.§_-x1h§;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-sQ§.§_-737§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ProgressBar;
   import feathers.core.IFeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.ILayoutDisplayObject;
   import feathers.layout.LayoutBoundsResult;
   import feathers.layout.ViewPortBounds;
   import flash.display.*;
   import flash.errors.IllegalOperationError;
   import flash.events.*;
   import flash.geom.Point;
   import flash.system.LoaderContext;
   import flash.text.TextFormat;
   import flash.utils.*;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.mobile.BaseMobileSocialController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.client.GetAchievements;
   import ru.pragmatix.wormix.messages.client.GetProfiles;
   import ru.pragmatix.wormix.messages.server.ProfilesResult;
   import ru.pragmatix.wormix.messages.structures.SteamProductInfoStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Stage;
   import starling.events.Event;
   import starling.textures.Texture;
   
   use namespace bi_internal;
   
   public class §_-52A§ extends §_-x1h§
   {
      
      private static var instance:§_-52A§;
      
      private static const _log:§_-11S§ = new §_-11S§(§_-52A§);
      
      private static var §_-HN§:Vector.<Function> = new Vector.<Function>();
      
      public function §_-52A§(param1:§_-p2U§, param2:String, param3:String, param4:LoaderContext, param5:Vector.<String>, param6:String = "")
      {
         super(param1,param2,param3,param4,param5,param6);
         if(instance != null)
         {
            throw new IllegalOperationError();
         }
         §_-52A§.instance = this;
      }
      
      public static function §_-Ji§() : §_-52A§
      {
         return §_-52A§.instance;
      }
      
      public static function §_-K3t§(param1:String, param2:Boolean = true) : String
      {
         if(param1)
         {
            return instance.§_-K3t§(param1,param2);
         }
         return "";
      }
      
      public static function setLanguage(param1:§_-p2U§) : void
      {
         instance.setLanguage(param1);
      }
      
      public static function §_-I9§() : §_-p2U§
      {
         return instance.§_-I9§();
      }
      
      public static function load() : void
      {
         instance.load();
      }
      
      public static function §_-Q18§(param1:Function) : void
      {
         §_-HN§.push(param1);
      }
      
      public static function §_-j1I§(param1:Function) : void
      {
         §_-fM§.remove(§_-HN§,param1);
      }
      
      public function §_-K3t§(param1:String, param2:Boolean = true) : String
      {
         return this.§_-Pj§(param1,§_-I9§(),param2);
      }
      
      public function §_-Pj§(param1:String, param2:§_-p2U§, param3:Boolean = true) : String
      {
         var _loc4_:String = null;
         if(messages[param2])
         {
            if(messages[param2][param1])
            {
               return messages[param2][param1];
            }
            if(param3)
            {
               _loc4_ = "Message not found by key \'" + param1 + "\'";
               this.log.§_-M2b§(_loc4_);
               throw new IllegalOperationError(_loc4_);
            }
         }
         else if(param3)
         {
            _loc4_ = "Messages on language \'" + param2 + "\' are not loaded";
            this.log.§_-M2b§(_loc4_);
            throw new IllegalOperationError(_loc4_);
         }
         return "";
      }
      
      override protected function get log() : §_-11S§
      {
         return _log;
      }
      
      override protected function §_-x2s§() : void
      {
         var _loc1_:Function = null;
         super.§_-x2s§();
         §_-737§.init(this);
         for each(_loc1_ in §_-HN§)
         {
            _loc1_();
         }
      }
   }
}


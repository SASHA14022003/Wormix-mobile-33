package §_-5P§
{
   import §_-03T§.§_-2p§;
   import §_-21p§.§_-4w§;
   import §_-22z§.§_-f1b§;
   import §_-2U§.Alchemist;
   import §_-2U§.AncientGhost;
   import §_-2U§.Archbot;
   import §_-2U§.Assassin;
   import §_-2U§.DarkKnight;
   import §_-2U§.Emperor;
   import §_-2U§.Engineer;
   import §_-2U§.Scientist;
   import §_-2U§.Symbiote;
   import §_-2U§.Yakuza;
   import §_-2U§.§_-217§;
   import §_-2U§.§_-cH§;
   import §_-2U§.§_-d1J§;
   import §_-2U§.§_-t2u§;
   import §_-31N§.§_-42G§;
   import §_-31W§.*;
   import §_-31Y§.§_-D3B§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-82a§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2F§.*;
   import §_-A2U§.*;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-C3f§.§_-1Y§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-CR§.§_-72p§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E29§.*;
   import §_-F39§.*;
   import §_-GQ§.§_-31v§;
   import §_-H3§.*;
   import §_-K35§.§_-99§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-D2p§;
   import §_-N8§.*;
   import §_-P1z§.§_-Cc§;
   import §_-P1z§.§_-E2z§;
   import §_-P1z§.§_-L1s§;
   import §_-P1z§.§_-j2E§;
   import §_-P1z§.§_-k2X§;
   import §_-R2S§.Farmer;
   import §_-R2S§.Hunter;
   import §_-R2S§.Maniacs;
   import §_-R2S§.Miner;
   import §_-R2S§.Sergeant;
   import §_-R2S§.§_-M2x§;
   import §_-R2S§.§_-P1U§;
   import §_-R2S§.§_-z2x§;
   import §_-RE§.*;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-Ub§.Vikings;
   import §_-Ub§.VoodooShaman;
   import §_-Ub§.WindMaster;
   import §_-Ub§.§_-W1E§;
   import §_-Ub§.§_-v1t§;
   import §_-Vg§.*;
   import §_-Vu§.MD5;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.§_-22N§;
   import §_-YF§.§_-N3§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z2S§.§_-yB§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-Bx§;
   import §_-f1G§.*;
   import §_-fo§.*;
   import §_-g2r§.§_-03A§;
   import §_-j22§.§_-5g§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-k1u§.§_-Oi§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1g§.§_-L3Q§;
   import §_-m1g§.§_-K2W§;
   import §_-n1w§.*;
   import §_-o14§.§_-Dd§;
   import §_-p24§.*;
   import §_-q2b§.§_-S2L§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.§_-J2g§;
   import §_-sQ§.§_-H3D§;
   import §_-t10§.§_-B29§;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-xu§.§_-91H§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-82X§;
   import §_-z1g§.§_-M2v§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.hurlant.math.*;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.SimpleScrollBar;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.display.BitmapData;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import flash.utils.clearInterval;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.utils.id.GetAuthKeyEvent;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.rules.§_-E1q§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.MobileLogin;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.server.LoginError;
   import ru.pragmatix.wormix.messages.server.UserIsBanned;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.LoginAwardStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.CancelBattle;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-v2b§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   use namespace gestouch_internal;
   
   public class §_-52y§ extends EventDispatcher implements §_-u2H§
   {
      
      private static const §_-nc§:int = 5;
      
      private static var §_-N1Y§:int = 0;
      
      private var §_-PR§:Boolean = false;
      
      protected var userProfile:UserProfile = null;
      
      protected var §_-P2R§:§_-4l§;
      
      private var §_-w1Z§:LoginAwardStructure;
      
      private var §_-Q1y§:LoginAwardStructure;
      
      private var §_-m1m§:Boolean;
      
      private var isRelogin:Boolean;
      
      private var §_-02M§:§_-d2F§;
      
      private var §_-iO§:§_-d2F§;
      
      private var §_-K1d§:§_-d2F§;
      
      private var §_-J11§:§_-d2F§;
      
      private var §_-t1Q§:§_-qg§;
      
      private var §_-m23§:§_-h2i§;
      
      private var §_-K1m§:String;
      
      private var §_-m12§:EnterAccount;
      
      public function §_-52y§()
      {
         super();
         this.§_-t1Q§ = new §_-qg§(this);
         this.§_-m23§ = new §_-h2i§(this);
      }
      
      public static function isLoggedIn() : Boolean
      {
         return Boolean(§_-X1j§.§_-p1c§) && §_-X1j§.§_-p1c§.isLoggedIn();
      }
      
      public function login() : void
      {
         §_-J2g§.§_-o1R§(EnterAccount,this.§_-L2h§);
         §_-J2g§.§_-o1R§(LoginError,this.§_-92M§);
         §_-J2g§.§_-o1R§(UserIsBanned,this.§_-m1E§);
         this.sendLogin();
      }
      
      public function sendLogin() : void
      {
         this.§_-W19§();
      }
      
      public function §_-92M§(param1:§_-63i§) : void
      {
         this.§_-PR§ = false;
         var _loc2_:LoginError = LoginError(param1.message);
         if(§_-N1V§.§_-hQ§)
         {
            if(this.§_-t1Q§)
            {
               this.§_-t1Q§.§_-532§(_loc2_);
            }
            §_-N1V§.§_-S1u§();
            return;
         }
         if(_loc2_.code == LoginError.ALREADY_IN_GAME)
         {
            if(++§_-N1Y§ < §_-nc§)
            {
               Starling.juggler.delayCall(this.§_-W19§,1000);
               return;
            }
         }
         if(this.§_-t1Q§)
         {
            this.§_-t1Q§.§_-532§(_loc2_);
         }
      }
      
      protected function §_-m1E§(param1:§_-63i§) : void
      {
         this.§_-PR§ = false;
         var _loc2_:UserIsBanned = UserIsBanned(param1.message);
         if(this.§_-m23§)
         {
            this.§_-m23§.§_-ev§(_loc2_);
         }
      }
      
      public function §_-L2h§(param1:§_-63i§) : void
      {
         §_-N1Y§ = 0;
         var _loc2_:EnterAccount = this.§_-fb§(param1);
         §_-X1j§.§_-Rr§.§_-i1y§(_loc2_.depositStructures);
         §_-X1j§.§_-w24§.§_-11w§(_loc2_.lastPaymentTime);
         §_-N1V§.§_-qw§();
         §_-N1V§.§_-51K§();
         §_-X1j§.§_-G3m§.§_-E22§();
         §_-N1V§.§_-I39§.§_-X1P§().§_-rm§ = _loc2_.curSoloMissionId;
         §_-N1V§.§_-I39§.§_-N1i§().§_-rm§ = _loc2_.curCooperativeMissionId;
         this.§_-D1G§();
         this.§_-11b§();
      }
      
      private function §_-fb§(param1:§_-63i§) : EnterAccount
      {
         var _loc2_:EnterAccount = null;
         _loc2_ = EnterAccount(param1.message);
         this.§_-m12§ = _loc2_;
         §_-J2g§.§_-i1N§.§_-zy§(_loc2_.sessionKey);
         §_-X1j§.§_-Q9§ = getTimer();
         §_-X1j§.serverTime = _loc2_.serverTime;
         this.§_-m1m§ = _loc2_.isSecure;
         this.userProfile = new UserProfile();
         this.userProfile.build.§_-q2o§(_loc2_.userProfileStructure);
         this.userProfile.build.§_-m2F§(_loc2_);
         var _loc3_:IPlatformAccountController = §_-X1j§.§_-It§;
         this.userProfile.getSocialIds()[_loc3_.getPlatformType()] = _loc3_.getUserId();
         §_-N1V§.§_-72Z§(this.userProfile);
         Application.userProfile = this.userProfile;
         §_-6A§.§_-tK§();
         this.§_-Z12§(_loc2_);
         §_-X1j§.§_-G3m§.§_-B3h§ = _loc2_.renameAct;
         §_-X1j§.§_-f2i§.list = _loc2_.restrictions;
         §_-f1b§.init(_loc2_.hotkeys);
         §_-A23§.§_-x1D§(_loc2_.invites);
         var _loc4_:Dictionary = UserProfileStructure.parseSocialIdsArray(_loc2_.socialLinks);
         var _loc5_:SocialType = §_-X1j§.§_-It§.getPlatformType();
         if(Boolean(_loc2_.socialLinks.length) && Boolean(_loc4_[_loc5_]) && _loc4_[_loc5_] != undefined)
         {
            switch(_loc5_)
            {
               case SocialType.MOBILE_ANDROID:
                  this.§_-K1m§ = _loc4_[SocialType.MOBILE_ANDROID];
                  break;
               case SocialType.MOBILE_IOS:
                  this.§_-K1m§ = _loc4_[SocialType.MOBILE_IOS];
            }
         }
         §_-vR§.§_-I2T§(_loc2_.cookies);
         return _loc2_;
      }
      
      private function §_-Z12§(param1:EnterAccount) : void
      {
         var _loc2_:LoginAwardStructure = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         var _loc5_:Array = null;
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc9_:Boolean = false;
         var _loc10_:Array = null;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:§_-IE§ = null;
         this.§_-K1d§ = null;
         this.§_-P2R§ = null;
         this.§_-02M§ = null;
         this.§_-w1Z§ = null;
         this.§_-Q1y§ = null;
         this.§_-iO§ = null;
         this.§_-J11§ = null;
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-q2d§);
         if(_loc2_)
         {
            this.§_-K1d§ = §_-H1u§.§_-42M§(_loc2_);
            _loc4_ = §_-s2a§.CLAN_SEASON_BONUS_TEXT;
            if(Boolean(_loc2_.attach) && _loc2_.attach.length != 0)
            {
               _loc5_ = _loc2_.attach.split(" ");
               _loc6_ = _loc5_[0];
               _loc7_ = _loc6_.slice(_loc6_.indexOf("=") + 1);
               _loc8_ = _loc5_[1];
               _loc4_ = _loc8_.slice(_loc8_.indexOf("=") + 1);
               _loc9_ = parseInt(_loc4_) <= §_-F3q§.getInstance().topPlaces;
               if(_loc9_)
               {
                  _loc3_ = §_-s2a§.CLAN_SEASON_BONUS_WITH_BANNER_TEXT;
               }
            }
            else if(this.userProfile.§_-ia§())
            {
               _loc4_ = this.userProfile.clanMember.prevSeasonTopPlace.toString();
            }
            else
            {
               _loc4_ = §_-s2a§.SEASON_CLAN_PLACE;
            }
            this.§_-K1d§.§_-52h§ = §_-s2a§.§_-K3t§(§_-s2a§.SEASON_BONUS_TITLE);
            this.§_-K1d§.bonusMessage = StringUtil.format(_loc3_,{"place":_loc4_});
         }
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-r1n§);
         if(_loc2_)
         {
            this.§_-P2R§ = §_-4l§.§_-d2h§(_loc2_);
         }
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-q12§);
         if(_loc2_)
         {
            this.§_-02M§ = §_-H1u§.§_-42M§(_loc2_);
            this.§_-02M§.§_-52h§ = §_-s2a§.§_-K3t§(§_-s2a§.BONUS_HOLIDAYS_TITLE);
            if(_loc2_.attach)
            {
               this.§_-02M§.bonusMessage = _loc2_.attach;
            }
         }
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-8f§);
         if(_loc2_)
         {
            this.§_-w1Z§ = _loc2_;
         }
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-a2a§);
         if(_loc2_)
         {
            this.§_-Q1y§ = _loc2_;
         }
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-Q23§);
         if(_loc2_)
         {
            this.§_-iO§ = §_-H1u§.§_-42M§(_loc2_);
            this.§_-iO§.type = §_-qU§.§_-Q23§;
            this.§_-iO§.§_-52h§ = §_-s2a§.§_-K3t§(§_-s2a§.WEAPONS_BONUS_TITLE);
            this.§_-iO§.bonusMessage = §_-s2a§.§_-K3t§(§_-s2a§.WEAPONS_BONUS_TEXT);
         }
         _loc2_ = param1.getLoginAwardByKind(§_-qU§.§_-21o§);
         if(_loc2_)
         {
            this.§_-J11§ = §_-H1u§.§_-42M§(_loc2_);
            this.§_-J11§.type = §_-qU§.§_-21o§;
            this.§_-J11§.§_-52h§ = §_-s2a§.§_-K3t§(§_-s2a§.DOWNGRADE_WEAPONS_COMPENSATION_TITLE);
            this.§_-J11§.bonusMessage = §_-s2a§.§_-K3t§(§_-s2a§.DOWNGRADE_WEAPONS_COMPENSATION_TEXT);
            _loc10_ = _loc2_.attach.split(",");
            _loc11_ = 0;
            for each(_loc12_ in _loc10_)
            {
               _loc13_ = §_-Cq§.§_-v2G§(_loc12_);
               this.§_-J11§.items[_loc13_.upgradeId] = -1;
               if(++_loc11_ == 20)
               {
                  break;
               }
            }
         }
         §_-F2n§.§_-r1w§();
      }
      
      public function §_-72O§() : void
      {
         if(!this.§_-02M§)
         {
            return;
         }
         var _loc1_:§_-d2F§ = this.§_-02M§;
         if(_loc1_.realMoney)
         {
            Application.userProfile.§_-H3i§(-_loc1_.realMoney);
         }
         if(_loc1_.money)
         {
            Application.userProfile.§_-oA§(-_loc1_.money);
         }
      }
      
      public function §_-z2i§() : void
      {
         var value:int = 0;
         if(!this.§_-P2R§)
         {
            return;
         }
         try
         {
            value = int(this.§_-P2R§.count);
            if(this.§_-P2R§.type.equals(§_-522§.§_-J2y§))
            {
               Application.userProfile.§_-oA§(value);
            }
            else if(this.§_-P2R§.type.equals(§_-522§.§_-Mu§))
            {
               §_-X1j§.§_-k2F§.§_-f1I§([§_-r26§.§_-wy§],[1]);
               Application.userProfile.§_-H3i§(value);
            }
            else if(this.§_-P2R§.type.equals(§_-522§.REACTION))
            {
               §_-X1j§.§_-k2F§.§_-f1I§([§_-r26§.§_-S2§],[value]);
               Application.userProfile.§_-P2P§(value);
            }
         }
         catch(e:Error)
         {
         }
         this.§_-P2R§ = null;
      }
      
      public function §_-Bl§() : void
      {
         if(!this.§_-02M§)
         {
            return;
         }
         var _loc1_:§_-d2F§ = this.§_-02M§;
         if(_loc1_.realMoney)
         {
            Application.userProfile.§_-H3i§(_loc1_.realMoney);
         }
         if(_loc1_.money)
         {
            Application.userProfile.§_-oA§(_loc1_.money);
         }
         if(_loc1_.reaction)
         {
            §_-X1j§.§_-k2F§.§_-f1I§([§_-r26§.§_-S2§],[_loc1_.reaction]);
         }
         this.§_-02M§ = null;
      }
      
      public function §_-F3K§() : void
      {
         if(!this.§_-K1d§)
         {
            return;
         }
         var _loc1_:§_-d2F§ = this.§_-K1d§;
         if(_loc1_.reaction > 0)
         {
            §_-X1j§.§_-k2F§.§_-f1I§([§_-r26§.§_-S2§],[_loc1_.reaction]);
         }
         this.§_-K1d§ = null;
      }
      
      public function §_-AI§() : void
      {
         §_-X1j§.§_-61v§.§_-G3d§(§_-J2g§.§_-i1N§.§_-yt§() ? this.§_-E3M§ : this.§_-W19§);
      }
      
      private function §_-W19§(param1:Object = null) : void
      {
         var acc:IPlatformAccountController = null;
         var link:§_-B29§ = null;
         var keychain:§_-S2L§ = null;
         var isAndroid:Boolean = false;
         var isIos:Boolean = false;
         var userTokenPair:Object = param1;
         acc = §_-X1j§.§_-It§;
         link = §_-X1j§.§_-61v§;
         keychain = §_-X1j§.§_-D1T§;
         isAndroid = acc.getPlatformType().equals(SocialType.MOBILE_ANDROID);
         isIos = acc.getPlatformType().equals(SocialType.MOBILE_IOS);
         var loginFunction:Function = function(param1:GetAuthKeyEvent):void
         {
            var _loc5_:Array = null;
            var _loc6_:String = null;
            var _loc7_:§_-O2i§ = null;
            var _loc8_:§_-eX§ = null;
            var _loc2_:MobileLogin = new MobileLogin();
            _loc2_.version = MobileLogin.versionFromString(§_-vR§.protocolVersion);
            var _loc3_:String = acc.getUserId();
            var _loc4_:String = "default";
            if(isIos)
            {
               _loc5_ = §_-50§.§_-R1Y§();
               if(_loc5_.length == 2)
               {
                  _loc3_ = _loc5_[0];
                  _loc4_ = _loc5_[1];
               }
            }
            _loc2_.deviceId = userTokenPair ? userTokenPair.m : _loc3_;
            _loc2_.authKey = userTokenPair ? userTokenPair.t : §_-H1u§.getAuthKey(false);
            _loc2_.platformId = acc.getPlatformType().servercode;
            _loc2_.params.push(§_-50§.§_-T2J§,§_-X1j§.§_-82T§.§_-I9§().§_-b2§().toUpperCase());
            _loc2_.params.push(§_-50§.§_-z1k§,§_-H1u§.§_-z2u§());
            if(isAndroid)
            {
               _loc2_.params.push("(true)hardId",acc.getUserIdByType(UserIdType.HARDWARE) || "-");
            }
            if(isIos)
            {
               _loc2_.params.push("isLinked",link ? link.isLinked : "-");
               _loc2_.params.push("isLinkAvailable",link ? link.isServiceAvailable : "-");
               _loc2_.params.push("cloudId",link.§_-x2Y§() || "-");
               _loc2_.params.push("keychainId",keychain.getUserId() || "-");
               _loc2_.params.push("localEncrId",acc.getUserId() || "-");
               _loc2_.params.push("localSharId",acc.getUserIdByType(StorageType.LOCAL_SHARED) || "-");
               _loc6_ = §_-X1j§.§_-d1s§.§_-J1w§();
               _loc2_.params.push("cloudAccId",_loc6_ || "-");
               _loc2_.params.push("cloudAccId_md5",_loc6_ ? MD5.§_-bf§(_loc6_) : "-");
               _loc2_.params.push("userIdSource",_loc4_);
            }
            if(Boolean(isRelogin) && Boolean(§_-X1j§.§_-12n§) && (§_-X1j§.§_-12n§.inBattle || §_-X1j§.§_-12n§.§_-Ac§))
            {
               _loc7_ = §_-X1j§.§_-12n§.§_-WN§();
               _loc8_ = §_-X1j§.§_-12n§.gameMaster;
               if(Boolean(_loc7_) && Boolean(_loc7_.missionIds) && _loc7_.missionIds.length == 1)
               {
                  _loc2_.params.push(§_-50§.§_-Tz§,_loc7_.battleId);
                  _loc2_.params.push(§_-50§.§_-Y1g§,_loc7_.missionIds[0]);
                  _loc2_.params.push(§_-50§.§_-Y2Z§,_loc8_ ? _loc8_.§_-82g§() : 0);
               }
            }
            §_-H1u§.§_-Ot§(_loc2_.params);
            §_-J2g§.§_-h18§(_loc2_);
         };
         §_-v2b§.§_-AO§(acc,loginFunction);
         §_-vR§.setUserId(acc.getUserId());
      }
      
      public function §_-E3M§(param1:Object = null) : void
      {
         §_-J2g§.§_-fy§(EnterAccount,this.§_-L2h§);
         §_-J2g§.§_-o1R§(EnterAccount,this.§_-6R§);
         this.isRelogin = true;
         this.§_-W19§(param1);
      }
      
      public function §_-6R§(param1:§_-63i§) : void
      {
         §_-N1Y§ = 0;
         var _loc2_:EnterAccount = this.§_-fb§(param1);
         §_-N1V§.§_-qw§();
         this.§_-72O§();
         §_-X1j§.§_-nT§();
         this.§_-D1G§();
         if(§_-X1j§.§_-12n§.scene)
         {
            §_-X1j§.§_-12n§.§_-H2r§();
            §_-X1j§.§_-12n§.§_-eq§(_loc2_.reconnectResult);
         }
         if(!§_-X1j§.§_-12n§.gameMaster)
         {
            if(Application.§_-E1k§.activeScreen == null && !§_-X1j§.§_-12n§.§_-9l§())
            {
               Application.§_-i1N§.§_-V6§();
            }
         }
         this.§_-11b§();
      }
      
      private function §_-D1G§() : void
      {
         var _loc1_:§_-O2i§ = null;
         if(Boolean(§_-X1j§.§_-12n§.gameMaster) && Boolean(!§_-X1j§.§_-12n§.gameMaster.§_-W2j§().online) && !(§_-X1j§.§_-12n§.§_-gj§() is §_-E1q§))
         {
            _loc1_ = §_-X1j§.§_-12n§.§_-WN§();
            if(_loc1_.battleType == §_-81M§.§_-e1C§)
            {
               §_-X1j§.§_-12n§.§_-E3v§();
            }
         }
      }
      
      public function dispose() : void
      {
         §_-J2g§.§_-fy§(EnterAccount,this.§_-L2h§);
         §_-J2g§.§_-fy§(LoginError,this.§_-92M§);
         §_-J2g§.§_-fy§(UserIsBanned,this.§_-m1E§);
         §_-J2g§.§_-fy§(EnterAccount,this.§_-6R§);
         if(this.userProfile)
         {
            this.userProfile.§_-g2M§();
            this.userProfile = null;
         }
         this.§_-P2R§ = null;
         this.§_-02M§ = null;
         this.§_-w1Z§ = null;
         this.§_-Q1y§ = null;
         this.§_-m12§ = null;
      }
      
      private function §_-11b§() : void
      {
         this.§_-PR§ = true;
         dispatchEvent(new flash.events.Event(flash.events.Event.COMPLETE));
         if(§_-J2l§.§_-u2b§.§_-h1C§())
         {
            §_-J2l§.§_-u2b§.hide();
         }
      }
      
      public function isSecure() : Boolean
      {
         return this.§_-m1m§;
      }
      
      public function §_-922§() : LoginAwardStructure
      {
         return this.§_-w1Z§;
      }
      
      public function §_-F33§() : LoginAwardStructure
      {
         return this.§_-Q1y§;
      }
      
      public function §_-82p§() : §_-d2F§
      {
         return this.§_-iO§;
      }
      
      public function §_-Ml§() : §_-d2F§
      {
         return this.§_-J11§;
      }
      
      public function §_-J3m§() : §_-d2F§
      {
         return null;
      }
      
      public function isLoggedIn() : Boolean
      {
         return this.§_-PR§;
      }
      
      public function get §_-i1v§() : String
      {
         return this.§_-K1m§;
      }
      
      public function set §_-i1v§(param1:String) : void
      {
         this.§_-K1m§ = param1;
      }
      
      public function §_-Yu§() : EnterAccount
      {
         return this.§_-m12§;
      }
      
      public function §_-5J§() : §_-4l§
      {
         return this.§_-P2R§;
      }
      
      public function §_-c1Y§() : §_-d2F§
      {
         return this.§_-02M§;
      }
      
      public function §_-ba§() : §_-d2F§
      {
         return this.§_-K1d§;
      }
   }
}


package §_-5P§
{
   import §_-62§.§_-O2H§;
   import §_-TF§.§_-y2n§;
   import §_-w§.§_-63m§;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderCore;
   import com.hurlant.util.*;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.utils.§_-v2b§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   
   public class §_-50§
   {
      
      public static const §_-T2J§:String = "locale";
      
      public static const §_-V2M§:String = "referrerKey";
      
      public static const §_-T2K§:String = "flv";
      
      public static const §_-3M§:String = "rlt";
      
      public static const §_-u1o§:String = "debug_login_awards";
      
      public static const §_-h2U§:String = "move_profile";
      
      public static const §_-Tz§:String = "reconnect_to_battle";
      
      public static const §_-Y1g§:String = "mission_id";
      
      public static const §_-Y2Z§:String = "last_turn_num";
      
      public static const §_-z1k§:String = "device_id";
      
      public static const PAR1:String = "par1";
      
      public static const PAR5:String = "par5";
      
      public function §_-50§()
      {
         super();
      }
      
      public static function §_-R1Y§() : Array
      {
         var _loc3_:Array = null;
         var _loc4_:String = null;
         var _loc5_:Boolean = false;
         var _loc6_:String = null;
         var _loc1_:IPlatformAccountController = §_-X1j§.§_-It§;
         var _loc2_:Boolean = _loc1_.getPlatformType().equals(SocialType.MOBILE_IOS);
         if(_loc2_)
         {
            _loc3_ = §_-X1j§.§_-d1s§.§_-K3J§() || §_-X1j§.§_-D1T§.§_-K3J§();
         }
         if(!_loc3_)
         {
            _loc4_ = _loc1_.getUserId();
            _loc5_ = _loc1_.localStoreType == StorageType.LOCAL_ENCRYPTED;
            _loc6_ = (_loc1_.isCreatedId ? "(New)" : "") + "Local" + (_loc5_ ? "(E)" : "(Sh)");
            _loc3_ = [_loc4_,_loc6_];
         }
         if(_loc2_)
         {
            §_-v2b§.§_-j1T§();
         }
         return _loc3_;
      }
   }
}


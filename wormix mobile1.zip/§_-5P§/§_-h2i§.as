package §_-5P§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.*;
   import §_-62§.§_-W1r§;
   import §_-A1m§.MultipartURLLoader;
   import §_-D3A§.*;
   import §_-DJ§.§_-G2k§;
   import §_-DJ§.§_-J2l§;
   import §_-OA§.§_-k2K§;
   import §_-P1z§.*;
   import §_-TF§.§_-y2n§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-e2r§.*;
   import §_-gG§.§_-M2S§;
   import §_-j1w§.§_-L1x§;
   import §_-jF§.*;
   import §_-r1C§.§_-h2B§;
   import feathers.controls.NumericStepper;
   import feathers.core.PopUpManager;
   import flash.events.ErrorEvent;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.net.URLLoader;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.controller.*;
   import ru.pragmatix.flox.social.model.ResponseFormat;
   import ru.pragmatix.flox.social.model.SocialErrorCode;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-D8§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.UserIsBanned;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-h2i§
   {
      
      private var _loginController:§_-u2H§;
      
      public function §_-h2i§(param1:§_-u2H§)
      {
         super();
         this._loginController = param1;
      }
      
      public function §_-ev§(param1:UserIsBanned) : void
      {
         var _loc2_:§_-D8§ = §_-X1j§.§_-12n§;
         if(Boolean(_loc2_.scene) && Boolean(_loc2_.scene.gameInterface))
         {
            _loc2_.scene.gameInterface.§_-Fb§.close();
            _loc2_.§_-co§();
            §_-J2l§.§_-u2b§.show(this.§_-eh§,param1);
         }
         else
         {
            this.§_-eh§(param1);
         }
      }
      
      private function §_-eh§(param1:UserIsBanned) : void
      {
         §_-YQ§.removeAllPopUps();
         var _loc2_:String = §_-s2a§.§_-K3t§(§_-s2a§.TITLE_BAN);
         var _loc3_:String = §_-41p§.§_-p1§(param1.reason,param1.endDate);
         §_-G2k§.show(_loc2_,_loc3_,param1.profileId,this.§_-Yl§);
      }
      
      private function §_-Yl§() : void
      {
         if(§_-X1j§.§_-61v§.isServiceAvailable && §_-X1j§.§_-61v§.isCanSwitchToAnotherAccount)
         {
            §_-X1j§.§_-61v§.§_-gw§();
         }
         else
         {
            Application.§_-i1N§.restart();
         }
      }
   }
}


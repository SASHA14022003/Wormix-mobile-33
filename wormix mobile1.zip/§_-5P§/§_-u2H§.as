package §_-5P§
{
   import §_-z1g§.§_-4l§;
   import flash.events.IEventDispatcher;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.LoginAwardStructure;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   
   public interface §_-u2H§ extends IEventDispatcher
   {
      
      function login() : void;
      
      function isLoggedIn() : Boolean;
      
      function isSecure() : Boolean;
      
      function dispose() : void;
      
      function sendLogin() : void;
      
      function §_-5J§() : §_-4l§;
      
      function §_-c1Y§() : §_-d2F§;
      
      function §_-ba§() : §_-d2F§;
      
      function §_-922§() : LoginAwardStructure;
      
      function §_-F33§() : LoginAwardStructure;
      
      function §_-J3m§() : §_-d2F§;
      
      function §_-82p§() : §_-d2F§;
      
      function §_-Ml§() : §_-d2F§;
      
      function §_-Yu§() : EnterAccount;
   }
}


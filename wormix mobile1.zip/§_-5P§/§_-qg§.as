package §_-5P§
{
   import §_-92a§.§_-Y2Y§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-7f§;
   import §_-TF§.§_-q1j§;
   import §_-X14§.*;
   import §_-s20§.§_-J2g§;
   import config.§_-vR§;
   import feathers.controls.Button;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ToggleButton;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import flash.desktop.Clipboard;
   import flash.desktop.ClipboardFormats;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.LoginError;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.core.Starling;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-qg§
   {
      
      private var _loginController:§_-u2H§;
      
      public function §_-qg§(param1:§_-u2H§)
      {
         super();
         this._loginController = param1;
      }
      
      public function §_-532§(param1:LoginError) : void
      {
         var _loc9_:String = null;
         var _loc2_:String = "";
         var _loc3_:String = "";
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc6_:Function = null;
         var _loc7_:Function = null;
         var _loc8_:int = §_-fH§.§_-1B§;
         switch(param1.code)
         {
            case LoginError.ALREADY_IN_GAME:
               _loc2_ = §_-s2a§.TITLE_ERROR;
               _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.ALREADY_IN_GAME_LOGIN_TRYING_LIMIT_OUT);
               break;
            case LoginError.INCORRECT_KEY:
               _loc2_ = §_-s2a§.TITLE_ERROR;
               _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.ERROR_AUTH_KEY);
               if(§_-N1V§.§_-hQ§ && Boolean(§_-N1V§.socialController))
               {
                  _loc3_ += " (" + §_-N1V§.socialController.getType().name + ")";
               }
               break;
            case LoginError.PROFILACTIC_WORK:
               _loc2_ = §_-s2a§.TITLE_ATTENTION;
               _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.SERVER_UPDATE);
               break;
            case LoginError.INTERNAL_SERVER_ERROR:
               _loc2_ = §_-s2a§.TITLE_ATTENTION;
               _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.ERROR_SERVER);
               break;
            case LoginError.INCORRECT_PROTOCOL_VERSION:
               _loc2_ = §_-s2a§.TITLE_UPDATE_IS_AVAILABLE;
               _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.TEXT_UPDATE_IS_AVAILABLE);
               _loc4_ = §_-vR§.§_-Ep§;
               _loc5_ = §_-s2a§.UPDATE;
               §_-J2g§.§_-i1N§.dispose();
               break;
            case LoginError.NOT_IN_WHITE_LIST:
               _loc2_ = §_-s2a§.TITLE_ATTENTION;
               _loc9_ = §_-50§.§_-R1Y§()[0];
               _loc3_ = StringUtil.format(§_-s2a§.TEXT_NOT_IN_WHITE_LIST,{"uid":_loc9_});
               Clipboard.generalClipboard.clear();
               Clipboard.generalClipboard.setData(ClipboardFormats.TEXT_FORMAT,_loc9_,false);
               break;
            case LoginError.NEED_STRICT_AUTHORIZATION:
               if(§_-J2g§.§_-i1N§.§_-yt§())
               {
                  §_-N1V§.§_-M1F§();
               }
               if(!§_-X1j§.§_-61v§.isCanSilent && (Boolean(§_-X1j§.§_-61v§.isStrong) || Boolean(§_-J2g§.§_-i1N§.§_-yt§())))
               {
                  _loc2_ = §_-s2a§.TITLE_ATTENTION;
                  _loc3_ = StringUtil.format(§_-s2a§.NEED_GOOGLE_AUTH,{"ok":§_-s2a§.§_-K3t§(§_-7f§.BUTTON_OK)});
                  _loc6_ = §_-X1j§.§_-p1c§.§_-AI§;
                  break;
               }
               §_-X1j§.§_-p1c§.§_-AI§();
         }
         if(Boolean(_loc2_) || Boolean(_loc3_))
         {
            this.showErrorMsg(§_-s2a§.§_-K3t§(_loc2_),_loc3_,_loc4_,_loc5_,_loc8_,_loc6_,_loc7_);
         }
      }
      
      private function showErrorMsg(param1:String, param2:String, param3:String = null, param4:String = null, param5:int = 0, param6:Function = null, param7:Function = null) : §_-fH§
      {
         var message:§_-fH§;
         var title:String = param1;
         var text:String = param2;
         var redirectionLink:String = param3;
         var customOkTextId:String = param4;
         var buttons:int = param5;
         var onOkClickFunction:Function = param6;
         var onCancelClick:Function = param7;
         if(onOkClickFunction == null)
         {
            onOkClickFunction = function():void
            {
               var _loc1_:URLRequest = null;
               if(redirectionLink)
               {
                  _loc1_ = new URLRequest(redirectionLink);
                  navigateToURL(_loc1_);
               }
               _loginController.sendLogin();
            };
         }
         message = §_-fH§.§_-F3p§(title,text,buttons,onOkClickFunction,onCancelClick);
         if(customOkTextId)
         {
            message.§_-12E§(customOkTextId);
         }
         message.outsideClosable = false;
         message.show();
         return message;
      }
   }
}


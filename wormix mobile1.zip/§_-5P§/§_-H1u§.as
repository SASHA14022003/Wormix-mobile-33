package §_-5P§
{
   import §_-12W§.*;
   import §_-A1K§.§_-7u§;
   import §_-A2F§.§_-4B§;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-Vu§.MD5;
   import §_-Z1K§.§_-M6§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Ia§;
   import com.hurlant.math.*;
   import com.mesmotronic.ane.AndroidID;
   import config.§_-vR§;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.system.Capabilities;
   import flash.system.System;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.response.photo.PhotoSaveResponse;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.MobileLogin;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.messages.structures.AwardTypes;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.LoginAwardStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.§_-N1C§;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   
   public class §_-H1u§
   {
      
      private static const §_-82z§:String = "E Q`KB&zIzYG.#1>+";
      
      public function §_-H1u§()
      {
         super();
      }
      
      public static function §_-42M§(param1:LoginAwardStructure) : §_-d2F§
      {
         var _loc3_:GenericAwardStructure = null;
         var _loc2_:§_-d2F§ = new §_-d2F§();
         for each(_loc3_ in param1.awards)
         {
            switch(_loc3_.awardKind)
            {
               case AwardTypes.MONEY:
                  _loc2_.money = _loc3_.count;
                  break;
               case AwardTypes.REAL_MONEY:
                  _loc2_.realMoney = _loc3_.count;
                  break;
               case AwardTypes.REACTION_RATE:
                  _loc2_.reaction = _loc3_.count;
                  break;
               case AwardTypes.EXPERIENCE:
                  _loc2_.exp = _loc3_.count;
                  break;
               case AwardTypes.BONUS_EXPERIENCE:
                  _loc2_.bonusExp = _loc3_.count;
                  break;
               case AwardTypes.REAGENTS:
                  _loc2_.reagents[_loc3_.itemId] = _loc3_.count;
                  break;
               case AwardTypes.WEAPON_SHOT:
                  _loc2_.items[_loc3_.itemId] = _loc3_.count;
                  break;
               case AwardTypes.STUFF:
                  _loc2_.items[_loc3_.itemId] = _loc3_.count;
                  break;
               case AwardTypes.TEMPORARY_HAT:
                  _loc2_.items[_loc3_.itemId] = _loc3_.count || 1;
                  break;
               case AwardTypes.WEAPON:
                  _loc2_.items[_loc3_.itemId] = _loc3_.count;
                  break;
               case AwardTypes.BATTLES_COUNT:
                  _loc2_.battlesCount = _loc3_.count;
                  break;
               case AwardTypes.WAGER_TOKEN:
                  _loc2_.§_-u28§ = _loc3_.count;
                  break;
               case AwardTypes.BOSS_TOKEN:
                  _loc2_.§_-R2R§ = _loc3_.count;
            }
         }
         _loc2_.type = §_-qU§.valueOf(param1.awardType);
         return _loc2_;
      }
      
      public static function §_-Ot§(param1:Array) : void
      {
         param1.push("buildVer",§_-vR§.§_-U0§);
         param1.push(§_-50§.PAR1,§_-X1j§.§_-E1P§().loaderInfo.bytesLoaded || "-");
         param1.push(§_-50§.PAR5,§_-X1j§.§_-E1P§().loaderInfo.loaderURL || "-");
         param1.push("cpuAr",Capabilities.cpuArchitecture);
         param1.push("lang",Capabilities.language);
         param1.push("manuf",Capabilities.manufacturer);
         param1.push("os",Capabilities.os);
         param1.push("screenResX",Capabilities.screenResolutionX);
         param1.push("screenResY",Capabilities.screenResolutionY);
         param1.push("sup32BPs",Capabilities.supports32BitProcesses);
         param1.push("sup64BPs",Capabilities.supports64BitProcesses);
         param1.push("s.platform: " + SystemUtil.platform);
         param1.push("s.ver: " + SystemUtil.version);
         param1.push("totMem",System.totalMemory);
         param1.push("vmVer",System.vmVersion);
         param1.push("ss",Capabilities.serverString);
      }
      
      public static function getAuthKey(param1:Boolean) : String
      {
         var _loc2_:int = MobileLogin.versionFromString(§_-vR§.protocolVersion);
         var _loc3_:String = §_-50§.§_-R1Y§()[0];
         var _loc4_:String = MD5.§_-bf§("" + _loc2_ + _loc3_ + §_-82z§);
         if(param1 && Boolean(§_-J2g§.§_-i1N§.§_-yt§()))
         {
            _loc4_ += "," + §_-J2g§.§_-i1N§.§_-yt§();
         }
         return _loc4_;
      }
      
      public static function §_-z2u§() : String
      {
         if(!§_-YD§.§_-t1O§ && SystemUtil.platform == §_-WK§.§_-c1l§)
         {
            if(AndroidID.isSupported)
            {
               return AndroidID.ANDROID_ID;
            }
         }
         return §_-X1j§.§_-It§.getUserId();
      }
   }
}


package §_-13R§
{
   import §_-82l§.§_-A2Y§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.*;
   import §_-DJ§.§_-fH§;
   import §_-H16§.*;
   import §_-P2i§.§_-G3J§;
   import §_-T1o§.§_-n1S§;
   import §_-fo§.*;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-f2L§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import feathers.controls.Button;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.display.MovieClip;
   import flash.events.Event;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.EndBattleResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.§_-Qd§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.Girder;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-i17§ extends DisplayObject
   {
      
      private var _container:DisplayObjectContainer;
      
      private var §_-xx§:Button;
      
      private var §_-q1R§:Button;
      
      public function §_-i17§(param1:DisplayObjectContainer)
      {
         super();
         this._container = param1;
         this.§_-xx§ = this.createButton(this._container,AlternateButtonsStyles.BUTTON_GREEN);
         this.§_-q1R§ = this.createButton(this._container,AlternateButtonsStyles.BUTTON_RED);
         §_-X1j§.§_-82T§.addEventListener(starling.events.Event.CHANGE,this.§_-V1a§);
         §_-N1V§.addListener(§_-f2L§.§_-Rx§,this.§_-V1a§);
         this.§_-V1a§();
      }
      
      private function createButton(param1:DisplayObjectContainer, param2:String) : Button
      {
         var _loc3_:Button = null;
         _loc3_ = new Button();
         _loc3_.styleName = param2;
         _loc3_.width = param1.width;
         _loc3_.height = param1.height;
         _loc3_.addEventListener(starling.events.Event.TRIGGERED,this.§_-y1l§);
         param1.addChild(_loc3_);
         return _loc3_;
      }
      
      private function §_-V1a§(param1:starling.events.Event = null) : void
      {
         this.§_-xx§.label = §_-Qd§.§_-920§(§_-X1j§.socialController.getType());
         this.§_-q1R§.label = §_-Qd§.§_-920§(§_-X1j§.socialController.getType());
         var _loc2_:Boolean = §_-X1j§.socialController.isLoggedIn();
         §_-YQ§.§_-Xv§(this.§_-xx§,_loc2_);
         §_-YQ§.§_-Xv§(this.§_-q1R§,!_loc2_);
         dispatchEventWith(starling.events.Event.UPDATE);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this._container = null;
         §_-X1j§.§_-82T§.removeEventListener(starling.events.Event.CHANGE,this.§_-V1a§);
         §_-N1V§.removeListener(§_-f2L§.§_-Rx§,this.§_-V1a§);
         this.§_-xx§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-y1l§);
         this.§_-q1R§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-y1l§);
      }
      
      override public function set x(param1:Number) : void
      {
         this._container.x = param1;
      }
      
      override public function get x() : Number
      {
         return this._container.x;
      }
      
      override public function set y(param1:Number) : void
      {
         this._container.y = param1;
      }
      
      override public function get y() : Number
      {
         return this._container.y;
      }
      
      private function §_-y1l§(param1:starling.events.Event) : void
      {
         §_-N1V§.§_-xJ§(this.§_-L2m§,true);
      }
      
      private function §_-L2m§(param1:Boolean) : void
      {
         this.§_-V1a§();
      }
   }
}


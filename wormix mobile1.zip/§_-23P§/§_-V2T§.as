package §_-23P§
{
   import §_-62§.§_-G1p§;
   import §_-62§.§_-T1y§;
   import §_-9§.§_-52A§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-SG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-P1z§.*;
   import §_-hO§.§_-BY§;
   import §_-k1u§.§_-Oi§;
   import §_-kP§.*;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-sQ§.§_-737§;
   import §_-sQ§.§_-H3D§;
   import feathers.controls.List;
   import feathers.layout.AnchorLayout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-V2T§ implements §_-SG§
   {
      
      private static var instance:§_-V2T§;
      
      public static const §_-v15§:int = 500;
      
      private var §_-62Q§:Vector.<§_-u1z§>;
      
      public function §_-V2T§(param1:Vector.<§_-u1z§>)
      {
         super();
         this.§_-62Q§ = param1;
      }
      
      public static function init(param1:Vector.<§_-u1z§>) : void
      {
         if(!instance)
         {
            instance = new §_-V2T§(param1);
         }
      }
      
      private static function getInstance() : §_-V2T§
      {
         if(!instance)
         {
            throw new Error("MercStore hasn\'t been initialized properly!");
         }
         return instance;
      }
      
      public static function §_-H2p§(param1:int) : §_-u1z§
      {
         var _loc2_:§_-u1z§ = null;
         for each(_loc2_ in getInstance().§_-62Q§)
         {
            if(_loc2_.getId() == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public static function §_-A1q§() : Vector.<§_-u1z§>
      {
         var _loc1_:Vector.<§_-u1z§> = new Vector.<§_-u1z§>(0);
         var _loc2_:Vector.<§_-u1z§> = getInstance().§_-62Q§;
         var _loc3_:int = Application.userProfile.getLevel();
         var _loc4_:* = int(_loc2_.length - 1);
         while(_loc4_ > -1)
         {
            if(_loc2_[_loc4_].getLevel() <= _loc3_)
            {
               _loc1_.push(_loc2_[_loc4_]);
            }
            _loc4_--;
         }
         return _loc1_;
      }
      
      public static function §_-N1o§(param1:UserProfile) : void
      {
         var _loc2_:§_-u1z§ = §_-H2p§(param1.getId());
         if(_loc2_)
         {
            if(!param1.getHat() && _loc2_.§_-PG§() != 0)
            {
               param1.§_-L§(§_-G1p§.§_-12J§(_loc2_.§_-PG§(),param1.§_-P2e§()));
            }
            if(!param1.§_-32q§() && _loc2_.§_-u1E§() != 0)
            {
               param1.§_-aV§(§_-G1p§.§_-93G§(_loc2_.§_-u1E§()));
            }
         }
      }
   }
}


package §_-23P§
{
   import §_-03T§.§_-2p§;
   import §_-31W§.§_-r26§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-F39§.§_-Ey§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-b1F§.§_-G4§;
   import §_-j1w§.§_-L1x§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-lp§;
   import §_-zI§.§_-8D§;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import flash.net.Socket;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.system.SecurityDomain;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanInviteTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-i14§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-u1z§
   {
      
      private var id:int = 0;
      
      private var level:int;
      
      private var name:String;
      
      private var attack:int;
      
      private var armor:int;
      
      private var race:§_-L1x§;
      
      private var hatId:uint = 0;
      
      private var artifactId:uint = 0;
      
      private var §_-R1T§:uint;
      
      private var realPrice:uint;
      
      public function §_-u1z§()
      {
         super();
      }
      
      public static function §_-Bs§(param1:Object) : §_-u1z§
      {
         var _loc2_:§_-u1z§ = new §_-u1z§();
         _loc2_.initFromConfig(param1);
         return _loc2_;
      }
      
      public function initFromConfig(param1:Object) : void
      {
         if(param1.id)
         {
            this.id = param1.id;
         }
         if(param1.level)
         {
            this.level = param1.level;
         }
         if(param1.name)
         {
            this.name = param1.name;
         }
         if(param1.attack)
         {
            this.attack = param1.attack;
         }
         if(param1.armor)
         {
            this.armor = param1.armor;
         }
         if(param1.race)
         {
            this.race = §_-L1x§.§_-V10§(§_-L1x§.§_-M19§(param1.race));
         }
         if(param1.price)
         {
            this.§_-R1T§ = param1.price;
         }
         if(param1.realPrice)
         {
            this.realPrice = param1.realPrice;
         }
         if(param1.hatId)
         {
            this.hatId = param1.hatId;
         }
         if(param1.artifactId)
         {
            this.artifactId = param1.artifactId;
         }
      }
      
      public function §_-d22§() : UserProfile
      {
         var _loc1_:UserProfile = UserProfile.custom(this.getName(),this.level,this.race,§_-lp§.§_-L2a§(this.level),this.armor,this.attack,this.hatId,this.artifactId);
         _loc1_.setId(this.id);
         _loc1_.§_-I1N§(this.getName());
         return _loc1_;
      }
      
      public function toString() : String
      {
         return "MercRecord{" + "id=" + this.id + ",level=" + this.level + ",name=" + this.name + "}";
      }
      
      public function §_-tV§(param1:§_-Oi§) : Boolean
      {
         return this.hatId == param1.getId() || this.artifactId == param1.getId();
      }
      
      public function getId() : int
      {
         return this.id;
      }
      
      public function getLevel() : int
      {
         return this.level;
      }
      
      public function getName() : String
      {
         var _loc1_:String = "";
         return _loc1_ + §_-s2a§.§_-K3t§(this.name);
      }
      
      public function §_-w1p§() : int
      {
         return this.attack;
      }
      
      public function §_-h2m§() : int
      {
         return this.armor;
      }
      
      public function §_-P2e§() : §_-L1x§
      {
         return this.race;
      }
      
      public function §_-PG§() : uint
      {
         return this.hatId;
      }
      
      public function §_-u1E§() : uint
      {
         return this.artifactId;
      }
      
      public function §_-91e§() : uint
      {
         return this.§_-R1T§;
      }
      
      public function §_-gc§() : uint
      {
         return this.realPrice;
      }
   }
}


package §_-d26§
{
   import §_-62§.§_-G1p§;
   import §_-CF§.§_-p2U§;
   import §_-Y1O§.*;
   import §_-l1K§.§_-cZ§;
   import config.§_-B1K§;
   import ru.pragmatix.flox.social.lang.EnLangController;
   import ru.pragmatix.flox.social.lang.ILangController;
   import ru.pragmatix.flox.social.lang.RuLangController;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-d1H§ extends EventDispatcher
   {
      
      private var §_-B2m§:§_-c2E§;
      
      private var §_-z2g§:UserProfile;
      
      private var §_-92§:Array;
      
      private var §_-8T§:Boolean;
      
      public function §_-d1H§()
      {
         super();
      }
      
      public function get userProfile() : UserProfile
      {
         return this.§_-z2g§;
      }
      
      public function setData(param1:UserProfile, param2:Boolean) : void
      {
         var _loc3_:Array = null;
         var _loc4_:§_-c2E§ = null;
         var _loc5_:int = 0;
         this.§_-8T§ = param2;
         if(this.§_-z2g§ != param1)
         {
            this.§_-z2g§ = param1;
            this.§_-92§ = [];
            _loc3_ = this.§_-z2g§.§_-A1U§();
            _loc5_ = 0;
            while(_loc5_ < _loc3_.length)
            {
               _loc4_ = new §_-c2E§(_loc3_[_loc5_]);
               this.§_-92§.push(_loc4_);
               _loc5_++;
            }
            dispatchEventWith(Event.CHANGE);
         }
      }
      
      public function get §_-GF§() : §_-c2E§
      {
         return this.§_-B2m§;
      }
      
      public function set §_-GF§(param1:§_-c2E§) : void
      {
         if(this.§_-B2m§ != param1)
         {
            this.§_-B2m§ = param1;
            dispatchEventWith(Event.SELECT);
         }
      }
      
      public function §_-4M§(param1:int, param2:int) : void
      {
         if(param2 == §_-B1K§.HAT)
         {
            this.§_-B2m§.hatId = param1;
         }
         else if(param2 == §_-B1K§.ARTIFACT)
         {
            this.§_-B2m§.artifactId = param1;
         }
         dispatchEventWith(Event.UPDATE);
      }
      
      public function §_-F2F§(param1:int) : void
      {
         var _loc2_:§_-c2E§ = this.§_-B2m§;
         if(param1 == §_-B1K§.HAT)
         {
            this.§_-4M§(_loc2_.§_-HB§,param1);
         }
         else if(param1 == §_-B1K§.ARTIFACT)
         {
            this.§_-4M§(_loc2_.§_-Q1x§,param1);
         }
      }
      
      public function get §_-M1o§() : Array
      {
         return this.§_-92§;
      }
      
      public function §_-S2F§() : Boolean
      {
         var _loc2_:§_-c2E§ = null;
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc1_:Boolean = false;
         for each(_loc2_ in this.§_-92§)
         {
            _loc3_ = _loc2_.userProfile.getHat() ? _loc2_.userProfile.getHat().getId() : 0;
            _loc4_ = _loc2_.userProfile.§_-32q§() ? _loc2_.userProfile.§_-32q§().getId() : 0;
            if(_loc3_ != _loc2_.hatId || _loc4_ != _loc2_.artifactId)
            {
               _loc1_ = true;
               break;
            }
         }
         return _loc1_;
      }
      
      public function §_-72m§() : Vector.<UserProfile>
      {
         var _loc2_:§_-c2E§ = null;
         var _loc3_:UserProfile = null;
         var _loc1_:Vector.<UserProfile> = new Vector.<UserProfile>(0);
         var _loc4_:int = 0;
         while(_loc4_ < this.§_-92§.length)
         {
            _loc2_ = this.§_-92§[_loc4_];
            _loc3_ = _loc2_.userProfile;
            _loc3_.§_-L§(§_-G1p§.§_-12J§(_loc2_.hatId,_loc3_.§_-P2e§()));
            _loc3_.§_-aV§(§_-G1p§.§_-93G§(_loc2_.artifactId));
            _loc1_.push(_loc3_);
            _loc4_++;
         }
         return _loc1_;
      }
      
      public function get §_-x2k§() : Boolean
      {
         return this.§_-8T§;
      }
   }
}


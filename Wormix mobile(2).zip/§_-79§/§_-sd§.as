package §_-79§
{
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-Ey§;
   import §_-J31§.§_-R1h§;
   import §_-b1F§.§_-v2Q§;
   import §_-bI§.*;
   import §_-d26§.§_-d1H§;
   import §_-r1C§.§_-t1R§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.particle.ParticleEffect;
   import ru.pragmatix.wormix.fx.particle.ParticleEffectType;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-sd§
   {
      
      public static const §_-Z1H§:§_-11E§ = new §_-9k§();
      
      public static const §_-lA§:§_-11E§ = new §_-d17§();
      
      public static const §_-TQ§:§_-11E§ = new §_-v1W§();
      
      private static var §_-5F§:Array = [§_-p2U§.§_-w13§,§_-p2U§.§_-qr§,"zn"];
      
      private static var schemes:Object = {
         "ru":{
            "worm":§_-Z1H§,
            "boxer":§_-Z1H§,
            "demon":§_-Z1H§,
            "rabbit":§_-Z1H§,
            "zombie":§_-Z1H§,
            "cat":§_-Z1H§,
            "dragon":§_-Z1H§,
            "bot":§_-Z1H§
         },
         "en":{
            "worm":§_-lA§,
            "boxer":§_-TQ§,
            "demon":§_-TQ§,
            "rabbit":§_-lA§,
            "zombie":§_-TQ§,
            "cat":§_-lA§,
            "dragon":§_-lA§,
            "bot":§_-lA§
         },
         "zn":{
            "worm":§_-lA§,
            "boxer":§_-TQ§,
            "demon":§_-TQ§,
            "rabbit":§_-lA§,
            "zombie":§_-TQ§,
            "cat":§_-lA§,
            "dragon":§_-lA§,
            "bot":§_-lA§
         }
      };
      
      public function §_-sd§()
      {
         super();
      }
      
      public static function §_-zC§(param1:String) : §_-11E§
      {
         var _loc2_:Object = schemes[§_-X1j§.§_-82T§.§_-I9§().§_-b2§()];
         if(!_loc2_)
         {
            _loc2_ = schemes[§_-p2U§.§_-qr§.§_-b2§()];
         }
         return _loc2_[param1];
      }
      
      public static function §_-BH§() : Vector.<String>
      {
         var _loc1_:§_-p2U§ = §_-X1j§.§_-82T§.§_-I9§();
         var _loc2_:Vector.<String> = new Vector.<String>(0);
         var _loc3_:String = _loc1_.toString();
         switch(_loc3_)
         {
            case §_-p2U§.§_-w13§.toString():
         }
         _loc2_.push("sound_worm_ru");
         return _loc2_;
      }
   }
}


package §_-G2H§
{
   import §_-T1o§.§_-L3M§;
   import §_-ZP§.§_-YG§;
   import §_-ZP§.§_-w1J§;
   import com.distriqt.extension.inappbilling.BillingService;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.InAppBillingServiceTypes;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.PurchaseRequest;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import config.§_-vR§;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.utils.StringUtil;
   
   public class §_-m2E§ extends §_-527§
   {
      
      private static var §_-Be§:Boolean;
      
      private var states:Object = {};
      
      public function §_-m2E§()
      {
         super();
      }
      
      override protected function addTransactionListeners() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".addTransactionListeners... isListened=" + §_-Be§);
         }
         if(§_-Be§)
         {
            return;
         }
         §_-Be§ = true;
         super.addTransactionListeners();
      }
      
      override protected function removeTransactionListeners() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".removeTransactionListeners... isListened=" + §_-Be§);
         }
         if(!§_-Be§)
         {
            return;
         }
         §_-Be§ = false;
         super.removeTransactionListeners();
      }
      
      override protected function §_-p1N§() : Dictionary
      {
         var _loc1_:Dictionary = null;
         if(§_-vR§.§_-42H§ || §_-vR§.§_-pD§ && §_-vR§.§_-73S§)
         {
            _loc1_ = new Dictionary();
            _loc1_[§_-w1J§.INSTANT_RUBY_5] = "instant_r_1";
            _loc1_[§_-w1J§.INSTANT_RUBY_11] = "instant_r_2";
            _loc1_[§_-w1J§.INSTANT_RUBY_30] = "instant_r_5";
            _loc1_[§_-w1J§.INSTANT_RUBY_65] = "instant_r_10";
            _loc1_[§_-w1J§.INSTANT_RUBY_140] = "instant_r_20";
            _loc1_[§_-w1J§.INSTANT_RUBY_375] = "instant_r_45";
            _loc1_[§_-w1J§.INSTANT_RUBY_800] = "instant_r_75_1";
            _loc1_[§_-w1J§.INSTANT_RUBY_1100] = "instant_r_75_2";
            _loc1_[§_-w1J§.INSTANT_FUZY_500] = "instant_f_1";
            _loc1_[§_-w1J§.INSTANT_FUZY_1100] = "instant_f_2";
            _loc1_[§_-w1J§.INSTANT_FUZY_3000] = "instant_f_5";
            _loc1_[§_-w1J§.INSTANT_FUZY_6500] = "instant_f_10";
            _loc1_[§_-w1J§.INSTANT_FUZY_14000] = "instant_f_20";
            _loc1_[§_-w1J§.INSTANT_FUZY_37500] = "instant_f_45";
            _loc1_[§_-w1J§.INSTANT_FUZY_80000] = "instant_f_75";
            _loc1_[§_-w1J§.INSTANT_FUZY_110000] = "instant_f_75_2";
            _loc1_[§_-w1J§.DEPOSIT_RUBY_10] = "daily_r_1";
            _loc1_[§_-w1J§.DEPOSIT_RUBY_20] = "daily_r_2";
            _loc1_[§_-w1J§.DEPOSIT_RUBY_50] = "daily_r_5";
            _loc1_[§_-w1J§.DEPOSIT_RUBY_105] = "daily_r_10";
            _loc1_[§_-w1J§.DEPOSIT_RUBY_220] = "daily_r_20";
            _loc1_[§_-w1J§.DEPOSIT_FUZY_1000] = "daily_f_1";
            _loc1_[§_-w1J§.DEPOSIT_FUZY_2000] = "daily_f_2";
            _loc1_[§_-w1J§.DEPOSIT_FUZY_5000] = "daily_f_5";
            _loc1_[§_-w1J§.DEPOSIT_FUZY_10500] = "daily_f_10";
            _loc1_[§_-w1J§.DEPOSIT_FUZY_22000] = "daily_f_20";
            _loc1_[§_-w1J§.§_-q1B§] = "rename";
            _loc1_[§_-w1J§.VIP_7] = "subscription_vip_7_auto_off";
            _loc1_[§_-w1J§.VIP_30] = "subscription_vip_30_auto_off";
            _loc1_[§_-w1J§.VIP_7_AUTORENEW] = "subscription_vip_7";
            _loc1_[§_-w1J§.VIP_30_AUTORENEW] = "subscription_vip_30";
            _loc1_[§_-w1J§.STICKER_PACK_1] = "stickers_1";
            _loc1_[§_-w1J§.STICKER_PACK_2] = "stickers_2";
            _loc1_[§_-w1J§.BUNDLE_1] = "craft_box_1";
            _loc1_[§_-w1J§.BUNDLE_2] = "craft_box_2";
            _loc1_[§_-w1J§.CLAN_DONATION_1] = "clan_donation_1";
            _loc1_[§_-w1J§.CLAN_DONATION_2] = "clan_donation_2";
            _loc1_[§_-w1J§.CLAN_DONATION_3] = "clan_donation_3";
            _loc1_[§_-w1J§.CLAN_DONATION_4] = "clan_donation_4";
            return _loc1_;
         }
         return super.§_-p1N§();
      }
      
      override protected function §_-7e§() : void
      {
         super.§_-7e§();
         §_-11p§(§_-YG§.§_-g2g§,1,0,0.99,null,§_-w1J§.STICKER_PACK_1);
         §_-11p§(§_-YG§.§_-g2g§,1,0,0.99,null,§_-w1J§.STICKER_PACK_2);
         §_-11p§(§_-YG§.§_-H18§,1,0,4.99,null,§_-w1J§.VIP_7_AUTORENEW);
         §_-11p§(§_-YG§.§_-H18§,1,0,9.99,null,§_-w1J§.VIP_30_AUTORENEW);
      }
      
      override public function §_-j1E§() : void
      {
         var success:Boolean = false;
         super.§_-j1E§();
         try
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: isServiceSupported ( apple ) : " + InAppBilling.service.isServiceSupported(InAppBillingServiceTypes.APPLE_INAPP_PURCHASE));
            }
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: applicationReceipt : " + InAppBilling.service.applicationReceipt.isSupported);
            }
            if(InAppBilling.service.implementation == "iOS")
            {
            }
            if(InAppBilling.isSupported)
            {
               this.§_-42X§(§_-L3M§.§_-i2p§,InAppBilling.service.isServiceSupported(InAppBillingServiceTypes.APPLE_INAPP_PURCHASE));
               if(InAppBilling.service.isServiceSupported(InAppBillingServiceTypes.APPLE_INAPP_PURCHASE))
               {
                  if(!§_-527§.service)
                  {
                     §_-527§.service = new BillingService(InAppBillingServiceTypes.APPLE_INAPP_PURCHASE);
                     success = InAppBilling.service.setup(§_-527§.service);
                     if(success)
                     {
                        this.addTransactionListeners();
                     }
                     else if(§_-G3E§)
                     {
                        §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: service setup is false");
                     }
                  }
                  else if(§_-G3E§)
                  {
                     §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: service already created!");
                  }
               }
               else if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: service NOT support: " + InAppBillingServiceTypes.APPLE_INAPP_PURCHASE.toUpperCase());
               }
            }
            else if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: service NOT supported!");
            }
         }
         catch(e:Error)
         {
            §§push(e);
            §§push(e);
            var _temp_1:* = §§pop();
            _temp_1.§§slot[1] = §§pop();
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: " + _temp_1.§§slot[1].message);
            }
         }
      }
      
      override protected function §_-X26§(param1:InAppBillingEvent) : void
      {
         var _loc2_:String = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onSetupSuccess: setup success." + " canMakePayments = " + InAppBilling.service.canMakePayments + "\n, isGetPurchasesSupported = " + InAppBilling.service.isGetPurchasesSupported + "\n, applicationReceipt = " + InAppBilling.service.applicationReceipt.getAppReceipt());
         }
         this.§_-42X§(§_-L3M§.§_-F2§,InAppBilling.service.canMakePayments);
         if(InAppBilling.service.canMakePayments)
         {
            isInited = true;
            getProducts();
            _loc2_ = InAppBilling.service.applicationReceipt.getAppReceipt();
            if(!_loc2_)
            {
               this.refreshAppReceipt();
            }
         }
      }
      
      override protected function §_-nv§(param1:ProductEvent) : void
      {
         var _loc3_:String = null;
         var _loc4_:Product = null;
         var _loc5_:Boolean = false;
         var _loc6_:Product = null;
         var _loc7_:Object = null;
         super.§_-nv§(param1);
         this.§_-42X§(§_-L3M§.§_-Sg§,InAppBilling.service.isGetPurchasesSupported);
         var _loc2_:Array = [];
         for each(_loc4_ in param1.products)
         {
            _loc5_ = _loc4_.id.indexOf("vip") > -1;
            if(_loc5_)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(_loc4_.toString());
               }
            }
            if(_loc4_.subscriptionPeriod != null)
            {
            }
            products.push(_loc4_);
            _loc3_ = §_-G1j§(_loc4_.id);
            _loc2_.push(§_-82Y§(_loc3_,_loc4_.priceString));
            if(_loc5_)
            {
               _loc6_ = products[products.length - 1];
               _loc7_ = _loc2_[_loc2_.length - 1];
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§("product: " + _loc6_.id + " " + _loc6_.price);
               }
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§("parsed: " + _loc7_.id + " " + _loc7_.price);
               }
            }
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onProductsLoaded ----- products.length=" + products.length);
         }
         if(products.length > 0)
         {
            §_-41m§(_loc2_);
            this.getPurchases();
         }
      }
      
      override public function getPurchases() : void
      {
         §§push(§_-G3E§);
         this.states[§_-L3M§.§_-Sg§] = InAppBilling.service.isGetPurchasesSupported;
         this.states[§_-L3M§.§_-61W§] = InAppBilling.service.applicationReceipt.isSupported;
         dispatchEvent(§_-L3M§.create(this.states));
         super.getPurchases();
      }
      
      override protected function §_-n2d§(param1:PurchaseRequest) : void
      {
         param1.applicationUsername = §_-X1j§.§_-It§.getUserId() + "--" + StringUtil.§_-u12§(14,StringUtil.§_-n1E§);
      }
      
      override protected function §_-dw§(param1:PurchaseEvent) : void
      {
         var _loc2_:Purchase = null;
         super.§_-dw§(param1);
         if(!§_-a1H§)
         {
            return;
         }
         for each(_loc2_ in param1.data)
         {
            switch(_loc2_.transactionState)
            {
               case Purchase.STATE_PURCHASED:
                  purchased.push(_loc2_);
                  if(_loc2_.transactionReceipt)
                  {
                     this.§_-G2V§(_loc2_);
                  }
                  else if(InAppBilling.service.applicationReceipt.getAppReceipt())
                  {
                     _loc2_.transactionReceipt = InAppBilling.service.applicationReceipt.getAppReceipt();
                  }
                  else
                  {
                     this.refreshAppReceiptAndVerifyLastPurchase();
                  }
            }
         }
      }
      
      private function refreshAppReceiptAndVerifyLastPurchase() : void
      {
         /*
          * Decompilation error
          * Code may be obfuscated
          * Error type: IndexOutOfBoundsException (Index -1 out of bounds for length 0)
          */
         throw new flash.errors.IllegalOperationError("Not decompiled due to error");
      }
      
      override protected function §_-G2V§(param1:Purchase) : Object
      {
         return super.§_-G2V§(param1);
      }
      
      override protected function §_-MB§(param1:Purchase) : Object
      {
         var _loc2_:AppleVerifyReceipt = new AppleVerifyReceipt();
         _loc2_.receiptData.writeUTF(param1.transactionReceipt);
         return _loc2_;
      }
      
      override protected function §_-x1b§(param1:PurchaseEvent) : void
      {
         super.§_-x1b§(param1);
         §_-81§();
      }
      
      override public function getAppReceipt() : void
      {
         this.§_-42X§(§_-L3M§.§_-61W§,InAppBilling.service.applicationReceipt.isSupported);
         super.getAppReceipt();
      }
      
      override public function refreshAppReceipt() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".refreshAppReceipt: isInited = " + §_-527§.isInited + ", appReceipt.isSupported = " + InAppBilling.service.applicationReceipt.isSupported);
         }
         if(!isInited)
         {
            return;
         }
         this.§_-42X§(§_-L3M§.§_-61W§,InAppBilling.service.applicationReceipt.isSupported);
         super.refreshAppReceipt();
      }
      
      private function §_-42X§(param1:String, param2:Boolean) : void
      {
         var _loc3_:String = null;
         this.states[param1] = param2;
         for(_loc3_ in this.states)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".dispatchIABEventStatesWithUpdate: state " + _loc3_ + " " + this.states[_loc3_]);
            }
         }
         dispatchEvent(§_-L3M§.create(this.states));
      }
   }
}


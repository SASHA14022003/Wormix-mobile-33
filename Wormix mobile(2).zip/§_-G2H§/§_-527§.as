package §_-G2H§
{
   import §_-62§.§_-O2H§;
   import §_-DJ§.§_-fH§;
   import §_-Vg§.§_-M11§;
   import §_-Y1O§.*;
   import §_-ZP§.§_-YG§;
   import §_-q26§.§_-52J§;
   import §_-s20§.§_-J2g§;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.BillingService;
   import com.distriqt.extension.inappbilling.ErrorCodes;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.InAppBillingAvailability;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.PurchaseRequest;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionOfferRequest;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import config.§_-vR§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import feathers.data.VectorCollection;
   import flash.net.SharedObject;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-o1q§;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class §_-527§ extends §_-IL§
   {
      
      protected static var isInited:Boolean;
      
      protected static var service:BillingService;
      
      protected var §_-C2b§:Vector.<PurchaseEvent>;
      
      protected var purchased:Vector.<Purchase>;
      
      protected var products:Vector.<Product>;
      
      protected var §_-t1C§:Array;
      
      public function §_-527§()
      {
         super();
         §_-o1q§.§_-y1Q§(this.toString());
         this.purchased = new Vector.<Purchase>(0);
         this.products = new Vector.<Product>(0);
         this.§_-t1C§ = [];
      }
      
      protected static function §_-82Y§(param1:String, param2:String) : Object
      {
         var _loc5_:String = null;
         var _loc6_:String = null;
         var _loc8_:int = 0;
         param2 = param2.replace(/\s+/,"");
         var _loc3_:RegExp = /[0-9]/;
         var _loc4_:RegExp = /[^0-9]/;
         var _loc7_:int = int(param2.search(_loc3_));
         if(_loc7_ == 0)
         {
            _loc8_ = int(param2.search(_loc4_));
            _loc5_ = param2.substr(_loc8_);
            _loc7_ = int(_loc5_.search(_loc3_));
            while(_loc7_ != -1)
            {
               _loc5_ = _loc5_.substr(_loc7_);
               _loc8_ = int(_loc5_.search(_loc4_));
               _loc5_ = _loc5_.substr(_loc8_);
               _loc7_ = int(_loc5_.search(_loc3_));
            }
            _loc6_ = param2.substring(0,param2.indexOf(_loc5_));
         }
         else
         {
            _loc6_ = param2.substr(_loc7_);
            _loc5_ = param2.substring(0,_loc7_);
         }
         if(_loc6_.indexOf(",") != -1)
         {
            _loc6_ = _loc6_.replace(",",_loc6_.indexOf(".") != -1 ? "" : ".");
         }
         if(_loc5_ == "₽")
         {
            _loc5_ = "RUB";
         }
         return {
            "id":param1,
            "price":parseFloat(_loc6_),
            "currency":_loc5_
         };
      }
      
      protected function addTransactionListeners() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".addTransactionListeners...");
         }
         InAppBilling.service.addEventListener(AvailabilityEvent.COMPLETE,this.§_-ae§);
         InAppBilling.service.addEventListener(InAppBillingEvent.SETUP_SUCCESS,this.§_-X26§);
         InAppBilling.service.addEventListener(InAppBillingEvent.SETUP_FAILURE,this.§_-m1T§);
         InAppBilling.service.addEventListener(ProductEvent.PRODUCTS_LOADED,this.§_-nv§);
         InAppBilling.service.addEventListener(ProductEvent.PRODUCTS_FAILED,this.§_-N2§);
         InAppBilling.service.addEventListener(ProductEvent.INVALID_PRODUCT,this.§_-k1G§);
         InAppBilling.service.addEventListener(PurchaseEvent.GET_PURCHASES_COMPLETE,this.§_-s22§);
         InAppBilling.service.addEventListener(PurchaseEvent.GET_PURCHASES_FAILED,this.§_-Gy§);
         InAppBilling.service.addEventListener(PurchaseEvent.PURCHASES_UPDATED,this.§_-dw§);
         InAppBilling.service.addEventListener(PurchaseEvent.PURCHASE_FAILED,this.§_-T7§);
         InAppBilling.service.addEventListener(PurchaseEvent.FINISH_SUCCESS,this.§_-x1b§);
         InAppBilling.service.addEventListener(PurchaseEvent.FINISH_FAILED,this.§_-Aa§);
         InAppBilling.service.addEventListener(PurchaseEvent.CONSUME_SUCCESS,this.§_-33§);
         InAppBilling.service.addEventListener(PurchaseEvent.CONSUME_FAILED,this.§_-R1i§);
         InAppBilling.service.applicationReceipt.addEventListener(ApplicationReceiptEvent.REFRESH_SUCCESS,this.§_-h2v§);
         InAppBilling.service.applicationReceipt.addEventListener(ApplicationReceiptEvent.REFRESH_FAILED,this.§_-C3x§);
      }
      
      protected function removeTransactionListeners() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".removeTransactionListeners...");
         }
         InAppBilling.service.removeEventListener(AvailabilityEvent.COMPLETE,this.§_-ae§);
         InAppBilling.service.removeEventListener(InAppBillingEvent.SETUP_SUCCESS,this.§_-X26§);
         InAppBilling.service.removeEventListener(InAppBillingEvent.SETUP_FAILURE,this.§_-m1T§);
         InAppBilling.service.removeEventListener(ProductEvent.PRODUCTS_LOADED,this.§_-nv§);
         InAppBilling.service.removeEventListener(ProductEvent.PRODUCTS_FAILED,this.§_-N2§);
         InAppBilling.service.removeEventListener(ProductEvent.INVALID_PRODUCT,this.§_-k1G§);
         InAppBilling.service.removeEventListener(PurchaseEvent.GET_PURCHASES_COMPLETE,this.§_-s22§);
         InAppBilling.service.removeEventListener(PurchaseEvent.GET_PURCHASES_FAILED,this.§_-Gy§);
         InAppBilling.service.removeEventListener(PurchaseEvent.PURCHASES_UPDATED,this.§_-dw§);
         InAppBilling.service.removeEventListener(PurchaseEvent.PURCHASE_FAILED,this.§_-T7§);
         InAppBilling.service.removeEventListener(PurchaseEvent.FINISH_SUCCESS,this.§_-x1b§);
         InAppBilling.service.removeEventListener(PurchaseEvent.FINISH_FAILED,this.§_-Aa§);
         InAppBilling.service.removeEventListener(PurchaseEvent.CONSUME_SUCCESS,this.§_-33§);
         InAppBilling.service.removeEventListener(PurchaseEvent.CONSUME_FAILED,this.§_-R1i§);
         InAppBilling.service.applicationReceipt.removeEventListener(ApplicationReceiptEvent.REFRESH_SUCCESS,this.§_-h2v§);
         InAppBilling.service.applicationReceipt.removeEventListener(ApplicationReceiptEvent.REFRESH_FAILED,this.§_-C3x§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.disposeService();
      }
      
      protected function disposeService() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".disposeService...");
         }
         this.removeTransactionListeners();
         if(service)
         {
            InAppBilling.service.dispose();
         }
         if(this.purchased)
         {
            this.purchased.length = 0;
         }
         isInited = false;
         service = null;
      }
      
      override public function §_-j1E§() : void
      {
         try
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: isSupported : " + InAppBilling.isSupported);
            }
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: version : " + InAppBilling.service.version);
            }
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: implementation=" + InAppBilling.service.implementation);
            }
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: isGetPurchasesSupported : " + InAppBilling.service.isGetPurchasesSupported);
            }
            if(InAppBilling.service.applicationReceipt.isSupported)
            {
            }
            if(InAppBilling.isSupported)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: service IS supported!");
               }
            }
            else if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: service NOT supported!");
            }
         }
         catch(e:Error)
         {
            §§push(e);
            §§push(e);
            var _temp_1:* = §§pop();
            _temp_1.§§slot[1] = §§pop();
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadPaymentOptionsData: " + _temp_1.§§slot[1].message);
            }
         }
      }
      
      protected function §_-ae§(param1:AvailabilityEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onAvailability: " + param1.availability);
         }
         if(param1.availability == InAppBillingAvailability.AVAILABLE)
         {
            Starling.juggler.delayCall(this.getProducts,1);
         }
      }
      
      protected function §_-X26§(param1:InAppBillingEvent) : void
      {
      }
      
      protected function getProducts() : void
      {
         var _loc3_:String = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".getProducts...");
         }
         var _loc1_:Array = [];
         var _loc2_:Array = [];
         for each(_loc3_ in §_-63Y§())
         {
            if(_loc3_.indexOf("vip") > -1)
            {
               _loc2_.push(_loc3_);
            }
            else
            {
               _loc1_.push(_loc3_);
            }
         }
         _loc2_ = _loc2_.sort();
         _loc1_ = _loc1_.sort();
         for each(_loc3_ in _loc1_)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".getProducts: " + _loc3_);
            }
         }
         InAppBilling.service.getProducts(_loc1_,_loc2_);
      }
      
      private function §_-m1T§(param1:InAppBillingEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(".onSetupFailure: FAILURE! [" + param1.errorCode + "]::" + param1.message);
         }
         this.disposeService();
         setTimeout(this.§_-j1E§,§_-J2g§.§_-i1N§.isActive ? 1000 : 10000);
      }
      
      protected function §_-nv§(param1:ProductEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onProductsLoaded:" + " isGetPurchasesSupported = " + InAppBilling.service.isGetPurchasesSupported);
         }
      }
      
      protected function §_-N2§(param1:ProductEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onProductsFailed: FAILED : [" + param1.errorCode + "] " + param1.message + " - " + param1.products);
         }
         this.§_-52d§();
      }
      
      private function §_-52d§() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".paymentFetchFail: Fetching product information failed. Using default payment options");
         }
      }
      
      private function §_-k1G§(param1:ProductEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onProductInvalid: " + param1.message + " - " + param1.errorCode + " (" + §_-G1j§(param1.errorCode) + ")");
         }
      }
      
      protected function §_-41m§(param1:Array) : void
      {
         var _loc2_:Object = null;
         var _loc4_:PaymentOption = null;
         var _loc5_:Boolean = false;
         §_-a1H§ = true;
         if(Boolean(§_-y2u§) && §_-y2u§.§_-h1C§())
         {
            LayoutGroup(§_-y2u§).invalidate(FeathersControl.INVALIDATION_FLAG_DATA);
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".paymentFetchResult: Fetching products information succeeded. Length: " + param1.length);
         }
         if(param1.length > 0 && param1[0].price != §_-L2T§(param1[0].id).price)
         {
            §_-22O§ = param1[0].currency;
         }
         var _loc3_:int = 0;
         while(_loc3_ < param1.length)
         {
            _loc2_ = param1[_loc3_];
            _loc4_ = §_-L2T§(_loc2_.id);
            _loc5_ = _loc4_.code == §_-YG§.§_-qQ§;
            if(_loc5_)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(_loc3_ + "/" + param1.length + " name: " + _loc4_.name + " price: " + _loc4_.price + " << converted: " + parseFloat(_loc2_.price));
               }
            }
            _loc4_.price = parseFloat(_loc2_.price);
            if(_loc5_)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(_loc3_ + "/" + param1.length + " name: " + _loc4_.name + " price: >> " + _loc4_.price);
               }
            }
            _loc3_++;
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".paymentFetchResult -----");
         }
         §_-X1j§.§_-j14§.setCurrency(§_-71P§());
      }
      
      public function getPurchases() : void
      {
         var _loc1_:Boolean = false;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".getPurchases: isInited = " + isInited + ", isGetPurchasesSupported = " + InAppBilling.service.isGetPurchasesSupported);
         }
         if(isInited)
         {
            if(InAppBilling.service.isGetPurchasesSupported)
            {
               _loc1_ = InAppBilling.service.getPurchases();
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".getPurchases: success = " + _loc1_);
               }
            }
            else if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".getPurchases: not supported!");
            }
         }
         else if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".getPurchases: not initialised!");
         }
      }
      
      protected function §_-s22§(param1:PurchaseEvent) : void
      {
         var _loc2_:Purchase = null;
         var _loc3_:Product = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onGetPurchasesComplete:");
         }
         for each(_loc2_ in param1.data)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(_loc2_.toString());
            }
            if(_loc2_.transactionState == Purchase.STATE_PURCHASED)
            {
               _loc3_ = this.§_-6t§(_loc2_.productId);
               if(_loc3_ != null)
               {
                  if(_loc3_.type == Product.TYPE_PRODUCT)
                  {
                     this.§_-k0§(_loc2_);
                     this.consumePurchase(_loc2_.productId);
                  }
                  else if(_loc3_.type == Product.TYPE_SUBSCRIPTION)
                  {
                     this.purchased.push(_loc2_);
                     this.§_-G2V§(_loc2_);
                  }
               }
            }
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onGetPurchasesComplete =====");
         }
         this.getPendingPurchases();
      }
      
      private function §_-Gy§(param1:PurchaseEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onGetPurchasesFailed: [" + param1.errorCode + "]:" + param1.message);
         }
      }
      
      protected function §_-6t§(param1:String) : Product
      {
         var _loc2_:Product = null;
         if(this.products != null)
         {
            for each(_loc2_ in this.products)
            {
               if(_loc2_.id == param1)
               {
                  return _loc2_;
               }
            }
         }
         return null;
      }
      
      private function §_-k0§(param1:Purchase) : void
      {
         var _loc4_:Object = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".addPurchaseToInventory (" + param1.productId + ")");
         }
         var _loc2_:SharedObject = SharedObject.getLocal("iab_inventory");
         if(!_loc2_.data.hasOwnProperty("inventory"))
         {
            _loc2_.data.inventory = [];
         }
         var _loc3_:Boolean = false;
         for each(_loc4_ in _loc2_.data.inventory)
         {
            if(_loc4_.productId == param1.productId)
            {
               _loc3_ = true;
            }
         }
         if(!_loc3_)
         {
            _loc2_.data.inventory.push({
               "productId":param1.productId,
               "transactionId":param1.transactionId
            });
         }
         _loc2_.flush();
         this.§_-k1e§();
      }
      
      private function §_-k1e§() : void
      {
         var _loc2_:Object = null;
         var _loc1_:SharedObject = SharedObject.getLocal("iab_inventory");
         if(!_loc1_.data.hasOwnProperty("inventory"))
         {
            _loc1_.data.inventory = [];
         }
         for each(_loc2_ in _loc1_.data.inventory)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".loadInventory(): owned item: " + _loc2_.productId);
            }
            this.§_-t1C§.push(_loc2_);
         }
      }
      
      public function consumePurchase(param1:String) : Boolean
      {
         var _loc2_:Object = null;
         var _loc3_:Purchase = null;
         var _loc4_:Boolean = false;
         if(this.§_-t1C§.length == 0)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".consumePurchase: " + param1 + " not found in inventory. (" + this.§_-t1C§.length + ")");
            }
            return false;
         }
         for each(_loc2_ in this.§_-t1C§)
         {
            if(_loc2_.productId == param1)
            {
               this.§_-2v§(_loc2_.productId);
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".consumePurchase(): " + _loc2_.productId);
               }
               _loc3_ = new Purchase(_loc2_.productId);
               _loc4_ = InAppBilling.service.consumePurchase(_loc3_);
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".consumePurchase() = " + _loc4_);
               }
               this.§_-t1C§.splice(this.§_-t1C§.indexOf(_loc2_,1));
               return true;
            }
         }
         return false;
      }
      
      private function §_-2v§(param1:String) : void
      {
         var _loc4_:Object = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".removeItemFromInventory(" + param1 + ")");
         }
         var _loc2_:SharedObject = SharedObject.getLocal("iab_inventory");
         if(!_loc2_.data.hasOwnProperty("inventory"))
         {
            _loc2_.data.inventory = [];
         }
         var _loc3_:Array = _loc2_.data.inventory;
         this.§_-t1C§ = [];
         for each(_loc4_ in _loc3_)
         {
            if(_loc4_.productId != param1)
            {
               this.§_-t1C§.push(_loc4_);
            }
         }
         _loc2_.data.inventory = this.§_-t1C§;
         _loc2_.flush();
      }
      
      public function §_-aW§() : void
      {
         if(isInited)
         {
         }
      }
      
      protected function §_-G2V§(param1:Purchase) : Object
      {
         var _loc2_:Object = this.§_-MB§(param1);
         _loc2_.productId = param1.productId;
         _loc2_.isSubscription = param1.productId.indexOf("vip") > -1;
         _loc2_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
         sendVerifyPaymentMessage(_loc2_);
         return _loc2_;
      }
      
      protected function §_-MB§(param1:Purchase) : Object
      {
         return null;
      }
      
      public function getPendingPurchases() : void
      {
         var _loc1_:Purchase = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".getPendingPurchases:");
         }
         for each(_loc1_ in InAppBilling.service.getPendingPurchases())
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(_loc1_.toString());
            }
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".getPendingPurchases =====");
         }
         for each(_loc1_ in InAppBilling.service.getPendingPurchases())
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".getPendingPurchases: " + _loc1_.productId + " " + _loc1_.transactionState);
            }
            if(_loc1_.transactionState == Purchase.STATE_PURCHASED)
            {
            }
         }
         this.getAppReceipt();
      }
      
      public function getAppReceipt() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".getAppReceipt: isInited = " + isInited + ", appReceipt.isSupported = " + InAppBilling.service.applicationReceipt.isSupported);
         }
         if(!isInited)
         {
            return;
         }
         if(InAppBilling.service.applicationReceipt.isSupported)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".getAppReceipt: " + InAppBilling.service.applicationReceipt.getAppReceipt());
            }
            this.refreshAppReceipt();
         }
      }
      
      public function refreshAppReceipt() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".refreshAppReceipt: isInited = " + §_-527§.isInited + ", appReceipt.isSupported = " + InAppBilling.service.applicationReceipt.isSupported);
         }
         if(!isInited)
         {
            return;
         }
         if(InAppBilling.service.applicationReceipt.isSupported)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".refreshAppReceipt...");
            }
            InAppBilling.service.applicationReceipt.refresh();
         }
         else if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".refreshAppReceipt: not supported");
         }
      }
      
      private function §_-h2v§(param1:ApplicationReceiptEvent) : void
      {
      }
      
      private function §_-C3x§(param1:ApplicationReceiptEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onAppReceiptRefreshFailed " + param1.error);
         }
      }
      
      override public function updateSubscribe() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".updateSubscribe...");
         }
         this.getPurchases();
      }
      
      protected function §_-dw§(param1:PurchaseEvent) : void
      {
         var _loc2_:Purchase = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onPurchasesUpdated: [" + param1.errorCode + "]:" + param1.message + " // (" + param1.data.length + ")");
         }
         for each(_loc2_ in param1.data)
         {
            if(§_-a1H§)
            {
               var _loc5_:String = _loc2_.transactionState;
               switch(_loc5_)
               {
                  case Purchase.STATE_PURCHASING:
               }
            }
            else
            {
               if(!this.§_-C2b§)
               {
                  this.§_-C2b§ = new Vector.<PurchaseEvent>(0);
               }
               this.§_-C2b§.push(param1);
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".onPurchasesUpdated:\n incoming transaction for not ready controller - " + _loc2_.productId + " : " + _loc2_.transactionId);
               }
            }
         }
      }
      
      protected function §_-T7§(param1:PurchaseEvent) : void
      {
         §§push(§_-G3E§);
         var _loc2_:String = param1.errorCode;
         switch(_loc2_)
         {
            case ErrorCodes.BILLING_UNAVAILABLE:
               §§push(0);
               break;
            case ErrorCodes.ITEM_ALREADY_OWNED:
               §§push(1);
               break;
            default:
               switch(_loc2_)
               {
                  case ErrorCodes.RESPONSE_CANCELLED:
                     §§push(2);
                     break;
                  case ErrorCodes.USER_CANCELLED:
                     §§push(3);
                     break;
                  default:
                     §§push(4);
               }
         }
         switch(§§pop())
         {
            case 0:
               §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.HELP_ADMINISTRATION));
               break;
            case 1:
               this.getPurchases();
               break;
            case 2:
            case 3:
               break;
            default:
               if(Boolean(param1.data) && param1.data.length > 0)
               {
                  InAppBilling.service.finishPurchase(param1.data[0]);
               }
         }
         §_-81§();
      }
      
      protected function §_-x1b§(param1:PurchaseEvent) : void
      {
         var _loc2_:Purchase = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onFinishPurchaseSuccess: [" + param1.errorCode + "] " + param1.message + " - " + param1.data);
         }
         if(Boolean(param1.data) && param1.data.length > 0)
         {
            for each(_loc2_ in param1.data)
            {
               if(_loc2_.productId.indexOf("vip") == -1)
               {
                  this.§_-k0§(_loc2_);
                  this.consumePurchase(_loc2_.productId);
               }
            }
         }
      }
      
      private function §_-Aa§(param1:PurchaseEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + " finish failed: [" + param1.errorCode + "] " + param1.message + " - " + param1.data);
         }
      }
      
      private function §_-33§(param1:PurchaseEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".consume success: [" + param1.errorCode + "] " + param1.message + " - " + param1.data);
         }
      }
      
      private function §_-R1i§(param1:PurchaseEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".consume failed: [" + param1.errorCode + "] " + param1.message + " - " + param1.data);
         }
      }
      
      override protected function initPurchase(param1:String) : void
      {
         var _loc4_:Boolean = false;
         var _loc5_:PurchaseRequest = null;
         var _loc6_:Product = null;
         var _loc7_:SubscriptionOffer = null;
         var _loc8_:Boolean = false;
         var _loc2_:String = §_-G1j§(param1);
         var _loc3_:PaymentOption = §_-L2T§(_loc2_);
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".initPurchase: platformProductId = " + param1);
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".initPurchase: InGameProductId " + _loc2_);
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".initPurchase: (by InGameProductId) \n" + _loc3_);
         }
         if(_loc3_)
         {
            _loc4_ = _loc3_.code == §_-YG§.§_-qQ§;
            _loc5_ = new PurchaseRequest(param1);
            this.§_-n2d§(_loc5_);
            if(_loc4_)
            {
               _loc6_ = this.§_-6t§(param1);
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".initPurchase: << product = " + _loc6_);
               }
               _loc7_ = _loc6_.subscriptionOffers[0];
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".initPurchase: << offer = " + _loc7_);
               }
               _loc5_.setSubscriptionOfferRequest(new SubscriptionOfferRequest().setSubscriptionOffer(_loc7_));
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".initPurchase: >> request.offer = " + _loc5_.subscriptionOfferRequest);
               }
            }
            if(InAppBilling.service.checkPurchaseRequestValid(_loc5_))
            {
               _loc8_ = InAppBilling.service.makePurchase(_loc5_);
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".initPurchase: checkPurchaseRequestValid success = " + _loc8_ + ", r.aun=\n" + _loc5_.applicationUsername);
               }
            }
            else
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".initPurchase: checkPurchaseRequestValid - invalid request");
               }
               §_-fH§.§_-h2r§(§_-s2a§.TITLE_ERROR,"wrong purchase request :(");
            }
            return;
         }
         throw new Error("initPurchase:: (" + param1 + ") price option by \'" + _loc2_ + "\' not found!");
      }
      
      protected function §_-n2d§(param1:PurchaseRequest) : void
      {
      }
      
      override protected function processSuccessReceiptResult(param1:VerifyPaymentResult) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".processSuccessReceiptResult... ");
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ": " + param1);
         }
         if(§_-vR§.§_-42H§ || §_-vR§.§_-pD§ && §_-vR§.§_-73S§)
         {
            this.§_-j13§(param1);
         }
         super.processSuccessReceiptResult(param1);
      }
      
      override protected function §_-Hr§(param1:VerifyPaymentResult) : void
      {
         var _loc2_:Boolean = false;
         if(§_-vR§.§_-42H§ || §_-vR§.§_-pD§ && §_-vR§.§_-73S§)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".processFailedReceiptResult: response.result = " + param1.result);
            }
            _loc2_ = false;
            if(param1.result == §_-12x§)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".processFailedReceiptResult: purchase " + param1.item + " is already purchased");
               }
               _loc2_ = true;
            }
            else
            {
               super.§_-Hr§(param1);
            }
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".processFailedReceiptResult: readyToFinish = " + _loc2_);
            }
            if(_loc2_)
            {
               this.§_-j13§(param1);
            }
         }
         else
         {
            super.§_-Hr§(param1);
         }
      }
      
      protected function §_-j13§(param1:VerifyPaymentResult) : void
      {
         var _loc5_:Purchase = null;
         var _loc2_:String = param1.item;
         var _loc3_:String = §_-G1j§(_loc2_);
         var _loc4_:PaymentOption = §_-L2T§(_loc3_);
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryingToFinish: " + param1.item);
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryingToFinish: inGameProductId = " + _loc3_);
         }
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryingToFinish: option = " + _loc4_);
         }
         for each(_loc5_ in this.purchased)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".tryingToFinish: " + _loc5_.productId + " " + _loc5_.transactionState);
            }
            if(_loc5_.productId == _loc2_)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".tryingToFinish: found in purchased...");
               }
               this.purchased.splice(this.purchased.indexOf(_loc5_),1);
               InAppBilling.service.finishPurchase(_loc5_);
               break;
            }
         }
      }
      
      protected function §_-G2b§() : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryProcessEarlyQueue: " + this.§_-C2b§);
         }
         if(Boolean(this.§_-C2b§) && Boolean(this.§_-C2b§.length))
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".tryProcessEarlyQueue: -> onPurchasesUpdated...");
            }
            this.§_-dw§(this.§_-C2b§.shift());
         }
      }
      
      protected function §_-C2X§(param1:VerifyPaymentResult) : void
      {
         var _loc5_:Purchase = null;
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryingToConsume: " + param1.item);
         }
         var _loc2_:String = param1.item;
         var _loc3_:String = §_-G1j§(_loc2_);
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryingToConsume: inGameProductId = " + _loc3_);
         }
         var _loc4_:PaymentOption = §_-L2T§(_loc3_);
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".tryingToConsume: option = " + _loc4_);
         }
         if(_loc4_.code != §_-YG§.§_-qQ§)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".tryingToConsume: " + _loc2_);
            }
            for each(_loc5_ in this.purchased)
            {
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".tryingToConsume: " + _loc5_.productId + " " + _loc5_.transactionState);
               }
            }
         }
      }
      
      public function §_-W2y§() : void
      {
         var _loc1_:Array = null;
         var _loc2_:Boolean = false;
         if(isInited)
         {
            _loc1_ = InAppBilling.service.getPendingPurchases();
            if(_loc1_.length > 0)
            {
               _loc2_ = InAppBilling.service.finishPurchase(_loc1_[0]);
               if(§_-G3E§)
               {
                  §_-X1j§.§_-NA§(this + ".finishPurchase() = " + _loc2_);
               }
            }
            else if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".NO PENDING PURCHASES");
            }
         }
      }
      
      public function finishPurchase() : void
      {
         var _loc1_:Purchase = null;
         var _loc2_:Boolean = false;
         if(isInited && this.purchased.length > 0)
         {
            _loc1_ = this.purchased.shift();
            _loc2_ = InAppBilling.service.finishPurchase(_loc1_);
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".finishPurchase() = " + _loc2_);
            }
         }
      }
      
      public function §_-A1B§() : void
      {
         if(this.purchased.length > 0)
         {
            this.§_-k0§(this.purchased[0]);
         }
      }
      
      public function restorePurchases() : void
      {
         if(isInited)
         {
            if(§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".restorePurchases");
            }
            InAppBilling.service.restorePurchases();
         }
      }
      
      protected function onRestorePurchasesSuccess(param1:InAppBillingEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onRestorePurchasesSuccess");
         }
      }
      
      protected function onRestorePurchasesFailed(param1:InAppBillingEvent) : void
      {
         if(§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onRestorePurchasesFailed");
         }
      }
   }
}


package §_-G2H§
{
   import §_-5Y§.§_-h2c§;
   import com.distriqt.extension.inappbilling.BillingService;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.InAppBillingServiceTypes;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import config.§_-vR§;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   
   public class §_-B2n§ extends §_-527§
   {
      
      public function §_-B2n§()
      {
         super();
      }
      
      override public function §_-j1E§() : void
      {
         var success:Boolean = false;
         super.§_-j1E§();
         try
         {
            if(InAppBilling.service.implementation == "Android")
            {
            }
            if(InAppBilling.isSupported)
            {
               if(InAppBilling.service.isServiceSupported(InAppBillingServiceTypes.GOOGLE_PLAY_INAPP_BILLING))
               {
                  if(!service)
                  {
                     service = new BillingService().setGooglePlayPublicKey(§_-vR§.§_-s5§);
                     success = InAppBilling.service.setup(service);
                     if(success)
                     {
                        addTransactionListeners();
                     }
                  }
               }
            }
         }
         catch(e:Error)
         {
         }
      }
      
      override protected function §_-X26§(param1:InAppBillingEvent) : void
      {
         if(InAppBilling.service.canMakePayments)
         {
            isInited = true;
            InAppBilling.service.checkAvailability();
            if(InAppBilling.service.isShowManageSubscriptionsSupported)
            {
            }
         }
      }
      
      override protected function §_-nv§(param1:ProductEvent) : void
      {
         var _loc3_:String = null;
         var _loc4_:Product = null;
         var _loc5_:Boolean = false;
         var _loc6_:SubscriptionOffer = null;
         var _loc7_:SubscriptionPhase = null;
         var _loc8_:Product = null;
         var _loc9_:Object = null;
         super.§_-nv§(param1);
         var _loc2_:Array = [];
         for each(_loc4_ in param1.products)
         {
            _loc5_ = _loc4_.id.indexOf("vip") > -1;
            if(_loc5_)
            {
            }
            for each(_loc6_ in _loc4_.subscriptionOffers)
            {
               _loc6_.id;
               _loc6_.offerId;
               _loc6_.tags;
               _loc6_.token;
               _loc6_.requiresSignature;
               _loc6_.storeDeterminedEligible;
               for each(_loc7_ in _loc6_.pricingPhases)
               {
                  if(!_loc4_.priceString && Boolean(_loc7_.priceString))
                  {
                     _loc4_.priceString = _loc7_.priceString.concat();
                  }
               }
            }
            if(_loc4_.subscriptionPeriod != null)
            {
            }
            products.push(_loc4_);
            _loc3_ = §_-G1j§(_loc4_.id);
            _loc2_.push(§_-82Y§(_loc3_,_loc4_.priceString));
            if(_loc5_)
            {
               _loc8_ = products[products.length - 1];
               _loc9_ = _loc2_[_loc2_.length - 1];
            }
         }
         §_-41m§(_loc2_);
         getPurchases();
      }
      
      override protected function §_-N2§(param1:ProductEvent) : void
      {
         super.§_-N2§(param1);
         Starling.juggler.delayCall(getProducts,10);
      }
      
      override protected function §_-dw§(param1:PurchaseEvent) : void
      {
         var _loc2_:Purchase = null;
         super.§_-dw§(param1);
         if(!§_-a1H§)
         {
            return;
         }
         for each(_loc2_ in param1.data)
         {
            switch(_loc2_.transactionState)
            {
               case Purchase.STATE_PURCHASED:
                  purchased.push(_loc2_);
                  §_-G2V§(_loc2_);
            }
         }
      }
      
      override protected function §_-MB§(param1:Purchase) : Object
      {
         var _loc2_:GoogleValidateInappPurchase = new GoogleValidateInappPurchase();
         _loc2_.purchaseToken = param1.transactionId;
         return _loc2_;
      }
   }
}


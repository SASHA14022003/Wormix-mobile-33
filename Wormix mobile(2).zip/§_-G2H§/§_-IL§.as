package §_-G2H§
{
   import §_-5Y§.§_-t2O§;
   import §_-72j§.§_-N19§;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-p2U§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-SP§.§_-M4§;
   import §_-Ta§.§_-G18§;
   import §_-YF§.§_-L29§;
   import §_-ZP§.§_-YG§;
   import §_-ZP§.§_-b23§;
   import §_-ZP§.§_-w1J§;
   import §_-eW§.§_-Zt§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-w2W§.§_-21w§;
   import config.§_-vR§;
   import feathers.core.PopUpManager;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.lang.EnLangController;
   import ru.pragmatix.flox.social.lang.ILangController;
   import ru.pragmatix.flox.social.lang.RuLangController;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.social.utils.FacebookTracking;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.EnterFrameEvent;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-IL§ extends §_-Zt§
   {
      
      protected var §_-y2u§:§_-G18§;
      
      protected var §_-VS§:Boolean;
      
      private var §_-Y2l§:String = "USD";
      
      private var §_-u1u§:Dictionary;
      
      private var §_-22m§:Dictionary;
      
      private var §_-sZ§:Dictionary;
      
      private var §_-32F§:int;
      
      protected var §_-G3E§:Boolean;
      
      public function §_-IL§()
      {
         super();
         this.§_-u1u§ = this.§_-p1N§();
         this.§_-7e§();
      }
      
      protected function §_-p1N§() : Dictionary
      {
         var _loc1_:Dictionary = new Dictionary();
         _loc1_[§_-w1J§.INSTANT_RUBY_5] = "new_ruby5";
         _loc1_[§_-w1J§.INSTANT_RUBY_11] = "new_ruby10";
         _loc1_[§_-w1J§.INSTANT_RUBY_30] = "new_ruby27";
         _loc1_[§_-w1J§.INSTANT_RUBY_65] = "new_ruby55";
         _loc1_[§_-w1J§.INSTANT_RUBY_140] = "new_ruby112";
         _loc1_[§_-w1J§.INSTANT_RUBY_375] = "new_ruby285";
         _loc1_[§_-w1J§.INSTANT_RUBY_800] = "new_ruby600";
         _loc1_[§_-w1J§.INSTANT_RUBY_1100] = "new_ruby1100";
         _loc1_[§_-w1J§.INSTANT_FUZY_500] = "new_fuzy500";
         _loc1_[§_-w1J§.INSTANT_FUZY_1100] = "new_fuzy1000";
         _loc1_[§_-w1J§.INSTANT_FUZY_3000] = "new_fuzy2700";
         _loc1_[§_-w1J§.INSTANT_FUZY_6500] = "new_fuzy5500";
         _loc1_[§_-w1J§.INSTANT_FUZY_14000] = "new_fuzy11200";
         _loc1_[§_-w1J§.INSTANT_FUZY_37500] = "new_fuzy28500";
         _loc1_[§_-w1J§.INSTANT_FUZY_80000] = "new_fuzy60000";
         _loc1_[§_-w1J§.INSTANT_FUZY_110000] = "new_fuzy110000";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_10] = "daily_ruby10";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_20] = "daily_ruby20";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_50] = "daily_ruby50";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_105] = "daily_ruby105";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_220] = "daily_ruby220";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_1000] = "daily_fuzy1000";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_2000] = "daily_fuzy2000";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_5000] = "daily_fuzy5000";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_10500] = "daily_fuzy10500";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_22000] = "daily_fuzy22000";
         _loc1_[§_-w1J§.§_-q1B§] = "rename";
         _loc1_[§_-w1J§.VIP_7] = "vip7";
         _loc1_[§_-w1J§.VIP_30] = "vip30";
         _loc1_[§_-w1J§.VIP_7_AUTORENEW] = "";
         _loc1_[§_-w1J§.VIP_30_AUTORENEW] = "";
         _loc1_[§_-w1J§.STICKER_PACK_1] = "stickers_1";
         _loc1_[§_-w1J§.STICKER_PACK_2] = "stickers_2";
         _loc1_[§_-w1J§.BUNDLE_1] = "craft_box_1";
         _loc1_[§_-w1J§.BUNDLE_2] = "craft_box_2";
         _loc1_[§_-w1J§.CLAN_DONATION_1] = "clan_donation_1";
         _loc1_[§_-w1J§.CLAN_DONATION_2] = "clan_donation_2";
         _loc1_[§_-w1J§.CLAN_DONATION_3] = "clan_donation_3";
         _loc1_[§_-w1J§.CLAN_DONATION_4] = "clan_donation_4";
         return _loc1_;
      }
      
      protected function §_-7e§() : void
      {
         this.§_-22m§ = new Dictionary();
         this.§_-sZ§ = new Dictionary();
         this.§_-11p§(§_-YG§.§_-92s§,5,0,1,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_5);
         this.§_-11p§(§_-YG§.§_-92s§,10,1,2,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_11);
         this.§_-11p§(§_-YG§.§_-92s§,25,5,5,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_30);
         this.§_-11p§(§_-YG§.§_-92s§,50,15,10,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_65);
         this.§_-11p§(§_-YG§.§_-92s§,100,40,20,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_140);
         this.§_-11p§(§_-YG§.§_-92s§,250,125,45,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_375);
         this.§_-11p§(§_-YG§.§_-92s§,500,300,75,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_800);
         this.§_-11p§(§_-YG§.§_-92s§,500,600,75,§_-E19§.§_-51D§,§_-w1J§.INSTANT_RUBY_1100);
         this.§_-11p§(§_-YG§.§_-92s§,500,0,1,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_500);
         this.§_-11p§(§_-YG§.§_-92s§,1000,100,2,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_1100);
         this.§_-11p§(§_-YG§.§_-92s§,2500,500,5,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_3000);
         this.§_-11p§(§_-YG§.§_-92s§,5000,1500,10,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_6500);
         this.§_-11p§(§_-YG§.§_-92s§,10000,4000,20,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_14000);
         this.§_-11p§(§_-YG§.§_-92s§,25000,12500,45,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_37500);
         this.§_-11p§(§_-YG§.§_-92s§,50000,30000,75,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_80000);
         this.§_-11p§(§_-YG§.§_-92s§,50000,60000,75,§_-E19§.§_-i2d§,§_-w1J§.INSTANT_FUZY_110000);
         this.§_-11p§(§_-YG§.§_-U1V§,10,0,1,§_-E19§.§_-51D§,§_-w1J§.DEPOSIT_RUBY_10);
         this.§_-11p§(§_-YG§.§_-U1V§,20,0,2,§_-E19§.§_-51D§,§_-w1J§.DEPOSIT_RUBY_20);
         this.§_-11p§(§_-YG§.§_-U1V§,50,0,5,§_-E19§.§_-51D§,§_-w1J§.DEPOSIT_RUBY_50);
         this.§_-11p§(§_-YG§.§_-U1V§,100,5,10,§_-E19§.§_-51D§,§_-w1J§.DEPOSIT_RUBY_105);
         this.§_-11p§(§_-YG§.§_-U1V§,200,20,20,§_-E19§.§_-51D§,§_-w1J§.DEPOSIT_RUBY_220);
         this.§_-11p§(§_-YG§.§_-U1V§,1000,0,1,§_-E19§.§_-i2d§,§_-w1J§.DEPOSIT_FUZY_1000);
         this.§_-11p§(§_-YG§.§_-U1V§,2000,0,2,§_-E19§.§_-i2d§,§_-w1J§.DEPOSIT_FUZY_2000);
         this.§_-11p§(§_-YG§.§_-U1V§,5000,0,5,§_-E19§.§_-i2d§,§_-w1J§.DEPOSIT_FUZY_5000);
         this.§_-11p§(§_-YG§.§_-U1V§,10000,500,10,§_-E19§.§_-i2d§,§_-w1J§.DEPOSIT_FUZY_10500);
         this.§_-11p§(§_-YG§.§_-U1V§,20000,2000,20,§_-E19§.§_-i2d§,§_-w1J§.DEPOSIT_FUZY_22000);
         this.§_-11p§(§_-YG§.OTHER,1,0,2.99,null,§_-w1J§.§_-q1B§);
         this.§_-11p§(§_-YG§.§_-qQ§,1,0,4.99,null,§_-w1J§.VIP_7);
         this.§_-11p§(§_-YG§.§_-qQ§,1,0,9.99,null,§_-w1J§.VIP_30);
         this.§_-11p§(§_-YG§.§_-g2g§,1,0,1.5,null,§_-w1J§.STICKER_PACK_1);
         this.§_-11p§(§_-YG§.§_-g2g§,1,0,1.5,null,§_-w1J§.STICKER_PACK_2);
         this.§_-11p§(§_-YG§.§_-e2Q§,1,0,4.99,null,§_-w1J§.BUNDLE_1);
         this.§_-11p§(§_-YG§.§_-e2Q§,2,0,8.99,null,§_-w1J§.BUNDLE_2);
         this.§_-11p§(§_-YG§.§_-f29§,30,10,5,§_-E19§.§_-51D§,§_-w1J§.CLAN_DONATION_1);
         this.§_-11p§(§_-YG§.§_-f29§,65,22,10,§_-E19§.§_-51D§,§_-w1J§.CLAN_DONATION_2);
         this.§_-11p§(§_-YG§.§_-f29§,140,47,20,§_-E19§.§_-51D§,§_-w1J§.CLAN_DONATION_3);
         this.§_-11p§(§_-YG§.§_-f29§,375,125,45,§_-E19§.§_-51D§,§_-w1J§.CLAN_DONATION_4);
      }
      
      protected function §_-11p§(param1:uint, param2:uint, param3:uint, param4:Number, param5:§_-E19§, param6:String = null, param7:String = null) : void
      {
         this.§_-22m§[param6] = PaymentOption.createBonusOption(param1,param2,param3,param4,param5,param6,param7);
         this.§_-sZ§[param6] = PaymentOption.createBonusOption(param1,param2,param3,param4,param5,param6,param7);
      }
      
      protected function §_-63Y§() : Array
      {
         var _loc2_:String = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this.§_-u1u§)
         {
            if(_loc2_)
            {
               _loc1_.push(_loc2_);
            }
         }
         return _loc1_;
      }
      
      override public function §_-G1j§(param1:String) : String
      {
         var _loc2_:String = null;
         for(_loc2_ in this.§_-u1u§)
         {
            if(this.§_-u1u§[_loc2_] == param1)
            {
               return _loc2_;
            }
         }
         throw new Error(this + ": Not found platformProductId (" + param1 + ") by inGameProductId\'s!");
      }
      
      override public function dispose() : void
      {
         this.§_-f2S§();
         this.§_-22m§ = null;
         this.§_-u1u§ = null;
      }
      
      private function exit(param1:Event = null) : void
      {
         this.§_-f2S§();
      }
      
      private function §_-f2S§() : void
      {
         if(this.§_-y2u§)
         {
            this.§_-y2u§.removeEventListener(§_-M4§.WINDOW_CANCEL,this.exit);
            this.§_-y2u§.removeEventListener(§_-M4§.WINDOW_CLOSE,this.exit);
            this.§_-y2u§.hide();
            if(!Application.§_-E1k§.§_-w18§(§_-21w§.§_-81H§))
            {
               §_-L29§.§_-gs§(§_-21w§.§_-81H§);
            }
            this.§_-y2u§.dispose();
            this.§_-y2u§ = null;
         }
      }
      
      override public function §_-B1f§(param1:int = -1) : void
      {
         this.§_-32F§ = param1;
         if(this.§_-y2u§)
         {
            this.§_-f2S§();
         }
         §_-J2l§.§_-u2b§.show(this.§_-PT§);
      }
      
      private function §_-PT§() : void
      {
         if(!Application.§_-E1k§.§_-w18§(§_-21w§.§_-81H§))
         {
            §_-L29§.§_-d2x§(§_-21w§.§_-81H§,this.§_-rd§);
         }
         else
         {
            this.§_-rd§();
         }
      }
      
      override public function §_-JC§() : Boolean
      {
         return Boolean(this.§_-y2u§) && this.§_-y2u§.§_-h1C§();
      }
      
      public function §_-rd§() : void
      {
         if(!this.§_-y2u§)
         {
            this.§_-y2u§ = §_-N19§.create(§_-X1j§.§_-It§.getPlatformType());
            this.§_-y2u§.addEventListener(§_-M4§.WINDOW_CANCEL,this.exit);
            this.§_-y2u§.addEventListener(§_-M4§.WINDOW_CLOSE,this.exit);
         }
         Starling.current.stage.addEventListener(Event.ENTER_FRAME,this.onEnterFrame);
      }
      
      private function onEnterFrame(param1:EnterFrameEvent) : void
      {
         Starling.current.stage.removeEventListener(Event.ENTER_FRAME,this.onEnterFrame);
         §_-J2l§.§_-u2b§.hide();
         this.§_-y2u§.§_-u2e§(this.§_-32F§);
         this.§_-y2u§.show();
      }
      
      override public function get isBankOpened() : Boolean
      {
         return Boolean(this.§_-y2u§) && this.§_-y2u§.§_-h1C§();
      }
      
      override public function §_-O1W§() : void
      {
         if(PopUpManager.isTopLevelPopUp(this.§_-y2u§ as DisplayObject))
         {
            if(this.§_-y2u§.isSubpanelOpened)
            {
               this.§_-y2u§.§_-52u§();
            }
            else
            {
               this.§_-I19§();
            }
         }
         else
         {
            §_-YQ§.§_-33S§();
         }
      }
      
      override public function §_-I19§() : void
      {
         if(this.§_-y2u§)
         {
            this.exit();
         }
      }
      
      override public function §_-F1I§(param1:String) : void
      {
         var _loc2_:String = this.§_-u1u§[param1];
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".callPayController: " + _loc2_ + " // " + param1);
         }
         if(Boolean(_loc2_) && _loc2_ != "")
         {
            this.§_-VS§ = true;
            if(this.§_-G3E§)
            {
               §_-X1j§.§_-NA§(this + ".callPayController: isPurchasing << " + this.§_-VS§);
            }
            §_-J2l§.§_-u2b§.show(this.§_-c1U§,_loc2_);
         }
         else if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".callPayController: Error! ProductId not found!");
         }
      }
      
      private function §_-c1U§(param1:String) : void
      {
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".startPurchase: " + param1 + " " + §_-vR§.§_-42H§ + " " + §_-vR§.§_-pD§ + " " + §_-vR§.§_-73S§);
         }
         if(§_-vR§.§_-42H§ || §_-vR§.§_-pD§ && §_-vR§.§_-73S§)
         {
            this.initPurchase(param1);
         }
         else
         {
            this.§_-D3i§(param1);
         }
      }
      
      protected function initPurchase(param1:String) : void
      {
         this.§_-81§();
      }
      
      protected function §_-D3i§(param1:String) : void
      {
         var _loc4_:Object = null;
         var _loc2_:String = this.§_-G1j§(param1);
         var _loc3_:PaymentOption = this.§_-L2T§(_loc2_);
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + " initTestPurchase, << name = " + _loc3_.name);
         }
         switch(SystemUtil.platform)
         {
            case §_-WK§.IOS:
            case §_-WK§.§_-c1l§:
         }
         _loc4_ = new GoogleValidateInappPurchase();
         _loc4_.productId = this.§_-u1u§[_loc3_.name];
         _loc4_.isSubscription = _loc3_.code == §_-YG§.§_-qQ§;
         _loc4_.purchaseToken = StringUtil.§_-u12§(256);
         _loc4_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + " initTestPurchase, >> productId = " + _loc4_.productId);
         }
         if(_loc4_)
         {
            this.sendVerifyPaymentMessage(_loc4_);
         }
      }
      
      protected function §_-81§() : void
      {
         this.§_-VS§ = false;
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".completePurchase: isPurchasing >> " + this.§_-VS§);
         }
         §_-J2l§.§_-u2b§.hide();
         if(Boolean(this.§_-y2u§) && Boolean(Application.userProfile))
         {
            this.§_-y2u§.§_-oG§(Application.userProfile);
         }
      }
      
      protected function sendVerifyPaymentMessage(param1:Object) : void
      {
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".sendVerifyPaymentMessage...");
         }
         §_-d21§.§_-51l§(param1,VerifyPaymentResult,this.onVerifyReceiptResult,this.§_-B3z§);
      }
      
      override public function §_-71P§() : String
      {
         return this.§_-Y2l§;
      }
      
      override public function §_-L2T§(param1:String) : PaymentOption
      {
         if(!this.§_-22m§[param1])
         {
            if(this.§_-G3E§)
            {
               §_-X1j§.§_-NA§("getItemPriceOptionByInGameProductId: Error!!! price option by \'" + param1 + "\' not found!");
            }
         }
         return this.§_-22m§[param1];
      }
      
      override public function §_-B12§(param1:String) : PaymentOption
      {
         if(!this.§_-sZ§[param1])
         {
            if(this.§_-G3E§)
            {
               §_-X1j§.§_-NA§("getItemPriceOptionUsdByInGameProductId: Error!!! price option by \'" + param1 + "\' not found!");
            }
         }
         return this.§_-sZ§[param1];
      }
      
      private function onVerifyReceiptResult(param1:§_-63i§, ... rest) : void
      {
         var _loc3_:VerifyPaymentResult = VerifyPaymentResult(param1.message);
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + ".onVerifyReceiptResult/onVerifyPaymentResult:" + " result = " + Result.toString(_loc3_.result) + "(" + _loc3_.result + ")" + "\n, productKey = " + _loc3_.item + "\n, args=" + rest);
         }
         if(_loc3_.result == Result.SUCCESS)
         {
            this.processSuccessReceiptResult(_loc3_);
         }
         else
         {
            this.§_-Hr§(_loc3_);
         }
         this.§_-81§();
      }
      
      private function §_-B3z§(param1:*, ... rest) : void
      {
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + " onVerifyReceiptError: " + " connect is opened=" + §_-J2g§.§_-i1N§.isOpened + " and active=" + §_-J2g§.§_-i1N§.isActive + ", " + param1 + ", args=" + rest);
         }
         var _loc3_:VerifyPaymentResult = new VerifyPaymentResult();
         _loc3_.result = Result.ERROR;
         this.§_-Hr§(_loc3_);
         this.§_-81§();
      }
      
      protected function processSuccessReceiptResult(param1:VerifyPaymentResult) : void
      {
         if(this.§_-G3E§)
         {
            §_-X1j§.§_-NA§(this + " processSuccessReceiptResult " + param1.item);
         }
         §_-X1j§.§_-w24§.§_-11w§(§_-72u§.§_-5L§());
         var _loc2_:String = param1.item;
         var _loc3_:String = this.§_-G1j§(_loc2_);
         var _loc4_:PaymentOption = this.§_-L2T§(_loc3_);
         switch(_loc4_.code)
         {
            case §_-YG§.§_-92s§:
               §_-X1j§.§_-P2t§.§_-T1h§(param1);
               break;
            case §_-YG§.OTHER:
               if(_loc4_.name == §_-w1J§.§_-q1B§)
               {
                  §_-X1j§.§_-G3m§.§_-G2f§();
               }
               break;
            case §_-YG§.§_-g2g§:
               §_-X1j§.§_-P2t§.§_-qp§(param1);
               break;
            case §_-YG§.§_-e2Q§:
               §_-X1j§.§_-P2t§.§_-Vb§(param1);
               break;
            case §_-YG§.§_-qQ§:
               Application.userProfile.§_-W2K§();
               if(Boolean(this.§_-y2u§) && Boolean(this.§_-y2u§.§_-s1E§))
               {
                  this.§_-y2u§.§_-s1E§.update();
                  FacebookTracking.trackPurchased(_loc4_,_loc2_);
                  §_-X1j§.§_-j14§.trackSubscribe(_loc4_);
               }
         }
         if(_loc4_.code != §_-YG§.§_-qQ§)
         {
            FacebookTracking.trackPurchased(_loc4_,_loc2_);
            §_-X1j§.§_-j14§.trackPurchased(_loc4_);
         }
      }
      
      protected function §_-Hr§(param1:VerifyPaymentResult) : void
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         var _loc5_:String = SystemUtil.platform;
         switch(_loc5_)
         {
            case §_-WK§.§_-c1l§:
               §§push(0);
               break;
            case §_-WK§.IOS:
               §§push(1);
               break;
            default:
               switch(_loc5_)
               {
                  case §_-WK§.WIN:
                     §§push(2);
                     break;
                  case §_-WK§.MAC:
                     §§push(3);
                     break;
                  default:
                     §§push(4);
               }
         }
         switch(§§pop())
         {
            case 0:
               _loc2_ = §_-s2a§.RECEIPT_VERIFICATION_ERROR_GOOGLE;
               break;
            case 1:
               _loc2_ = §_-s2a§.RECEIPT_VERIFICATION_ERROR_APPLE;
               break;
            case 2:
            case 3:
               _loc2_ = §_-s2a§.RECEIPT_VERIFICATION_ERROR_STEAM;
         }
         if(_loc2_)
         {
            _loc3_ = param1.transactionId;
            _loc4_ = _loc3_ ? "\n(" + _loc3_.substr(0,5) + "**..**" + _loc3_.substring(_loc3_.length - 5) + ")" : "";
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(_loc2_) + _loc4_,§_-fH§.§_-1B§);
         }
      }
      
      override public function §_-j1E§() : void
      {
      }
      
      override public function §_-71Z§(param1:uint) : Array
      {
         var _loc3_:PaymentOption = null;
         var _loc2_:Array = [];
         for each(_loc3_ in this.§_-22m§)
         {
            if(_loc3_.code == param1)
            {
               _loc2_.push(_loc3_);
            }
         }
         return _loc2_;
      }
      
      override public function §_-WE§() : Array
      {
         var _loc1_:Array = [§_-b23§.§_-92s§,§_-b23§.§_-U1V§,§_-b23§.§_-qQ§,§_-b23§.§_-e2Q§];
         if(Application.userProfile.§_-ia§())
         {
            _loc1_.push(§_-b23§.§_-f29§);
         }
         return _loc1_;
      }
      
      public function set §_-22O§(param1:String) : void
      {
         this.§_-Y2l§ = param1;
      }
   }
}


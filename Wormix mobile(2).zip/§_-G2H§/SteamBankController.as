package §_-G2H§
{
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.*;
   import §_-DJ§.§_-fH§;
   import §_-ZP§.§_-b23§;
   import §_-ZP§.§_-w1J§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import com.amanitadesign.steam.FRESteamWorks;
   import com.amanitadesign.steam.MicroTxnAuthorizationResponse;
   import com.amanitadesign.steam.SteamConstants;
   import com.amanitadesign.steam.SteamEvent;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.steam.SteamWorks;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.SteamProductsInfoRequest;
   import ru.pragmatix.wormix.messages.client.SteamTransactionCommitRequest;
   import ru.pragmatix.wormix.messages.client.SteamTransactionInitRequest;
   import ru.pragmatix.wormix.messages.server.SteamProductsInfoResponse;
   import ru.pragmatix.wormix.messages.server.SteamTransactionCommitResponse;
   import ru.pragmatix.wormix.messages.server.SteamTransactionInitResponse;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.SteamProductInfoStructure;
   import ru.pragmatix.wormix.messages.utils.Result;
   
   public class SteamBankController extends §_-IL§
   {
      
      private static const §_-81F§:String = "SteamBankController";
      
      private var steamworks:FRESteamWorks;
      
      private var purchaseTransactionId:String;
      
      private var §_-335§:§_-11S§;
      
      public function SteamBankController()
      {
         super();
         this.steamworks = SteamWorks.getInstance();
         this.§_-335§ = new §_-11S§(SteamBankController);
         if(this.steamworks.isReady)
         {
            this.steamworks.addEventListener(SteamEvent.STEAM_RESPONSE,this.§_-i1j§);
         }
      }
      
      override protected function §_-p1N§() : Dictionary
      {
         var _loc1_:Dictionary = new Dictionary();
         _loc1_[§_-w1J§.INSTANT_RUBY_5] = "instant_ruby_5";
         _loc1_[§_-w1J§.INSTANT_RUBY_11] = "instant_ruby_11";
         _loc1_[§_-w1J§.INSTANT_RUBY_30] = "instant_ruby_30";
         _loc1_[§_-w1J§.INSTANT_RUBY_65] = "instant_ruby_65";
         _loc1_[§_-w1J§.INSTANT_RUBY_140] = "instant_ruby_140";
         _loc1_[§_-w1J§.INSTANT_RUBY_375] = "instant_ruby_375";
         _loc1_[§_-w1J§.INSTANT_RUBY_800] = "instant_ruby_800";
         _loc1_[§_-w1J§.INSTANT_FUZY_500] = "instant_fuzy_500";
         _loc1_[§_-w1J§.INSTANT_FUZY_1100] = "instant_fuzy_1100";
         _loc1_[§_-w1J§.INSTANT_FUZY_3000] = "instant_fuzy_3000";
         _loc1_[§_-w1J§.INSTANT_FUZY_6500] = "instant_fuzy_6500";
         _loc1_[§_-w1J§.INSTANT_FUZY_14000] = "instant_fuzy_14000";
         _loc1_[§_-w1J§.INSTANT_FUZY_37500] = "instant_fuzy_37500";
         _loc1_[§_-w1J§.INSTANT_FUZY_80000] = "instant_fuzy_80000";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_10] = "daily_ruby10";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_20] = "daily_ruby20";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_50] = "daily_ruby50";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_105] = "daily_ruby105";
         _loc1_[§_-w1J§.DEPOSIT_RUBY_220] = "daily_ruby220";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_1000] = "daily_fuzy1000";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_2000] = "daily_fuzy2000";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_5000] = "daily_fuzy5000";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_10500] = "daily_fuzy10500";
         _loc1_[§_-w1J§.DEPOSIT_FUZY_22000] = "daily_fuzy22000";
         _loc1_[§_-w1J§.§_-q1B§] = "rename";
         _loc1_[§_-w1J§.VIP_7] = "vip7";
         _loc1_[§_-w1J§.VIP_30] = "vip30";
         _loc1_[§_-w1J§.VIP_7_AUTORENEW] = "";
         _loc1_[§_-w1J§.VIP_30_AUTORENEW] = "";
         _loc1_[§_-w1J§.STICKER_PACK_1] = "stickers_1";
         _loc1_[§_-w1J§.STICKER_PACK_2] = "stickers_2";
         _loc1_[§_-w1J§.BUNDLE_1] = "craft_box_1";
         _loc1_[§_-w1J§.BUNDLE_2] = "craft_box_2";
         _loc1_[§_-w1J§.CLAN_DONATION_1] = "clan_donate_1";
         _loc1_[§_-w1J§.CLAN_DONATION_2] = "clan_donate_2";
         _loc1_[§_-w1J§.CLAN_DONATION_3] = "clan_donate_3";
         _loc1_[§_-w1J§.CLAN_DONATION_4] = "clan_donate_4";
         return _loc1_;
      }
      
      private function §_-i1j§(param1:SteamEvent) : void
      {
         var _loc2_:MicroTxnAuthorizationResponse = null;
         var _loc3_:SteamTransactionCommitRequest = null;
         if(param1.req_type == SteamConstants.RESPONSE_OnMicroTxnAuthorizationResponse)
         {
            while(true)
            {
               _loc2_ = this.steamworks.microTxnResult();
               if(_loc2_ == null)
               {
                  break;
               }
               _loc3_ = new SteamTransactionCommitRequest();
               _loc3_.purchaseOrderId = int(_loc2_.orderID);
               _loc3_.purchaseTransactionId = this.purchaseTransactionId;
               _loc3_.sessionId = §_-J2g§.§_-i1N§.§_-yt§();
               this.§_-335§.info(_loc3_.toString(),§_-81F§);
               §_-d21§.§_-vH§(§_-J2g§.§_-i1N§,_loc3_,SteamTransactionCommitResponse,this.§_-51h§,this.onSteamTransactionCommitFail);
            }
         }
      }
      
      private function §_-51h§(param1:§_-63i§) : void
      {
         var _loc2_:SteamTransactionCommitResponse = param1.message as SteamTransactionCommitResponse;
         this.§_-335§.info(_loc2_.toString(),§_-81F§);
         var _loc3_:VerifyPaymentResult = new VerifyPaymentResult();
         _loc3_.result = _loc2_.result;
         _loc3_.transactionId = _loc2_.purchaseTransactionId;
         _loc3_.item = _loc2_.item;
         _loc3_.moneyType = _loc2_.moneyType;
         _loc3_.count = _loc2_.count;
         _loc3_.awards = _loc2_.awards;
         _loc3_.sessionKey = _loc2_.sessionKey;
         if(_loc3_.result == Result.SUCCESS)
         {
            processSuccessReceiptResult(_loc3_);
         }
         else
         {
            §_-Hr§(_loc3_);
         }
         §_-81§();
      }
      
      private function onSteamTransactionCommitFail(param1:Object) : void
      {
         this.§_-335§.info("onSteamTransactionCommitFail",§_-81F§);
         var _loc2_:VerifyPaymentResult = new VerifyPaymentResult();
         _loc2_.result = Result.ERROR;
         §_-Hr§(_loc2_);
         §_-81§();
      }
      
      override public function §_-j1E§() : void
      {
         this.§_-335§.info("requesting steam products from server...",§_-81F§);
         var _loc1_:SteamProductsInfoRequest = new SteamProductsInfoRequest();
         §_-d21§.§_-vH§(§_-J2g§.§_-i1N§,_loc1_,SteamProductsInfoResponse,this.§_-v2U§,this.§_-V1§);
      }
      
      private function §_-v2U§(param1:§_-63i§) : void
      {
         var _loc3_:String = null;
         var _loc4_:SteamProductInfoStructure = null;
         var _loc5_:PaymentOption = null;
         var _loc2_:SteamProductsInfoResponse = param1.message as SteamProductsInfoResponse;
         this.§_-335§.info(_loc2_.toString(),§_-81F§);
         §_-22O§ = _loc2_.currencyCode;
         this.§_-335§.info("Products:",§_-81F§);
         for each(_loc4_ in _loc2_.products)
         {
            this.§_-335§.info(_loc4_.toString(),§_-81F§);
            _loc3_ = §_-G1j§(_loc4_.code);
            _loc5_ = §_-L2T§(_loc3_);
            if(_loc5_)
            {
               _loc5_.descr = _loc4_.description;
               _loc5_.price = _loc4_.cost / 100;
            }
         }
      }
      
      private function §_-V1§(param1:Object) : void
      {
         this.§_-335§.info("steam products info request fail",§_-81F§);
      }
      
      override protected function initPurchase(param1:String) : void
      {
         var _loc2_:SteamTransactionInitRequest = null;
         if(this.steamworks.isOverlayEnabled())
         {
            _loc2_ = new SteamTransactionInitRequest();
            _loc2_.productCode = param1;
            this.§_-335§.info(_loc2_.toString(),§_-81F§);
            §_-d21§.§_-vH§(§_-J2g§.§_-i1N§,_loc2_,SteamTransactionInitResponse,this.§_-g4§,this.onSteamTransactionInitFail);
         }
         else
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.STEAM_OVERLAY_ACTIVATION_NEEDED),§_-fH§.§_-1B§);
            §_-81§();
         }
      }
      
      private function §_-g4§(param1:§_-63i§) : void
      {
         var _loc3_:String = null;
         var _loc2_:SteamTransactionInitResponse = param1.message as SteamTransactionInitResponse;
         if(_loc2_.errorCode == 0)
         {
            this.purchaseTransactionId = _loc2_.purchaseTransactionId;
            this.§_-335§.info(_loc2_.toString(),§_-81F§);
         }
         else
         {
            _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.RECEIPT_VERIFICATION_ERROR_STEAM);
            _loc3_ += "\n" + _loc2_.errorCode.toString() + ": " + _loc2_.errorMessage;
            §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),_loc3_,§_-fH§.§_-1B§);
            §_-81§();
         }
      }
      
      private function onSteamTransactionInitFail(param1:Object) : void
      {
         this.§_-335§.info("onSteamTransactionInitFail",§_-81F§);
         §_-81§();
      }
      
      override public function §_-WE§() : Array
      {
         return [§_-b23§.§_-92s§,§_-b23§.§_-U1V§,§_-b23§.§_-qQ§,§_-b23§.§_-e2Q§,§_-b23§.§_-f29§];
      }
      
      override protected function §_-D3i§(param1:String) : void
      {
         var _loc2_:SteamTransactionInitRequest = new SteamTransactionInitRequest();
         _loc2_.productCode = param1;
         this.§_-335§.info(_loc2_.toString(),§_-81F§);
         §_-d21§.§_-vH§(§_-J2g§.§_-i1N§,_loc2_,SteamTransactionInitResponse,this.§_-My§,this.onSteamTestTransactionInitFail);
      }
      
      private function §_-My§(param1:§_-63i§) : void
      {
         var _loc2_:SteamTransactionInitResponse = param1.message as SteamTransactionInitResponse;
         this.purchaseTransactionId = _loc2_.purchaseTransactionId;
         this.§_-335§.info(_loc2_.toString(),§_-81F§);
         var _loc3_:SteamTransactionCommitRequest = new SteamTransactionCommitRequest();
         _loc3_.purchaseOrderId = _loc2_.purchaseOrderId;
         _loc3_.purchaseTransactionId = _loc2_.purchaseTransactionId;
         _loc3_.sessionId = §_-J2g§.§_-i1N§.§_-yt§();
         this.§_-335§.info(_loc3_.toString(),§_-81F§);
         §_-d21§.§_-vH§(§_-J2g§.§_-i1N§,_loc3_,SteamTransactionCommitResponse,this.§_-51h§,this.onSteamTransactionCommitFail);
      }
      
      private function onSteamTestTransactionInitFail(param1:Object) : void
      {
         this.§_-335§.info("onSteamTestTransactionInitFail",§_-81F§);
         §_-81§();
      }
   }
}


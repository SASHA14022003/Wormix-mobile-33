package §_-E1I§
{
   import §_-12a§.§_-41b§;
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-Ly§.§_-81L§;
   import §_-P2i§.§_-b7§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-ZP§.§_-b23§;
   import §_-l1K§.§_-cZ§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import feathers.controls.Button;
   import feathers.controls.ButtonGroup;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.layout.Direction;
   import feathers.layout.VerticalAlign;
   import feathers.skins.ImageSkin;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.geom.ColorTransform;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.weapons.*;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.ScaleMode;
   
   public class §_-b2n§
   {
      
      public static const §_-g2o§:String = " %";
      
      public static const §_-k1U§:String = §_-g2o§ + ":?#/@";
      
      public static const §_-3f§:String = §_-g2o§ + "?#";
      
      public static const §_-lL§:String = §_-g2o§ + "#";
      
      public static const §_-Tk§:String = §_-g2o§ + "#&=";
      
      public static const §_-029§:String = §_-g2o§ + "?#/";
      
      public static const §_-Of§:String = "unknown";
      
      protected static const §_-Z2n§:§_-k1f§ = new §_-k1f§(§_-k1U§);
      
      protected static const §_-P16§:§_-k1f§ = §_-Z2n§;
      
      protected static const §_-q2t§:§_-k1f§ = §_-Z2n§;
      
      protected static const §_-M1H§:§_-k1f§ = §_-Z2n§;
      
      protected static const §_-Qc§:§_-k1f§ = §_-Z2n§;
      
      protected static const §_-a2B§:§_-k1f§ = new §_-k1f§(§_-3f§);
      
      protected static const §_-RH§:§_-k1f§ = new §_-k1f§(§_-lL§);
      
      protected static const §_-3J§:§_-k1f§ = new §_-k1f§(§_-Tk§);
      
      protected static const §_-u27§:§_-k1f§ = §_-RH§;
      
      protected static const §_-G2i§:§_-k1f§ = new §_-k1f§(§_-029§);
      
      public static const §_-91d§:int = 0;
      
      public static const §_-nO§:int = 1;
      
      public static const §_-SS§:int = 2;
      
      public static const PARENT:int = 3;
      
      protected static var §_-h22§:§_-5§ = null;
      
      protected var §_-j1R§:Boolean = false;
      
      protected var §_-g8§:Boolean = false;
      
      protected var §_-K1b§:String = "";
      
      protected var §_-y2i§:String = "";
      
      protected var §_-d2C§:String = "";
      
      protected var §_-N1L§:String = "";
      
      protected var _port:String = "";
      
      protected var §_-s2N§:String = "";
      
      protected var §_-RC§:String = "";
      
      protected var §_-vF§:String = "";
      
      protected var §_-e29§:String = "";
      
      public function §_-b2n§(param1:String = null)
      {
         super();
         if(param1 == null)
         {
            this.initialize();
         }
         else
         {
            this.§_-c2m§(param1);
         }
      }
      
      public static function §_-22X§(param1:String) : String
      {
         return §_-37§(param1,§_-b2n§.§_-Z2n§);
      }
      
      public static function §_-Ev§(param1:String) : String
      {
         var _loc2_:String = null;
         return decodeURIComponent(param1);
      }
      
      public static function §_-37§(param1:String, param2:§_-k1f§) : String
      {
         var _loc4_:String = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc3_:String = "";
         _loc6_ = 0;
         while(_loc6_ < param1.length)
         {
            _loc4_ = param1.charAt(_loc6_);
            _loc5_ = param2.§_-l1f§(_loc4_);
            if(_loc5_)
            {
               _loc4_ = _loc5_.toString(16);
               if(_loc4_.length == 1)
               {
                  _loc4_ = "0" + _loc4_;
               }
               _loc4_ = "%" + _loc4_;
               _loc4_ = _loc4_.toUpperCase();
            }
            _loc3_ += _loc4_;
            _loc6_++;
         }
         return _loc3_;
      }
      
      public static function §_-A3D§(param1:String) : String
      {
         var _loc2_:String = param1;
         return §_-b2n§.§_-37§(param1,§_-b2n§.§_-3J§);
      }
      
      public static function §_-81k§(param1:String) : String
      {
         var _loc2_:String = param1;
         return §_-Ev§(_loc2_);
      }
      
      protected static function §_-ur§(param1:String, param2:String, param3:Boolean = true) : Boolean
      {
         if(param3 == false)
         {
            param1 = param1.toLowerCase();
            param2 = param2.toLowerCase();
         }
         return param1 == param2;
      }
      
      protected static function §_-Xr§(param1:§_-b2n§) : §_-b2n§
      {
         var _loc2_:§_-b2n§ = new §_-b2n§();
         _loc2_.§_-cg§(param1);
         if(§_-h22§ != null)
         {
            return §_-h22§.§_-Xr§(_loc2_);
         }
         return _loc2_;
      }
      
      public static function set §_-aj§(param1:§_-5§) : void
      {
         §_-h22§ = param1;
      }
      
      public static function get §_-aj§() : §_-5§
      {
         return §_-h22§;
      }
      
      protected function §_-c2m§(param1:String) : Boolean
      {
         if(!this.§_-63J§(param1))
         {
            this.§_-j1R§ = false;
         }
         return this.isValid();
      }
      
      protected function initialize() : void
      {
         this.§_-j1R§ = false;
         this.§_-g8§ = false;
         this.§_-K1b§ = §_-Of§;
         this.§_-y2i§ = "";
         this.§_-d2C§ = "";
         this.§_-N1L§ = "";
         this._port = "";
         this.§_-s2N§ = "";
         this.§_-RC§ = "";
         this.§_-vF§ = "";
         this.§_-e29§ = "";
      }
      
      protected function set §_-o1V§(param1:Boolean) : void
      {
         if(param1)
         {
            this.§_-e29§ = "";
            if(this.§_-K1b§ == "" || this.§_-K1b§ == §_-Of§)
            {
               this.§_-g8§ = true;
            }
            else
            {
               this.§_-g8§ = false;
            }
            if(this.§_-y2i§.length == 0 && this.§_-s2N§.length == 0)
            {
               this.§_-j1R§ = false;
            }
            else
            {
               this.§_-j1R§ = true;
            }
         }
         else
         {
            this.§_-y2i§ = "";
            this.§_-d2C§ = "";
            this.§_-N1L§ = "";
            this._port = "";
            this.§_-s2N§ = "";
            this.§_-g8§ = false;
            if(this.§_-K1b§ == "" || this.§_-K1b§ == §_-Of§)
            {
               this.§_-j1R§ = false;
            }
            else
            {
               this.§_-j1R§ = true;
            }
         }
      }
      
      protected function get §_-o1V§() : Boolean
      {
         return this.§_-e29§.length == 0;
      }
      
      protected function §_-z14§() : Boolean
      {
         if(this.§_-s1r§())
         {
            if(this.§_-K1b§.length <= 1 || this.§_-K1b§ == §_-Of§)
            {
               return false;
            }
            if(this.§_-B3X§(this.§_-K1b§) == false)
            {
               return false;
            }
         }
         if(this.§_-o1V§)
         {
            if(this.§_-s2N§.search("\\") != -1)
            {
               return false;
            }
            if(this.§_-M1x§() == false && this.§_-K1b§ == §_-Of§)
            {
               return false;
            }
         }
         else if(this.§_-e29§.search("\\") != -1)
         {
            return false;
         }
         return true;
      }
      
      protected function §_-63J§(param1:String) : Boolean
      {
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc2_:String = param1;
         this.initialize();
         _loc3_ = int(_loc2_.indexOf("#"));
         if(_loc3_ != -1)
         {
            if(_loc2_.length > _loc3_ + 1)
            {
               this.§_-vF§ = _loc2_.substr(_loc3_ + 1,_loc2_.length - (_loc3_ + 1));
            }
            _loc2_ = _loc2_.substr(0,_loc3_);
         }
         _loc3_ = int(_loc2_.indexOf("?"));
         if(_loc3_ != -1)
         {
            if(_loc2_.length > _loc3_ + 1)
            {
               this.§_-RC§ = _loc2_.substr(_loc3_ + 1,_loc2_.length - (_loc3_ + 1));
            }
            _loc2_ = _loc2_.substr(0,_loc3_);
         }
         _loc3_ = int(_loc2_.search(":"));
         _loc4_ = int(_loc2_.search("/"));
         var _loc5_:Boolean = _loc3_ != -1;
         var _loc6_:Boolean = _loc4_ != -1;
         var _loc7_:Boolean = !_loc6_ || _loc3_ < _loc4_;
         if(_loc5_ && _loc7_)
         {
            this.§_-K1b§ = _loc2_.substr(0,_loc3_);
            this.§_-K1b§ = this.§_-K1b§.toLowerCase();
            _loc2_ = _loc2_.substr(_loc3_ + 1);
            if(_loc2_.substr(0,2) != "//")
            {
               this.§_-e29§ = _loc2_;
               if((this.§_-j1R§ = this.§_-z14§()) == false)
               {
                  this.initialize();
               }
               return this.isValid();
            }
            this.§_-e29§ = "";
            _loc2_ = _loc2_.substr(2,_loc2_.length - 2);
         }
         else
         {
            this.§_-K1b§ = "";
            this.§_-g8§ = true;
            this.§_-e29§ = "";
         }
         if(this.§_-M1x§())
         {
            this.§_-y2i§ = "";
            this._port = "";
            this.§_-s2N§ = _loc2_;
         }
         else
         {
            if(_loc2_.substr(0,2) == "//")
            {
               while(_loc2_.charAt(0) == "/")
               {
                  _loc2_ = _loc2_.substr(1,_loc2_.length - 1);
               }
            }
            _loc3_ = int(_loc2_.search("/"));
            if(_loc3_ == -1)
            {
               this.§_-y2i§ = _loc2_;
               this.§_-s2N§ = "";
            }
            else
            {
               this.§_-y2i§ = _loc2_.substr(0,_loc3_);
               this.§_-s2N§ = _loc2_.substr(_loc3_,_loc2_.length - _loc3_);
            }
            _loc3_ = int(this.§_-y2i§.search("@"));
            if(_loc3_ != -1)
            {
               this.§_-d2C§ = this.§_-y2i§.substr(0,_loc3_);
               this.§_-y2i§ = this.§_-y2i§.substr(_loc3_ + 1);
               _loc3_ = int(this.§_-d2C§.search(":"));
               if(_loc3_ != -1)
               {
                  this.§_-N1L§ = this.§_-d2C§.substring(_loc3_ + 1,this.§_-d2C§.length);
                  this.§_-d2C§ = this.§_-d2C§.substr(0,_loc3_);
               }
               else
               {
                  this.§_-N1L§ = "";
               }
            }
            else
            {
               this.§_-d2C§ = "";
               this.§_-N1L§ = "";
            }
            _loc3_ = int(this.§_-y2i§.search(":"));
            if(_loc3_ != -1)
            {
               this._port = this.§_-y2i§.substring(_loc3_ + 1,this.§_-y2i§.length);
               this.§_-y2i§ = this.§_-y2i§.substr(0,_loc3_);
            }
            else
            {
               this._port = "";
            }
            this.§_-y2i§ = this.§_-y2i§.toLowerCase();
         }
         if((this.§_-j1R§ = this.§_-z14§()) == false)
         {
            this.initialize();
         }
         return this.isValid();
      }
      
      public function §_-cg§(param1:§_-b2n§) : void
      {
         this.§_-K1b§ = param1.§_-K1b§;
         this.§_-y2i§ = param1.§_-y2i§;
         this.§_-d2C§ = param1.§_-d2C§;
         this.§_-N1L§ = param1.§_-N1L§;
         this._port = param1._port;
         this.§_-s2N§ = param1.§_-s2N§;
         this.§_-RC§ = param1.§_-RC§;
         this.§_-vF§ = param1.§_-vF§;
         this.§_-e29§ = param1.§_-e29§;
         this.§_-j1R§ = param1.§_-j1R§;
         this.§_-g8§ = param1.§_-g8§;
      }
      
      protected function §_-B3X§(param1:String) : Boolean
      {
         var _loc3_:int = 0;
         var _loc2_:RegExp = /[^a-z]/;
         param1 = param1.toLowerCase();
         _loc3_ = int(param1.search(_loc2_));
         if(_loc3_ == -1)
         {
            return true;
         }
         return false;
      }
      
      public function isValid() : Boolean
      {
         return this.§_-j1R§;
      }
      
      public function §_-s1r§() : Boolean
      {
         return !this.§_-g8§;
      }
      
      public function §_-M1x§() : Boolean
      {
         return this.§_-g8§;
      }
      
      public function isDirectory() : Boolean
      {
         if(this.§_-s2N§.length == 0)
         {
            return false;
         }
         return this.§_-s2N§.charAt(this.path.length - 1) == "/";
      }
      
      public function §_-63H§() : Boolean
      {
         return this.§_-o1V§;
      }
      
      public function get §_-a1Y§() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-K1b§);
      }
      
      public function set §_-a1Y§(param1:String) : void
      {
         var _loc2_:String = param1.toLowerCase();
         this.§_-K1b§ = §_-b2n§.§_-37§(_loc2_,§_-b2n§.§_-P16§);
      }
      
      public function get §_-31D§() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-y2i§);
      }
      
      public function set §_-31D§(param1:String) : void
      {
         param1 = param1.toLowerCase();
         this.§_-y2i§ = §_-b2n§.§_-37§(param1,§_-b2n§.§_-M1H§);
         this.§_-o1V§ = true;
      }
      
      public function get §_-k1Y§() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-d2C§);
      }
      
      public function set §_-k1Y§(param1:String) : void
      {
         this.§_-d2C§ = §_-b2n§.§_-37§(param1,§_-b2n§.§_-q2t§);
         this.§_-o1V§ = true;
      }
      
      public function get §_-Yw§() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-N1L§);
      }
      
      public function set §_-Yw§(param1:String) : void
      {
         this.§_-N1L§ = §_-b2n§.§_-37§(param1,§_-b2n§.§_-q2t§);
         this.§_-o1V§ = true;
      }
      
      public function get port() : String
      {
         return §_-b2n§.§_-Ev§(this._port);
      }
      
      public function set port(param1:String) : void
      {
         this._port = §_-b2n§.§_-22X§(param1);
         this.§_-o1V§ = true;
      }
      
      public function get path() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-s2N§);
      }
      
      public function set path(param1:String) : void
      {
         this.§_-s2N§ = §_-b2n§.§_-37§(param1,§_-b2n§.§_-a2B§);
         if(this.§_-K1b§ == §_-Of§)
         {
            this.§_-K1b§ = "";
         }
         this.§_-o1V§ = true;
      }
      
      public function get §_-J29§() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-RC§);
      }
      
      public function set §_-J29§(param1:String) : void
      {
         this.§_-RC§ = §_-b2n§.§_-37§(param1,§_-b2n§.§_-RH§);
      }
      
      public function get §_-01j§() : String
      {
         return this.§_-RC§;
      }
      
      public function set §_-01j§(param1:String) : void
      {
         this.§_-RC§ = param1;
      }
      
      public function get fragment() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-vF§);
      }
      
      public function set fragment(param1:String) : void
      {
         this.§_-vF§ = §_-b2n§.§_-37§(param1,§_-u27§);
      }
      
      public function get §_-S1d§() : String
      {
         return §_-b2n§.§_-Ev§(this.§_-e29§);
      }
      
      public function set §_-S1d§(param1:String) : void
      {
         this.§_-e29§ = §_-b2n§.§_-37§(param1,§_-G2i§);
         this.§_-o1V§ = false;
      }
      
      public function §_-E1h§(param1:String, param2:String, param3:String, param4:String, param5:String, param6:String) : void
      {
         this.§_-a1Y§ = param1;
         this.§_-31D§ = param2;
         this.port = param3;
         this.path = param4;
         this.§_-J29§ = param5;
         this.fragment = param6;
         this.§_-o1V§ = true;
      }
      
      public function §_-f1g§(param1:String) : Boolean
      {
         param1 = param1.toLowerCase();
         return this.§_-K1b§ == param1;
      }
      
      public function §_-X2G§(param1:String) : String
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         _loc2_ = this.§_-wV§();
         for(_loc3_ in _loc2_)
         {
            if(_loc3_ == param1)
            {
               return _loc2_[_loc3_];
            }
         }
         return new String("");
      }
      
      public function §_-Hj§(param1:String, param2:String) : void
      {
         var _loc3_:Object = null;
         _loc3_ = this.§_-wV§();
         _loc3_[param1] = param2;
         this.§_-o1g§(_loc3_);
      }
      
      public function §_-wV§() : Object
      {
         var _loc1_:String = null;
         var _loc2_:String = null;
         var _loc3_:Array = null;
         var _loc4_:Array = null;
         var _loc5_:String = null;
         var _loc6_:String = null;
         var _loc7_:int = 0;
         var _loc8_:Object = new Object();
         _loc1_ = this.§_-RC§;
         _loc3_ = _loc1_.split("&");
         for each(_loc2_ in _loc3_)
         {
            if(_loc2_.length != 0)
            {
               _loc4_ = _loc2_.split("=");
               if(_loc4_.length > 0)
               {
                  _loc5_ = _loc4_[0];
                  if(_loc4_.length > 1)
                  {
                     _loc6_ = _loc4_[1];
                  }
                  else
                  {
                     _loc6_ = "";
                  }
                  _loc5_ = §_-81k§(_loc5_);
                  _loc6_ = §_-81k§(_loc6_);
                  _loc8_[_loc5_] = _loc6_;
               }
            }
         }
         return _loc8_;
      }
      
      public function §_-o1g§(param1:Object) : void
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc5_:String = "";
         for(_loc2_ in param1)
         {
            _loc3_ = _loc2_;
            _loc4_ = param1[_loc2_];
            if(_loc4_ == null)
            {
               _loc4_ = "";
            }
            _loc3_ = §_-A3D§(_loc3_);
            _loc4_ = §_-A3D§(_loc4_);
            _loc6_ = _loc3_;
            if(_loc4_.length > 0)
            {
               _loc6_ += "=";
               _loc6_ = _loc6_ + _loc4_;
            }
            if(_loc5_.length != 0)
            {
               _loc5_ += "&";
            }
            _loc5_ += _loc6_;
         }
         this.§_-RC§ = _loc5_;
      }
      
      public function toString() : String
      {
         if(this == null)
         {
            return "";
         }
         return this.§_-Z2R§(false);
      }
      
      public function §_-jX§() : String
      {
         return this.§_-Z2R§(true);
      }
      
      protected function §_-Z2R§(param1:Boolean) : String
      {
         var _loc2_:String = "";
         var _loc3_:String = "";
         if(this.§_-63H§() == false)
         {
            _loc2_ += param1 ? this.§_-a1Y§ : this.§_-K1b§;
            _loc2_ += ":";
            _loc2_ += param1 ? this.§_-S1d§ : this.§_-e29§;
         }
         else
         {
            if(this.§_-M1x§() == false)
            {
               if(this.§_-K1b§.length != 0)
               {
                  _loc3_ = param1 ? this.§_-a1Y§ : this.§_-K1b§;
                  _loc2_ += _loc3_ + ":";
               }
               if(this.§_-y2i§.length != 0 || this.§_-f1g§("file"))
               {
                  _loc2_ += "//";
                  if(this.§_-d2C§.length != 0)
                  {
                     _loc3_ = param1 ? this.§_-k1Y§ : this.§_-d2C§;
                     _loc2_ += _loc3_;
                     if(this.§_-N1L§.length != 0)
                     {
                        _loc3_ = param1 ? this.§_-Yw§ : this.§_-N1L§;
                        _loc2_ += ":" + _loc3_;
                     }
                     _loc2_ += "@";
                  }
                  _loc3_ = param1 ? this.§_-31D§ : this.§_-y2i§;
                  _loc2_ += _loc3_;
                  if(this.port.length != 0)
                  {
                     _loc2_ += ":" + this.port;
                  }
               }
            }
            _loc3_ = param1 ? this.path : this.§_-s2N§;
            _loc2_ += _loc3_;
         }
         if(this.§_-RC§.length != 0)
         {
            _loc3_ = param1 ? this.§_-J29§ : this.§_-RC§;
            _loc2_ += "?" + _loc3_;
         }
         if(this.fragment.length != 0)
         {
            _loc3_ = param1 ? this.fragment : this.§_-vF§;
            _loc2_ += "#" + _loc3_;
         }
         return _loc2_;
      }
      
      public function §_-a2I§() : void
      {
         this.§_-a1Y§ = this.§_-a1Y§;
         this.§_-o1g§(this.§_-wV§());
         this.fragment = this.fragment;
         if(this.§_-63H§())
         {
            this.§_-31D§ = this.§_-31D§;
            this.path = this.path;
            this.port = this.port;
            this.§_-k1Y§ = this.§_-k1Y§;
            this.§_-Yw§ = this.§_-Yw§;
         }
         else
         {
            this.§_-S1d§ = this.§_-S1d§;
         }
      }
      
      public function §_-W2W§(param1:String) : Boolean
      {
         var _loc2_:String = null;
         var _loc3_:int = 0;
         _loc3_ = int(param1.lastIndexOf("."));
         if(_loc3_ != -1)
         {
            param1 = param1.substr(_loc3_ + 1);
         }
         _loc2_ = this.§_-i1m§(true);
         if(_loc2_ == "")
         {
            return false;
         }
         if(§_-ur§(_loc2_,param1,false) == 0)
         {
            return true;
         }
         return false;
      }
      
      public function §_-i1m§(param1:Boolean = false) : String
      {
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc2_:String = this.§_-ks§();
         if(_loc2_ == "")
         {
            return String("");
         }
         _loc4_ = int(_loc2_.lastIndexOf("."));
         if(_loc4_ == -1 || _loc4_ == 0)
         {
            return String("");
         }
         _loc3_ = _loc2_.substr(_loc4_);
         if(param1 && _loc3_.charAt(0) == ".")
         {
            _loc3_ = _loc3_.substr(1);
         }
         return _loc3_;
      }
      
      public function §_-ks§(param1:Boolean = false) : String
      {
         var _loc3_:String = null;
         var _loc4_:int = 0;
         if(this.isDirectory())
         {
            return String("");
         }
         var _loc2_:String = this.path;
         var _temp_1:* = int(_loc2_.lastIndexOf("/"));
         _loc4_ = int(_loc2_.lastIndexOf("/"));
         if(_loc4_ != -1)
         {
            _loc3_ = _loc2_.substr(_loc4_ + 1);
         }
         else
         {
            _loc3_ = _loc2_;
         }
         if(param1)
         {
            _loc4_ = int(_loc3_.lastIndexOf("."));
            if(_loc4_ != -1)
            {
               _loc3_ = _loc3_.substr(0,_loc4_);
            }
         }
         return _loc3_;
      }
      
      public function §_-ZJ§() : String
      {
         if(this.§_-K1b§ == "http")
         {
            return String("80");
         }
         if(this.§_-K1b§ == "ftp")
         {
            return String("21");
         }
         if(this.§_-K1b§ == "file")
         {
            return String("");
         }
         if(this.§_-K1b§ == "sftp")
         {
            return String("22");
         }
         return String("");
      }
      
      public function §_-mM§(param1:§_-b2n§, param2:Boolean = true) : int
      {
         var _loc9_:Array = null;
         var _loc10_:Array = null;
         var _loc11_:String = null;
         var _loc12_:String = null;
         var _loc13_:int = 0;
         var _loc3_:§_-b2n§ = §_-b2n§.§_-Xr§(this);
         var _loc4_:§_-b2n§ = §_-b2n§.§_-Xr§(param1);
         if(_loc3_.§_-M1x§() || _loc4_.§_-M1x§())
         {
            return §_-b2n§.§_-91d§;
         }
         if(_loc3_.§_-63H§() == false || _loc4_.§_-63H§() == false)
         {
            if(_loc3_.§_-63H§() == false && _loc4_.§_-63H§() == true || _loc3_.§_-63H§() == true && _loc4_.§_-63H§() == false)
            {
               return §_-b2n§.§_-91d§;
            }
            if(_loc3_.§_-a1Y§ != _loc4_.§_-a1Y§)
            {
               return §_-b2n§.§_-91d§;
            }
            if(_loc3_.§_-S1d§ != _loc4_.§_-S1d§)
            {
               return §_-b2n§.§_-91d§;
            }
            return §_-b2n§.§_-SS§;
         }
         if(_loc3_.§_-a1Y§ != _loc4_.§_-a1Y§)
         {
            return §_-b2n§.§_-91d§;
         }
         if(_loc3_.§_-31D§ != _loc4_.§_-31D§)
         {
            return §_-b2n§.§_-91d§;
         }
         var _loc5_:String = _loc3_.port;
         var _loc6_:String = _loc4_.port;
         if(_loc5_ == "")
         {
            _loc5_ = _loc3_.§_-ZJ§();
         }
         if(_loc6_ == "")
         {
            _loc6_ = _loc4_.§_-ZJ§();
         }
         if(_loc5_ != _loc6_)
         {
            return §_-b2n§.§_-91d§;
         }
         if(§_-ur§(_loc3_.path,_loc4_.path,param2))
         {
            return §_-b2n§.§_-SS§;
         }
         var _loc7_:String = _loc3_.path;
         var _loc8_:String = _loc4_.path;
         if((_loc7_ == "/" || _loc8_ == "/") && (_loc7_ == "" || _loc8_ == ""))
         {
            return §_-b2n§.§_-SS§;
         }
         _loc9_ = _loc7_.split("/");
         _loc10_ = _loc8_.split("/");
         if(_loc9_.length > _loc10_.length)
         {
            _loc12_ = _loc10_[_loc10_.length - 1];
            if(_loc12_.length > 0)
            {
               return §_-b2n§.§_-91d§;
            }
            _loc10_.pop();
            _loc13_ = 0;
            while(_loc13_ < _loc10_.length)
            {
               _loc11_ = _loc9_[_loc13_];
               _loc12_ = _loc10_[_loc13_];
               if(§_-ur§(_loc11_,_loc12_,param2) == false)
               {
                  return §_-b2n§.§_-91d§;
               }
               _loc13_++;
            }
            return §_-b2n§.§_-nO§;
         }
         if(_loc9_.length < _loc10_.length)
         {
            _loc11_ = _loc9_[_loc9_.length - 1];
            if(_loc11_.length > 0)
            {
               return §_-b2n§.§_-91d§;
            }
            _loc9_.pop();
            _loc13_ = 0;
            while(_loc13_ < _loc9_.length)
            {
               _loc11_ = _loc9_[_loc13_];
               _loc12_ = _loc10_[_loc13_];
               if(§_-ur§(_loc11_,_loc12_,param2) == false)
               {
                  return §_-b2n§.§_-91d§;
               }
               _loc13_++;
            }
            return §_-b2n§.PARENT;
         }
         return §_-b2n§.§_-91d§;
      }
      
      public function §_-9J§(param1:§_-b2n§, param2:Boolean = true) : §_-b2n§
      {
         var _loc6_:String = null;
         var _loc7_:String = null;
         var _loc3_:§_-b2n§ = §_-b2n§.§_-Xr§(this);
         var _loc4_:§_-b2n§ = §_-b2n§.§_-Xr§(param1);
         if(!_loc3_.§_-s1r§() || !_loc4_.§_-s1r§() || _loc3_.§_-63H§() == false || _loc4_.§_-63H§() == false)
         {
            return null;
         }
         var _loc5_:int = _loc3_.§_-mM§(_loc4_);
         if(_loc5_ == §_-b2n§.§_-91d§)
         {
            return null;
         }
         _loc3_.§_-MX§(".");
         _loc4_.§_-MX§(".");
         while(true)
         {
            _loc5_ = _loc3_.§_-mM§(_loc4_,param2);
            if(_loc5_ == §_-b2n§.§_-SS§ || _loc5_ == §_-b2n§.PARENT)
            {
               break;
            }
            _loc6_ = _loc3_.toString();
            _loc3_.§_-MX§("..");
            _loc7_ = _loc3_.toString();
            if(_loc6_ == _loc7_)
            {
               break;
            }
         }
         return _loc3_;
      }
      
      public function §_-MX§(param1:String, param2:Boolean = false) : Boolean
      {
         var _loc3_:§_-b2n§ = null;
         var _loc5_:String = null;
         var _loc6_:String = null;
         var _loc7_:Array = null;
         var _loc8_:Array = null;
         var _loc14_:String = null;
         var _loc15_:int = 0;
         var _loc17_:String = null;
         var _loc4_:String = param1;
         if(param2)
         {
            _loc4_ = §_-b2n§.§_-22X§(param1);
         }
         if(_loc4_ == "")
         {
            return true;
         }
         if(_loc4_.substr(0,2) == "//")
         {
            _loc17_ = this.§_-a1Y§ + ":" + _loc4_;
            return this.§_-c2m§(_loc17_);
         }
         if(_loc4_.charAt(0) == "?")
         {
            _loc4_ = "./" + _loc4_;
         }
         _loc3_ = new §_-b2n§(_loc4_);
         if(_loc3_.§_-s1r§() || _loc3_.§_-63H§() == false)
         {
            this.§_-cg§(_loc3_);
            return true;
         }
         var _loc9_:Boolean = false;
         var _loc10_:Boolean = false;
         var _loc11_:Boolean = false;
         var _loc12_:Boolean = false;
         var _loc13_:Boolean = false;
         _loc5_ = this.path;
         _loc6_ = _loc3_.path;
         if(_loc5_.length > 0)
         {
            _loc7_ = _loc5_.split("/");
         }
         else
         {
            _loc7_ = new Array();
         }
         if(_loc6_.length > 0)
         {
            _loc8_ = _loc6_.split("/");
         }
         else
         {
            _loc8_ = new Array();
         }
         if(_loc7_.length > 0 && _loc7_[0] == "")
         {
            _loc11_ = true;
            _loc7_.shift();
         }
         if(_loc7_.length > 0 && _loc7_[_loc7_.length - 1] == "")
         {
            _loc9_ = true;
            _loc7_.pop();
         }
         if(_loc8_.length > 0 && _loc8_[0] == "")
         {
            _loc12_ = true;
            _loc8_.shift();
         }
         if(_loc8_.length > 0 && _loc8_[_loc8_.length - 1] == "")
         {
            _loc10_ = true;
            _loc8_.pop();
         }
         if(_loc12_)
         {
            this.path = _loc3_.path;
            this.§_-01j§ = _loc3_.§_-01j§;
            this.fragment = _loc3_.fragment;
            return true;
         }
         if(_loc8_.length == 0 && _loc3_.§_-J29§ == "")
         {
            this.fragment = _loc3_.fragment;
            return true;
         }
         if(_loc9_ == false && _loc7_.length > 0)
         {
            _loc7_.pop();
         }
         this.§_-01j§ = _loc3_.§_-01j§;
         this.fragment = _loc3_.fragment;
         _loc7_ = _loc7_.concat(_loc8_);
         _loc15_ = 0;
         while(_loc15_ < _loc7_.length)
         {
            _loc14_ = _loc7_[_loc15_];
            _loc13_ = false;
            if(_loc14_ == ".")
            {
               _loc7_.splice(_loc15_,1);
               _loc15_--;
               _loc13_ = true;
            }
            else if(_loc14_ == "..")
            {
               if(_loc15_ >= 1)
               {
                  if(_loc7_[_loc15_ - 1] != "..")
                  {
                     _loc7_.splice(_loc15_ - 1,2);
                     _loc15_ -= 2;
                  }
               }
               else if(!this.§_-M1x§())
               {
                  _loc7_.splice(_loc15_,1);
                  _loc15_--;
               }
               _loc13_ = true;
            }
            _loc15_++;
         }
         var _loc16_:String = "";
         _loc10_ ||= _loc13_;
         _loc16_ = this.§_-HI§(_loc7_,_loc11_,_loc10_);
         this.path = _loc16_;
         return true;
      }
      
      protected function §_-HI§(param1:Array, param2:Boolean, param3:Boolean) : String
      {
         var _loc5_:int = 0;
         var _loc4_:String = "";
         _loc5_ = 0;
         while(_loc5_ < param1.length)
         {
            if(_loc4_.length > 0)
            {
               _loc4_ += "/";
            }
            _loc4_ += param1[_loc5_];
            _loc5_++;
         }
         if(param3 && _loc4_.length > 0)
         {
            _loc4_ += "/";
         }
         if(param2)
         {
            _loc4_ = "/" + _loc4_;
         }
         return _loc4_;
      }
      
      public function §_-gp§(param1:§_-b2n§) : Boolean
      {
         if(this.§_-s1r§() || param1.§_-M1x§())
         {
            return false;
         }
         var _loc2_:§_-b2n§ = new §_-b2n§();
         _loc2_.§_-cg§(param1);
         if(_loc2_.§_-MX§(this.toString()) == false)
         {
            return false;
         }
         this.§_-cg§(_loc2_);
         return true;
      }
      
      public function §_-A21§(param1:§_-b2n§, param2:Boolean = true) : Boolean
      {
         var _loc4_:Array = null;
         var _loc5_:Array = null;
         var _loc7_:String = null;
         var _loc8_:String = null;
         var _loc9_:String = null;
         var _loc13_:int = 0;
         var _loc3_:§_-b2n§ = new §_-b2n§();
         _loc3_.§_-cg§(param1);
         var _loc6_:Array = new Array();
         var _loc10_:String = this.path;
         var _loc11_:String = this.§_-01j§;
         var _loc12_:String = this.fragment;
         var _loc14_:Boolean = false;
         var _loc15_:Boolean = false;
         if(this.§_-M1x§())
         {
            return true;
         }
         if(_loc3_.§_-M1x§())
         {
            return false;
         }
         if(this.§_-f1g§(param1.§_-a1Y§) == false || this.§_-31D§ != param1.§_-31D§)
         {
            return false;
         }
         _loc15_ = this.isDirectory();
         _loc3_.§_-MX§(".");
         _loc4_ = _loc10_.split("/");
         _loc5_ = _loc3_.path.split("/");
         if(_loc4_.length > 0 && _loc4_[0] == "")
         {
            _loc4_.shift();
         }
         if(_loc4_.length > 0 && _loc4_[_loc4_.length - 1] == "")
         {
            _loc15_ = true;
            _loc4_.pop();
         }
         if(_loc5_.length > 0 && _loc5_[0] == "")
         {
            _loc5_.shift();
         }
         if(_loc5_.length > 0 && _loc5_[_loc5_.length - 1] == "")
         {
            _loc5_.pop();
         }
         while(_loc5_.length > 0)
         {
            if(_loc4_.length == 0)
            {
               break;
            }
            _loc7_ = _loc4_[0];
            _loc8_ = _loc5_[0];
            if(!§_-ur§(_loc7_,_loc8_,param2))
            {
               break;
            }
            _loc4_.shift();
            _loc5_.shift();
         }
         var _loc16_:String = "..";
         _loc13_ = 0;
         while(_loc13_ < _loc5_.length)
         {
            _loc6_.push(_loc16_);
            _loc13_++;
         }
         _loc6_ = _loc6_.concat(_loc4_);
         _loc9_ = this.§_-HI§(_loc6_,false,_loc15_);
         if(_loc9_.length == 0)
         {
            _loc9_ = "./";
         }
         this.§_-E1h§("","","",_loc9_,_loc11_,_loc12_);
         return true;
      }
      
      public function §_-E30§(param1:String, param2:String = "http") : Boolean
      {
         var _loc3_:String = null;
         var _loc5_:String = null;
         if(param1.length == 0)
         {
            this.initialize();
            return false;
         }
         param1 = param1.replace(/\\/g,"/");
         if(param1.length >= 2)
         {
            _loc3_ = param1.substr(0,2);
            if(_loc3_ == "//")
            {
               param1 = param2 + ":" + param1;
            }
         }
         if(param1.length >= 3)
         {
            _loc3_ = param1.substr(0,3);
            if(_loc3_ == "://")
            {
               param1 = param2 + param1;
            }
         }
         var _loc4_:§_-b2n§ = new §_-b2n§(param1);
         if(_loc4_.§_-63H§() == false)
         {
            if(_loc4_.§_-a1Y§ == §_-Of§)
            {
               this.initialize();
               return false;
            }
            this.§_-cg§(_loc4_);
            this.§_-a2I§();
            return true;
         }
         if(_loc4_.§_-a1Y§ != §_-Of§ && _loc4_.§_-a1Y§.length > 0)
         {
            if(_loc4_.§_-31D§.length > 0 || _loc4_.§_-a1Y§ == "file")
            {
               this.§_-cg§(_loc4_);
               this.§_-a2I§();
               return true;
            }
            if(_loc4_.§_-31D§.length == 0 && _loc4_.path.length == 0)
            {
               this.§_-E1h§(_loc4_.§_-a1Y§,"","","","","");
               return false;
            }
         }
         else
         {
            _loc5_ = _loc4_.path;
            if(_loc5_ == ".." || _loc5_ == "." || _loc5_.length >= 3 && _loc5_.substr(0,3) == "../" || _loc5_.length >= 2 && _loc5_.substr(0,2) == "./")
            {
               this.§_-cg§(_loc4_);
               this.§_-a2I§();
               return true;
            }
         }
         _loc4_ = new §_-b2n§(param2 + "://" + param1);
         if(_loc4_.§_-a1Y§.length > 0 && _loc4_.§_-31D§.length > 0)
         {
            this.§_-cg§(_loc4_);
            this.§_-a2I§();
            return true;
         }
         this.initialize();
         return false;
      }
   }
}


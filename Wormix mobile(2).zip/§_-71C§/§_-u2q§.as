package §_-71C§
{
   import §_-21p§.§_-4w§;
   import §_-82l§.§_-1I§;
   import §_-B2z§.§_-63i§;
   import §_-C2t§.§_-C1i§;
   import §_-DJ§.§_-J2l§;
   import §_-H3§.*;
   import §_-Yi§.§_-EG§;
   import §_-d2p§.*;
   import §_-l1g§.§_-L3Q§;
   import flash.events.Event;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.AndroidAccountController;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.id.IosAccountController;
   import ru.pragmatix.flox.social.utils.id.SteamAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-YD§;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-u2q§
   {
      
      public function §_-u2q§()
      {
         super();
      }
      
      public static function create(param1:String, param2:Object) : IPlatformAccountController
      {
         var _loc3_:Boolean = §_-YD§.§_-t1O§;
         switch(param1)
         {
            case SocialType.MOBILE_ANDROID.name:
               return new AndroidAccountController(param2);
            case SocialType.MOBILE_IOS.name:
               return new IosAccountController(param2);
            case "steam":
               return new SteamAccountController(param2);
            case "web":
         }
         return null;
      }
   }
}


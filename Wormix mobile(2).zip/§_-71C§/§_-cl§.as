package §_-71C§
{
   import §_-2k§.§_-51r§;
   import §_-2k§.§_-m2i§;
   import §_-62§.§_-W1r§;
   import §_-83J§.§_-NT§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-H3§.*;
   import §_-T1S§.§_-E1a§;
   import §_-Ta§.§_-G18§;
   import §_-Tm§.§_-RF§;
   import §_-g2r§.§_-03A§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-cl§
   {
      
      public static var §_-03C§:String = "BackupUserId";
      
      public static const §_-tW§:String = "Cloud";
      
      public static const §_-D30§:String = "LocKeychain";
      
      public function §_-cl§()
      {
         super();
      }
   }
}


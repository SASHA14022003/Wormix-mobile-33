package §_-j1w§
{
   import §_-91A§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-SP§.§_-M4§;
   import §_-U1Y§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-q2v§;
   import §_-ZP§.§_-b23§;
   import §_-j22§.§_-5g§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-F4§;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.MortarMissile;
   import starling.display.Canvas;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-L1x§
   {
      
      public static const §_-z2Z§:Vector.<§_-L1x§> = new Vector.<§_-L1x§>();
      
      public static const §_-r2V§:Vector.<uint> = new <uint>[0,1];
      
      public static const §_-t1I§:§_-L1x§ = new §_-L1x§(0);
      
      public static const §_-T2T§:§_-L1x§ = new §_-L1x§(1);
      
      public static const §_-AU§:§_-L1x§ = new §_-L1x§(2);
      
      public static const §_-l2G§:§_-L1x§ = new §_-L1x§(3);
      
      public static const §_-I1h§:§_-L1x§ = new §_-L1x§(4);
      
      public static const §_-p21§:§_-L1x§ = new §_-L1x§(5);
      
      public static const §_-r2y§:§_-L1x§ = new §_-L1x§(6);
      
      public static const §_-So§:§_-L1x§ = new §_-L1x§(7);
      
      public static const §_-Q1Q§:§_-L1x§ = new §_-L1x§(8);
      
      private var id:uint;
      
      private var raceRecord:§_-B2i§;
      
      public function §_-L1x§(param1:uint)
      {
         super();
         this.id = param1;
         this.raceRecord = §_-lD§.§_-I3U§()[param1];
         §_-z2Z§[§_-z2Z§.length] = this;
      }
      
      public static function §_-R2b§(param1:Vector.<§_-L1x§> = null) : §_-L1x§
      {
         var _loc3_:§_-L1x§ = null;
         var _loc2_:Vector.<§_-L1x§> = new Vector.<§_-L1x§>(0);
         for each(_loc3_ in §_-z2Z§)
         {
            if(§_-r2V§.indexOf(_loc3_.getId()) == -1)
            {
               if(Boolean(param1) && param1.indexOf(_loc3_) == -1)
               {
                  _loc2_.push(_loc3_);
               }
               else if(!param1)
               {
                  _loc2_.push(_loc3_);
               }
            }
         }
         return _loc2_[§_-X1j§.randomSeed.§_-Fh§(0,_loc2_.length - 1)];
      }
      
      public static function §_-M19§(param1:uint) : §_-B2i§
      {
         var _loc2_:§_-L1x§ = null;
         for each(_loc2_ in §_-z2Z§)
         {
            if(param1 == _loc2_.getId())
            {
               return _loc2_.§_-wz§();
            }
         }
         return null;
      }
      
      public static function §_-V10§(param1:§_-B2i§) : §_-L1x§
      {
         var _loc2_:§_-L1x§ = null;
         for each(_loc2_ in §_-z2Z§)
         {
            if(param1 == _loc2_.§_-wz§())
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public static function §_-S1D§(param1:int) : §_-L1x§
      {
         var _loc2_:§_-L1x§ = null;
         for each(_loc2_ in §_-z2Z§)
         {
            if(_loc2_.getId() == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public static function create(param1:UserProfile, param2:int, param3:int) : §_-01J§
      {
         var _loc4_:§_-L1x§ = null;
         var _loc5_:Class = null;
         for each(_loc4_ in §_-z2Z§)
         {
            if(param1.§_-P2e§() == _loc4_.§_-wz§())
            {
               _loc5_ = _loc4_.§_-wz§().getClass();
               return new _loc5_(param1,param2,param3);
            }
         }
         return null;
      }
      
      public function getId() : uint
      {
         return this.id;
      }
      
      public function §_-wz§() : §_-B2i§
      {
         return this.raceRecord;
      }
   }
}


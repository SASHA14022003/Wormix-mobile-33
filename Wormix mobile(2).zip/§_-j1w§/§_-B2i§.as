package §_-j1w§
{
   import §_-21p§.§_-N1H§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.*;
   import §_-C3f§.§_-1Y§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import §_-YF§.§_-g2W§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-z1x§;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-B2i§ extends §_-1Y§ implements §_-g2W§
   {
      
      public var fraction:int = 0;
      
      public var abilities:Vector.<§_-T0§>;
      
      public var configName:String = "";
      
      public var stayClip:String = "";
      
      public var goClip:String = "";
      
      public var prepareToJumpClip:String = "";
      
      public var endJumpClip:String = "";
      
      public var jumpClip:String = "";
      
      public var jumpBackClip:String = "";
      
      public var breathClip:String = "";
      
      public var sadClip:String = "";
      
      public var clapClip:String = "";
      
      public var jetpack:String = "";
      
      public var jetpackStay:String = "";
      
      public var shocker:String = "";
      
      public var defrost:String = "";
      
      public var defrostAttack:String = "";
      
      public var defrostArmory:String = "";
      
      public var hammer:String = "";
      
      public var bat:String = "";
      
      public var rope:String = "";
      
      public var hatClip:String = "";
      
      public var eyesClip:String = "";
      
      public var earsClip:String = "";
      
      public var leftHand:String = "";
      
      public var rightHand:String = "";
      
      public var stateActions:Array = [];
      
      public var stateActionsInHat:Array = [];
      
      public var damage:String = "";
      
      public var damageInHat:String = "";
      
      public var damaged:String = "";
      
      public var happy:String = "";
      
      public var graveType:String = "";
      
      public var soulType:String = "";
      
      private var §_-b1t§:§_-N1H§ = new §_-N1H§(§_-N1H§.RACE);
      
      private var className:Class;
      
      public function §_-B2i§()
      {
         super();
      }
      
      override public function initFromConfig(param1:Object) : void
      {
         var _loc2_:§_-T0§ = null;
         super.initFromConfig(param1);
         id = param1.id;
         name = param1.name;
         description = param1.descr;
         requiredLevel = param1.requiredLevel;
         this.configName = param1.configName;
         this.fraction = param1.fraction;
         hideInShop = param1.hideInShop;
         this.stayClip = param1.stayClip;
         this.goClip = param1.goClip;
         this.prepareToJumpClip = param1.prepareToJumpClip;
         this.endJumpClip = param1.endJumpClip;
         this.jumpClip = param1.jumpClip;
         this.jumpBackClip = param1.jumpBackClip;
         this.breathClip = param1.breathClip;
         this.sadClip = param1.sadClip;
         this.clapClip = param1.clapClip;
         this.jetpack = param1.jetpack;
         this.jetpackStay = param1.jetpackStay;
         this.shocker = param1.shocker;
         this.defrost = param1.defrost;
         this.defrostArmory = param1.defrostArmory;
         this.defrostAttack = param1.defrostAttack;
         this.hammer = param1.hammer;
         this.rope = param1.rope;
         this.bat = param1.bat;
         this.hatClip = param1.hatClip;
         this.earsClip = param1.earsClip;
         this.eyesClip = param1.eyesClip;
         this.leftHand = param1.leftHand;
         this.rightHand = param1.rightHand;
         this.graveType = param1.graveType;
         this.soulType = param1.soulType;
         this.stateActions = param1.stateActions;
         this.stateActionsInHat = param1.stateActionsInHat;
         this.damage = param1.damage;
         this.damageInHat = param1.damageInHat;
         this.damaged = param1.damaged;
         this.happy = param1.happy;
         this.className = param1.className;
         this.§_-q1k§(param1.bonus);
         this.abilities = param1.abilities;
         for each(_loc2_ in this.abilities)
         {
            _loc2_.§_-i1C§(param1.bonus);
         }
      }
      
      public function getClass() : Class
      {
         return this.className;
      }
      
      public function §_-V1v§() : §_-N1H§
      {
         return this.§_-b1t§;
      }
      
      public function §_-q1k§(param1:Object) : void
      {
         §_-2t§.§_-X1r§(this.§_-b1t§,param1);
      }
      
      public function §_-mj§(param1:String) : §_-T0§
      {
         var _loc2_:§_-T0§ = null;
         for each(_loc2_ in this.abilities)
         {
            if(_loc2_.§_-M2c§() == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
   }
}


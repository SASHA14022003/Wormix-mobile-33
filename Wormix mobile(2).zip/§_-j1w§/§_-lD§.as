package §_-j1w§
{
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-fH§;
   import §_-R2I§.§_-H7§;
   import §_-R2I§.§_-u2V§;
   import §_-Y1O§.§_-V23§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-8D§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.Slider;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.events.Event;
   
   public class §_-lD§
   {
      
      private static var instance:§_-lD§;
      
      public static const §_-81B§:String = "default";
      
      private var chars:Object = new Object();
      
      public function §_-lD§()
      {
         super();
      }
      
      public static function getInstance() : §_-lD§
      {
         if(!instance)
         {
            instance = new §_-lD§();
         }
         return instance;
      }
      
      public static function §_-I3U§() : Object
      {
         return §_-lD§.getInstance().chars;
      }
   }
}


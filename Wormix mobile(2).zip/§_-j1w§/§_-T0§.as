package §_-j1w§
{
   import §_-62§.§_-T1y§;
   import §_-79§.§_-ps§;
   import §_-B1y§.§_-F1P§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G2H§.§_-527§;
   import §_-R2I§.§_-u2V§;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.§_-82X§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import flash.events.Event;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-T0§
   {
      
      private var title:String;
      
      private var description:String;
      
      private var iconName:String;
      
      private var §_-l1X§:Object;
      
      public function §_-T0§(param1:String, param2:String, param3:String)
      {
         super();
         this.title = param1;
         this.description = param2;
         this.iconName = param3;
      }
      
      public function §_-i1C§(param1:Object) : void
      {
         this.§_-l1X§ = param1;
      }
      
      public function §_-23r§() : String
      {
         return §_-s2a§.§_-K3t§(this.title);
      }
      
      public function §_-p1§() : String
      {
         return §_-F1P§.format(§_-s2a§.§_-K3t§(this.description),this.§_-l1X§);
      }
      
      public function §_-M2c§() : String
      {
         return this.iconName;
      }
   }
}


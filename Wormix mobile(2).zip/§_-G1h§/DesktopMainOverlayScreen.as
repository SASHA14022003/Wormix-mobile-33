package §_-G1h§
{
   import §_-73d§.§_-g1J§;
   import §_-DJ§.§_-J2l§;
   import §_-H16§.*;
   import §_-X14§.MainSidePanel;
   import §_-b1F§.§_-v2Q§;
   import §_-eO§.§_-yH§;
   import §_-fo§.*;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-u1T§.LocalizationService;
   import com.greensock.events.LoaderEvent;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Screen;
   import feathers.controls.ToggleButton;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.Dictionary;
   import flash.utils.Timer;
   import org.as3commons.zip.§_-61c§;
   import org.swiftsuspenders.Injector;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import ru.pragmatix.flox.social.controller.ICustomInviter;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-O1f§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.BlendMode;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.textures.TextureSmoothing;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class DesktopMainOverlayScreen extends Screen
   {
      
      private var binder:Binder;
      
      private var §_-k2E§:§_-I1W§;
      
      private var §_-Ef§:§_-e2a§;
      
      private var §_-s2T§:§_-32C§;
      
      private var §_-6F§:§_-I2g§;
      
      private var §_-i2U§:§_-13W§;
      
      private var §_-go§:Array;
      
      private var §_-V8§:MainSidePanel;
      
      public function DesktopMainOverlayScreen()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         var _loc1_:Object = Application.uiBuilder.load(Application.assetManager.getObject("base_screen_overlay"),true,this.binder);
         var _loc2_:Sprite = _loc1_.object as Sprite;
         var _loc3_:Dictionary = _loc1_.params;
         Application.uiBuilder.tweenBuilder.start(_loc2_,_loc3_);
         addChild(this.binder._screen);
         this.binder._blicksLeft.touchable = false;
         this.binder._blicksRight.touchable = false;
         this.binder._left_back_0.touchable = false;
         this.binder._right_back_0.touchable = false;
         this.binder._right_back_1.touchable = false;
         this.§_-k2E§ = new §_-I1W§(Application.§_-E1k§);
         this.§_-k2E§.§_-3Q§(this.binder._blicksLeft);
         this.§_-k2E§.§_-3Q§(this.binder._blicksRight);
         this.§_-k2E§.§_-3Q§(this.binder._bankBtnContainer);
         this.§_-k2E§.§_-3Q§(this.binder._shopBtnContainer);
         this.binder._exitBtn.convertIntoButton();
         this.binder._settingBtn.convertIntoButton();
         this.binder._bankBtn.convertIntoButton();
         this.binder._shopBtn.convertIntoButton();
         this.§_-Ef§ = new §_-e2a§();
         this.§_-Ef§.§_-r1t§(this.binder._bankBtn.button,§_-in§.§_-sg§);
         this.§_-Ef§.§_-r1t§(this.binder._shopBtn.button,§_-in§.SHOP);
         this.§_-Ef§.§_-r1t§(this.binder._settingBtn.button,§_-in§.§_-Z20§);
         this.§_-Ef§.§_-r1t§(this.binder._exitBtn.button,§_-in§.§_-nu§);
         this.§_-s2T§ = new §_-32C§(this.binder._avatarContainer,this.binder._levelContainer,this.binder._nameLabel);
         this.§_-6F§ = new §_-I2g§(this.binder._moneyContainer);
         this.§_-i2U§ = new §_-13W§();
         this.§_-i2U§.§_-E2V§(this.binder._shopBtnContainer);
         this.§_-i2U§.§_-E2V§(this.binder._bankBtnContainer);
         var _loc4_:LocalizationService = §_-X1j§.localizationService;
         _loc4_.§_-I2k§(this.binder._exitBtn.button,"toolTip",§_-s2a§.EXIT_QTIP);
         _loc4_.§_-I2k§(this.binder._settingBtn.button,"toolTip",§_-s2a§.SETTINGS_QTIP);
         _loc4_.§_-I2k§(this.binder._shopBtn.button,"toolTip",§_-s2a§.SHOP_QTIP);
         _loc4_.§_-I2k§(this.binder._bankBtn.button,"toolTip",§_-s2a§.BANK_QTIP);
         this.§_-go§ = [];
         this.§_-go§.push(this.§_-Ef§);
         this.§_-go§.push(this.§_-s2T§);
         this.§_-go§.push(this.§_-6F§);
         this.§_-go§.push(this.§_-i2U§);
         var _loc5_:§_-r1d§ = Application.§_-SH§;
         _loc5_.addEventListener(starling.events.Event.CHANGE,this.§_-Z2B§);
         var _loc6_:ToggleButton = this.binder._panelToggleButton.convertIntoToggleButton();
         _loc6_.y = 400;
         this.binder._panelToggleButton.removeFromParent();
         addChild(_loc6_);
         this.§_-V8§ = new MainSidePanel();
         Application.§_-ow§.§_-K3Q§(this.§_-V8§,_loc6_);
      }
      
      override public function dispose() : void
      {
         this.§_-k2E§.dispose();
         this.§_-Ef§.dispose();
         this.§_-s2T§.dispose();
         this.§_-6F§.dispose();
         this.§_-i2U§.dispose();
         var _loc1_:LocalizationService = §_-X1j§.localizationService;
         _loc1_.removeObject(this.binder._exitBtn.button);
         _loc1_.removeObject(this.binder._settingBtn.button);
         _loc1_.removeObject(this.binder._shopBtn.button);
         _loc1_.removeObject(this.binder._bankBtn.button);
         var _loc2_:§_-r1d§ = Application.§_-SH§;
         if(_loc2_)
         {
            _loc2_.removeEventListener(starling.events.Event.CHANGE,this.§_-Z2B§);
         }
         Application.§_-ow§.§_-K3Q§(null);
         this.§_-V8§.dispose();
         super.dispose();
      }
      
      override protected function draw() : void
      {
         var _loc6_:§_-r1d§ = null;
         super.draw();
         var _loc1_:Number = stage.stageWidth;
         var _loc2_:Number = stage.stageHeight;
         var _loc3_:Rectangle = Pool.getRectangle(0,0,1920,1080);
         var _loc4_:Rectangle = Pool.getRectangle(0,0,_loc1_,_loc2_);
         _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
         var _loc5_:Number = Number(Math.max(_loc3_.width / 1920,_loc3_.height / 1080));
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
         this.binder._screen.scale = _loc5_;
         this.binder._screen.width = _loc1_;
         this.binder._screen.height = _loc2_;
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc6_ = Application.§_-SH§;
            this.§_-G1L§(this.§_-go§,_loc6_);
         }
      }
      
      private function §_-G1L§(param1:Array, param2:§_-r1d§) : void
      {
         var _loc3_:§_-O1f§ = null;
         for each(_loc3_ in param1)
         {
            _loc3_.§_-32X§(param2);
         }
      }
      
      private function §_-Z2B§(param1:starling.events.Event) : void
      {
         if(Application.§_-ow§.isLeftDrawerOpen)
         {
            Application.§_-ow§.toggleLeftDrawer(0);
         }
      }
   }
}

import feathers.controls.LayoutGroup;
import starling.display.Image;
import starling.display.Sprite;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
import starlingbuilder.extensions.uicomponents.CustomLabel;

class Binder
{
   
   public var _screen:LayoutGroup;
   
   public var _blicksLeft:Sprite;
   
   public var _blicksRight:Sprite;
   
   public var _shopBtnContainer:Sprite;
   
   public var _bankBtnContainer:Sprite;
   
   public var _moneyContainer:Sprite;
   
   public var _left_back_0:Image;
   
   public var _right_back_0:Image;
   
   public var _right_back_1:Image;
   
   public var _exitBtn:ContainerButtonWithStates;
   
   public var _settingBtn:ContainerButtonWithStates;
   
   public var _bankBtn:ContainerButtonWithStates;
   
   public var _shopBtn:ContainerButtonWithStates;
   
   public var _panelToggleButton:ContainerButtonWithStates;
   
   public var _avatarContainer:LayoutGroup;
   
   public var _levelContainer:Sprite;
   
   public var _nameLabel:CustomLabel;
   
   public function Binder()
   {
      super();
   }
}

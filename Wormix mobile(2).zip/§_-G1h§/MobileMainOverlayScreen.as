package §_-G1h§
{
   import §_-23P§.§_-u1z§;
   import §_-62§.*;
   import §_-63U§.§_-412§;
   import §_-9§.§_-52A§;
   import §_-A1K§.§_-7u§;
   import §_-A2F§.§_-4B§;
   import §_-Af§.*;
   import §_-DJ§.§_-J2l§;
   import §_-J31§.§_-e2J§;
   import §_-X14§.MainSidePanel;
   import §_-Z1K§.§_-M6§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-F3m§;
   import §_-l1K§.§_-I7§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-f2L§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sK§.*;
   import §_-sQ§.§_-737§;
   import §_-w2W§.§_-21w§;
   import §_-w2i§.§_-Ia§;
   import §_-z20§.§_-V7§;
   import §_-z20§.§_-p4§;
   import §_-z2S§.SafeAreaUtils;
   import feathers.controls.List;
   import feathers.controls.Screen;
   import feathers.controls.ToggleButton;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import flash.geom.Rectangle;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-in§;
   import ru.pragmatix.wormix.messages.client.EndTurn;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.weapons.§_-N1C§;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class MobileMainOverlayScreen extends Screen
   {
      
      private var binder:Binder;
      
      private var toggleButton:ToggleButton;
      
      private var §_-V8§:MainSidePanel;
      
      private var isReady:Boolean;
      
      public function MobileMainOverlayScreen()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         var _loc1_:Object = Application.uiBuilder.load(Application.assetManager.getObject("main_screen_overlay"),true,this.binder);
         var _loc2_:Sprite = _loc1_.object as Sprite;
         var _loc3_:Dictionary = _loc1_.params;
         Application.uiBuilder.tweenBuilder.start(_loc2_,_loc3_);
         addChild(this.binder._screen);
         this.layout = new AnchorLayout();
         this.binder._screen.layoutData = new AnchorLayoutData(0,0,0,0);
         this.binder._right_background.touchable = false;
         this.binder._socialLabel.touchable = false;
         this.binder._bankButton.useHandCursor = true;
         this.binder._shopButton.useHandCursor = true;
         this.binder._settingsButton.useHandCursor = true;
         this.binder._socialButton.useHandCursor = true;
         this.binder._tgButton.useHandCursor = true;
         this.binder._vkButton.useHandCursor = true;
         this.binder._bankButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._shopButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._settingsButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._socialButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._tgButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._vkButton.addEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.toggleButton = this.binder._panelToggleButton.convertIntoToggleButton();
         this.binder._panelToggleButton.removeFromParent();
         this.toggleButton.pivotX = this.binder._panelToggleButton.pivotX;
         this.toggleButton.pivotY = this.binder._panelToggleButton.pivotY;
         this.toggleButton.x = this.binder._panelToggleButton.x;
         this.toggleButton.y = this.binder._panelToggleButton.y;
         this.§_-V8§ = new MainSidePanel();
         Application.§_-ow§.§_-K3Q§(this.§_-V8§,this.toggleButton);
         §_-N1V§.addListener(§_-f2L§.§_-Rx§,this.updateVisibility);
      }
      
      private function updateVisibility(param1:Object = null) : void
      {
         this.binder._socialButton.visible = §_-N1V§.§_-e28§ != "";
         this.binder._socialLabel.text = §_-N1V§.§_-e28§;
      }
      
      override protected function draw() : void
      {
         var _loc1_:Number = NaN;
         var _loc2_:Number = NaN;
         var _loc3_:Number = NaN;
         var _loc4_:Rectangle = null;
         var _loc5_:Rectangle = null;
         var _loc6_:Rectangle = null;
         var _loc7_:Boolean = false;
         if(!this.binder)
         {
            return;
         }
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE))
         {
            _loc1_ = stage.stageWidth;
            _loc2_ = stage.stageHeight;
            if(_loc1_ == 0 || _loc2_ == 0)
            {
               return;
            }
            _loc3_ = _loc2_ / 1080;
            this.binder._screen.scale = _loc3_;
            this.binder._screen.width = _loc1_;
            this.binder._screen.height = _loc2_;
            this.binder._socialButton.visible = §_-N1V§.§_-e28§ != "";
            this.binder._socialLabel.text = §_-N1V§.§_-e28§;
            _loc4_ = SafeAreaUtils.§_-o1J§();
            _loc5_ = SafeAreaUtils.§_-C29§();
            _loc6_ = SafeAreaUtils.§_-q1J§();
            _loc7_ = SafeAreaUtils.willCutoutAffectView();
            this.toggleButton.scale = _loc3_;
            this.toggleButton.y = _loc7_ ? _loc2_ - _loc5_.x - (this.toggleButton.height - this.toggleButton.pivotY) : (_loc2_ + this.toggleButton.pivotY) * 0.5 + this.toggleButton.height;
            this.binder._screen.layoutData = new AnchorLayoutData(0,0,0,0);
            this.readjustLayout();
            Application.§_-ow§.§_-K3Q§(this.§_-V8§,this.toggleButton,_loc4_.left,0);
            Pool.putRectangle(_loc4_);
            Pool.putRectangle(_loc5_);
            Pool.putRectangle(_loc6_);
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.binder._bankButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._shopButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._settingsButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         this.binder._socialButton.removeEventListener(Event.TRIGGERED,this.§_-y1l§);
         Application.§_-ow§.§_-K3Q§(null);
         §_-N1V§.removeListener(§_-f2L§.§_-Rx§,this.updateVisibility);
         this.§_-V8§.dispose();
         this.toggleButton.dispose();
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         var _loc2_:int = -1;
         var _loc3_:EventDispatcher = param1.currentTarget;
         switch(_loc3_)
         {
            case this.binder._bankButton:
               §§push(0);
               break;
            case this.binder._shopButton:
               §§push(1);
               break;
            case this.binder._settingsButton:
               §§push(2);
               break;
            case this.binder._socialButton:
               §§push(3);
               break;
            case this.binder._tgButton:
               §§push(4);
               break;
            default:
               if(this.binder._vkButton === _loc3_)
               {
                  §§push(5);
                  break;
               }
               §§push(6);
         }
         switch(§§pop())
         {
            case 0:
               _loc2_ = §_-in§.§_-sg§;
               break;
            case 1:
               _loc2_ = §_-in§.SHOP;
               break;
            case 2:
               _loc2_ = §_-in§.§_-Z20§;
               break;
            case 3:
               _loc2_ = §_-in§.§_-6b§;
               break;
            case 4:
               _loc2_ = §_-in§.§_-P2I§;
               break;
            case 5:
               _loc2_ = §_-in§.§_-f2Y§;
         }
         dispatchEventWith(Event.TRIGGERED,false,_loc2_);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import starling.display.Image;
import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
import starlingbuilder.extensions.uicomponents.ImageButton;

class Binder
{
   
   public var _screen:LayoutGroup;
   
   public var _right_background:Image;
   
   public var _bankButton:ImageButton;
   
   public var _shopButton:ImageButton;
   
   public var _settingsButton:ImageButton;
   
   public var _socialButton:ImageButton;
   
   public var _tgButton:ImageButton;
   
   public var _vkButton:ImageButton;
   
   public var _socialLabel:Label;
   
   public var _panelToggleButton:ContainerButtonWithStates;
   
   public function Binder()
   {
      super();
   }
}

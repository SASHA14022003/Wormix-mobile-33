package §_-N8§
{
   public class §_-2C§ extends §_-o2w§
   {
      
      private var §_-p1b§:int;
      
      public function §_-2C§(param1:int, param2:String, param3:String, param4:Object, param5:Object, param6:int, param7:uint)
      {
         super(param1,param2,param3,param4,param5,"",param7);
         this.§_-p1b§ = param6;
      }
      
      public function get §_-B3d§() : int
      {
         return this.§_-p1b§;
      }
   }
}


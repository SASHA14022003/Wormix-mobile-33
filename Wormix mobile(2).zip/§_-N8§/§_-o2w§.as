package §_-N8§
{
   import §_-31W§.§_-8§;
   import §_-31W§.§_-Kb§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.display.Quad;
   import starling.events.Event;
   
   public class §_-o2w§ implements §_-8§
   {
      
      private var _id:§_-TA§;
      
      private var _description:String;
      
      private var §_-N1f§:Object;
      
      private var §_-q§:Vector.<§_-Kb§>;
      
      public function §_-o2w§(param1:int, param2:String, param3:String, param4:Object, param5:Object, param6:String, param7:uint)
      {
         super();
         this._id = new §_-TA§(param1);
         this._description = param3;
         this.§_-N1f§ = param4;
         this.§_-q§ = new Vector.<§_-Kb§>(0);
         this.§_-q§.push(new §_-Kb§(param2,param5,1,param6,param7));
      }
      
      public function get id() : int
      {
         return this._id.value;
      }
      
      public function get levels() : Vector.<§_-Kb§>
      {
         return this.§_-q§;
      }
      
      public function §_-p1§(param1:uint) : String
      {
         return this._description != null && this.§_-N1f§ != null ? §_-F1P§.format(§_-s2a§.§_-y2o§(this._description),{"value":this.§_-N1f§.value}) : §_-s2a§.§_-y2o§(this._description);
      }
   }
}


package §_-K3r§
{
   import §_-31W§.§_-aO§;
   import §_-63U§.§_-21K§;
   import §_-73I§.§_-K2s§;
   import §_-9§.§_-52A§;
   import §_-931§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-Nq§.*;
   import §_-R2S§.Farmer;
   import §_-R2S§.Hunter;
   import §_-R2S§.Miner;
   import §_-R2S§.§_-P1U§;
   import §_-R2S§.§_-z2x§;
   import §_-RE§.§_-w0§;
   import §_-TF§.§_-q1j§;
   import §_-Y1O§.*;
   import §_-YF§.§_-L29§;
   import §_-YF§.§_-q2v§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-bI§.§_-d2V§;
   import §_-hO§.§_-03k§;
   import §_-k1u§.§_-H2M§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-kP§.*;
   import §_-l1K§.*;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-r1C§.§_-h2B§;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-v27§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.greensock.TweenMax;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ScrollPolicy;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import flash.errors.IllegalOperationError;
   import flash.geom.Rectangle;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.response.ListClansResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillMissile;
   import ru.pragmatix.wormix.weapons.ammo.VerticalDrillStanding;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-E3O§ extends ScreenNavigator
   {
      
      private var §_-e1d§:String;
      
      private var §_-Q2Z§:Function;
      
      private var §_-k2W§:String;
      
      private var §_-sC§:Boolean;
      
      public function §_-E3O§()
      {
         super();
         super.addEventListener(Event.CHANGE,this.§_-c1k§);
      }
      
      public function §_-MO§(param1:String, param2:Function, param3:Function = null) : DisplayObject
      {
         if(param2 != null)
         {
            this.§_-Q2Z§ = param2;
            this.§_-k2W§ = param1;
         }
         return this.showScreen(param1,param3);
      }
      
      override public function showScreen(param1:String, param2:Function = null) : DisplayObject
      {
         var gameScreen:§_-v27§ = null;
         var saveCallback:Function = null;
         var id:String = param1;
         var transition:Function = param2;
         this.transition = transition;
         if(!isEnabled)
         {
            isEnabled = true;
         }
         if(Boolean(activeScreen) && activeScreenID != id)
         {
            gameScreen = activeScreen as §_-v27§;
            if(gameScreen)
            {
               saveCallback = function(param1:Boolean):void
               {
                  if(param1)
                  {
                     showScreenAfterCurScreenSaved(id);
                  }
                  else
                  {
                     dispatchEventWith(Event.CHANGE);
                  }
               };
               gameScreen.save(saveCallback);
            }
         }
         else
         {
            this.showScreenAfterCurScreenSaved(id);
         }
         return null;
      }
      
      private function showScreenAfterCurScreenSaved(param1:String) : void
      {
         if(_activeScreenID != param1)
         {
            if(!hasScreen(param1))
            {
               this.§_-y2A§(param1);
            }
            this.§_-o5§(param1);
         }
         else
         {
            this.§_-S5§();
         }
      }
      
      public function §_-A1J§() : void
      {
         var _loc1_:§_-v27§ = _activeScreen as §_-v27§;
         _loc1_.update();
      }
      
      public function §_-do§() : Boolean
      {
         return Boolean(_activeScreenID) && _activeScreenID.search("Room") != -1;
      }
      
      public function §_-w18§(param1:String) : Boolean
      {
         return _activeScreenID == param1;
      }
      
      private function §_-y2A§(param1:String) : void
      {
         var _loc2_:Class = this.§_-m2Q§(param1);
         if(_loc2_)
         {
            addScreen(param1,new ScreenNavigatorItem(_loc2_));
         }
      }
      
      protected function §_-m2Q§(param1:String) : Class
      {
         return null;
      }
      
      private function §_-o5§(param1:String) : void
      {
         this.§_-e1d§ = param1;
         this.§_-sC§ = false;
         if(this.§_-w18§(§_-21w§.§_-lv§) || param1 == §_-21w§.§_-lv§)
         {
            this.§_-s21§();
         }
         else
         {
            this.§_-sC§ = true;
            §_-J2l§.§_-u2b§.show(this.§_-s21§);
         }
      }
      
      private function §_-s21§() : void
      {
         if(this.§_-e1d§)
         {
            §_-L29§.§_-d2x§(this.§_-e1d§,this.§_-C1z§);
         }
         else
         {
            this.§_-C1z§();
         }
      }
      
      private function §_-C1z§() : void
      {
         if(Boolean(this.§_-e1d§) && Boolean(getScreen(this.§_-e1d§)))
         {
            super.showScreen(this.§_-e1d§);
         }
         this.§_-e1d§ = null;
      }
      
      private function §_-c1k§(param1:Event) : void
      {
         if(_transition == null)
         {
            this.§_-RI§();
            this.§_-S5§();
         }
      }
      
      override protected function transitionComplete(param1:Boolean = false) : void
      {
         super.transitionComplete(param1);
         this.§_-RI§();
         this.§_-S5§();
      }
      
      private function §_-S5§() : void
      {
         var _loc1_:Function = null;
         if(this.§_-Q2Z§ != null && _activeScreenID == this.§_-k2W§)
         {
            _loc1_ = this.§_-Q2Z§;
            this.§_-Q2Z§ = null;
            this.§_-k2W§ = null;
            _loc1_();
         }
      }
      
      private function §_-RI§() : void
      {
         if(activeScreenID != §_-21w§.§_-lv§ && this.§_-sC§)
         {
            §_-J2l§.§_-u2b§.hide();
         }
      }
   }
}


package §_-K3r§
{
   import §_-21p§.§_-4w§;
   import §_-p24§.*;
   import §_-w2W§.AchieveRoomScreenDesktop;
   import §_-w2W§.ArmoryScreenDesktop;
   import §_-w2W§.CraftRoomScreenDesktop;
   import §_-w2W§.DesktopRaceRoomScreen;
   import §_-w2W§.MainMenuScreenDesktop;
   import §_-w2W§.TeamRoomScreenDesktop;
   import §_-w2W§.WardrobeRoomScreen;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-72M§;
   import §_-w2W§.§_-HV§;
   import §_-w2W§.§_-I2R§;
   import §_-w2W§.§_-I3c§;
   import §_-w2W§.§_-h1Z§;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   
   public class §_-M2u§ extends §_-E3O§
   {
      
      public function §_-M2u§()
      {
         super();
      }
      
      override protected function §_-m2Q§(param1:String) : Class
      {
         var _loc2_:String = param1;
         switch(_loc2_)
         {
            case §_-21w§.§_-lv§:
               §§push(0);
               break;
            case §_-21w§.§_-G31§:
               §§push(1);
               break;
            default:
               loop1:
               switch(_loc2_)
               {
                  case §_-21w§.§_-81H§:
                     §§push(2);
                     break;
                  case §_-21w§.§_-F3d§:
                     §§push(3);
                     break;
                  case §_-21w§.§_-H2E§:
                     §§push(4);
                     break;
                  case §_-21w§.§_-G2M§:
                     §§push(5);
                     break;
                  case §_-21w§.§_-jc§:
                     §§push(6);
                     break;
                  case §_-21w§.§_-l1e§:
                     §§push(7);
                     break;
                  case §_-21w§.§_-43d§:
                     §§push(8);
                     break;
                  case §_-21w§.BATTLE_LOADING:
                     §§push(9);
                     break;
                  default:
                     switch(_loc2_)
                     {
                        case §_-21w§.BATTLE_CLEANING:
                           §§push(10);
                           break loop1;
                        case §_-21w§.BATTLE_SCENE:
                           §§push(11);
                           break loop1;
                        default:
                           §§push(12);
                           break loop1;
                     }
               }
         }
         switch(§§pop())
         {
            case 0:
               return §_-I3c§;
            case 1:
               return MainMenuScreenDesktop;
            case 2:
               return §_-I2R§;
            case 3:
               return ArmoryScreenDesktop;
            case 4:
               return TeamRoomScreenDesktop;
            case 5:
               return WardrobeRoomScreen;
            case 6:
               return DesktopRaceRoomScreen;
            case 7:
               return AchieveRoomScreenDesktop;
            case 8:
               return CraftRoomScreenDesktop;
            case 9:
               return §_-HV§;
            case 10:
               return §_-h1Z§;
            case 11:
               return §_-72M§;
            default:
               return null;
         }
      }
   }
}


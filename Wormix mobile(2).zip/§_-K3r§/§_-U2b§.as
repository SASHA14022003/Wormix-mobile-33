package §_-K3r§
{
   import §_-l1g§.§_-L3Q§;
   import §_-w2W§.AchieveRoomScreenMobile;
   import §_-w2W§.ArmoryScreenMobile;
   import §_-w2W§.CraftRoomScreenMobile;
   import §_-w2W§.MainMenuScreenMobile;
   import §_-w2W§.MobileRaceRoomScreen;
   import §_-w2W§.TeamRoomScreenMobile;
   import §_-w2W§.WardrobeRoomScreen;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-72M§;
   import §_-w2W§.§_-HV§;
   import §_-w2W§.§_-I2R§;
   import §_-w2W§.§_-I3c§;
   import §_-w2W§.§_-h1Z§;
   import §_-zI§.*;
   import com.worlize.websocket.§_-ue§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   
   public class §_-U2b§ extends §_-E3O§
   {
      
      public function §_-U2b§()
      {
         super();
      }
      
      override protected function §_-m2Q§(param1:String) : Class
      {
         var _loc2_:String = param1;
         switch(_loc2_)
         {
            case §_-21w§.§_-lv§:
               §§push(0);
               break;
            case §_-21w§.§_-G31§:
               §§push(1);
               break;
            default:
               loop1:
               switch(_loc2_)
               {
                  case §_-21w§.§_-81H§:
                     §§push(2);
                     break;
                  case §_-21w§.§_-F3d§:
                     §§push(3);
                     break;
                  case §_-21w§.§_-H2E§:
                     §§push(4);
                     break;
                  case §_-21w§.§_-G2M§:
                     §§push(5);
                     break;
                  case §_-21w§.§_-jc§:
                     §§push(6);
                     break;
                  case §_-21w§.§_-l1e§:
                     §§push(7);
                     break;
                  case §_-21w§.§_-43d§:
                     §§push(8);
                     break;
                  case §_-21w§.BATTLE_LOADING:
                     §§push(9);
                     break;
                  default:
                     switch(_loc2_)
                     {
                        case §_-21w§.BATTLE_CLEANING:
                           §§push(10);
                           break loop1;
                        case §_-21w§.BATTLE_SCENE:
                           §§push(11);
                           break loop1;
                        default:
                           §§push(12);
                           break loop1;
                     }
               }
         }
         switch(§§pop())
         {
            case 0:
               return §_-I3c§;
            case 1:
               return MainMenuScreenMobile;
            case 2:
               return §_-I2R§;
            case 3:
               return ArmoryScreenMobile;
            case 4:
               return TeamRoomScreenMobile;
            case 5:
               return WardrobeRoomScreen;
            case 6:
               return MobileRaceRoomScreen;
            case 7:
               return AchieveRoomScreenMobile;
            case 8:
               return CraftRoomScreenMobile;
            case 9:
               return §_-HV§;
            case 10:
               return §_-h1Z§;
            case 11:
               return §_-72M§;
            default:
               return null;
         }
      }
   }
}


package §_-f2N§
{
   import §_-21p§.§_-4w§;
   import §_-63M§.§_-F3f§;
   import §_-71F§.Command;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-b2K§;
   import §_-L1w§.§_-J2w§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Y1b§.§_-22N§;
   import §_-l1g§.§_-L3Q§;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalLayout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-N2v§ extends Command
   {
      
      [Inject]
      public var event:Event;
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      public function §_-N2v§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var _loc1_:UserProfile = this.event.data as UserProfile;
         if(_loc1_.§_-ia§())
         {
            if(_loc1_.§_-d1C§)
            {
               §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.OTHER_PLATFORM_CLAN_SHOW_UNAVAILABLE));
            }
            else
            {
               this.§_-2f§.§_-E24§ = _loc1_.clanMember.clanId;
               this.§_-2f§.userProfile = Application.userProfile;
               MainClanWindow.§_-Fg§(§_-K3K§.INFO);
            }
         }
      }
   }
}


package §_-f2N§
{
   import §_-71F§.Command;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-83E§;
   import §_-L1H§.§_-C3e§;
   import §_-l1K§.*;
   import §_-r1C§.§_-h2B§;
   import flash.errors.IllegalOperationError;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-j11§ extends Command
   {
      
      [Inject]
      public var event:Event;
      
      public function §_-j11§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var _loc2_:ClanTO = null;
         var _loc3_:ClanMemberTO = null;
         var _loc1_:UserProfile = this.event.data as UserProfile;
         if(_loc1_.§_-ia§())
         {
            _loc2_ = §_-A23§.§_-Y1d§(_loc1_.clanMember.clanId);
            _loc3_ = §_-6A§.§_-k1a§(_loc1_.getId(),_loc2_);
            §_-X1j§.§_-hl§.member.§_-Jx§(_loc3_.profileId,_loc3_.rank + 1,null);
         }
      }
   }
}


package §_-f2N§
{
   import §_-71F§.Command;
   import §_-73I§.*;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-DJ§.ClanFireWindow;
   import §_-DJ§.§_-fH§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontSize;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.events.Event;
   
   public class §_-31O§ extends Command
   {
      
      [Inject]
      public var event:starling.events.Event;
      
      public function §_-31O§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var _loc1_:UserProfile = this.event.data as UserProfile;
         var _loc2_:ClanMemberTO = §_-6A§.§_-k1a§(_loc1_.getId());
         var _loc3_:ClanMemberTO = §_-6A§.§_-k1a§(Application.userProfile.getId());
         if(!_loc3_.expelPermit)
         {
            §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.§_-V1p§),MessageBox.§_-1B§);
         }
         else
         {
            §_-X1j§.§_-hl§.common.§_-G3b§(_loc2_.clanId,ClanTO.SCOPE_ALL,§_-bs§.§_-d1Z§(this.§_-r1y§,this,[_loc1_]));
         }
      }
      
      private function §_-r1y§(param1:UserProfile) : void
      {
         var clanMemberTO:ClanMemberTO = null;
         var clanSettings:§_-sI§ = null;
         var myProfile:UserProfile = null;
         var donation:int = 0;
         var medalsRate:int = 0;
         var medalsAllForChange:uint = 0;
         var cost:int = 0;
         var summ:int = 0;
         var msg:String = null;
         var isEnough:Boolean = false;
         var userProfile:UserProfile = param1;
         clanMemberTO = §_-6A§.§_-k1a§(userProfile.getId());
         clanSettings = §_-F3q§.getInstance();
         myProfile = Application.userProfile;
         var myRank:int = myProfile.clanMember.rank;
         donation = clanMemberTO.donationCurrSeason + clanMemberTO.donationPrevSeason;
         medalsRate = clanMemberTO.seasonRating - clanMemberTO.cashedMedals * clanSettings.medalRatingChangeValue;
         medalsAllForChange = medalsRate / clanSettings.medalRatingChangeValue;
         cost = §_-A23§.userClan.medalPrice * medalsAllForChange;
         summ = donation + cost;
         var title:String = §_-s2a§.TITLE_ATTENTION;
         if(summ > 0)
         {
            msg = "";
            if(myRank == §_-X1q§.§_-O2V§)
            {
               isEnough = summ <= §_-A23§.userClan.treasury;
               if(isEnough)
               {
                  new ClanFireWindow(userProfile,donation,cost,function():void
                  {
                     §_-X1j§.§_-hl§.member.§_-E34§(clanMemberTO.profileId,function():void
                     {
                        §_-A23§.userClan.treasury -= summ;
                        §_-h2B§.play(§_-d27§.§_-sg§);
                     });
                  }).show();
               }
               else
               {
                  title = §_-s2a§.TREASURY_NOT_ENOUGH_TITLE;
                  msg = §_-s2a§.NEED_FOR_COMPENSATION_MEMBER;
               }
            }
            else
            {
               msg = §_-s2a§.ONLY_LEADER_CAN_EXPELL_MEMBER_WITH_COMPENSATION;
            }
            if(msg != "")
            {
               §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(title),§_-s2a§.§_-K3t§(msg),MessageBox.§_-1B§);
               §_-h2B§.play(§_-d27§.§_-b2H§);
            }
         }
         else
         {
            msg = §_-s2a§.CONFIRM_EXPELL_CLANMATE;
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(title),§_-s2a§.§_-K3t§(msg),MessageBox.§_-X2g§,function():void
            {
               §_-X1j§.§_-hl§.member.§_-E34§(clanMemberTO.profileId,null);
            });
         }
      }
   }
}


package §_-f2N§
{
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-71F§.Command;
   import §_-73d§.§_-pT§;
   import §_-A2U§.§_-A23§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-j1w§.§_-B2i§;
   import §_-l1K§.§_-W2f§;
   import §_-w2W§.§_-21w§;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import config.§_-V2w§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.events.Event;
   
   public class §_-910§ extends Command
   {
      
      [Inject]
      public var event:Event;
      
      public function §_-910§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var up:UserProfile = null;
         var clan:ClanTO = null;
         var clanMember:ClanMemberTO = null;
         var profileRank:int = 0;
         var clanSettings:§_-sI§ = null;
         var isOfficer:Boolean = false;
         var msgText:String = null;
         up = this.event.data as UserProfile;
         var me:UserProfile = Application.userProfile;
         if(up.§_-ia§())
         {
            clan = §_-A23§.§_-Y1d§(up.clanMember.clanId);
            clanMember = §_-6A§.§_-k1a§(up.getId(),clan);
            profileRank = clanMember.rank;
            clanSettings = §_-F3q§.getInstance();
            isOfficer = profileRank == §_-X1q§.OFFICER;
            msgText = isOfficer ? §_-s2a§.§_-K3t§(§_-s2a§.PROMOTION_CONFIRMATION_LEADER) : §_-s2a§.§_-K3t§(§_-s2a§.PROMOTION_CONFIRMATION_OFFICER);
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),msgText,§_-fH§.§_-X2g§,function():void
            {
               var _loc6_:ClanMemberTO = null;
               var _loc7_:String = null;
               var _loc8_:String = null;
               var _loc9_:String = null;
               var _loc1_:uint = uint(up.§_-y1E§());
               var _loc2_:uint = up.§_-Zp§();
               var _loc3_:Boolean = profileRank == §_-X1q§.§_-CM§ || _loc1_ >= clanSettings.promoteToLeaderLevel && _loc2_ >= clanSettings.promoteToLeaderRating;
               var _loc4_:§_-92Q§ = §_-92Q§.getLevel(§_-A23§.userClan.level);
               var _loc5_:int = 0;
               for each(_loc6_ in §_-A23§.userClan.members)
               {
                  if(_loc6_.rank == §_-X1q§.OFFICER)
                  {
                     _loc5_++;
                  }
                  if(_loc5_ == _loc4_.§_-52X§)
                  {
                     break;
                  }
               }
               _loc7_ = §_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR);
               if(!_loc3_)
               {
                  _loc8_ = StringUtil.format(§_-s2a§.PROMOTION_LEADER_FAILED,{
                     "level":clanSettings.promoteToLeaderLevel,
                     "rating":clanSettings.promoteToLeaderRating
                  });
                  §_-fH§.§_-q1a§(_loc7_,_loc8_,MessageBox.§_-1B§);
               }
               else if(isOfficer && (!clanMember.expelPermit || clanMember.muteMode))
               {
                  §_-fH§.§_-q1a§(_loc7_,§_-s2a§.§_-K3t§(§_-s2a§.PROMOTION_LEADER_FAILED_2),MessageBox.§_-1B§);
               }
               else if(profileRank == §_-X1q§.§_-CM§ && _loc5_ == _loc4_.§_-52X§)
               {
                  _loc9_ = §_-92Q§.getLevel(§_-A23§.userClan.level + 1) != null ? " " + §_-s2a§.§_-K3t§(§_-s2a§.PROMOTION_OFFICER_FAILED_LIMIT) : "";
                  §_-fH§.§_-q1a§(_loc7_,§_-s2a§.§_-K3t§(§_-s2a§.PROMOTION_OFFICER_FAILED) + _loc9_,MessageBox.§_-1B§);
               }
               else
               {
                  §_-X1j§.§_-hl§.member.§_-L1a§(clanMember.profileId,profileRank - 1,null);
               }
            });
         }
      }
   }
}


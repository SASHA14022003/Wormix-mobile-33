package §_-f2N§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-71F§.Command;
   import §_-DJ§.§_-fH§;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-X1q§;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import starling.events.Event;
   
   public class §_-h10§ extends Command
   {
      
      [Inject]
      public var event:Event;
      
      public function §_-h10§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var attention:String;
         var userProfile:UserProfile = null;
         var myProfile:UserProfile = null;
         var msgText:String = null;
         userProfile = this.event.data as UserProfile;
         myProfile = Application.userProfile;
         if(userProfile.equals(myProfile))
         {
            return;
         }
         attention = §_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION);
         if(myProfile.clanMember.clanId == 0)
         {
            §_-fH§.§_-q1a§(attention,§_-s2a§.§_-K3t§("PLAYER_NOT_IN_CLAN"));
         }
         else if(myProfile.clanMember.rank == §_-X1q§.§_-CM§)
         {
            §_-fH§.§_-q1a§(attention,§_-s2a§.§_-K3t§("RESTRICTION_ON_RANK_AT_INVITE"));
         }
         else if(userProfile.§_-ia§())
         {
            §_-fH§.§_-q1a§(attention,§_-s2a§.§_-K3t§("FRIEND_ALREADY_IN_CLAN"));
         }
         else if(userProfile.getLevel() < §_-8D§.§_-v3§)
         {
            msgText = StringUtil.format(§_-s2a§.§_-K3t§("ERR_INVITE_LOW_LEVEL_FRIEND"),{"level":§_-8D§.§_-v3§});
            §_-fH§.§_-q1a§(attention,msgText);
         }
         else if(userProfile.§_-d1C§)
         {
            §_-fH§.§_-q1a§(attention,§_-s2a§.§_-K3t§(§_-s2a§.OTHER_PLATFORM_INVITES_UNAVAILABLE));
         }
         else
         {
            §_-fH§.§_-q1a§(attention,§_-s2a§.§_-K3t§("CONFIRM_INVITE_TO_CLAN"),§_-fH§.§_-H2d§,function():void
            {
               §_-X1j§.§_-hl§.member.inviteFriend(userProfile,myProfile.clanMember.clanId);
            });
         }
      }
   }
}


package §_-f2N§
{
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-71F§.Command;
   import §_-A1K§.§_-TA§;
   import §_-J3L§.§_-h1D§;
   import §_-L1H§.§_-C3e§;
   import §_-Z1K§.§_-q24§;
   import §_-w2i§.§_-Zd§;
   import flash.geom.Point;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-83C§ extends Command
   {
      
      [Inject]
      public var event:Event;
      
      public function §_-83C§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var _loc1_:UserProfile = this.event.data as UserProfile;
         var _loc2_:ClanMemberTO = §_-6A§.§_-k1a§(_loc1_.getId());
         if(_loc2_)
         {
            §_-X1j§.§_-hl§.member.expelPermit(_loc2_,null);
         }
      }
   }
}


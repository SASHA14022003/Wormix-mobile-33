package §_-f2N§
{
   import §_-21p§.§_-4w§;
   import §_-63U§.§_-21K§;
   import §_-71F§.Command;
   import §_-C2t§.§_-wL§;
   import §_-U1i§.§_-U16§;
   import §_-jF§.§_-82f§;
   import §_-l1K§.§_-W2f§;
   import §_-rM§.§_-61j§;
   import §_-wD§.*;
   import feathers.core.ITextRenderer;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.server.ArenaResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionDailyProgressStructure;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-i2M§ extends Command
   {
      
      [Inject]
      public var event:Event;
      
      public function §_-i2M§()
      {
         super();
      }
      
      override public function execute() : void
      {
         var _loc1_:UserProfile = this.event.data as UserProfile;
         var _loc2_:ClanMemberTO = §_-6A§.§_-k1a§(_loc1_.getId());
         if(_loc2_)
         {
            §_-X1j§.§_-hl§.member.muteMode(_loc2_,null);
         }
      }
   }
}


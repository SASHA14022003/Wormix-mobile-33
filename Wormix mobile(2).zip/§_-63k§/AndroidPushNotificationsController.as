package §_-63k§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-31W§.*;
   import §_-43V§.*;
   import §_-5Y§.*;
   import §_-62§.*;
   import §_-9§.§_-52A§;
   import §_-91B§.§_-z2l§;
   import §_-931§.*;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.*;
   import §_-C3f§.§_-yG§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-OJ§.§_-jt§;
   import §_-TF§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.*;
   import §_-Z1K§.§_-q24§;
   import §_-b19§.BossCard;
   import §_-j1w§.§_-B2i§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-L3Q§;
   import §_-m0§.§_-X1F§;
   import §_-m2s§.§_-R11§;
   import §_-p24§.*;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-v2t§.§_-43O§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.pushnotifications.PushNotifications;
   import com.distriqt.extension.pushnotifications.Service;
   import com.distriqt.extension.pushnotifications.builders.ActionBuilder;
   import com.distriqt.extension.pushnotifications.builders.CategoryBuilder;
   import com.distriqt.extension.pushnotifications.builders.ChannelBuilder;
   import com.distriqt.extension.pushnotifications.events.AuthorisationEvent;
   import com.distriqt.extension.pushnotifications.events.PushNotificationEvent;
   import com.distriqt.extension.pushnotifications.events.PushNotificationGroupEvent;
   import com.distriqt.extension.pushnotifications.events.RegistrationEvent;
   import com.hurlant.math.*;
   import com.mesmotronic.ane.AndroidID;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ImageLoader;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.IListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.Direction;
   import feathers.layout.TiledRowsLayout;
   import feathers.themes.FontColor;
   import flash.desktop.NativeApplication;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import flash.events.Event;
   import flash.events.InvokeEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.IAuthorizeSocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.Gender;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.client.NotifyProfile;
   import ru.pragmatix.wormix.messages.client.RegisterForNotify;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionDailyProgressStructure;
   import ru.pragmatix.wormix.messages.structures.PreCalculatedPoints;
   import ru.pragmatix.wormix.messages.structures.PumpReactionRateStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.ReadyForBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.interfaces.§_-J3w§;
   import ru.pragmatix.wormix.weapons.interfaces.§_-o2d§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.display.Stage;
   import starling.events.Event;
   import starling.events.TouchEvent;
   import starling.rendering.Painter;
   import starling.textures.Texture;
   import starling.textures.TextureSmoothing;
   import starling.utils.Color;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class AndroidPushNotificationsController implements §_-hB§
   {
      
      private static const REGISTRATION_ID:String = "REGISTRATION_ID";
      
      private static const §_-s18§:String = §_-vR§.§_-61E§;
      
      private var §_-U2D§:String;
      
      private var payload:String;
      
      private var §_-B2e§:Boolean;
      
      private var isInited:Boolean;
      
      public function AndroidPushNotificationsController()
      {
         super();
         §_-o1q§.§_-y1Q§("AndroidPushNotificationsController");
      }
      
      public function init() : void
      {
         var registrationId:String = null;
         var service:Service = null;
         if(this.isInited)
         {
            return;
         }
         try
         {
            if(PushNotifications.isSupported)
            {
               PushNotifications.service.addEventListener(AuthorisationEvent.CHANGED,this.§_-L27§);
               PushNotifications.service.addEventListener(RegistrationEvent.REGISTER_SUCCESS,this.§_-He§);
               PushNotifications.service.addEventListener(RegistrationEvent.REGISTER_FAILED,this.§_-He§);
               PushNotifications.service.addEventListener(RegistrationEvent.REGISTERING,this.§_-He§);
               PushNotifications.service.addEventListener(RegistrationEvent.UNREGISTERED,this.§_-He§);
               PushNotifications.service.addEventListener(RegistrationEvent.ERROR,this.§_-GI§);
               PushNotifications.service.addEventListener(PushNotificationEvent.NOTIFICATION,this.§_-3t§);
               PushNotifications.service.addEventListener(PushNotificationEvent.NOTIFICATION_SELECTED,this.§_-3t§);
               PushNotifications.service.addEventListener(PushNotificationEvent.ACTION,this.§_-YV§);
               PushNotifications.service.addEventListener(PushNotificationGroupEvent.GROUP_SELECTED,this.§_-PX§);
            }
         }
         catch(e:Error)
         {
         }
         try
         {
            registrationId = Cookie.getStringValue(REGISTRATION_ID);
            this.§_-B2e§ = registrationId != null;
            if(PushNotifications.isSupported)
            {
               if(PushNotifications.service.isServiceSupported(Service.FCM))
               {
                  service = new Service(Service.FCM);
               }
               if(service)
               {
                  service.setShouldRequestCriticalAlerts(true).setNotificationsWhenActive(true);
                  service.categories.push(new CategoryBuilder().setIdentifier("INVITE_CATEGORY").addAction(new ActionBuilder().setTitle("Accept").setIdentifier("ACCEPT_IDENTIFIER").setWillLaunchApplication(true).build()).addAction(new ActionBuilder().setTitle("Delete").setDestructive(true).setIdentifier("DELETE_IDENTIFIER").build()).build());
                  service.channels.push(new ChannelBuilder().setId("wormix_channel").setName("Wormix Channel").build());
                  PushNotifications.service.setup(service);
                  this.isInited = true;
               }
               if(this.isInited && !this.§_-B2e§)
               {
                  this.register();
               }
            }
         }
         catch(e:Error)
         {
         }
      }
      
      private function §_-w2D§(param1:*) : void
      {
         this.payload = param1.message;
         NativeApplication.nativeApplication.addEventListener(InvokeEvent.INVOKE,this.§_-j1§,false,0,true);
      }
      
      private function §_-X2d§() : void
      {
         var _loc1_:RegisterForNotify = null;
         if(!this.§_-U2D§)
         {
            throw new Error(this + ".handleRegistrationIdReceived: deviceID is empty!");
         }
         if(this.isInited)
         {
            _loc1_ = new RegisterForNotify();
            _loc1_.registrationId = this.§_-U2D§;
            _loc1_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
            _loc1_.socialType = SocialType.MOBILE_ANDROID;
            §_-J2g§.§_-h18§(_loc1_);
            Cookie.setValue(REGISTRATION_ID,this.§_-U2D§);
            this.§_-B2e§ = true;
         }
      }
      
      public function §_-V16§(param1:int, param2:String, param3:String) : void
      {
         var _loc4_:NotifyProfile = null;
         if(this.isInited)
         {
            _loc4_ = new NotifyProfile();
            _loc4_.locKey = param3;
            _loc4_.locArgs = Vector.<String>([param2]);
            _loc4_.recipientProfileId = param1;
            _loc4_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
            _loc4_.socialType = SocialType.MOBILE_ANDROID;
            §_-J2g§.§_-h18§(_loc4_);
         }
      }
      
      public function §_-I1c§() : void
      {
      }
      
      private function §_-j1§(param1:InvokeEvent) : void
      {
         NativeApplication.nativeApplication.removeEventListener(InvokeEvent.INVOKE,this.§_-j1§);
         this.§_-W1x§();
      }
      
      public function §_-W1x§() : void
      {
      }
      
      public function authorisationStatus() : void
      {
         if(PushNotifications.isSupported)
         {
         }
      }
      
      public function requestAuthorisation() : void
      {
         if(PushNotifications.isSupported)
         {
         }
      }
      
      public function register() : void
      {
         if(PushNotifications.isSupported)
         {
         }
      }
      
      public function unregister() : void
      {
         if(PushNotifications.isSupported)
         {
            PushNotifications.service.unregister();
         }
      }
      
      public function setBadgeNumber() : void
      {
         if(PushNotifications.isSupported)
         {
            PushNotifications.service.setBadgeNumber(Math.floor(Math.random() * 10));
         }
      }
      
      public function openDeviceSettings() : void
      {
         if(PushNotifications.service.canOpenDeviceSettings)
         {
         }
      }
      
      public function subscribeToTopic() : void
      {
         var _loc1_:Boolean = false;
         if(PushNotifications.service.canSubscribeToTopics)
         {
            _loc1_ = PushNotifications.service.subscribeToTopic("news");
         }
      }
      
      public function unsubscribeFromTopic() : void
      {
         var _loc1_:Boolean = false;
         if(PushNotifications.service.canSubscribeToTopics)
         {
            _loc1_ = PushNotifications.service.unsubscribeFromTopic("news");
         }
      }
      
      private function §_-L27§(param1:AuthorisationEvent) : void
      {
      }
      
      private function §_-He§(param1:RegistrationEvent) : void
      {
         if(param1.type == RegistrationEvent.REGISTER_SUCCESS)
         {
            this.§_-U2D§ = param1.data;
            this.§_-X2d§();
         }
         else if(param1.type == RegistrationEvent.UNREGISTERED)
         {
            Cookie.setValue(REGISTRATION_ID,null);
            this.§_-B2e§ = false;
         }
      }
      
      private function §_-GI§(param1:RegistrationEvent) : void
      {
      }
      
      private function §_-3t§(param1:PushNotificationEvent) : void
      {
         var event:PushNotificationEvent = param1;
         try
         {
            JSON.parse(event.payload);
         }
         catch(e:Error)
         {
         }
      }
      
      private function §_-YV§(param1:PushNotificationEvent) : void
      {
      }
      
      private function §_-PX§(param1:PushNotificationGroupEvent) : void
      {
         var _loc2_:String = null;
         for each(_loc2_ in param1.payloads)
         {
         }
      }
   }
}


package §_-63k§
{
   import §_-21p§.§_-4w§;
   import §_-2k§.*;
   import §_-73d§.§_-a2s§;
   import §_-82a§.§_-pp§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-fM§;
   import §_-CF§.§_-gE§;
   import §_-DJ§.§_-T22§;
   import §_-Y1O§.*;
   import §_-d26§.§_-d1H§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-T2N§;
   import §_-o14§.§_-Dd§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-sQ§.§_-V1n§;
   import §_-w2W§.§_-21w§;
   import §_-x2Q§.§_-dU§;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.events.RemoteNotificationEvent;
   import flash.events.StatusEvent;
   import flash.geom.Rectangle;
   import flash.notifications.NotificationStyle;
   import flash.notifications.RemoteNotifier;
   import flash.notifications.RemoteNotifierSubscribeOptions;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.IAuthorizeSocialController;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.client.EndBattle;
   import ru.pragmatix.wormix.messages.client.NotifyProfile;
   import ru.pragmatix.wormix.messages.client.RegisterForNotify;
   import ru.pragmatix.wormix.messages.server.RepeatBossBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Stage;
   import starling.events.Event;
   import starling.rendering.Painter;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-2j§ implements §_-hB§
   {
      
      private static const §_-J3Z§:String = "LAST_TOKEN_ID";
      
      private var §_-H2b§:RemoteNotifier = new RemoteNotifier();
      
      private var §_-z1s§:Vector.<String> = new Vector.<String>();
      
      private var §_-O1Z§:RemoteNotifierSubscribeOptions = new RemoteNotifierSubscribeOptions();
      
      public function §_-2j§()
      {
         super();
         this.§_-z1s§.push(NotificationStyle.ALERT,NotificationStyle.BADGE,NotificationStyle.SOUND);
         this.§_-O1Z§.notificationStyles = this.§_-z1s§;
      }
      
      public function init() : void
      {
         if(RemoteNotifier.supportedNotificationStyles.toString() != " ")
         {
            this.§_-H2b§.addEventListener(RemoteNotificationEvent.TOKEN,this.§_-Z2J§,false,0,true);
            this.§_-H2b§.addEventListener(RemoteNotificationEvent.NOTIFICATION,this.§_-v1f§,false,0,true);
            this.§_-H2b§.addEventListener(StatusEvent.STATUS,this.§_-O1U§,false,0,true);
            this.§_-H2b§.subscribe(this.§_-O1Z§);
         }
      }
      
      private function §_-Z2J§(param1:RemoteNotificationEvent) : void
      {
         var _loc3_:RegisterForNotify = null;
         var _loc2_:String = Cookie.getStringValue(§_-J3Z§);
         if(_loc2_ == null)
         {
            _loc3_ = new RegisterForNotify();
            _loc3_.registrationId = param1.tokenId;
            _loc3_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
            _loc3_.socialType = SocialType.MOBILE_IOS;
            §_-J2g§.§_-h18§(_loc3_);
            Cookie.setValue(§_-J3Z§,param1.tokenId);
         }
      }
      
      public function §_-V16§(param1:int, param2:String, param3:String) : void
      {
         var _loc4_:NotifyProfile = new NotifyProfile();
         _loc4_.locKey = param3;
         _loc4_.locArgs = Vector.<String>([param2]);
         _loc4_.recipientProfileId = param1;
         _loc4_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
         _loc4_.socialType = SocialType.MOBILE_IOS;
         §_-J2g§.§_-h18§(_loc4_);
      }
      
      private function §_-v1f§(param1:RemoteNotificationEvent) : void
      {
         var _loc2_:String = null;
         for(_loc2_ in param1.data)
         {
         }
      }
      
      private function §_-O1U§(param1:StatusEvent) : void
      {
      }
   }
}


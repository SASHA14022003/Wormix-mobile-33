package §_-63k§
{
   public interface §_-hB§
   {
      
      function init() : void;
      
      function §_-V16§(param1:int, param2:String, param3:String) : void;
   }
}


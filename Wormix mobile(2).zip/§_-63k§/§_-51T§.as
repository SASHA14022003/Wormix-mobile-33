package §_-63k§
{
   import §_-62§.§_-W1r§;
   import §_-D3A§.§_-TZ§;
   import §_-Y1b§.§_-OP§;
   import §_-fo§.§_-21L§;
   import §_-fo§.§_-r5§;
   import §_-l1g§.§_-L3Q§;
   import §_-u1m§.*;
   import §_-w2i§.§_-Ia§;
   import com.distriqt.extension.inappbilling.Purchase;
   import flash.display.MovieClip;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.utils.Timer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-51T§
   {
      
      public function §_-51T§()
      {
         super();
      }
      
      public static function create() : §_-hB§
      {
         var controller:§_-hB§ = null;
         try
         {
            switch(SystemUtil.platform)
            {
               case §_-WK§.§_-c1l§:
                  controller = new AndroidPushNotificationsController();
                  break;
               case §_-WK§.IOS:
                  controller = new §_-2j§();
            }
         }
         catch(e:Error)
         {
            controller = null;
         }
         if(controller == null)
         {
            controller = new §_-L12§();
         }
         controller.init();
         return controller;
      }
   }
}


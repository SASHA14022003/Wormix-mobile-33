package §_-82a§
{
   import §_-2k§.*;
   import §_-5Y§.§_-h2c§;
   import §_-5Y§.§_-t2O§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-73d§.§_-a2s§;
   import §_-82l§.§_-A2Y§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.§_-Ey§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-YF§.§_-q2v§;
   import §_-a29§.*;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-Go§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-T2N§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sQ§.§_-H3D§;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import §_-u1T§.*;
   import §_-u2J§.§_-T1K§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-lp§;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.core.IFeathersControl;
   import feathers.data.ArrayCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayoutDisplayObject;
   import feathers.layout.LayoutBoundsResult;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.ViewPortBounds;
   import flash.display.BitmapData;
   import flash.display.MovieClip;
   import flash.geom.*;
   import flash.system.System;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.clearInterval;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.MobileShopPropertiesListItem;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.SimpleProfileStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-c2B§ extends EventDispatcher
   {
      
      private static const §_-fg§:int = 1;
      
      private var container:DisplayObjectContainer;
      
      private var §_-K2I§:Array;
      
      private var §_-f23§:int;
      
      protected var §_-410§:Array;
      
      protected var _bitmapDataArray:Array;
      
      protected var §_-Yr§:Array;
      
      protected var §_-k1H§:Array;
      
      private var §_-W2E§:int;
      
      private var §_-ap§:int = -1;
      
      private var §_-638§:Number;
      
      private var §_-kM§:Number;
      
      private var §_-n1G§:Number;
      
      private var §_-Z1V§:Number;
      
      private var §_-eE§:Point;
      
      private var §_-d24§:Rectangle;
      
      private var §_-B2f§:Array;
      
      private var §_-jC§:Array;
      
      public function §_-c2B§(param1:Number, param2:Number)
      {
         super();
         this.§_-W2E§ = 0;
         this.§_-638§ = param1;
         this.§_-kM§ = param2;
      }
      
      public function init() : void
      {
         this._bitmapDataArray = new Array();
         this.§_-410§ = new Array();
         this.§_-Yr§ = new Array();
         this.§_-k1H§ = new Array();
         this.§_-eE§ = Pool.getPoint();
         this.§_-d24§ = Pool.getRectangle();
         this.§_-ap§ = -1;
         this.§_-B2f§ = [];
         this.§_-jC§ = [];
         var _loc1_:int = 0;
         while(_loc1_ < 4)
         {
            this.§_-B2f§[_loc1_] = Pool.getRectangle();
            this.§_-jC§[_loc1_] = Pool.getPoint();
            _loc1_++;
         }
      }
      
      public function §_-42P§() : void
      {
         Pool.putPoint(this.§_-eE§);
         this.§_-eE§ = null;
         Pool.putRectangle(this.§_-d24§);
         this.§_-d24§ = null;
         var _loc1_:int = 0;
         while(_loc1_ < 4)
         {
            Pool.putPoint(this.§_-jC§[_loc1_]);
            Pool.putRectangle(this.§_-B2f§[_loc1_]);
            _loc1_++;
         }
         this.§_-B2f§ = null;
         this.§_-jC§ = null;
         this.§_-Yr§ = null;
         this.§_-k1H§ = null;
      }
      
      public function clearAll() : void
      {
         this.clearArray(this._bitmapDataArray);
         this.clearArray(this.§_-410§);
         this._bitmapDataArray = null;
         this.§_-410§ = null;
         this.§_-Yr§ = null;
         this.§_-k1H§ = null;
      }
      
      public function §_-637§(param1:Array) : void
      {
         var _loc2_:int = int(param1.length);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_)
         {
            this.§_-Yr§.push(param1[_loc3_]);
            _loc3_++;
         }
         this.§_-W2E§ += _loc2_;
      }
      
      public function §_-T1X§(param1:DisplayObjectContainer, param2:TileType) : void
      {
         var _loc5_:AtlasTileData = null;
         var _loc6_:§_-pp§ = null;
         this.container = param1;
         this.§_-K2I§ = [];
         var _loc3_:Array = this.§_-T19§(param2);
         var _loc4_:int = int(_loc3_.length);
         if(_loc4_ > 0)
         {
            this.§_-f23§ = _loc4_;
            while(--_loc4_ > -1)
            {
               _loc5_ = _loc3_[_loc4_];
               _loc6_ = this.§_-mq§(_loc5_,param2);
               _loc6_.addEventListener(Event.COMPLETE,this.§_-A1F§);
               _loc6_.addEventListener(Event.CANCEL,this.§_-X1w§);
               _loc6_.createImage();
            }
         }
         else
         {
            this.§_-yn§();
         }
      }
      
      protected function §_-mq§(param1:AtlasTileData, param2:TileType) : §_-pp§
      {
         return new §_-Dv§(this.§_-410§,param1,param2);
      }
      
      private function §_-A1F§(param1:Event) : void
      {
         var _loc3_:Image = null;
         var _loc2_:§_-pp§ = param1.target as §_-pp§;
         if(_loc2_)
         {
            _loc2_.removeEventListener(Event.COMPLETE,this.§_-A1F§);
            _loc2_.removeEventListener(Event.CANCEL,this.§_-X1w§);
            _loc2_.§_-F2z§().sourceRect = null;
            _loc3_ = param1.data as Image;
            this.§_-K2I§.push(_loc3_);
            if(this.§_-K2I§.length == this.§_-f23§)
            {
               this.§_-C2u§();
            }
         }
      }
      
      private function §_-X1w§(param1:Event) : void
      {
         var _loc2_:§_-pp§ = param1.target as §_-pp§;
         _loc2_.createImage();
      }
      
      protected function §_-T19§(param1:TileType) : Array
      {
         var _loc3_:AtlasTileData = null;
         var _loc2_:Array = [];
         var _loc4_:int = int(this.§_-k1H§.length);
         while(--_loc4_ > -1)
         {
            _loc3_ = this.§_-k1H§[_loc4_];
            if(Boolean(_loc3_) && _loc3_.type == param1)
            {
               _loc2_.push(_loc3_);
            }
         }
         return _loc2_;
      }
      
      private function §_-C2u§() : void
      {
         var _loc2_:Image = null;
         var _loc1_:int = int(this.§_-K2I§.length);
         while(--_loc1_ > -1)
         {
            _loc2_ = this.§_-K2I§[_loc1_] as Image;
            if(_loc2_)
            {
               this.container.addChild(_loc2_);
            }
         }
         this.§_-yn§();
      }
      
      private function §_-yn§() : void
      {
         dispatchEventWith(Event.COMPLETE);
      }
      
      public function §_-p1F§(param1:Function) : void
      {
         var _loc11_:TileData = null;
         var _loc12_:int = 0;
         var _loc2_:int = this.§_-638§ + §_-fg§ * 2;
         var _loc3_:int = this.§_-kM§ + §_-fg§ * 2;
         var _loc4_:int = Math.floor(2048 / _loc2_) * Math.floor(2048 / _loc3_);
         var _loc5_:int = Math.floor(1024 / _loc2_) * Math.floor(1024 / _loc3_);
         var _loc6_:int = Math.floor(512 / _loc2_) * Math.floor(512 / _loc3_);
         var _loc7_:int = this.§_-W2E§;
         var _loc8_:int = _loc7_ / _loc4_;
         _loc7_ %= _loc4_;
         var _loc9_:int = _loc7_ / _loc5_;
         _loc7_ %= _loc5_;
         var _loc10_:int = int(Math.ceil(_loc7_ / _loc6_));
         if(_loc10_ > 2)
         {
            _loc10_ = 0;
            _loc9_ += 1;
         }
         if(_loc9_ > 2)
         {
            _loc9_ = 0;
            _loc8_ += 1;
         }
         this.§_-X2u§(_loc8_,2048);
         this.§_-X2u§(_loc9_,1024);
         this.§_-X2u§(_loc10_,512);
         _loc12_ = 0;
         while(_loc12_ < this.§_-Yr§.length)
         {
            _loc11_ = this.§_-Yr§[_loc12_];
            this.§_-O1X§(_loc11_);
            _loc11_.dispose();
            _loc11_ = null;
            _loc12_++;
         }
         this.§_-H1F§(param1);
      }
      
      protected function §_-H1F§(param1:Function) : void
      {
         var _loc2_:BitmapData = null;
         var _loc3_:int = 0;
         while(_loc3_ < this._bitmapDataArray.length)
         {
            _loc2_ = this._bitmapDataArray[_loc3_];
            this.§_-410§.push(new TextureAtlas(Texture.fromBitmapData(_loc2_,false)));
            if(SystemUtil.platform == §_-WK§.IOS)
            {
               _loc2_.dispose();
               _loc2_ = null;
            }
            System.gc();
            _loc3_++;
         }
         this.§_-W2E§ = 0;
         if(param1 != null)
         {
            param1();
         }
      }
      
      private function §_-X2u§(param1:int, param2:int) : void
      {
         while(--param1 > -1)
         {
            this._bitmapDataArray.push(new BitmapData(param2,param2,true,0));
         }
      }
      
      private function §_-O1X§(param1:TileData) : void
      {
         if(this.§_-ap§ == -1)
         {
            this.§_-Q1r§();
         }
         var _loc2_:BitmapData = this._bitmapDataArray[this.§_-ap§];
         var _loc3_:BitmapData = param1.bitmapData;
         var _loc4_:Rectangle = _loc3_.rect;
         var _loc5_:int = this.§_-638§ + §_-fg§ * 2;
         var _loc6_:int = this.§_-kM§ + §_-fg§ * 2;
         this.§_-eE§.setTo(this.§_-n1G§,this.§_-Z1V§);
         this.§_-C2d§(_loc3_,_loc2_,this.§_-eE§,§_-fg§);
         this.§_-tY§(_loc3_,_loc2_,this.§_-eE§,§_-fg§);
         this.§_-eE§.offset(§_-fg§,§_-fg§);
         this.§_-d24§.setTo(this.§_-n1G§ + §_-fg§,this.§_-Z1V§ + §_-fg§,this.§_-638§,this.§_-kM§);
         _loc2_.copyPixels(param1.bitmapData,_loc4_,this.§_-eE§);
         this.§_-k1H§.push(AtlasTileData.create(param1,this.§_-d24§.clone(),this.§_-ap§));
         if(this.§_-n1G§ + _loc5_ * 2 > _loc2_.width)
         {
            this.§_-n1G§ = 0;
            if(this.§_-Z1V§ + _loc6_ * 2 > _loc2_.height)
            {
               this.§_-Q1r§();
            }
            else
            {
               this.§_-Z1V§ += _loc6_;
            }
         }
         else
         {
            this.§_-n1G§ += _loc5_;
         }
      }
      
      private function §_-C2d§(param1:BitmapData, param2:BitmapData, param3:Point, param4:int) : void
      {
         this.§_-B2f§[0].setTo(0,0,param4,param4);
         this.§_-B2f§[1].setTo(param1.width - 1,0,param4,param4);
         this.§_-B2f§[2].setTo(0,param1.height - 1,param4,param4);
         this.§_-B2f§[3].setTo(param1.width - 1,param1.height - 1,param4,param4);
         this.§_-jC§[0].setTo(param3.x,param3.y);
         this.§_-jC§[1].setTo(param3.x + param1.width + 1,param3.y);
         this.§_-jC§[2].setTo(param3.x,param3.y + param1.height + 1);
         this.§_-jC§[3].setTo(param3.x + param1.width + 1,param3.y + param1.height + 1);
         var _loc5_:int = 0;
         while(_loc5_ < 4)
         {
            param2.copyPixels(param1,this.§_-B2f§[_loc5_],this.§_-jC§[_loc5_]);
            _loc5_++;
         }
      }
      
      private function §_-tY§(param1:BitmapData, param2:BitmapData, param3:Point, param4:int) : void
      {
         this.§_-B2f§[0].setTo(0,0,param1.width,param4);
         this.§_-B2f§[1].setTo(0,param1.height - 1,param1.width,param4);
         this.§_-B2f§[2].setTo(0,0,param4,param1.height);
         this.§_-B2f§[3].setTo(param1.width - 1,0,param4,param1.height);
         this.§_-jC§[0].setTo(param3.x + param4,param3.y);
         this.§_-jC§[1].setTo(param3.x + param4,param3.y + param1.height + param4);
         this.§_-jC§[2].setTo(param3.x,param3.y + param4);
         this.§_-jC§[3].setTo(param3.x + param1.width + 1,param3.y + param4);
         var _loc5_:int = 0;
         while(_loc5_ < 4)
         {
            param2.copyPixels(param1,this.§_-B2f§[_loc5_],this.§_-jC§[_loc5_]);
            _loc5_++;
         }
      }
      
      private function §_-Q1r§() : void
      {
         ++this.§_-ap§;
         this.§_-n1G§ = 0;
         this.§_-Z1V§ = 0;
      }
      
      protected function clearArray(param1:Array) : void
      {
         var _loc2_:* = undefined;
         for each(_loc2_ in param1)
         {
            if(_loc2_)
            {
               _loc2_.dispose();
            }
         }
      }
   }
}


package §_-82a§
{
   import ru.pragmatix.wormix.controller.§_-X1j§;
   
   public class §_-j1O§
   {
      
      public function §_-j1O§()
      {
         super();
      }
      
      public static function §_-n1P§(param1:int, param2:int) : §_-c2B§
      {
         return new §_-zv§(param1,param2);
      }
   }
}


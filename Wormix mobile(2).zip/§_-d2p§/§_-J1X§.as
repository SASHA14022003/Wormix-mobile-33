package §_-d2p§
{
   import §_-62§.§_-Q2c§;
   import §_-A2U§.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.events.Event;
   
   public class §_-J1X§ extends SimpleBuyDialog
   {
      
      public function §_-J1X§()
      {
         super();
         setItem(new §_-Q2c§(),1,3);
      }
   }
}


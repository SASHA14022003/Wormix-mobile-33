package §_-d2p§
{
   import §_-62§.§_-W1r§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-V1Y§;
   import §_-P2i§.§_-b7§;
   import §_-YF§.§_-g2W§;
   import §_-Z1K§.§_-q24§;
   import §_-g1P§.§_-L38§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-T2N§;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-230§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class BuyEquipCraftDialog extends §_-V1Y§ implements §_-230§
   {
      
      private var binder:Binder;
      
      private var _itemIcon:§_-3m§;
      
      private var §_-52H§:§_-1Y§;
      
      private var _count:int;
      
      private var §_-93b§:Boolean;
      
      private var §_-R7§:Boolean;
      
      private var §_-O9§:int;
      
      public function BuyEquipCraftDialog(param1:CraftedEquipFamily, param2:Boolean, param3:Boolean, param4:int)
      {
         super();
         this.§_-93b§ = param2;
         this.§_-R7§ = param3;
         this.§_-O9§ = param4;
         this.setItem(param1);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("buy_equip_craft_dialog",this.binder);
         addChild(this.binder._panel);
         this._itemIcon = new §_-3m§(this.binder._itemIcon);
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._pricePanel,§_-T2N§.BUY_EVENT,this.§_-PC§);
         this.binder._pricePanel.checkFuzyButtonEnabledFunction = function():Boolean
         {
            return §_-O9§ == 0;
         };
         this.binder._pricePanel.checkRubyButtonEnabledFunction = function():Boolean
         {
            return true;
         };
      }
      
      override protected function draw() : void
      {
         var _loc1_:CraftedEquipFamily = null;
         var _loc2_:String = null;
         var _loc3_:Boolean = false;
         var _loc4_:§_-W1r§ = null;
         var _loc5_:§_-x2t§ = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(this.§_-52H§))
         {
            _loc1_ = this.§_-52H§ as CraftedEquipFamily;
            if(_loc1_)
            {
               _loc2_ = §_-s2a§.§_-K3t§(_loc1_.getName());
               this.binder._panel.title = §_-s2a§.§_-K3t§(§_-s2a§.CRAFT_BTN) + ": " + _loc2_;
               this._itemIcon.setItem(_loc1_);
               _loc3_ = Boolean(_loc1_.§_-92P§()) || Boolean(_loc1_.§_-G3a§());
               §_-YQ§.§_-Xv§(this.binder._iconContainer,_loc3_);
               this.binder._itemName.text = _loc2_;
               this.binder._requirements.text = this.§_-O9§ ? §_-s2a§.§_-K3t§(§_-s2a§.CRAFT_EQUIP_NOT_ENOUGH_REGS) : "";
               _loc4_ = new §_-W1r§();
               _loc5_ = this.§_-93b§ ? _loc1_.getPrice() : _loc1_.§_-e18§();
               _loc4_.§_-I1u§(_loc5_.§_-R1T§,_loc5_.realPrice + this.§_-O9§);
               this.binder._pricePanel.setItem(_loc4_);
            }
         }
      }
      
      public function setItem(param1:§_-1Y§, param2:int = 1, param3:int = 1) : void
      {
         this.§_-52H§ = param1;
         this._count = param2;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-PC§(param1:§_-T2N§) : void
      {
         param1.item = this.§_-52H§;
         param1.count = this._count;
         dispatchEventWith(§_-T2N§.BUY_EVENT,false,[param1,this.§_-O9§]);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import ru.pragmatix.wormix.gui.menu.shop.mobile.MobilePriceInfoPanel;

class Binder
{
   
   public var _panel:Panel;
   
   public var _itemIcon:LayoutGroup;
   
   public var _iconContainer:LayoutGroup;
   
   public var _itemName:Label;
   
   public var _requirements:Label;
   
   public var _pricePanel:MobilePriceInfoPanel;
   
   public function Binder()
   {
      super();
   }
}

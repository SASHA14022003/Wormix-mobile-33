package §_-d2p§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-91B§.§_-QK§;
   import §_-C3f§.§_-1Y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-V1Y§;
   import §_-Ly§.§_-I2K§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-eG§.§_-02w§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-F4§;
   import §_-zI§.§_-F3q§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.MovieClip;
   import flash.events.Event;
   import flash.utils.clearInterval;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-230§;
   import ru.pragmatix.wormix.gui.menu.shop.desktop.DesktopShopnfoRequirementRenderer;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.MobileShopPropertiesListItem;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.events.Event;
   
   public class BuyEquipDialog extends §_-V1Y§ implements §_-230§
   {
      
      private var binder:Binder;
      
      private var §_-52H§:§_-1Y§;
      
      private var _itemIcon:§_-3m§;
      
      private var _count:int;
      
      public function BuyEquipDialog()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("buy_equip_dialog",this.binder);
         addChild(this.binder._panel);
         this._itemIcon = new §_-3m§(this.binder._itemIcon);
         this.§_-Q1s§(this.binder._properties);
         this.§_-228§(this.binder._requirements);
         §_-J2N§(this.binder._panel,starling.events.Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._pricePanel,§_-T2N§.BUY_EVENT,this.§_-PC§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,starling.events.Event.CLOSE);
         §_-jg§(this.binder._pricePanel,§_-T2N§.BUY_EVENT);
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-L1r§ = null;
         var _loc2_:Boolean = false;
         var _loc3_:String = null;
         var _loc4_:Array = null;
         var _loc5_:Array = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(this.§_-52H§))
         {
            _loc1_ = this.§_-52H§ as §_-L1r§;
            if(_loc1_)
            {
               _loc2_ = §_-G1p§.§_-61d§(_loc1_);
               _loc3_ = §_-s2a§.§_-K3t§(_loc1_.getName());
               this.binder._panel.title = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_BUY) + ": " + _loc3_;
               this._itemIcon.setItem(_loc1_);
               this.binder._itemName.text = _loc3_;
               this.binder._description.text = §_-2t§.§_-B34§(_loc1_);
               _loc4_ = this.§_-z2H§(_loc1_);
               (this.binder._properties.layout as TiledColumnsLayout).requestedRowCount = Math.ceil(_loc4_.length / 2);
               (this.binder._properties.dataProvider as ArrayCollection).arrayData = _loc4_;
               _loc5_ = _loc2_ ? [] : §_-F4§.§_-Nd§(_loc1_);
               (this.binder._requirements.dataProvider as ArrayCollection).arrayData = _loc5_;
               this.binder._pricePanel.setItem(this.§_-52H§,this._count);
            }
         }
      }
      
      private function §_-z2H§(param1:§_-L1r§) : Array
      {
         var _loc3_:Vector.<§_-4w§> = null;
         var _loc4_:§_-4w§ = null;
         var _loc2_:Array = [];
         if(param1)
         {
            _loc3_ = param1.§_-V1v§().§_-b2I§();
            for each(_loc4_ in _loc3_)
            {
               if(_loc4_.§_-I2a§())
               {
                  _loc2_.push({
                     "icon":_loc4_.getType().§_-M2c§(),
                     "name":§_-s2a§.§_-K3t§(_loc4_.getType().§_-23r§()),
                     "text":_loc4_.§_-I2a§()
                  });
               }
            }
         }
         return _loc2_;
      }
      
      private function §_-Q1s§(param1:List) : void
      {
         var _loc2_:TiledColumnsLayout = new TiledColumnsLayout();
         _loc2_.useSquareTiles = false;
         _loc2_.requestedColumnCount = 2;
         _loc2_.horizontalAlign = HorizontalAlign.LEFT;
         _loc2_.verticalAlign = VerticalAlign.TOP;
         param1.layout = _loc2_;
         param1.dataProvider = new ArrayCollection();
         param1.verticalScrollPolicy = ScrollPolicy.OFF;
         param1.horizontalScrollPolicy = ScrollPolicy.OFF;
         param1.itemRendererType = MobileShopPropertiesListItem;
      }
      
      private function §_-228§(param1:List) : void
      {
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.padding = 0;
         _loc2_.gap = 10;
         _loc2_.hasVariableItemDimensions = true;
         _loc2_.horizontalAlign = HorizontalAlign.LEFT;
         param1.layout = _loc2_;
         param1.dataProvider = new ArrayCollection();
         param1.verticalScrollPolicy = ScrollPolicy.OFF;
         param1.horizontalScrollPolicy = ScrollPolicy.OFF;
         param1.itemRendererType = DesktopShopnfoRequirementRenderer;
      }
      
      public function setItem(param1:§_-1Y§, param2:int = 1, param3:int = 1) : void
      {
         this.§_-52H§ = param1;
         this._count = param2;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-PC§(param1:§_-T2N§) : void
      {
         dispatchEvent(param1);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;
import ru.pragmatix.wormix.gui.menu.shop.mobile.MobilePriceInfoPanel;

class Binder
{
   
   public var _panel:Panel;
   
   public var _itemIcon:LayoutGroup;
   
   public var _itemName:Label;
   
   public var _description:Label;
   
   public var _properties:List;
   
   public var _requirements:List;
   
   public var _pricePanel:MobilePriceInfoPanel;
   
   public function Binder()
   {
      super();
   }
}

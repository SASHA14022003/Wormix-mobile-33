package §_-d2p§
{
   import §_-62§.§_-W1r§;
   import §_-91B§.§_-z2l§;
   import §_-Bv§.§_-G3P§;
   import §_-C3f§.§_-1Y§;
   import §_-DJ§.§_-V1Y§;
   import §_-Tm§.§_-RF§;
   import §_-jF§.§_-82f§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-T2N§;
   import §_-n1w§.*;
   import §_-u13§.MD2;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u13§.§_-F3§;
   import §_-wD§.*;
   import com.hurlant.util.der.Sequence;
   import com.hurlant.util.der.§_-cz§;
   import com.hurlant.util.der.§_-l1b§;
   import feathers.core.ITextRenderer;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-230§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class SimpleBuyDialog extends §_-V1Y§ implements §_-230§
   {
      
      protected var binder:Binder;
      
      private var §_-52H§:§_-1Y§;
      
      private var _itemIcon:§_-3m§;
      
      private var _count:int;
      
      private var §_-xl§:int;
      
      public function SimpleBuyDialog()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("simple_buy_dialog",this.binder);
         addChild(this.binder._panel);
         this._itemIcon = new §_-3m§(this.binder._itemIcon);
         this.binder._description.textRendererProperties.isHTML = true;
         this.binder._itemName.textRendererProperties.isHTML = true;
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._pricePanel,§_-T2N§.BUY_EVENT,this.§_-PC§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,Event.CLOSE);
         §_-jg§(this.binder._pricePanel,§_-T2N§.BUY_EVENT);
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-W1r§ = null;
         var _loc2_:String = null;
         var _loc3_:Boolean = false;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(this.§_-52H§))
         {
            _loc1_ = this.§_-52H§ as §_-W1r§;
            if(_loc1_)
            {
               _loc2_ = §_-s2a§.§_-K3t§(_loc1_.getName());
               this.binder._panel.title = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_BUY) + ": " + _loc2_;
               this._itemIcon.setItem(_loc1_);
               _loc3_ = Boolean(_loc1_.§_-92P§()) || Boolean(_loc1_.§_-G3a§());
               §_-YQ§.§_-Xv§(this.binder._iconContainer,_loc3_);
               this.binder._itemName.text = _loc2_;
               this.binder._description.text = §_-s2a§.§_-K3t§(_loc1_.§_-p1§());
               this.binder._pricePanel.setItem(this.§_-52H§,this._count,this.§_-xl§);
            }
         }
      }
      
      public function setItem(param1:§_-1Y§, param2:int = 1, param3:int = 1) : void
      {
         this.§_-52H§ = param1;
         this._count = param2;
         this.§_-xl§ = param3;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-PC§(param1:§_-T2N§) : void
      {
         dispatchEvent(param1);
      }
      
      public function get §_-L1E§() : int
      {
         return this.§_-xl§;
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import ru.pragmatix.wormix.gui.menu.shop.mobile.MobilePriceInfoPanel;

class Binder
{
   
   public var _panel:Panel;
   
   public var _itemIcon:LayoutGroup;
   
   public var _iconContainer:LayoutGroup;
   
   public var _itemName:Label;
   
   public var _description:Label;
   
   public var _pricePanel:MobilePriceInfoPanel;
   
   public function Binder()
   {
      super();
   }
}

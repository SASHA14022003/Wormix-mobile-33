package §_-d2p§
{
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-Y1l§;
   import §_-A1K§.§_-TA§;
   import §_-A2F§.§_-4B§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.*;
   import §_-DJ§.§_-V1Y§;
   import §_-T1o§.§_-L3M§;
   import §_-Y1b§.*;
   import §_-Z1K§.§_-q24§;
   import §_-fo§.§_-r5§;
   import §_-l1g§.§_-T2N§;
   import §_-w2i§.*;
   import §_-z1g§.§_-F4§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.FlowLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.MovieClip;
   import flash.geom.ColorTransform;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-230§;
   import ru.pragmatix.wormix.gui.menu.shop.desktop.DesktopShopnfoRequirementRenderer;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.MobileShopPropertiesListItem;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class BuyWeaponDialog extends §_-V1Y§ implements §_-230§
   {
      
      private var binder:Binder;
      
      private var §_-52H§:§_-1Y§;
      
      private var _itemIcon:§_-3m§;
      
      private var _count:int;
      
      private var §_-b16§:Number;
      
      public function BuyWeaponDialog()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("buy_weapon_dialog",this.binder);
         addChild(this.binder._panel);
         this._itemIcon = new §_-3m§(this.binder._itemIcon);
         this.§_-b16§ = this.binder._progressBarSkin.width;
         this.§_-g1r§(this.binder._properties);
         this.§_-g1r§(this.binder._nextLevelProperties);
         this.§_-228§(this.binder._requirements);
         this.binder._properties.itemRendererType = MobileShopPropertiesListItem;
         this.binder._nextLevelProperties.itemRendererType = MobileShopPropertiesListItem;
         this.binder._requirements.itemRendererType = DesktopShopnfoRequirementRenderer;
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._pricePanel,§_-T2N§.BUY_EVENT,this.§_-PC§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,Event.CLOSE);
         §_-jg§(this.binder._pricePanel,§_-T2N§.BUY_EVENT);
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-O2H§ = null;
         var _loc2_:String = null;
         var _loc3_:Boolean = false;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:Array = null;
         var _loc7_:Array = null;
         var _loc8_:Boolean = false;
         var _loc9_:Array = null;
         var _loc10_:Boolean = false;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(this.§_-52H§))
         {
            _loc1_ = this.§_-52H§ as §_-O2H§;
            if(_loc1_)
            {
               _loc2_ = §_-s2a§.§_-K3t§(_loc1_.getName());
               _loc3_ = _loc1_.isComplex();
               _loc4_ = _loc3_ ? int(§_-Cq§.§_-sj§(_loc1_.getId())) : -1;
               _loc5_ = int(_loc1_.getMaxLevel());
               this.binder._panel.title = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_BUY) + ": " + _loc2_;
               this._itemIcon.setItem(_loc1_);
               this.binder._itemName.text = §_-s2a§.§_-K3t§(_loc1_.getName());
               this.binder._levelData.visible = _loc3_;
               if(this.binder._levelData.visible)
               {
                  this.binder._levelLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.LEVEL_LABEL);
                  this.binder._levelValue.text = _loc4_.toString() + "/" + _loc5_.toString();
                  this.binder._progressBarSkin.width = Number(_loc4_) / Number(_loc5_) * this.§_-b16§;
               }
               this.binder._description.text = §_-4B§.§_-p1§(_loc1_);
               _loc6_ = §_-4B§.§_-81h§(_loc1_,_loc4_);
               (this.binder._properties.dataProvider as ArrayCollection).arrayData = _loc6_;
               _loc7_ = §_-4B§.§_-X1A§(_loc1_,_loc4_);
               _loc8_ = _loc7_.length > 0;
               §_-YQ§.§_-Xv§(this.binder._nextLevelDescription,_loc8_);
               §_-YQ§.§_-Xv§(this.binder._nextLevelProperties,_loc8_);
               if(_loc8_)
               {
                  (this.binder._nextLevelProperties.dataProvider as ArrayCollection).arrayData = _loc7_;
                  this.binder._nextLevelDescription.text = §_-s2a§.§_-K3t§(§_-s2a§.WEAPON_AFTER_IMPROVE);
               }
               _loc9_ = §_-F4§.§_-Nd§(_loc1_);
               _loc10_ = _loc9_.length > 0;
               §_-YQ§.§_-Xv§(this.binder._requirements,_loc10_);
               if(_loc10_)
               {
                  (this.binder._requirements.dataProvider as ArrayCollection).arrayData = _loc9_;
               }
               this.binder._pricePanel.setItem(_loc1_);
               this.binder._pricePanel.enabled = _loc4_ < _loc5_;
            }
         }
      }
      
      private function §_-228§(param1:List) : void
      {
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.padding = 0;
         _loc2_.gap = 10;
         _loc2_.hasVariableItemDimensions = true;
         _loc2_.horizontalAlign = HorizontalAlign.LEFT;
         param1.layout = _loc2_;
         param1.verticalScrollPolicy = ScrollPolicy.OFF;
         param1.horizontalScrollPolicy = ScrollPolicy.OFF;
         param1.dataProvider = new ArrayCollection();
      }
      
      private function §_-g1r§(param1:List) : void
      {
         var _loc2_:FlowLayout = new FlowLayout();
         _loc2_.horizontalAlign = HorizontalAlign.LEFT;
         _loc2_.verticalAlign = VerticalAlign.TOP;
         _loc2_.rowVerticalAlign = VerticalAlign.TOP;
         param1.layout = _loc2_;
         param1.verticalScrollPolicy = ScrollPolicy.OFF;
         param1.horizontalScrollPolicy = ScrollPolicy.OFF;
         param1.dataProvider = new ArrayCollection();
      }
      
      public function setItem(param1:§_-1Y§, param2:int = 1, param3:int = 1) : void
      {
         this.§_-52H§ = param1;
         this._count = param2;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-PC§(param1:§_-T2N§) : void
      {
         dispatchEvent(param1);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;
import ru.pragmatix.wormix.gui.menu.shop.mobile.MobilePriceInfoPanel;
import starling.display.Image;

class Binder
{
   
   public var _panel:Panel;
   
   public var _itemIcon:LayoutGroup;
   
   public var _levelData:LayoutGroup;
   
   public var _itemName:Label;
   
   public var _levelLabel:Label;
   
   public var _levelValue:Label;
   
   public var _description:Label;
   
   public var _nextLevelDescription:Label;
   
   public var _properties:List;
   
   public var _nextLevelProperties:List;
   
   public var _requirements:List;
   
   public var _pricePanel:MobilePriceInfoPanel;
   
   public var _progressBarSkin:Image;
   
   public function Binder()
   {
      super();
   }
}

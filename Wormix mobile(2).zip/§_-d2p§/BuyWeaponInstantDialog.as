package §_-d2p§
{
   import §_-12a§.§_-B16§;
   import §_-62§.§_-O2H§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-1Y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-T2G§;
   import §_-DJ§.§_-V1Y§;
   import §_-DJ§.§_-fH§;
   import §_-DJ§.§_-zb§;
   import §_-P2i§.§_-G3J§;
   import §_-T2h§.*;
   import §_-Y1b§.§_-jH§;
   import §_-b1R§.§_-Bx§;
   import §_-l1g§.§_-T2N§;
   import §_-lh§.§_-z2A§;
   import §_-w2W§.§_-21w§;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-230§;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.events.Event;
   
   public class BuyWeaponInstantDialog extends §_-V1Y§ implements §_-230§
   {
      
      private var binder:Binder;
      
      private var §_-52H§:§_-1Y§;
      
      private var _itemIcon:§_-3m§;
      
      private var _count:int;
      
      public function BuyWeaponInstantDialog()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("buy_weapon_instant_dialog",this.binder);
         addChild(this.binder._panel);
         this._itemIcon = new §_-3m§(this.binder._itemIcon);
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._pricePanel,§_-T2N§.BUY_EVENT,this.§_-PC§);
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-O2H§ = null;
         var _loc2_:String = null;
         var _loc3_:uint = 0;
         var _loc4_:uint = 0;
         var _loc5_:String = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc1_ = this.§_-52H§ as §_-O2H§;
            if(_loc1_)
            {
               _loc2_ = §_-s2a§.§_-K3t§(_loc1_.getName());
               this.binder._panel.title = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_BUY) + ": " + _loc2_;
               this._itemIcon.setItem(_loc1_);
               this.binder._itemName.text = §_-s2a§.§_-K3t§(_loc1_.getName());
               _loc3_ = §_-Cq§.§_-sj§(this.§_-52H§.getId());
               _loc4_ = _loc1_.getMaxLevel();
               if(_loc3_ < _loc4_)
               {
                  this._count = _loc4_ - _loc3_;
               }
               if(§_-Cq§.§_-hr§(_loc1_))
               {
                  _loc5_ = StringUtil.format(§_-s2a§.WEAPON_IMPROVE_NEED,{
                     "current":_loc3_,
                     "max":_loc4_
                  });
                  this.binder._description.text = _loc5_;
               }
               this.binder._pricePanel.setItem(_loc1_,this._count);
            }
         }
      }
      
      public function setItem(param1:§_-1Y§, param2:int = 1, param3:int = 1) : void
      {
         this.§_-52H§ = param1;
         this._count = param2;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-PC§(param1:§_-T2N§) : void
      {
         dispatchEvent(param1);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import ru.pragmatix.wormix.gui.menu.shop.mobile.MobilePriceInfoPanel;

class Binder
{
   
   public var _panel:Panel;
   
   public var _itemIcon:LayoutGroup;
   
   public var _itemName:Label;
   
   public var _description:Label;
   
   public var _pricePanel:MobilePriceInfoPanel;
   
   public function Binder()
   {
      super();
   }
}

package §_-d2p§
{
   import §_-62§.§_-P14§;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-U1i§.§_-O2i§;
   import §_-g2r§.§_-03A§;
   import §_-l1g§.§_-L3Q§;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-71c§ extends SimpleBuyDialog
   {
      
      public function §_-71c§()
      {
         super();
         setItem(new §_-P14§(),1);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         binder._itemName.styleName = AlternateTextStyles.NEW_DARK_BIG_CENTER;
         binder._description.styleName = AlternateTextStyles.NEW_DARK_NORMAL_CENTER;
      }
   }
}


package §_-23U§
{
   import §_-12W§.*;
   import §_-5Y§.§_-h2c§;
   import §_-71F§.§_-kk§;
   import §_-A2U§.§_-A23§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-UK§;
   import §_-DJ§.§_-J2l§;
   import §_-G3w§.TopClanRatingScreen;
   import §_-P1z§.*;
   import §_-QD§.§_-G2z§;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.*;
   import §_-YF§.§_-Zi§;
   import §_-aM§.§_-P1N§;
   import §_-d26§.*;
   import §_-eW§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1g§.§_-L3Q§;
   import §_-s20§.§_-J2g§;
   import §_-u1m§.*;
   import §_-w2W§.§_-21w§;
   import §_-z1g§.§_-5c§;
   import §_-z1w§.§_-I3d§;
   import com.greensock.loading.*;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.layout.VerticalLayout;
   import feathers.layout.VerticalLayoutData;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.events.Event;
   import flash.events.ProgressEvent;
   import flash.net.URLLoader;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import ru.pragmatix.wormix.weapons.render.IRenderer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-62N§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:TopClanRatingScreen;
      
      [Inject]
      public var §_-53H§:§_-I3d§;
      
      public function §_-62N§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(starling.events.Event.CHANGE,this.§_-72d§);
         §_-32S§(starling.events.Event.SELECT,this.§_-X2W§);
         §_-g2k§(§_-G2z§.§_-g1A§,this.§_-C2w§);
         §_-g2k§(§_-G2z§.§_-b20§,this.§_-P1V§);
         §_-g2k§(§_-aG§.§_-91N§,this.§_-l2c§);
         §_-g2k§(§_-aG§.§_-jf§,this.§_-l2c§);
         §_-g2k§(§_-tc§.§_-33G§,this.§_-l2c§);
         this.§_-j1r§.invalidate(FeathersControl.INVALIDATION_FLAG_STATE);
      }
      
      private function §_-X2W§(param1:starling.events.Event) : void
      {
         var _loc2_:ClanTO = null;
         if(param1.data)
         {
            _loc2_ = param1.data.clan as ClanTO;
            if(_loc2_)
            {
               dispatchWith(§_-61Z§.§_-bg§,false,_loc2_);
            }
         }
      }
      
      private function §_-72d§() : void
      {
         this.§_-53H§.§_-c2P§();
      }
      
      private function §_-C2w§(param1:starling.events.Event) : void
      {
         var _loc2_:TopClansResponse = param1.data as TopClansResponse;
         if(_loc2_)
         {
            this.§_-j1r§.setData(_loc2_,§_-A23§.userClan);
         }
      }
      
      private function §_-P1V§() : void
      {
      }
      
      private function §_-l2c§() : void
      {
         this.§_-53H§.§_-c2P§();
      }
   }
}


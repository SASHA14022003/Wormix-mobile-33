package §_-23U§
{
   import §_-12W§.§_-J3J§;
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-71F§.§_-kk§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2F§.*;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-4I§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G3w§.§_-Cj§;
   import §_-K3q§.§_-L3A§;
   import §_-L1H§.§_-C3e§;
   import §_-QD§.§_-G2z§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-G4§;
   import §_-fo§.§_-r5§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-m1g§.§_-N1y§;
   import §_-p14§.§_-pP§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-6a§;
   import §_-s20§.§_-J2g§;
   import §_-z1g§.§_-Uc§;
   import §_-z1w§.§_-I3d§;
   import com.worlize.websocket.§_-x2j§;
   import feathers.controls.Button;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.ConnectResult;
   import ru.pragmatix.wormix.messages.server.FastBattleResult;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-X2Q§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:§_-Cj§;
      
      [Inject]
      public var §_-53H§:§_-I3d§;
      
      public function §_-X2Q§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(Event.CHANGE,this.§_-72d§);
         §_-g2k§(§_-G2z§.§_-Y2A§,this.§_-C2w§);
         §_-g2k§(§_-G2z§.§_-S1V§,this.§_-P1V§);
         this.§_-j1r§.invalidate(FeathersControl.INVALIDATION_FLAG_STATE);
      }
      
      private function §_-72d§(param1:Event) : void
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         if(param1.data)
         {
            _loc2_ = int(param1.data.type as int);
            _loc3_ = int(param1.data.wager as int);
            this.§_-53H§.§_-XH§(_loc2_,_loc3_);
         }
      }
      
      private function §_-C2w§(param1:Event) : void
      {
         var _loc2_:UserProfile = null;
         var _loc3_:Array = null;
         var _loc4_:GetRatingResult = null;
         var _loc5_:int = 0;
         var _loc6_:RatingProfileStructure = null;
         if(param1.data)
         {
            _loc2_ = param1.data.owner as UserProfile;
            _loc3_ = param1.data.profiles as Array;
            _loc4_ = param1.data.result as GetRatingResult;
            if(this.§_-j1r§.§_-l2h§() == §_-N1y§.§_-gA§)
            {
               _loc5_ = 0;
               while(_loc5_ < _loc4_.userProfileStructures.length)
               {
                  _loc6_ = _loc4_.userProfileStructures[_loc5_];
                  if(_loc6_.dailyRating < §_-Uc§.§_-l2S§)
                  {
                     _loc4_.userProfileStructures.insertAt(_loc5_,{"rating":§_-Uc§.§_-l2S§});
                     break;
                  }
                  _loc5_++;
               }
            }
            this.§_-j1r§.setData(_loc2_,_loc3_,_loc4_);
         }
      }
      
      private function §_-P1V§() : void
      {
      }
   }
}


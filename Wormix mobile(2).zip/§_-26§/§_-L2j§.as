package §_-26§
{
   import §_-12W§.*;
   import §_-62§.*;
   import §_-71F§.§_-M2D§;
   import §_-A1K§.§_-TA§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Z1K§.§_-q24§;
   import §_-f1G§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import feathers.controls.ImageLoader;
   import flash.utils.ByteArray;
   import flash.utils.getTimer;
   import org.gestouch.core.Touch;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.wormix.controller.§_-W2C§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-03J§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   
   public class §_-L2j§ extends §_-M2D§ implements §_-03J§
   {
      
      public function §_-L2j§()
      {
         super();
      }
      
      public function §_-j1p§(param1:§_-E19§, param2:§_-W1r§, param3:uint = 1) : void
      {
         var _loc4_:§_-W2C§ = null;
         var _loc5_:§_-x2t§ = null;
         var _loc6_:§_-x2t§ = null;
         if(param2)
         {
            _loc4_ = §_-X1j§.§_-zU§;
            _loc5_ = param2.getPrice();
            _loc6_ = new §_-x2t§(_loc5_.§_-R1T§ * param3 + _loc4_.§_-F20§(),_loc5_.realPrice * param3 + §_-X1j§.§_-zU§.§_-t2L§());
            if(§_-33r§.§_-As§(param1,_loc6_))
            {
               §_-X1j§.§_-zU§.§_-dh§(param2,param3,param1);
            }
         }
      }
   }
}


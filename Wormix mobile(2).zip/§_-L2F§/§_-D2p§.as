package §_-L2F§
{
   import §_-73d§.§_-g1J§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-H3§.*;
   import §_-RE§.§_-D3v§;
   import §_-Tm§.§_-RF§;
   import §_-YF§.§_-q2v§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-y1S§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import flash.filters.BlurFilter;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-A16§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-D2p§ extends §_-y1S§
   {
      
      private var §_-jh§:§_-xF§;
      
      private var §_-J3q§:§_-P2q§;
      
      private var §_-d1i§:§_-P2q§;
      
      private var §_-C1s§:int;
      
      private var §_-VQ§:Boolean;
      
      public function §_-D2p§(param1:int, param2:Class, param3:String, param4:§_-P2q§, param5:§_-P2q§ = null, param6:int = -1, param7:Boolean = false)
      {
         this.§_-jh§ = §_-I1q§.§_-QB§()[param1];
         super(this.§_-jh§.getId(),this.§_-jh§.getName(),param2,param3,param4);
         this.§_-d1i§ = new §_-P2q§([new §_-iI§(§_-E19§.§_-i2d§,param4.§_-51e§() * 0.5),new §_-uU§(param4.§_-p25§() * 0.5)]);
         this.§_-J3q§ = param5;
         this.§_-C1s§ = param6;
         this.§_-VQ§ = param7;
      }
      
      public function §_-7k§() : §_-xF§
      {
         return this.§_-jh§;
      }
      
      public function §_-K1z§() : §_-P2q§
      {
         return this.§_-J3q§;
      }
      
      public function §_-ky§() : §_-P2q§
      {
         return this.§_-d1i§;
      }
      
      public function §_-eH§() : int
      {
         return this.§_-C1s§ == -1 ? int(§_-D3v§.§_-7G§) : this.§_-C1s§;
      }
      
      public function isNew() : Boolean
      {
         return this.§_-VQ§;
      }
   }
}


package §_-L2F§
{
   import §_-12a§.§_-6p§;
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-A2U§.§_-SG§;
   import §_-GQ§.§_-31v§;
   import §_-V1H§.§_-m1d§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Ia§;
   import dragonBones.animation.WorldClock;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.events.Event;
   
   public class §_-I1q§ implements §_-SG§
   {
      
      private static var instance:§_-I1q§;
      
      private var §_-M1w§:Object = new Object();
      
      private var bosses:Object = new Object();
      
      public function §_-I1q§()
      {
         super();
      }
      
      public static function getInstance() : §_-I1q§
      {
         if(!instance)
         {
            instance = new §_-I1q§();
         }
         return instance;
      }
      
      public static function §_-x9§() : Object
      {
         return §_-I1q§.getInstance().§_-M1w§;
      }
      
      public static function §_-QB§() : Object
      {
         return §_-I1q§.getInstance().bosses;
      }
   }
}


package §_-L2F§
{
   import §_-62§.§_-W1r§;
   import §_-73I§.§_-Y1l§;
   import §_-B2z§.§_-63i§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-C3f§.*;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-Ey§;
   import §_-L1H§.§_-b2K§;
   import §_-P2i§.*;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.*;
   import §_-YF§.§_-g2W§;
   import §_-YF§.§_-q2v§;
   import §_-a19§.§_-g1S§;
   import §_-fo§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-p24§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import dragonBones.Armature;
   import dragonBones.core.BaseObject;
   import feathers.controls.List;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.flox.social.response.*;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.LinkResult;
   import ru.pragmatix.wormix.messages.structures.DailyBonusStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.objects.ZombieGrave;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-t2Z§ implements §_-g2W§
   {
      
      private var id:int;
      
      private var hatId:int;
      
      private var minLevelUser:int;
      
      private var maxLevelUser:int;
      
      private var baseArsenal:Vector.<§_-de§>;
      
      private var pricePoints:uint;
      
      private var typeParams:Vector.<§_-g1S§>;
      
      private var races:Vector.<§_-L1x§>;
      
      public function §_-t2Z§()
      {
         super();
      }
      
      public function initFromConfig(param1:Object) : void
      {
         var _loc2_:§_-L1x§ = null;
         var _loc3_:Boolean = false;
         var _loc4_:uint = 0;
         this.id = param1.hatId;
         this.hatId = param1.hatId;
         this.minLevelUser = param1.minLevelUser ? int(param1.minLevelUser) : 1;
         this.maxLevelUser = param1.maxLevelUser ? int(param1.maxLevelUser) : 99;
         this.pricePoints = param1.pricePoints;
         if(param1.typeParams)
         {
            this.typeParams = param1.typeParams;
         }
         else
         {
            §§push(this);
            var _temp_4:* = new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-jl§,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§];
            §§pop().typeParams = new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-jl§,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§];
         }
         if(param1.races)
         {
            this.races = param1.races;
         }
         else
         {
            this.races = new Vector.<§_-L1x§>();
            for each(_loc2_ in §_-L1x§.§_-z2Z§)
            {
               _loc3_ = false;
               for each(_loc4_ in §_-L1x§.§_-r2V§)
               {
                  if(_loc2_.getId() == _loc4_)
                  {
                     _loc3_ = true;
                     break;
                  }
               }
               if(!_loc3_)
               {
                  this.races.push(_loc2_);
               }
            }
         }
         if(param1.baseArsenal)
         {
            this.baseArsenal = param1.baseArsenal;
         }
         else
         {
            this.baseArsenal = new Vector.<§_-de§>();
         }
      }
      
      public function getId() : int
      {
         return this.id;
      }
      
      public function §_-PG§() : int
      {
         return this.hatId;
      }
      
      public function §_-D0§() : int
      {
         return this.minLevelUser;
      }
      
      public function §_-01i§() : int
      {
         return this.maxLevelUser;
      }
      
      public function §_-rQ§() : uint
      {
         return this.pricePoints;
      }
      
      public function §_-72b§() : Vector.<§_-de§>
      {
         return this.baseArsenal;
      }
      
      public function §_-F1W§() : Vector.<§_-g1S§>
      {
         return this.typeParams;
      }
      
      public function §_-A37§() : Vector.<§_-L1x§>
      {
         return this.races;
      }
      
      public function isAvailable(param1:uint, param2:int) : Boolean
      {
         return this.§_-rQ§() <= param2 && param1 >= this.§_-D0§() && param1 <= this.§_-01i§();
      }
   }
}


package §_-L2F§
{
   import §_-12a§.§_-6p§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-T1y§;
   import §_-A1K§.§_-TA§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-O2i§;
   import §_-YF§.§_-g2W§;
   import §_-b1F§.§_-v2Q§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-F4§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import feathers.data.ArrayCollection;
   import feathers.layout.TiledColumnsLayout;
   import flash.events.Event;
   import flash.filters.DropShadowFilter;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-xF§ implements §_-g2W§
   {
      
      private var id:uint;
      
      private var name:String;
      
      private var script:Class;
      
      private var race:§_-L1x§;
      
      private var skinId:uint = 0;
      
      private var hatId:int = 0;
      
      private var artifactId:int = 0;
      
      public function §_-xF§()
      {
         super();
      }
      
      public function getId() : int
      {
         return this.id;
      }
      
      public function initFromConfig(param1:Object) : void
      {
         this.id = param1.id;
         this.name = param1.name;
         this.script = param1.script;
         this.race = param1.race;
         if(param1.skinId)
         {
            this.skinId = param1.skinId;
         }
         if(§_-V2w§.§_-q1F§(param1.hatId))
         {
            this.hatId = param1.hatId;
         }
         if(§_-V2w§.§_-Q2a§(param1.artifactId))
         {
            this.artifactId = param1.artifactId;
         }
      }
      
      public function §_-G3u§() : Class
      {
         return this.script;
      }
      
      public function getName() : String
      {
         return this.name;
      }
      
      public function §_-P2e§() : §_-L1x§
      {
         return this.race;
      }
      
      public function §_-I1f§() : uint
      {
         return this.skinId;
      }
      
      public function §_-PG§() : uint
      {
         return this.hatId;
      }
      
      public function §_-u1E§() : uint
      {
         return this.artifactId;
      }
   }
}


package §_-52L§
{
   import §_-62§.§_-o6§;
   import §_-CF§.§_-E19§;
   import §_-Z1K§.§_-q24§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import config.§_-B1K§;
   import flash.events.SecurityErrorEvent;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-Pk§
   {
      
      private var recipes:Array;
      
      public function §_-Pk§()
      {
         §§push(this);
         §§push({
            "id":1,
            "description":"CL_GRENADE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.§_-K3z§,
            "upgradeId":§_-q24§.§_-g1q§,
            "reagents":new <§_-o6§>[new §_-o6§(4,15),new §_-o6§(3,25),new §_-o6§(26,10)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":2,
            "description":"CL_GRENADE.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-g1q§,
            "upgradeId":§_-q24§.§_-ZW§,
            "reagents":new <§_-o6§>[new §_-o6§(10,30),new §_-o6§(23,20),new §_-o6§(42,10)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":3,
            "description":"CL_GRENADE.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-g1q§,
            "upgradeId":§_-q24§.§_-F31§,
            "reagents":new <§_-o6§>[new §_-o6§(0,40),new §_-o6§(21,15),new §_-o6§(41,12)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":4,
            "description":"MORTAR.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.MORTAR,
            "upgradeId":§_-q24§.§_-A1a§,
            "reagents":new <§_-o6§>[new §_-o6§(3,15),new §_-o6§(6,15),new §_-o6§(20,12)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":5,
            "description":"MORTAR.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-A1a§,
            "upgradeId":§_-q24§.§_-42a§,
            "reagents":new <§_-o6§>[new §_-o6§(1,20),new §_-o6§(22,20),new §_-o6§(41,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":6,
            "description":"MORTAR.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-A1a§,
            "upgradeId":§_-q24§.§_-m1P§,
            "reagents":new <§_-o6§>[new §_-o6§(3,40),new §_-o6§(21,10),new §_-o6§(44,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":7,
            "description":"SHURIKEN.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.SHURIKEN,
            "upgradeId":§_-q24§.§_-13G§,
            "reagents":new <§_-o6§>[new §_-o6§(4,25),new §_-o6§(6,18),new §_-o6§(22,10)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":8,
            "description":"SHURIKEN.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-13G§,
            "upgradeId":§_-q24§.§_-I2I§,
            "reagents":new <§_-o6§>[new §_-o6§(10,35),new §_-o6§(24,15),new §_-o6§(40,10)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":9,
            "description":"SHURIKEN.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-13G§,
            "upgradeId":§_-q24§.§_-AV§,
            "reagents":new <§_-o6§>[new §_-o6§(0,25),new §_-o6§(20,15),new §_-o6§(44,15)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":10,
            "description":"STICKY_BOMB.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.§_-82U§,
            "upgradeId":§_-q24§.§_-G2Z§,
            "reagents":new <§_-o6§>[new §_-o6§(0,25),new §_-o6§(2,15),new §_-o6§(21,10)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":11,
            "description":"STICKY_BOMB.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-G2Z§,
            "upgradeId":§_-q24§.§_-h2N§,
            "reagents":new <§_-o6§>[new §_-o6§(2,40),new §_-o6§(23,12),new §_-o6§(40,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":12,
            "description":"STICKY_BOMB.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-G2Z§,
            "upgradeId":§_-q24§.§_-Qb§,
            "reagents":new <§_-o6§>[new §_-o6§(9,35),new §_-o6§(26,20),new §_-o6§(42,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":13,
            "description":"SNIPER_RIFLE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.SNIPER_RIFLE,
            "upgradeId":§_-q24§.SNIPER_RIFLE_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(2,10),new §_-o6§(24,18),new §_-o6§(43,10)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":14,
            "description":"SHOTGUN.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.SHOTGUN,
            "upgradeId":§_-q24§.§_-i2k§,
            "reagents":new <§_-o6§>[new §_-o6§(2,25),new §_-o6§(10,20),new §_-o6§(23,10)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":15,
            "description":"SHOTGUN.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-i2k§,
            "upgradeId":§_-q24§.§_-J2R§,
            "reagents":new <§_-o6§>[new §_-o6§(4,40),new §_-o6§(22,15),new §_-o6§(40,12)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":16,
            "description":"SHOTGUN.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-i2k§,
            "upgradeId":§_-q24§.§_-t§,
            "reagents":new <§_-o6§>[new §_-o6§(6,45),new §_-o6§(26,15),new §_-o6§(44,10)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":17,
            "description":"MINIGUN.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.MINIGUN,
            "upgradeId":§_-q24§.§_-LY§,
            "reagents":new <§_-o6§>[new §_-o6§(1,25),new §_-o6§(9,20),new §_-o6§(24,15)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":18,
            "description":"MINIGUN.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-LY§,
            "upgradeId":§_-q24§.§_-s1b§,
            "reagents":new <§_-o6§>[new §_-o6§(9,35),new §_-o6§(20,15),new §_-o6§(41,15)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":19,
            "description":"MINIGUN.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-LY§,
            "upgradeId":§_-q24§.§_-w1s§,
            "reagents":new <§_-o6§>[new §_-o6§(1,35),new §_-o6§(21,15),new §_-o6§(42,12)],
            "requiredLevel":15,
            "level":2
         });
         §§push({
            "id":20,
            "description":"BAZOOKA.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.BAZOOKA,
            "upgradeId":§_-q24§.§_-d25§,
            "reagents":new <§_-o6§>[new §_-o6§(4,4),new §_-o6§(3,4),new §_-o6§(6,2)],
            "requiredLevel":4,
            "level":1
         });
         §§push({
            "id":21,
            "description":"BAZOOKA.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.§_-d25§,
            "upgradeId":§_-q24§.§_-s26§,
            "reagents":new <§_-o6§>[new §_-o6§(1,20),new §_-o6§(6,20),new §_-o6§(22,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":22,
            "description":"GRENADE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.GRENADE,
            "upgradeId":§_-q24§.§_-L3D§,
            "reagents":new <§_-o6§>[new §_-o6§(0,4),new §_-o6§(1,4),new §_-o6§(10,2)],
            "requiredLevel":4,
            "level":1
         });
         §§push({
            "id":23,
            "description":"GRENADE.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.§_-L3D§,
            "upgradeId":§_-q24§.§_-O1R§,
            "reagents":new <§_-o6§>[new §_-o6§(0,20),new §_-o6§(3,15),new §_-o6§(23,12)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":24,
            "description":"RIFLE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.RIFLE,
            "upgradeId":§_-q24§.RIFLE_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(2,4),new §_-o6§(9,6)],
            "requiredLevel":4,
            "level":1
         });
         §§push({
            "id":25,
            "description":"HOMING_BAZOOKA.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.HOMING_BAZOOKA,
            "upgradeId":§_-q24§.HOMING_BAZOOKA_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(0,15),new §_-o6§(4,15),new §_-o6§(20,12)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":26,
            "description":"HOMING_BAZOOKA.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.HOMING_BAZOOKA_UPG_1,
            "upgradeId":§_-q24§.HOMING_BAZOOKA_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(10,20),new §_-o6§(26,10),new §_-o6§(43,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":27,
            "description":"HARPOON.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.§_-p2f§,
            "upgradeId":§_-q24§.ELECTRIC_HARPOON_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(2,25),new §_-o6§(9,15),new §_-o6§(43,8)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":28,
            "description":"HARPOON.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.ELECTRIC_HARPOON_UPG_1,
            "upgradeId":§_-q24§.ELECTRIC_HARPOON_UPG_2_BOOST_DMG,
            "reagents":new <§_-o6§>[new §_-o6§(10,25),new §_-o6§(22,20),new §_-o6§(44,12)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":29,
            "description":"HARPOON.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.ELECTRIC_HARPOON_UPG_1,
            "upgradeId":§_-q24§.§_-Jy§,
            "reagents":new <§_-o6§>[new §_-o6§(9,25),new §_-o6§(21,20),new §_-o6§(42,12)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":30,
            "description":"AUGER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.AUGER,
            "upgradeId":§_-q24§.AUGER_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(1,6),new §_-o6§(6,2),new §_-o6§(9,2)],
            "requiredLevel":4,
            "level":1
         });
         §§push({
            "id":31,
            "description":"AUGER.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.AUGER_UPG_1,
            "upgradeId":§_-q24§.AUGER_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(4,10),new §_-o6§(23,10),new §_-o6§(26,8)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":32,
            "description":"MINE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.MINE,
            "upgradeId":§_-q24§.MINE_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(0,4),new §_-o6§(3,4),new §_-o6§(10,6)],
            "requiredLevel":6,
            "level":1
         });
         §§push({
            "id":33,
            "description":"MINE.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.MINE_UPG_1,
            "upgradeId":§_-q24§.MINE_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(3,25),new §_-o6§(6,20),new §_-o6§(26,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":34,
            "description":"UZI.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.UZI,
            "upgradeId":§_-q24§.§_-12h§,
            "reagents":new <§_-o6§>[new §_-o6§(2,4),new §_-o6§(4,4),new §_-o6§(6,6)],
            "requiredLevel":6,
            "level":1
         });
         §§push({
            "id":35,
            "description":"BARRIER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.§_-F2y§,
            "upgradeId":§_-q24§.LASER_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(3,15),new §_-o6§(20,8),new §_-o6§(41,8)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":37,
            "description":"SPIDER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.SPIDER,
            "upgradeId":§_-q24§.SPIDER_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(1,20),new §_-o6§(4,20),new §_-o6§(24,12)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":38,
            "description":"DYNAMITE.DISTINCT.U1A",
            "prevUpgradeId":§_-q24§.DYNAMITE,
            "upgradeId":§_-q24§.§_-s14§,
            "reagents":new <§_-o6§>[new §_-o6§(3,15),new §_-o6§(6,15),new §_-o6§(23,12)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":39,
            "description":"DYNAMITE.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.DYNAMITE,
            "upgradeId":§_-q24§.§_-c1p§,
            "reagents":new <§_-o6§>[new §_-o6§(4,10),new §_-o6§(10,10),new §_-o6§(21,15)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":42,
            "description":"SHOCKER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.SHOCKER,
            "upgradeId":§_-q24§.§_-43k§,
            "reagents":new <§_-o6§>[new §_-o6§(0,15),new §_-o6§(10,10),new §_-o6§(26,12)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":43,
            "description":"CAT_BAZOOKA.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.CAT_BAZOOKA,
            "upgradeId":§_-q24§.§_-z12§,
            "reagents":new <§_-o6§>[new §_-o6§(2,15),new §_-o6§(9,15),new §_-o6§(20,12)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":44,
            "description":"CAT_BAZOOKA.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-z12§,
            "upgradeId":§_-q24§.§_-w2m§,
            "reagents":new <§_-o6§>[new §_-o6§(0,20),new §_-o6§(24,15),new §_-o6§(42,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":45,
            "description":"CAT_BAZOOKA.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-z12§,
            "upgradeId":§_-q24§.§_-Z2L§,
            "reagents":new <§_-o6§>[new §_-o6§(4,20),new §_-o6§(23,15),new §_-o6§(41,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":46,
            "description":"GIRDER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.GIRDER,
            "upgradeId":§_-q24§.§_-R2h§,
            "reagents":new <§_-o6§>[new §_-o6§(1,20),new §_-o6§(24,15),new §_-o6§(44,5)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":47,
            "description":"SWINE.DISTINCT.U1A",
            "prevUpgradeId":§_-q24§.SWINE,
            "upgradeId":§_-q24§.§_-L13§,
            "reagents":new <§_-o6§>[new §_-o6§(1,15),new §_-o6§(26,15),new §_-o6§(41,8)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":48,
            "description":"SWINE.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.SWINE,
            "upgradeId":§_-q24§.§_-I16§,
            "reagents":new <§_-o6§>[new §_-o6§(6,20),new §_-o6§(21,20),new §_-o6§(40,12)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":49,
            "description":"EMERGENCY_TELEPORT.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.EMERGENCY_TELEPORT,
            "upgradeId":§_-q24§.EMERGENCY_TELEPORT_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(9,10),new §_-o6§(21,8),new §_-o6§(22,8)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":50,
            "description":"EMERGENCY_TELEPORT.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.EMERGENCY_TELEPORT_UPG_1,
            "upgradeId":§_-q24§.EMERGENCY_TELEPORT_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(4,10),new §_-o6§(26,15),new §_-o6§(43,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":51,
            "description":"BOOMERANG.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.BOOMERANG,
            "upgradeId":§_-q24§.BOOMERANG_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(2,20),new §_-o6§(24,8),new §_-o6§(26,8)],
            "requiredLevel":12,
            "level":1
         });
         §§push("id");
         §§push(52);
         §§push("description");
         §§push("BOOMERANG.DISTINCT.U2");
         §§push("prevUpgradeId");
         §§push(§_-q24§.BOOMERANG_UPG_1);
         §§push("upgradeId");
         §§push(§_-q24§.BOOMERANG_UPG_2);
         §§push("reagents");
         var _temp_144:* = new <§_-o6§>[new §_-o6§(20,10),new §_-o6§(22,30),new §_-o6§(24,15)];
         §§push(null);
         §§push({
            "id":53,
            "description":"TELE_THROWER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.§_-f2f§,
            "upgradeId":§_-q24§.§_-H25§,
            "reagents":new <§_-o6§>[new §_-o6§(20,20),new §_-o6§(41,8),new §_-o6§(42,12)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":54,
            "description":"ANTIFREEZE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.ANTIFREEZE,
            "upgradeId":§_-q24§.§_-z2w§,
            "reagents":new <§_-o6§>[new §_-o6§(0,12),new §_-o6§(9,12),new §_-o6§(23,12)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":55,
            "description":"ANTIFREEZE.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-z2w§,
            "upgradeId":§_-q24§.§_-gi§,
            "reagents":new <§_-o6§>[new §_-o6§(10,15),new §_-o6§(23,12),new §_-o6§(40,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":56,
            "description":"ANTIFREEZE.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-z2w§,
            "upgradeId":§_-q24§.§_-H3z§,
            "reagents":new <§_-o6§>[new §_-o6§(3,15),new §_-o6§(21,12),new §_-o6§(44,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":57,
            "description":"PNEUMATIC_DRILL.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.PNEUMATIC_DRILL,
            "upgradeId":§_-q24§.DRILL_UPG1,
            "reagents":new <§_-o6§>[new §_-o6§(1,2),new §_-o6§(4,2),new §_-o6§(6,6)],
            "requiredLevel":4,
            "level":1
         });
         §§push({
            "id":58,
            "description":"PARASITE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.PARASITE,
            "upgradeId":§_-q24§.§_-C25§,
            "reagents":new <§_-o6§>[new §_-o6§(22,18),new §_-o6§(40,6),new §_-o6§(42,8)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":60,
            "description":"SNIPER_RIFLE.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.SNIPER_RIFLE_UPG_1,
            "upgradeId":§_-q24§.SNIPER_RIFLE_UPG_2A,
            "reagents":new <§_-o6§>[new §_-o6§(23,15),new §_-o6§(24,20),new §_-o6§(43,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":61,
            "description":"SNIPER_RIFLE.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.SNIPER_RIFLE_UPG_1,
            "upgradeId":§_-q24§.SNIPER_RIFLE_UPG_2B,
            "reagents":new <§_-o6§>[new §_-o6§(20,20),new §_-o6§(21,18),new §_-o6§(43,8)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":62,
            "description":"AIR_STRIKE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.AIR_STRIKE,
            "upgradeId":§_-q24§.§_-622§,
            "reagents":new <§_-o6§>[new §_-o6§(20,20),new §_-o6§(23,15),new §_-o6§(43,8)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":63,
            "description":"NEGATOR.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.§_-B3l§,
            "upgradeId":§_-q24§.§_-j29§,
            "reagents":new <§_-o6§>[new §_-o6§(9,20),new §_-o6§(26,18),new §_-o6§(44,8)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":64,
            "description":"NEGATOR.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.§_-j29§,
            "upgradeId":§_-q24§.§_-l1q§,
            "reagents":new <§_-o6§>[new §_-o6§(3,25),new §_-o6§(22,25),new §_-o6§(42,8)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":65,
            "description":"NEGATOR.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.§_-j29§,
            "upgradeId":§_-q24§.§_-O1B§,
            "reagents":new <§_-o6§>[new §_-o6§(24,20),new §_-o6§(26,18),new §_-o6§(44,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":67,
            "description":"GAS_GRENADE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.GAS_GRENADE,
            "upgradeId":§_-q24§.GAS_GRENADE_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(2,25),new §_-o6§(23,15),new §_-o6§(40,10)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":68,
            "description":"SHOCKER.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.§_-43k§,
            "upgradeId":§_-q24§.§_-40§,
            "reagents":new <§_-o6§>[new §_-o6§(4,20),new §_-o6§(9,20),new §_-o6§(41,8)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":69,
            "description":"BUNKER_BUSTER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.BUNKER_BUSTER,
            "upgradeId":§_-q24§.BUNKER_BUSTER_UPG1,
            "reagents":new <§_-o6§>[new §_-o6§(1,20),new §_-o6§(24,20),new §_-o6§(44,10)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":70,
            "description":"METEOR.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.METEOR,
            "upgradeId":§_-q24§.§_-W1k§,
            "reagents":new <§_-o6§>[new §_-o6§(3,20),new §_-o6§(20,25),new §_-o6§(23,25)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":71,
            "description":"TELEPORT.DISTINCT.U1A",
            "prevUpgradeId":§_-q24§.TELEPORT,
            "upgradeId":§_-q24§.TELEPORT_UPG_1A,
            "reagents":new <§_-o6§>[new §_-o6§(0,15),new §_-o6§(10,15),new §_-o6§(21,10)],
            "requiredLevel":8,
            "level":1
         });
         §§push({
            "id":72,
            "description":"MOLOTOV.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.MOLOTOV,
            "upgradeId":§_-q24§.§_-73A§,
            "reagents":new <§_-o6§>[new §_-o6§(6,30),new §_-o6§(23,15),new §_-o6§(42,8)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":74,
            "description":"CAT_STRIKE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.CAT_STRIKE,
            "upgradeId":§_-q24§.§_-oc§,
            "reagents":new <§_-o6§>[new §_-o6§(3,40),new §_-o6§(22,20),new §_-o6§(42,15)],
            "requiredLevel":24,
            "level":1
         });
         §§push({
            "id":78,
            "description":"NAPALM_STRIKE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.NAPALM,
            "upgradeId":§_-q24§.§_-02B§,
            "reagents":new <§_-o6§>[new §_-o6§(6,25),new §_-o6§(26,18),new §_-o6§(41,8)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":79,
            "description":"ROPE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.ROPE,
            "upgradeId":§_-q24§.ROPE_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(1,25),new §_-o6§(10,10),new §_-o6§(24,15)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":80,
            "description":"GRAVITY_GUN.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.GRAVITY_GUN,
            "upgradeId":§_-q24§.GRAVITY_GUN_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(0,20),new §_-o6§(1,25),new §_-o6§(21,10)],
            "requiredLevel":12,
            "level":1
         });
         §§push({
            "id":81,
            "description":"UFO.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.UFO,
            "upgradeId":§_-q24§.UFO_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(0,20),new §_-o6§(1,20),new §_-o6§(20,20)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":82,
            "description":"UFO.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.UFO_UPG_1,
            "upgradeId":§_-q24§.UFO_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(22,25),new §_-o6§(24,20),new §_-o6§(42,15)],
            "requiredLevel":21,
            "level":2
         });
         §§push({
            "id":83,
            "description":"SUPER_BOAR.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.SUPER_BOAR,
            "upgradeId":§_-q24§.SUPER_BOAR_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(6,25),new §_-o6§(23,15),new §_-o6§(41,5)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":84,
            "description":"SUPER_BOAR.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.SUPER_BOAR_UPG_1,
            "upgradeId":§_-q24§.SUPER_BOAR_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(10,35),new §_-o6§(21,20),new §_-o6§(40,10)],
            "requiredLevel":21,
            "level":2
         });
         §§push({
            "id":86,
            "description":"PNEUMATIC_DRILL.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.DRILL_UPG1,
            "upgradeId":§_-q24§.DRILL_UPG2,
            "reagents":new <§_-o6§>[new §_-o6§(1,20),new §_-o6§(6,15),new §_-o6§(26,10)],
            "requiredLevel":12,
            "level":2
         });
         §§push({
            "id":87,
            "description":"BARRIER.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.LASER_UPG_1,
            "upgradeId":§_-q24§.LASER_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(20,15),new §_-o6§(21,15),new §_-o6§(42,8)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":88,
            "description":"BUNKER_BUSTER.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.BUNKER_BUSTER_UPG1,
            "upgradeId":§_-q24§.BUNKER_BUSTER_UPG2,
            "reagents":new <§_-o6§>[new §_-o6§(3,25),new §_-o6§(22,20),new §_-o6§(44,12)],
            "requiredLevel":24,
            "level":2
         });
         §§push({
            "id":90,
            "description":"GRAVITY_GUN.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.GRAVITY_GUN_UPG_1,
            "upgradeId":§_-q24§.GRAVITY_GUN_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(22,20),new §_-o6§(26,20),new §_-o6§(41,10)],
            "requiredLevel":18,
            "level":2
         });
         §§push({
            "id":91,
            "description":"FREEZER.DISTINCT.U1A",
            "prevUpgradeId":§_-q24§.§_-Qf§,
            "upgradeId":§_-q24§.FREEZING_BAZOOKA_UPG1A,
            "reagents":new <§_-o6§>[new §_-o6§(4,25),new §_-o6§(20,15),new §_-o6§(40,10)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":92,
            "description":"PUSHING_MINE.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.PUSHING_MINE,
            "upgradeId":§_-q24§.§_-S2U§,
            "reagents":new <§_-o6§>[new §_-o6§(0,30),new §_-o6§(21,20),new §_-o6§(41,8)],
            "requiredLevel":24,
            "level":1
         });
         §§push({
            "id":93,
            "prevUpgradeId":§_-q24§.SLEDGEHAMMER,
            "upgradeId":§_-q24§.SLEDGEHAMMER_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(20,20),new §_-o6§(40,8),new §_-o6§(44,8)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":94,
            "description":"BAT.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.BAT,
            "upgradeId":§_-q24§.§_-z2a§,
            "reagents":new <§_-o6§>[new §_-o6§(2,30),new §_-o6§(24,15),new §_-o6§(44,8)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":96,
            "description":"EMERGENCY_TELEPORT.DISTINCT.U3",
            "prevUpgradeId":§_-q24§.EMERGENCY_TELEPORT_UPG_2,
            "upgradeId":§_-q24§.EMERGENCY_TELEPORT_UPG_3,
            "reagents":new <§_-o6§>[new §_-o6§(20,15),new §_-o6§(24,15),new §_-o6§(43,10)],
            "requiredLevel":24,
            "level":3
         });
         §§push({
            "id":98,
            "description":"ROPE.DISTINCT.U2",
            "prevUpgradeId":§_-q24§.ROPE_UPG_1,
            "upgradeId":§_-q24§.ROPE_UPG_2,
            "reagents":new <§_-o6§>[new §_-o6§(2,20),new §_-o6§(9,20),new §_-o6§(43,10)],
            "requiredLevel":21,
            "level":2
         });
         §§push({
            "id":99,
            "prevUpgradeId":§_-q24§.SLEDGEHAMMER,
            "upgradeId":§_-q24§.SLEDGEHAMMER_UPG_1B,
            "reagents":new <§_-o6§>[new §_-o6§(2,25),new §_-o6§(22,25),new §_-o6§(24,25)],
            "requiredLevel":18,
            "level":1
         });
         §§push({
            "id":100,
            "description":"SUPER_SHEEP.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.SUPER_BOAR_UPG_1,
            "upgradeId":§_-q24§.SUPER_BOAR_UPG_2B,
            "reagents":new <§_-o6§>[new §_-o6§(6,10),new §_-o6§(23,25),new §_-o6§(43,15)],
            "requiredLevel":21,
            "level":2
         });
         §§push({
            "id":112,
            "description":"TELEPORT.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.TELEPORT,
            "upgradeId":§_-q24§.TELEPORT_UPG_1B,
            "reagents":new <§_-o6§>[new §_-o6§(0,15),new §_-o6§(20,10),new §_-o6§(40,8)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":113,
            "description":"GUARDING_BOT.DISTINCT.U1A",
            "prevUpgradeId":§_-q24§.GUARDING_BOT,
            "upgradeId":§_-q24§.GUARDING_BOT_UPG_1A,
            "reagents":new <§_-o6§>[new §_-o6§(4,20),new §_-o6§(24,20),new §_-o6§(42,12)],
            "requiredLevel":21,
            "level":1
         });
         §§push({
            "id":114,
            "description":"AIR_BLOCKER.DISTINCT.U1",
            "prevUpgradeId":§_-q24§.AIR_BLOCKER,
            "upgradeId":§_-q24§.AIR_BLOCKER_UPG_1,
            "reagents":new <§_-o6§>[new §_-o6§(1,30),new §_-o6§(22,20),new §_-o6§(43,12)],
            "requiredLevel":24,
            "level":1
         });
         §§push({
            "id":115,
            "description":"GUARDING_BOT.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.GUARDING_BOT,
            "upgradeId":§_-q24§.GUARDING_BOT_UPG_1B,
            "reagents":new <§_-o6§>[new §_-o6§(2,20),new §_-o6§(10,30),new §_-o6§(40,10)],
            "requiredLevel":21,
            "level":1
         });
         §§push({
            "id":117,
            "description":"FREEZER.DISTINCT.U2A",
            "prevUpgradeId":§_-q24§.FREEZING_BAZOOKA_UPG1A,
            "upgradeId":§_-q24§.FREEZING_BAZOOKA_UPG2A,
            "reagents":new <§_-o6§>[new §_-o6§(20,15),new §_-o6§(26,20),new §_-o6§(44,12)],
            "requiredLevel":21,
            "level":2
         });
         §§push({
            "id":118,
            "description":"FREEZER.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.§_-Qf§,
            "upgradeId":§_-q24§.FREEZING_BAZOOKA_UPG1B,
            "reagents":new <§_-o6§>[new §_-o6§(9,25),new §_-o6§(24,15),new §_-o6§(40,10)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":119,
            "description":"FREEZER.DISTINCT.U2B",
            "prevUpgradeId":§_-q24§.FREEZING_BAZOOKA_UPG1B,
            "upgradeId":§_-q24§.FREEZING_BAZOOKA_UPG2B,
            "reagents":new <§_-o6§>[new §_-o6§(20,20),new §_-o6§(22,15),new §_-o6§(43,12)],
            "requiredLevel":21,
            "level":2
         });
         §§push({
            "id":120,
            "description":"GAS_GRENADE.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.GAS_GRENADE,
            "upgradeId":§_-q24§.GAS_GRENADE_UPG_1B,
            "reagents":new <§_-o6§>[new §_-o6§(6,30),new §_-o6§(21,15),new §_-o6§(41,10)],
            "requiredLevel":15,
            "level":1
         });
         §§push({
            "id":121,
            "description":"SPIDER.DISTINCT.U1B",
            "prevUpgradeId":§_-q24§.SPIDER,
            "upgradeId":§_-q24§.SPIDER_UPG_1B,
            "reagents":new <§_-o6§>[new §_-o6§(0,25),new §_-o6§(4,25),new §_-o6§(42,5)],
            "requiredLevel":15,
            "level":1
         });
         §§push("id");
         §§push(123);
         §§push("description");
         §§push("AIR_BLOCKER.DISTINCT.U1B");
         §§push("prevUpgradeId");
         §§push(§_-q24§.AIR_BLOCKER);
         §§push("upgradeId");
         §§push(§_-q24§.AIR_BLOCKER_UPG_1B);
         §§push("reagents");
         var _temp_289:* = new <§_-o6§>[new §_-o6§(10,30),new §_-o6§(22,20),new §_-o6§(44,10)];
         §§pop().recipes = null;
         super();
      }
      
      public function §_-uO§() : Array
      {
         return this.recipes;
      }
   }
}


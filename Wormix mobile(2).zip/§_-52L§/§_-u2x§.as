package §_-52L§
{
   import §_-03T§.§_-2p§;
   import §_-73j§.§_-E3z§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-e2r§.CraftEquipCompleteDialog;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.crypto.tls.*;
   import flash.events.Event;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.HideableGuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.type.air.cat.AirFireCatAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.animal.BurningRunningSwine;
   import ru.pragmatix.wormix.weapons.ammo.type.animal.SpiderMineFrostBolt;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.DarkHealBlocker;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.FreezingAirBlocker;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.LightHealBlocker;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.MagneticAirBlocker;
   import ru.pragmatix.wormix.weapons.ammo.type.dynamite.DynamiteBunch;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.VampiricParasite;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.BouncingClusterGrenadeMine;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.HomingShard;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.SensoryShard;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.simple.StuffedBouncingGrenade;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.sticky.PoisonShard;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.sticky.PoisonStickyProjectile;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.sticky.ShardMine;
   import ru.pragmatix.wormix.weapons.ammo.type.mine.SpiderMinePoisonBolt;
   import ru.pragmatix.wormix.weapons.ammo.type.mine.StickyGuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.type.missile.bazooka.CumulativeBazookaMissile;
   import ru.pragmatix.wormix.weapons.ammo.type.missile.homing.StuffedHomingMissile;
   import ru.pragmatix.wormix.weapons.ammo.type.shuriken.ShurikenSaw;
   import starling.extensions.ColorArgb;
   
   public class §_-u2x§
   {
      
      public static const §_-H24§:int = 300;
      
      public static const §_-v3§:int = 4;
      
      public var upgrades:Array = [{
         "id":§_-q24§.§_-g1q§,
         "name":"CL_GRENADE.NAME.U1",
         "description":"CL_GRENADE.DESCR.U1",
         "maxdamage":"CL_GRENADE.DAMAGE.U1",
         "classname":"ClusterGrenadeExplodable",
         "render":{"clipClass":"ClusterGrenadeUpg1"},
         "params":{
            "clipClassName":"AmClusterGrenadeUpg1",
            "damage":new §_-TA§(45)
         },
         "property":{
            "quantityShards":new §_-TA§(9),
            "blinkClassName":"ClGrenadeUpg1Blink"
         },
         "menuIcon":"IconClusterGrenadeUpg1"
      },{
         "id":§_-q24§.§_-ZW§,
         "name":"CL_GRENADE.NAME.U2A",
         "description":"CL_GRENADE.DESCR.U2A",
         "maxdamage":"CL_GRENADE.DAMAGE.U2A",
         "render":{"clipClass":"ClusterGrenadeUpg2A"},
         "params":{"clipClassName":"AmClusterGrenadeUpg2A"},
         "secondaryParams":{"clipClassName":"ClusterGrenadeUpg2A_Splinter"},
         "property":{
            "ammoClass":BouncingClusterGrenadeMine,
            "classShard":HomingShard,
            "blinkClassName":"HomingClGrenadeBlink",
            "quantityShards":new §_-TA§(9),
            "explodeOnStopMoving":false
         },
         "infinite":{"maxShots":3},
         "menuIcon":"IconClusterGrenadeUpg2A"
      },{
         "id":§_-q24§.§_-F31§,
         "name":"CL_GRENADE.NAME.U2B",
         "description":"CL_GRENADE.DESCR.U2B",
         "maxdamage":"CL_GRENADE.DAMAGE.U2B",
         "note":"",
         "render":{"clipClass":"ClusterGrenadeUpg2B"},
         "params":{"clipClassName":"AmClusterGrenadeUpg2B"},
         "property":{
            "ammoClass":§_-E3o§,
            "classShard":SensoryShard,
            "hasTimer":new §_-7u§(false),
            "blinkClassName":"ClGrenadeMineBlink",
            "quantityShards":new §_-TA§(9)
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconClusterGrenadeUpg2B"
      },{
         "id":304,
         "name":"MORTAR.NAME.U1",
         "description":"MORTAR.DESCR.U1",
         "maxdamage":"MORTAR.DAMAGE.U1",
         "iconClassName":"MortarUpg1",
         "render":{
            "clipClass":"MortarUpg1",
            "charParams":{
               "default":{
                  "x":-2,
                  "y":7,
                  "hideHands":"both"
               },
               "worm":{
                  "y":4,
                  "hideHands":"both"
               },
               "bull":{
                  "y":4,
                  "hideHands":"both"
               }
            }
         },
         "params":{
            "clipClassName":"AmMortarUpg1",
            "damage":new §_-TA§(45)
         },
         "property":{
            "trajectoryCrosshair":new §_-7u§(true),
            "cleverShards":new §_-7u§(true)
         },
         "infinite":{"maxShots":6},
         "menuIcon":"IconMortarUpg1"
      },{
         "id":305,
         "name":"MORTAR.NAME.U2A",
         "description":"MORTAR.DESCR.U2A",
         "maxdamage":"MORTAR.DAMAGE.U2A",
         "iconClassName":"MortarRadius",
         "render":{"clipClass":"MortarRadius"},
         "params":{
            "clipClassName":"AmMortarRadius",
            "damage":new §_-TA§(50),
            "damageRadius":new §_-TA§(90),
            "explosionRadius":new §_-TA§(65)
         },
         "secondaryParams":{
            "damage":new §_-TA§(35),
            "damageRadius":new §_-TA§(50),
            "explosionRadius":new §_-TA§(30)
         },
         "infinite":{"maxShots":6},
         "menuIcon":"IconMortarUpgRadius"
      },{
         "id":306,
         "name":"MORTAR.NAME.U2B",
         "description":"MORTAR.DESCR.U2B",
         "maxdamage":"MORTAR.DAMAGE.U2B",
         "iconClassName":"MortarDoubleShot",
         "render":{"clipClass":"MortarDoubleShot"},
         "params":{
            "clipClassName":"AmMortarDoubleShot",
            "damage":new §_-TA§(40)
         },
         "property":{"additionalMissile":1},
         "infinite":{"maxShots":6},
         "menuIcon":"IconMortarDoubleShot"
      },{
         "id":307,
         "name":"SHURIKEN.NAME.U1",
         "description":"SHURIKEN.DESCR.U1",
         "maxdamage":"SHURIKEN.DAMAGE.U1",
         "iconClassName":"ShurikenUpg1",
         "render":{"clipClass":"ShurikenUpg1"},
         "property":{"quantityShots":new §_-TA§(5)},
         "params":{"clipClassName":"AmShurikenUpg1"},
         "infinite":{"maxShots":4},
         "shotsPerTurn":5,
         "menuIcon":"IconShurikenUpg1"
      },{
         "id":308,
         "name":"SHURIKEN.NAME.U2A",
         "description":"SHURIKEN.DESCR.U2A",
         "maxdamage":"SHURIKEN.DAMAGE.U2A",
         "iconClassName":"ShurikenTrajectory",
         "render":{"clipClass":"ShurikenTrajectory"},
         "params":{
            "clipClassName":"AmShurikenTrajectory",
            "damage":new §_-TA§(22)
         },
         "property":{
            "power":new §_-TA§(35),
            "trajectoryCrosshair":new §_-7u§(true),
            "noTrail":true
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconShurikenTrajectory"
      },{
         "id":309,
         "name":"SHURIKEN.NAME.U2B",
         "description":"SHURIKEN.DESCR.U2B",
         "maxdamage":"SHURIKEN.DAMAGE.U2B",
         "hint":"",
         "iconClassName":"ShurikenSaw",
         "render":{"clipClass":"ShurikenSaw"},
         "params":{
            "clipClassName":"AmShurikenSaw",
            "damage":new §_-TA§(12)
         },
         "property":{
            "classShuriken":ShurikenSaw,
            "quantityShots":new §_-TA§(4)
         },
         "infinite":{"maxShots":5},
         "shotsPerTurn":5,
         "menuIcon":"IconShurikenSaw"
      },{
         "id":310,
         "name":"STICKY_BOMB.NAME.U1",
         "description":"STICKY_BOMB.DESCR.U1",
         "maxdamage":"STICKY_BOMB.DAMAGE.U1",
         "render":{"clipClass":"StickyBombUpg1"},
         "iconClassName":"StickyBombUpg1",
         "params":{"clipClassName":"AmStickyBombUpg1"},
         "property":{
            "quantityShards":new §_-TA§(8),
            "blinkClassName":"StickyBombUpg1Blink"
         },
         "menuIcon":"IconStickyBombUpg1"
      },{
         "id":311,
         "name":"STICKY_BOMB.NAME.U2A",
         "description":"STICKY_BOMB.DESCR.U2A",
         "maxdamage":"STICKY_BOMB.DAMAGE.U2A",
         "render":{"clipClass":"PoisonStickyBomb"},
         "iconClassName":"PoisonStickyBomb",
         "params":{"clipClassName":"AmPoisonStickyBomb"},
         "property":{
            "classShard":PoisonShard,
            "classProjectile":PoisonStickyProjectile,
            "blinkClassName":"PoisonStickyBombBlink"
         },
         "infinite":{"maxShots":5},
         "menuIcon":"IconPoisonStickyBomb"
      },{
         "id":312,
         "name":"STICKY_BOMB.NAME.U2B",
         "description":"STICKY_BOMB.DESCR.U2B",
         "maxdamage":"STICKY_BOMB.DAMAGE.U2B",
         "render":{"clipClass":"StickyBombMine"},
         "iconClassName":"StickyBombMine",
         "params":{"clipClassName":"AmStickyBombMine"},
         "secondaryParams":{
            "clipClassName":"AmStickBombMineSplinter",
            "damage":new §_-TA§(25),
            "damageRadius":new §_-TA§(50)
         },
         "property":{
            "classShard":ShardMine,
            "blinkClassName":"StickyBombMineBlink"
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconStickyBombMine"
      },{
         "id":§_-q24§.SNIPER_RIFLE_UPG_1,
         "name":"SNIPER_RIFLE.NAME.U1",
         "maxdamage":"SNIPER_RIFLE.DAMAGE.U1",
         "iconClassName":"SniperRifleUpgSight",
         "render":{"clipClass":"SniperRifleUpgSight"},
         "params":{"damage":new §_-TA§(105)},
         "property":{
            "rayLength":new §_-TA§(600),
            "angleFluct":MathUtil.PI_ONE_288,
            "colorLaser":12009742
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconSniperRifleUpgSight"
      },{
         "id":§_-q24§.SNIPER_RIFLE_UPG_2A,
         "name":"SNIPER_RIFLE.NAME.U2A",
         "description":"SNIPER_RIFLE.DESCR.U2A",
         "maxdamage":"SNIPER_RIFLE.DAMAGE.U2A",
         "iconClassName":"SniperRifleUpg2A",
         "render":{"clipClass":"SniperRifleUpg2A"},
         "params":{"damage":new §_-TA§(110)},
         "property":{
            "armorReduction":new §_-TA§(40),
            "colorLaser":12009742
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconSniperRifleUpg2A"
      },{
         "id":§_-q24§.SNIPER_RIFLE_UPG_2B,
         "name":"SNIPER_RIFLE.NAME.U2B",
         "description":"SNIPER_RIFLE.DESCR.U2B",
         "maxdamage":"SNIPER_RIFLE.DAMAGE.U2B",
         "iconClassName":"SniperRifleUpg2B",
         "render":{
            "clipClass":"SniperRifleUpg2B",
            "charParams":{
               "default":{
                  "x":-5.6,
                  "y":2.3,
                  "hideHands":"both"
               },
               "bull":{
                  "x":-5,
                  "y":4
               }
            }
         },
         "params":{"damage":new §_-TA§(80)},
         "property":{
            "antidodge":new §_-7u§(true),
            "colorLaser":12009742,
            "angleFluct":MathUtil.PI_ONE_512
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconSniperRifleUpg2B"
      },{
         "id":313,
         "name":"SNIPER_RIFLE.NAME.U1",
         "description":"SNIPER_RIFLE.DESCR.U1",
         "maxdamage":"SNIPER_RIFLE.DAMAGE.U1",
         "iconClassName":"SniperRifleUpgSight",
         "render":{
            "clipClass":"SniperRifleUpgSight",
            "charParams":{
               "default":{
                  "x":-5.6,
                  "y":2.3,
                  "hideHands":"both"
               },
               "bull":{
                  "x":-5,
                  "y":4
               }
            }
         },
         "params":{"damage":new §_-TA§(100)},
         "property":{
            "rayLength":new §_-TA§(600),
            "angleFluct":MathUtil.PI_ONE_288,
            "colorLaser":12009742
         },
         "menuIcon":"IconSniperRifleUpgSight"
      },{
         "id":§_-q24§.§_-622§,
         "name":"AIR_STRIKE.NAME.U1",
         "description":"AIR_STRIKE.DESCR.U1",
         "firstShotDelay":3,
         "params":{
            "damage":new §_-TA§(50),
            "clipClassName":"AmAirStrikeUpg1"
         },
         "property":{"isHoming":new §_-7u§(true)},
         "menuIcon":"IconAirStrikeUpg1"
      },{
         "id":§_-q24§.§_-j29§,
         "name":"NEGATOR.NAME.U1",
         "description":"NEGATOR.DESCR.U1",
         "property":{
            "duration":new §_-TA§(8),
            "idleClipName":"HealBlockerIdleUpg1"
         },
         "iconClassName":"BlockerClipUpg1",
         "render":{"clipClass":"BlockerClipUpg1"},
         "params":{"clipClassName":"BlockerClipUpg1"},
         "menuIcon":"BlockerIconUpg1"
      },{
         "id":§_-q24§.§_-l1q§,
         "name":"NEGATOR.NAME.U2A",
         "description":"NEGATOR.DESCR.U2A",
         "maxdamage":"NEGATOR.DAMAGE.U2A",
         "property":{
            "ammoClass":DarkHealBlocker,
            "idleClipName":"HealBlockerIdleUpg2A"
         },
         "iconClassName":"BlockerClipUpg2A",
         "render":{"clipClass":"BlockerClipUpg2A"},
         "params":{"clipClassName":"BlockerClipUpg2A"},
         "menuIcon":"BlockerIconUpg2A"
      },{
         "id":§_-q24§.§_-O1B§,
         "name":"NEGATOR.NAME.U2B",
         "description":"NEGATOR.DESCR.U2B",
         "property":{
            "ammoClass":LightHealBlocker,
            "idleClipName":"HealBlockerIdleUpg2B"
         },
         "render":{"clipClass":"BlockerClipUpg2B"},
         "params":{"clipClassName":"BlockerClipUpg2B"},
         "iconClassName":"BlockerClipUpg2B",
         "menuIcon":"BlockerIconUpg2B"
      },{
         "id":§_-q24§.BUNKER_BUSTER_UPG1,
         "name":"BUNKER_BUSTER.NAME.U1",
         "description":"BUNKER_BUSTER.DESCR.U1",
         "maxdamage":"BUNKER_BUSTER.DAMAGE.U1",
         "render":{"clipClass":"BunkerBusterUpg1Control"},
         "menuIcon":"IconBunkerBreakerUpg1",
         "params":{
            "clipClassName":"AmBunkerBreakerUpg1",
            "damage":new §_-TA§(45)
         },
         "property":{
            "counter":new §_-TA§(23),
            "armorReduction":new §_-TA§(30)
         }
      },{
         "id":§_-q24§.BUNKER_BUSTER_UPG2,
         "name":"BUNKER_BUSTER.NAME.U2",
         "description":"BUNKER_BUSTER.DESCR.U2",
         "maxdamage":"BUNKER_BUSTER.DAMAGE.U2",
         "menuIcon":"IconBunkerBreakerUpg2",
         "params":{
            "clipClassName":"AmBunkerBreakerUpg2",
            "damage":new §_-TA§(60)
         },
         "property":{
            "cripple":true,
            "armorReduction":new §_-TA§(50)
         }
      },{
         "id":§_-q24§.§_-L13§,
         "classname":"ControlledSwineWeapon",
         "name":"SWINE.NAME.U1A",
         "description":"SWINE.DESCR.U1A",
         "maxdamage":"SWINE.DAMAGE.U1A",
         "menuIcon":"IconSwineUpg1A",
         "render":{
            "type":"clip",
            "clipClass":"SwineUpg1A",
            "charParams":{"default":{
               "hideHands":"both",
               "x":0,
               "y":-26
            }}
         },
         "firstShotDelay":1,
         "cooldown":1,
         "property":{"maxFuel":new §_-TA§(360)},
         "params":{
            "clipClassName":"AmSwineUpg1A",
            "damage":new §_-TA§(120),
            "damageRadius":new §_-TA§(100),
            "explosionRadius":new §_-TA§(90)
         }
      },{
         "id":§_-q24§.§_-I16§,
         "name":"SWINE.NAME.U1B",
         "description":"SWINE.DESCR.U1B",
         "maxdamage":"SWINE.DAMAGE.U1B",
         "menuIcon":"IconSwineUpg1B",
         "render":{
            "type":"clip",
            "clipClass":"SwineUpg1B",
            "charParams":{"default":{
               "hideHands":"both",
               "x":0,
               "y":-26
            }}
         },
         "firstShotDelay":1,
         "cooldown":1,
         "property":{
            "ammoClassName":BurningRunningSwine,
            "maxFuel":new §_-TA§(240)
         },
         "params":{
            "clipClassName":"AmSwineUpg1B",
            "damage":new §_-TA§(45),
            "damageRadius":new §_-TA§(80),
            "explosionRadius":new §_-TA§(60)
         }
      },{
         "id":§_-q24§.§_-W1k§,
         "name":"METEOR.NAME.U1",
         "description":"METEOR.DESCR.U1",
         "maxdamage":"METEOR.DAMAGE.U1",
         "menuIcon":"IconMeteorUpg1",
         "property":{
            "shards":new §_-TA§(2),
            "missiles":new §_-TA§(3)
         },
         "params":{"damage":new §_-TA§(55)},
         "firstShotDelay":3
      },{
         "id":§_-q24§.TELEPORT_UPG_1A,
         "name":"TELEPORT.NAME.U1A",
         "description":"TELEPORT.DESCR.U1A",
         "maxdamage":"TELEPORT.DAMAGE.U1A",
         "render":{"clipClass":"TeleportUpg1A"},
         "menuIcon":"IconTeleportUpg1a",
         "params":{"damage":new §_-TA§(35)},
         "cooldown":2,
         "infinite":{"maxShots":3},
         "property":{"sourceLocationDamage":new §_-7u§(true)}
      },{
         "id":§_-q24§.TELEPORT_UPG_1B,
         "name":"TELEPORT.NAME.U1B",
         "description":"TELEPORT.DESCR.U1B",
         "render":{"clipClass":"TeleportUpg1B"},
         "cooldown":2,
         "infinite":{"maxShots":3},
         "menuIcon":"IconTeleportUpg1b",
         "property":{
            "sourceLocationDamage":new §_-7u§(true),
            "allowAntiFreeze":new §_-7u§(true),
            "healBonus":new §_-TA§(40),
            "targetAreaMinRadius":new §_-TA§(0)
         }
      },{
         "id":§_-q24§.SUPER_BOAR_UPG_1,
         "name":"SUPER_BOAR.NAME.U1",
         "description":"SUPER_BOAR.DESCR.U1",
         "maxdamage":"SUPER_BOAR.DAMAGE.U1",
         "menuIcon":"IconSuperBoarUpg1",
         "render":{"clipClass":"SuperBoarUpg1"},
         "params":{"damage":new §_-TA§(100)},
         "property":{
            "clipClassName":"AmSuperBoarUpg1",
            "cripple":true
         }
      },{
         "id":§_-q24§.SUPER_BOAR_UPG_2,
         "name":"SUPER_BOAR.NAME.U2",
         "description":"SUPER_BOAR.DESCR.U2",
         "maxdamage":"SUPER_BOAR.DAMAGE.U2",
         "menuIcon":"IconSuperBoarUpg2A",
         "render":{"clipClass":"SuperBoarUpg2A"},
         "params":{"damage":new §_-TA§(120)},
         "property":{
            "clipClassName":"AmSuperBoarUpg2A",
            "groundBreaks":new §_-TA§(6)
         }
      },{
         "id":§_-q24§.SUPER_BOAR_UPG_2B,
         "name":"SUPER_BOAR.NAME.U2B",
         "description":"SUPER_BOAR.DESCR.U2B",
         "menuIcon":"IconSuperBoarUpg2B",
         "render":{"clipClass":"SuperBoarUpg2B"},
         "property":{
            "clipClassName":"AmSuperBoarUpg2B",
            "duration":new §_-TA§(570),
            "damagePerSupply":new §_-TA§(40)
         }
      },{
         "id":§_-q24§.§_-oc§,
         "name":"CAT_STRIKE.NAME.U1",
         "description":"CAT_STRIKE.DESCR.U1",
         "maxdamage":"CAT_STRIKE.DAMAGE.U1",
         "property":{"targets":new §_-TA§(2)},
         "render":{
            "clipClass":"CatStrike",
            "type":"clip",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "params":{"clipClassName":"AmCatStrikeUpg1"},
         "firstShotDelay":3,
         "menuIcon":"IconCatStrikeUpg1"
      },{
         "id":§_-q24§.§_-02B§,
         "name":"NAPALM_STRIKE.NAME.U1",
         "maxdamage":"NAPALM_STRIKE.DAMAGE.U1",
         "property":{"missiles":new §_-TA§(6)},
         "render":{
            "type":"clip",
            "clipClass":"NapalmStrikeUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "firstShotDelay":3,
         "params":{
            "clipClassName":"AmNapalmStrikeUpg1",
            "damage":new §_-TA§(25)
         },
         "menuIcon":"IconNapalmStrikeUpg1"
      },{
         "id":314,
         "name":"SHOTGUN.NAME.U1",
         "description":"SHOTGUN.DESCR.U1",
         "maxdamage":"SHOTGUN.DAMAGE.U1",
         "iconClassName":"ShotgunUpg1",
         "render":{"clipClass":"ShotgunUpg1"},
         "params":{"damage":new §_-TA§(14)},
         "property":{
            "quantityBullets":new §_-TA§(9),
            "trailColor":16776960
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconShotgunUpg1"
      },{
         "id":315,
         "name":"SHOTGUN.NAME.U2A",
         "description":"SHOTGUN.DESCR.U2A",
         "maxdamage":"SHOTGUN.DAMAGE.U2A",
         "iconClassName":"SlowingShotgun",
         "render":{"clipClass":"SlowingShotgun"},
         "params":{"damage":new §_-TA§(15)},
         "property":{
            "bulletName":"SlowSpeedBullet",
            "trailColor":12009742
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconSlowingShotgun"
      },{
         "id":316,
         "name":"SHOTGUN.NAME.U2B",
         "description":"SHOTGUN.DESCR.U2B",
         "maxdamage":"SHOTGUN.DAMAGE.U2B",
         "iconClassName":"ShotgunDoubleShot",
         "render":{"clipClass":"ShotgunDoubleShot"},
         "property":{
            "quantityBullets":new §_-TA§(6),
            "shots":new §_-TA§(2)
         },
         "infinite":{"maxShots":4},
         "shotsPerTurn":2,
         "menuIcon":"IconShotgunDoubleShot"
      },{
         "id":317,
         "name":"MINIGUN.NAME.U1",
         "description":"MINIGUN.DESCR.U1",
         "maxdamage":"MINIGUN.DAMAGE.U1",
         "iconClassName":"MinigunUpg1",
         "render":{"clipClass":"MinigunUpg1"},
         "params":{"damage":new §_-TA§(8)},
         "property":{"trailColor":16776960},
         "infinite":{"maxShots":4},
         "menuIcon":"IconMinigunUpg1"
      },{
         "id":318,
         "name":"MINIGUN.NAME.U2A",
         "description":"MINIGUN.DESCR.U2A",
         "maxdamage":"MINIGUN.DAMAGE.U2A",
         "render":{"clipClass":"MinigunUpg2A"},
         "property":{
            "bulletName":"ReductionArmorBullet",
            "trailColor":12009742
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconMinigunUpg2A"
      },{
         "id":319,
         "name":"MINIGUN.NAME.U2B",
         "description":"MINIGUN.DESCR.U2B",
         "maxdamage":"MINIGUN.DAMAGE.U2B",
         "classname":"HomingMinigun",
         "render":{"clipClass":"MinigunUpg2B"},
         "property":{"quantityBullets":new §_-TA§(10)},
         "params":{
            "clipClassName":"AmMortarDoubleShot",
            "damage":new §_-TA§(16),
            "explosionRadius":new §_-TA§(20)
         },
         "infinite":{"maxShots":4},
         "menuIcon":"IconMinigunUpg2B"
      },{
         "id":320,
         "name":"BAZOOKA.NAME.U1",
         "description":"BAZOOKA.DESCR.U1",
         "maxdamage":"BAZOOKA.DAMAGE.U1",
         "render":{
            "clipClass":"BazookaUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconBazookaUpg1",
         "params":{
            "clipClassName":"AmBazookaUpg1",
            "damage":new §_-TA§(70)
         }
      },{
         "id":321,
         "name":"BAZOOKA.NAME.U2",
         "description":"BAZOOKA.DESCR.U2",
         "maxdamage":"BAZOOKA.DAMAGE.U2",
         "render":{"clipClass":"BazookaUpg2"},
         "menuIcon":"IconBazookaUpg2",
         "property":{"ammoClass":CumulativeBazookaMissile},
         "params":{
            "clipClassName":"AmBazookaUpg2",
            "damage":new §_-TA§(40),
            "damageRadius":new §_-TA§(60)
         }
      },{
         "id":322,
         "name":"GRENADE.NAME.U1",
         "description":"GRENADE.DESCR.U1",
         "maxdamage":"GRENADE.DAMAGE.U1",
         "render":{"clipClass":"GrenadeUpg1"},
         "menuIcon":"IconGrenadeUpg1",
         "params":{"clipClassName":"AmGrenadeUpg1"},
         "property":{
            "ammoClass":StuffedBouncingGrenade,
            "multiBurst":new §_-TA§(2),
            "blink":"StuffedBouncingGrenadeBlink"
         }
      },{
         "id":323,
         "name":"GRENADE.NAME.U2",
         "description":"GRENADE.DESCR.U2",
         "maxdamage":"GRENADE.DAMAGE.U2",
         "iconClassName":"GrenadeUpg2",
         "render":{"clipClass":"GrenadeUpg2"},
         "menuIcon":"IconGrenadeUpg2",
         "params":{"clipClassName":"AmGrenadeUpg2"},
         "property":{
            "multiBurst":new §_-TA§(3),
            "cripple":true,
            "blink":"GrenadeUpg2Blink",
            "explodeOnCollide":"true"
         }
      },{
         "id":324,
         "name":"RIFLE.NAME.U1",
         "description":"RIFLE.DESCR.U1",
         "maxdamage":"RIFLE.DAMAGE.U1",
         "iconClassName":"RifleUpg1",
         "render":{
            "clipClass":"RifleUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconRifleUpg1",
         "params":{"damage":new §_-TA§(35)},
         "property":{"trajectoryCrosshair":new §_-7u§(true)}
      },{
         "id":325,
         "name":"HOMING_BAZOOKA.NAME.U1",
         "description":"HOMING_BAZOOKA.DESCR.U1",
         "maxdamage":"HOMING_BAZOOKA.DAMAGE.U1",
         "iconClassName":"HomingBazookaUpg1",
         "render":{
            "clipClass":"HomingBazookaUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconHomingBazookaUpg1",
         "property":{
            "ammoClass":StuffedHomingMissile,
            "damagePerFrame":new §_-TA§(1),
            "damageBonusLimit":new §_-TA§(40)
         },
         "params":{"clipClassName":"AmHomingBazookaUpg1"}
      },{
         "id":326,
         "name":"HOMING_BAZOOKA.NAME.U2",
         "description":"HOMING_BAZOOKA.DESCR.U2",
         "maxdamage":"HOMING_BAZOOKA.DAMAGE.U2",
         "iconClassName":"HomingBazookaUpg2",
         "render":{"clipClass":"HomingBazookaUpg2"},
         "menuIcon":"IconHomingBazookaUpg2",
         "property":{
            "damagePerFrame":new §_-TA§(2),
            "damageBonusLimit":new §_-TA§(80)
         },
         "params":{"clipClassName":"AmHomingBazookaUpg2"}
      },{
         "id":§_-q24§.ELECTRIC_HARPOON_UPG_1,
         "name":"HARPOON.NAME.U1",
         "description":"HARPOON.DESCR.U1",
         "maxdamage":"HARPOON.DAMAGE.U1",
         "iconClassName":"MainElectricHarpoonTrajectory",
         "render":{"clipClass":"MainElectricHarpoonTrajectory"},
         "menuIcon":"IconElectricHarpoonTrajectory",
         "property":{
            "trajectoryCrosshair":new §_-7u§(true),
            "dragDamage":new §_-TA§(10)
         },
         "params":{
            "clipClassName":"MainElectricHarpoonTrajectoryTip",
            "damage":new §_-TA§(35)
         }
      },{
         "id":§_-q24§.ELECTRIC_HARPOON_UPG_2_BOOST_DMG,
         "name":"HARPOON.NAME.U2A",
         "description":"HARPOON.DESCR.U2A",
         "maxdamage":"HARPOON.DAMAGE.U2A",
         "iconClassName":"ElectricHarpoonUpg2",
         "render":{"clipClass":"ElectricHarpoonUpg2"},
         "menuIcon":"IconElectricHarpoonUpg2",
         "params":{"clipClassName":"ElectricHarpoonUpg2Tip"},
         "property":{"dragDamage":new §_-TA§(12)}
      },{
         "id":§_-q24§.§_-Jy§,
         "name":"HARPOON.NAME.U2B",
         "description":"HARPOON.DESCR.U2B",
         "maxdamage":"HARPOON.DAMAGE.U2B",
         "classname":"ElectroGun",
         "iconClassName":"ElectroGun",
         "render":{"clipClass":"ElectroGun"},
         "menuIcon":"IconElectroGun",
         "params":{
            "clipClassName":"AmShocker",
            "damage":new §_-TA§(45)
         }
      },{
         "id":330,
         "name":"AUGER.NAME.U1",
         "description":"AUGER.DESCR.U1",
         "maxdamage":"AUGER.DAMAGE.U1",
         "iconClassName":"AugerUpg1",
         "render":{
            "clipClass":"AugerUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconAugerUpg1",
         "params":{"clipClassName":"AmAugerUpg1"},
         "property":{"drillDistance":new §_-TA§(105)}
      },{
         "id":331,
         "name":"AUGER.NAME.U2",
         "description":"AUGER.DESCR.U2",
         "classname":"Auger",
         "iconClassName":"AugerUpg2",
         "render":{"clipClass":"AugerUpg2"},
         "menuIcon":"IconAugerUpg2",
         "params":{"clipClassName":"AmAugerUpg2"},
         "property":{"setPlug":true}
      },{
         "id":§_-q24§.MINE_UPG_1,
         "name":"MINE.NAME.U1",
         "maxdamage":"MINE.DAMAGE.U1",
         "iconClassName":"MineUpg1",
         "render":{"clipClass":"MineUpg1"},
         "menuIcon":"IconMineUpg1",
         "params":{
            "clipClassName":"AmMineUpg1",
            "damage":new §_-TA§(45)
         }
      },{
         "id":§_-q24§.MINE_UPG_2,
         "name":"MINE.NAME.U2",
         "maxdamage":"MINE.DAMAGE.U2",
         "iconClassName":"MineUpg2",
         "render":{"clipClass":"MineUpg2"},
         "menuIcon":"IconMineUpg2",
         "params":{
            "clipClassName":"AmMineUpg2",
            "damage":new §_-TA§(50),
            "damageRadius":new §_-TA§(70),
            "explosionRadius":new §_-TA§(50)
         }
      },{
         "id":§_-q24§.§_-12h§,
         "name":"UZI.NAME.U1",
         "description":"UZI.DESCR.U1",
         "maxdamage":"UZI.DAMAGE.U1",
         "iconClassName":"UziUpg1",
         "render":{"clipClass":"UziUpg1"},
         "menuIcon":"IconUziUpg1",
         "params":{"damage":new §_-TA§(6)},
         "property":{"trailColor":12009742},
         "maxShots":5
      },{
         "id":§_-q24§.LASER_UPG_1,
         "name":"BARRIER.NAME.U1",
         "maxdamage":"BARRIER.DAMAGE.U1",
         "iconClassName":"LaserBarrierUpg1",
         "render":{"clipClass":"LaserBarrierUpg1"},
         "menuIcon":"IconLaserBarrierUpg1",
         "infinite":true,
         "maxShots":5,
         "params":{
            "clipClassName":"AmLaserBarrierUpg1",
            "damage":new §_-TA§(20)
         }
      },{
         "id":§_-q24§.LASER_UPG_2,
         "name":"BARRIER.NAME.U2",
         "note":"BARRIER.NOTE.U2",
         "maxdamage":"BARRIER.DAMAGE.U2",
         "iconClassName":"LaserBarrierUpg2",
         "render":{"clipClass":"LaserBarrierUpg2"},
         "menuIcon":"IconLaserBarrierUpg2",
         "infinite":true,
         "maxShots":6,
         "property":{"radiusIncreasing":50},
         "params":{
            "clipClassName":"AmLaserBarrierUpg2",
            "damage":new §_-TA§(25)
         }
      },{
         "id":337,
         "name":"SPIDER.NAME.U1",
         "description":"SPIDER.DESCR.U1",
         "maxdamage":"SPIDER.DAMAGE.U1",
         "iconClassName":"SpiderUpg1",
         "render":{"clipClass":"SpiderUpg1"},
         "menuIcon":"IconSpiderUpg1",
         "cooldown":1,
         "params":{"clipClassName":"AmSpiderUpg1"},
         "property":{"classMine":SpiderMinePoisonBolt}
      },{
         "id":§_-q24§.§_-s14§,
         "name":"DYNAMITE.NAME.U1A",
         "description":"DYNAMITE.DESCR.U1A",
         "maxdamage":"DYNAMITE.DAMAGE.U1A",
         "menuIcon":"IconDynamiteUpg1",
         "iconClassName":"DynamiteUpg1",
         "render":{
            "type":"clip",
            "clipClass":"DynamiteUpg1",
            "charParams":{"default":{"hideHands":"left"}}
         },
         "property":{"classDynamite":DynamiteBunch},
         "infinite":{"maxShots":5},
         "params":{"clipClassName":"AmDynamiteUpg1"},
         "secondaryParams":{
            "clipClassName":"AmDynamite",
            "damage":new §_-TA§(65),
            "damageRadius":new §_-TA§(82),
            "explosionRadius":new §_-TA§(60),
            "pushForce":new §_-TA§(0)
         }
      },{
         "id":§_-q24§.§_-c1p§,
         "name":"DYNAMITE.NAME.U1B",
         "description":"DYNAMITE.DESCR.U1B",
         "maxdamage":"DYNAMITE.DAMAGE.U1B",
         "hint":" ",
         "menuIcon":"IconDynamiteUpg2",
         "iconClassName":"DynamiteUpg2",
         "render":{
            "type":"clip",
            "clipClass":"DynamiteUpg2",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "infinite":{"maxShots":4},
         "classname":"KamikazeDynamite",
         "params":{
            "damage":new §_-TA§(70),
            "damageRadius":new §_-TA§(70),
            "explosionRadius":new §_-TA§(40),
            "pushForce":new §_-TA§(0)
         }
      },{
         "id":§_-q24§.§_-43k§,
         "name":"SHOCKER.NAME.U1",
         "description":"SHOCKER.DESCR.U1",
         "maxdamage":"SHOCKER.DAMAGE.U1",
         "menuIcon":"IconShockerUpg1",
         "iconClassName":"ShockerUpg1",
         "render":{"clipClass":"ShockerUpg1"},
         "params":{"damage":new §_-TA§(50)},
         "property":{"isSlowdown":new §_-7u§(true)},
         "infinite":{"maxShots":4}
      },{
         "id":§_-q24§.§_-40§,
         "name":"SHOCKER.NAME.U2",
         "description":"SHOCKER.DESCR.U2",
         "maxdamage":"SHOCKER.DAMAGE.U2",
         "menuIcon":"IconShockerUpg2",
         "render":{"clipClass":"ShockerUpg2"},
         "classname":"JumpingShocker",
         "property":{"jump":new §_-7u§(true)},
         "infinite":{"maxShots":5}
      },{
         "id":§_-q24§.§_-z12§,
         "name":"CAT_BAZOOKA.NAME.U1",
         "description":"CAT_BAZOOKA.DESCR.U1",
         "maxdamage":"CAT_BAZOOKA.DAMAGE.U1",
         "menuIcon":"IconCatBazookaUpg1",
         "render":{
            "type":"clip",
            "clipClass":"CatBazookaUpg1",
            "charParams":{
               "default":{"hideHands":"left"},
               "worm":{"x":-3}
            }
         },
         "infinite":{"maxShots":4},
         "property":{
            "damageForBounce":new §_-TA§(5),
            "autoTargeting":true
         },
         "params":{"clipClassName":"AmCatBazookaUpg1"}
      },{
         "id":§_-q24§.§_-w2m§,
         "name":"CAT_BAZOOKA.NAME.U2A",
         "maxdamage":"CAT_BAZOOKA.DAMAGE.U2A",
         "menuIcon":"IconCatBazookaUpg2A",
         "render":{
            "type":"clip",
            "clipClass":"CatBazookaUpg2A",
            "charParams":{
               "default":{"hideHands":"both"},
               "worm":{"x":-3}
            }
         },
         "infinite":{"maxShots":4},
         "property":{"maxBounce":new §_-TA§(4)},
         "params":{"clipClassName":"AmCatBazookaUpg2A"}
      },{
         "id":§_-q24§.§_-Z2L§,
         "name":"CAT_BAZOOKA.NAME.U2B",
         "description":"CAT_BAZOOKA.DESCR.U2B",
         "menuIcon":"IconCatBazookaUpg2B",
         "render":{
            "type":"clip",
            "clipClass":"CatBazookaUpg2B",
            "charParams":{
               "default":{"hideHands":"both"},
               "worm":{"x":-3}
            }
         },
         "infinite":{"maxShots":4},
         "property":{"ammoClassName":AirFireCatAmmo},
         "params":{"clipClassName":"AmCatBazookaUpg2B"}
      },{
         "id":§_-q24§.EMERGENCY_TELEPORT_UPG_1,
         "name":"EMERGENCY_TELEPORT.NAME.U1",
         "description":"EMERGENCY_TELEPORT.DESCR.U1",
         "menuIcon":"IconEmergencyTeleportUpg1",
         "iconClassName":"",
         "render":{"clipClass":"EmergencyTeleportUpg1"},
         "property":{"teleportRadius":new §_-TA§(1000)}
      },{
         "id":§_-q24§.EMERGENCY_TELEPORT_UPG_2,
         "name":"EMERGENCY_TELEPORT.NAME.U2",
         "description":"EMERGENCY_TELEPORT.DESCR.U2",
         "menuIcon":"IconEmergencyTeleportUpg2",
         "iconClassName":"",
         "render":{"clipClass":"EmergencyTeleportUpg2"},
         "property":{"mindDangerObj":new §_-7u§(true)}
      },{
         "id":§_-q24§.EMERGENCY_TELEPORT_UPG_3,
         "name":"EMERGENCY_TELEPORT.NAME.U3",
         "description":"EMERGENCY_TELEPORT.DESCR.U3",
         "note":"DOWNGRADE_ON_SHIFT.NOTE",
         "menuIcon":"IconEmergencyTeleportUpg3",
         "classname":"MedEmergencyTeleport",
         "iconClassName":"",
         "render":{"clipClass":"EmergencyTeleportUpg3"},
         "property":{"toMedkit":new §_-7u§(true)}
      },{
         "id":§_-q24§.BOOMERANG_UPG_1,
         "name":"BOOMERANG.NAME.U1",
         "maxdamage":"BOOMERANG.DAMAGE.U1",
         "menuIcon":"IconBoomerangUpg1",
         "iconClassName":"BoomerangUpg1",
         "render":{"clipClass":"BoomerangUpg1"},
         "params":{"clipClassName":"AmBoomerangUpg1"},
         "property":{"secondHitBonus":new §_-TA§(15)}
      },{
         "id":§_-q24§.BOOMERANG_UPG_2,
         "name":"BOOMERANG.NAME.U2",
         "description":"BOOMERANG.DESCR.U2",
         "maxdamage":"BOOMERANG.DAMAGE.U2",
         "menuIcon":"IconBoomerangUpg2",
         "iconClassName":"BoomerangUpg2",
         "render":{"clipClass":"BoomerangUpg2"},
         "params":{
            "damage":new §_-TA§(75),
            "clipClassName":"AmBoomerangUpg2"
         },
         "property":{"knockHat":new §_-7u§(true)}
      },{
         "id":§_-q24§.DRILL_UPG1,
         "name":"PNEUMATIC_DRILL.NAME.U1",
         "description":"PNEUMATIC_DRILL.DESCR.U1",
         "menuIcon":"IconPneumaticDrillUpg1",
         "iconClassName":"PneumaticDrillUpg1",
         "render":{"clipClass":"PneumaticDrillUpg1"},
         "property":{"setPlug":true},
         "params":{"clipClassName":"AmPneumaticDrillUpg1"}
      },{
         "id":§_-q24§.DRILL_UPG2,
         "name":"PNEUMATIC_DRILL.NAME.U2",
         "description":"PNEUMATIC_DRILL.DESCR.U2",
         "menuIcon":"IconPneumaticDrillUpg2",
         "iconClassName":"PneumaticDrillUpg2",
         "render":{"clipClass":"PneumaticDrillUpg2"},
         "property":{"allowTorch":true},
         "params":{"clipClassName":"AmPneumaticDrillUpg2"}
      },{
         "id":§_-q24§.§_-H25§,
         "name":"TELE_THROWER.NAME.U1",
         "description":"TELE_THROWER.DESCR.U1",
         "menuIcon":"TeleportThrowerIconUpg1",
         "iconClassName":"TeleportThrowerIconUpg1",
         "render":{"clipClass":"TeleportThrowerUpg1"},
         "params":{"clipClassName":"AmTeleportThrowerUpg1"},
         "property":{
            "blinkClassName":"TeleportThrowerBlinkUpg1",
            "teleportOnButton":new §_-7u§(true)
         }
      },{
         "id":§_-q24§.§_-z2w§,
         "name":"ANTIFREEZE.NAME.U1",
         "description":"ANTIFREEZE.DESCR.U1",
         "menuIcon":"AntifreezeIconUpg1",
         "iconClassName":"AntifreezeClipUpg1",
         "render":{"clipClass":"AntifreezeClipUpg1"},
         "params":{"damage":new §_-TA§(60)},
         "property":{"protection":new §_-7u§(true)}
      },{
         "id":§_-q24§.§_-gi§,
         "name":"ANTIFREEZE.NAME.U2A",
         "description":"ANTIFREEZE.DESCR.U2A",
         "menuIcon":"AntifreezeIconAttackUpg",
         "iconClassName":"AntifreezeClipAttackUpg",
         "render":{"clipClass":"AntifreezeClipAttackUpg"},
         "params":{"damage":new §_-TA§(70)},
         "property":{"burstAttack":new §_-TA§(30)}
      },{
         "id":§_-q24§.§_-H3z§,
         "name":"ANTIFREEZE.NAME.U2B",
         "description":"ANTIFREEZE.DESCR.U2B",
         "menuIcon":"AntifreezeIconArmorUpg",
         "iconClassName":"AntifreezeClipArmorUpg",
         "render":{"clipClass":"AntifreezeClipArmorUpg"},
         "params":{"damage":new §_-TA§(70)},
         "property":{"burstArmor":new §_-TA§(30)}
      },{
         "id":§_-q24§.§_-R2h§,
         "name":"GIRDER.NAME.U1",
         "note":"GIRDER.NOTE.U1",
         "menuIcon":"IconGirderUpg1",
         "iconClassName":"",
         "property":{
            "resizable":new §_-7u§(true),
            "indestructible":new §_-7u§(false),
            "clipGirder":"GirderUpg1"
         }
      },{
         "id":§_-q24§.§_-C25§,
         "name":"PARASITE.NAME.U1",
         "description":"PARASITE.DESCR.U1",
         "iconClassName":"ParasiteUpg1",
         "menuIcon":"IconParasiteUpg1",
         "cooldown":1,
         "property":{
            "ammoClass":VampiricParasite,
            "blinkClip":"ParasiteBlinkUpg1",
            "attachedClip":"ParasiteBlinkUpg1",
            "switchTurnCooldownEnemy":new §_-7u§(false)
         },
         "render":{"clipClass":"ParasiteUpg1"},
         "params":{"clipClassName":"AmParasiteUpg1"}
      },{
         "id":§_-q24§.ROPE_UPG_1,
         "name":"ROPE.NAME.U1",
         "description":"ROPE.DESCR.U1",
         "property":{
            "extraLength":true,
            "ropeSpeed":new §_-TA§(80)
         },
         "render":{
            "clipClass":"RopeUpg1",
            "charParams":{"default":{
               "x":-4.3,
               "y":-3.6,
               "hideHands":"both"
            }}
         },
         "menuIcon":"IconRopeUpg1",
         "params":{"clipClassName":"RopeTipUpg1"}
      },{
         "id":§_-q24§.ROPE_UPG_2,
         "name":"ROPE.NAME.U2",
         "description":"ROPE.DESCR.U2",
         "note":"ROPE.NOTE.U2",
         "classname":"SupplyRopeGun",
         "property":{"weaponClip":"RopeGrUpg2"},
         "render":{"clipClass":"RopeUpg2"},
         "menuIcon":"IconRopeUpg2",
         "params":{"clipClassName":"RopeTipUpg2"}
      },{
         "id":§_-q24§.GRAVITY_GUN_UPG_1,
         "name":"GRAVITY_GUN.NAME.U1",
         "maxdamage":"GRAVITY_GUN.DAMAGE.U1",
         "description":"GRAVITY_GUN.DESCR.U1",
         "render":{
            "clipClass":"GravityGunUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconGravityGunUpg1",
         "property":{"trajectoryCrosshair":new §_-7u§(true)},
         "params":{"damage":new §_-TA§(30)}
      },{
         "id":§_-q24§.GRAVITY_GUN_UPG_2,
         "name":"GRAVITY_GUN.NAME.U2",
         "note":"GRAVITY_GUN.NOTE.U2",
         "description":"GRAVITY_GUN.DESCR.U2",
         "classname":"GrabberGun",
         "render":{
            "clipClass":"GravityGunUpg2",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconGravityGunUpg2",
         "property":{"attraction":new §_-7u§(true)}
      },{
         "id":§_-q24§.GUARDING_BOT_UPG_1A,
         "name":"GUARDING_BOT.NAME.U1A",
         "description":"GUARDING_BOT.DESCR.U1A",
         "property":{"mineClass":HideableGuardingBot},
         "render":{"clipClass":"GuardingBotNinja"},
         "params":{"clipClassName":"AmGuardingBotNinja"},
         "iconClassName":"AmGuardingBotNinja",
         "menuIcon":"IconGuardingBotNinja"
      },{
         "id":§_-q24§.GUARDING_BOT_UPG_1B,
         "name":"GUARDING_BOT.NAME.U1B",
         "description":"GUARDING_BOT.DESCR.U1B",
         "classname":"ThrowableMineWeapon",
         "property":{"mineClass":StickyGuardingBot},
         "render":{"clipClass":"GuardingBotSticky"},
         "params":{"clipClassName":"AmGuardingBotSticky"},
         "iconClassName":"AmGuardingBotSticky",
         "menuIcon":"IconGuardingBotSticky"
      },{
         "id":§_-q24§.§_-S2U§,
         "name":"PUSHING_MINE.NAME.U1",
         "description":"PUSHING_MINE.DESCR.U1",
         "render":{"clipClass":"PushingMineUpg1"},
         "menuIcon":"IconPushingMineUpg1",
         "params":{"clipClassName":"AmPushingMineUpg1"},
         "property":{"groundSetup":true}
      },{
         "id":§_-q24§.SLEDGEHAMMER_UPG_1,
         "name":"SLEDGEHAMMER.NAME.U1",
         "description":"SLEDGEHAMMER.DESCR.U1",
         "note":"DOWNGRADE_ON_SHIFT.NOTE",
         "classname":"SledgehammerDownGradable",
         "render":{"clipClass":"SledgeHammerUpg1"},
         "params":{"clipClassName":"AmSledgeHammerUpg1"},
         "menuIcon":"IconSledgehammerUpg1",
         "property":{
            "holeDepth":18,
            "weaponClip":"AmSledgeHammerUpg1"
         }
      },{
         "id":§_-q24§.SLEDGEHAMMER_UPG_1B,
         "name":"SLEDGEHAMMER.NAME.U1B",
         "description":"SLEDGEHAMMER.DESCR.U1B",
         "render":{"clipClass":"SledgeHammerUpg1B"},
         "params":{"clipClassName":"AmSledgeHammerUpg1B"},
         "menuIcon":"IconSledgehammerUpg1B",
         "property":{
            "statsReduction":new §_-TA§(20),
            "weaponClip":"AmSledgeHammerUpg1B"
         }
      },{
         "id":§_-q24§.§_-z2a§,
         "name":"BAT.NAME.U1",
         "description":"BAT.DESCR.U1",
         "note":"DOWNGRADE_ON_SHIFT.NOTE",
         "classname":"BatDownGradable",
         "render":{"clipClass":"BatUpg1"},
         "menuIcon":"IconBatUpg1",
         "property":{
            "groundBreak":true,
            "weaponClip":"AmBatUpg1",
            "offsetX":-5,
            "offsetY":-10
         }
      },{
         "id":§_-q24§.UFO_UPG_1,
         "name":"UFO.NAME.U1",
         "description":"UFO.DESCR.U1",
         "maxdamage":"UFO.DAMAGE.U1",
         "menuIcon":"IconUfoUpg1",
         "params":{
            "clipClassName":"AmFlightUpg1",
            "damage":new §_-TA§(85)
         },
         "property":{"maxFuel":new §_-TA§(3000)}
      },{
         "id":§_-q24§.UFO_UPG_2,
         "name":"UFO.NAME.U2",
         "description":"UFO.DESCR.U2",
         "maxdamage":"UFO.DAMAGE.U2",
         "menuIcon":"IconUfoUpg2",
         "params":{
            "clipClassName":"AmFlightUpg2",
            "damage":new §_-TA§(95)
         },
         "property":{"canCarryUnits":true}
      },{
         "id":§_-q24§.§_-73A§,
         "name":"MOLOTOV.NAME.U1",
         "description":"MOLOTOV.DESCR.U1",
         "classname":"MolotovExplodable",
         "property":{"fireCount":new §_-TA§(48)},
         "render":{"clipClass":"MolotovUpg1"},
         "params":{"clipClassName":"AmMolotovUpg1"},
         "menuIcon":"IconMolotovUpg1"
      },{
         "id":§_-q24§.GAS_GRENADE_UPG_1,
         "name":"GAS_GRENADE.NAME.U1",
         "description":"GAS_GRENADE.DESCR.U1",
         "note":"",
         "classname":"GasGrenadeExplodable",
         "render":{"clipClass":"GasGrenadeUpg1"},
         "menuIcon":"IconGasGrenadeUpg1",
         "params":{"clipClassName":"AmGasGrenadeUpg1"},
         "property":{
            "cloudClipName":"GasCloudUpg1",
            "armorReduction":new §_-TA§(10),
            "cloudColor":new ColorArgb(1,0.5,1,0.5)
         }
      },{
         "id":§_-q24§.GAS_GRENADE_UPG_1B,
         "name":"GAS_GRENADE.NAME.U1B",
         "description":"GAS_GRENADE.DESCR.U1B",
         "render":{"clipClass":"GasGrenadeUpg1B"},
         "menuIcon":"IconGasGrenadeUpg1B",
         "params":{"clipClassName":"AmGasGrenadeUpg1B"},
         "property":{
            "cloudClipName":"GasCloudUpg1B",
            "slowing":true,
            "cloudColor":new ColorArgb(0.7,0.9,1,0.5)
         }
      },{
         "id":§_-q24§.SPIDER_UPG_1B,
         "name":"SPIDER.NAME.U1B",
         "description":"SPIDER.DESCR.U1B",
         "maxdamage":"SPIDER.DAMAGE.U1B",
         "hint":"",
         "note":"",
         "cooldown":1,
         "render":{"clipClass":"SpiderUpg1B"},
         "menuIcon":"IconSpiderUpg1B",
         "params":{
            "clipClassName":"AmSpiderUpg1B",
            "damage":new §_-TA§(30),
            "damageRadius":new §_-TA§(50),
            "explosionRadius":new §_-TA§(30)
         },
         "property":{"classMine":SpiderMineFrostBolt}
      },{
         "id":§_-q24§.FREEZING_BAZOOKA_UPG1A,
         "name":"FREEZER.NAME.U1A",
         "description":"FREEZER.DESCR.U1A",
         "maxdamage":"FREEZER.DAMAGE.U1A",
         "render":{
            "clipClass":"FreezingBazookaUpg1",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconFreezingBazookaUpg1",
         "cooldown":1,
         "property":{
            "bonusOnFrozen":true,
            "bonusDamage":0.5,
            "bonusFreeze":1
         },
         "params":{
            "clipClassName":"AmFreezingBazookaUpg1",
            "damage":new §_-TA§(60)
         }
      },{
         "id":§_-q24§.FREEZING_BAZOOKA_UPG2A,
         "name":"FREEZER.NAME.U2A",
         "description":"FREEZER.DESCR.U2A",
         "maxdamage":"FREEZER.DAMAGE.U2A",
         "render":{
            "clipClass":"FreezingBazookaUpg2A",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconFreezingBazookaUpg2A",
         "classname":"AlterableFreezingBazooka",
         "cooldown":1,
         "params":{"damage":new §_-TA§(80)},
         "property":{
            "bonusOnSlowed":true,
            "targetSearch":true
         }
      },{
         "id":§_-q24§.FREEZING_BAZOOKA_UPG1B,
         "name":"FREEZER.NAME.U1B",
         "description":"FREEZER.DESCR.U1B",
         "maxdamage":"FREEZER.DAMAGE.U1B",
         "render":{
            "clipClass":"FreezingBazookaUpg1B",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconFreezingBazookaUpg1B",
         "params":{
            "damage":new §_-TA§(30),
            "clipClassName":"AmFreezingBazookaUpg1"
         },
         "cooldown":1,
         "property":{"freezeDuration":1},
         "shotsPerTurn":2
      },{
         "id":§_-q24§.FREEZING_BAZOOKA_UPG2B,
         "name":"FREEZER.NAME.U2B",
         "description":"FREEZER.DESCR.U2B",
         "maxdamage":"FREEZER.DAMAGE.U2B",
         "render":{
            "clipClass":"FreezingBazookaUpg2B",
            "charParams":{"default":{"hideHands":"both"}}
         },
         "menuIcon":"IconFreezingBazookaUpg2B",
         "cooldown":1,
         "params":{"damage":new §_-TA§(30)},
         "property":{"trajectoryCrosshair":true},
         "shotsPerTurn":3
      },{
         "id":§_-q24§.AIR_BLOCKER_UPG_1,
         "name":"AIR_BLOCKER.NAME.U1",
         "description":"AIR_BLOCKER.DESCR.U1",
         "property":{"ammoClass":MagneticAirBlocker},
         "render":{"clipClass":"AirBlockerClipUpg1"},
         "params":{"clipClassName":"AirBlockerClipUpg1"},
         "iconClassName":"AirBlockerClipUpg1",
         "menuIcon":"AirBlockerIconUpg1"
      },{
         "id":§_-q24§.AIR_BLOCKER_UPG_1B,
         "name":"AIR_BLOCKER.NAME.U1B",
         "description":"AIR_BLOCKER.DESCR.U1B",
         "property":{"ammoClass":FreezingAirBlocker},
         "render":{"clipClass":"AirBlockerClipUpg1B"},
         "params":{"clipClassName":"AirBlockerClipUpg1B"},
         "menuIcon":"AirBlockerIconUpg1B"
      }];
      
      public function §_-u2x§()
      {
         super();
      }
      
      public function §_-Pu§(param1:int) : Object
      {
         var _loc2_:Object = null;
         for each(_loc2_ in this.upgrades)
         {
            if(_loc2_.id == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
   }
}


package §_-AN§
{
   import §_-71F§.§_-kk§;
   import §_-K35§.§_-99§;
   import §_-K35§.§_-S18§;
   import §_-YF§.§_-N3§;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.events.Event;
   
   public class §_-Na§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:§_-S18§;
      
      public function §_-Na§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         var _loc1_:String = null;
         §_-32S§(Event.SELECT,this.§_-d2Z§);
         if(this.§_-j1r§.userProfile == null)
         {
            _loc1_ = this.§_-j1r§.profileId.toString();
            if(this.§_-j1r§.platformId)
            {
               _loc1_ = this.§_-j1r§.platformId + ":" + _loc1_;
            }
            §_-N3§.§_-Oc§([_loc1_],this.§_-m2T§,true);
         }
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         this.§_-j1r§.clear();
      }
      
      private function §_-m2T§(param1:Vector.<UserProfile>) : void
      {
         if(Boolean(param1.length > 0) && Boolean(this.§_-j1r§) && Boolean(this.§_-j1r§.stage))
         {
            this.§_-j1r§.userProfile = param1[0];
         }
      }
      
      private function §_-d2Z§(param1:Event) : void
      {
         var _loc2_:§_-99§ = param1.data.action as §_-99§;
         var _loc3_:UserProfile = param1.data.profile as UserProfile;
         if(_loc2_)
         {
            dispatchWith(_loc2_.eventType,false,_loc3_);
            this.§_-j1r§.close();
         }
      }
   }
}


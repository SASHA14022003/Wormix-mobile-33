package §_-G16§
{
   public interface §_-Y2x§
   {
      
      function removeFromPool() : void;
   }
}


package §_-G16§
{
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-A1K§.§_-TA§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-f1G§.§_-kf§;
   import §_-m2s§.§_-R11§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-sI§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.TweenEvent;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayoutData;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Rectangle;
   import flash.utils.*;
   import org.gestouch.core.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Stage;
   import starling.events.Event;
   import starling.rendering.Painter;
   import starling.utils.Pool;
   
   use namespace gestouch_internal;
   
   public class §_-L1B§
   {
      
      private static var instance:§_-L1B§;
      
      private var §_-R2u§:Dictionary;
      
      private var pool:Vector.<Rectangle>;
      
      private var counter:int;
      
      private var §_-423§:int;
      
      public function §_-L1B§(param1:uint = 0)
      {
         super();
         if(instance)
         {
            throw new Error("RectPool instance already created!");
         }
         this.§_-R2u§ = new Dictionary();
         this.§_-423§ = param1;
         this.pool = new Vector.<Rectangle>(0);
         this.counter = 0;
         if(param1 > 0)
         {
            this.fill(param1);
         }
      }
      
      public static function getInstance(param1:uint = 0) : §_-L1B§
      {
         if(!instance)
         {
            instance = new §_-L1B§(param1);
         }
         return instance;
      }
      
      public function fill(param1:uint) : void
      {
         var _loc2_:int = int(param1);
         while(--_loc2_ > -1)
         {
            this.put(new Rectangle(),null);
         }
      }
      
      public function empty(param1:Boolean = false) : void
      {
         var _loc2_:int = int(this.pool.length);
         while(--_loc2_ > -1)
         {
            Pool.putRectangle(this.pool[_loc2_]);
         }
         this.pool.length = this.counter = 0;
         if(param1)
         {
            this.fill(this.§_-423§);
         }
      }
      
      public function dispose() : void
      {
         this.empty();
         this.pool = null;
      }
      
      public function put(param1:Rectangle, param2:Object) : void
      {
         var _loc4_:Array = null;
         var _loc5_:int = 0;
         var _loc3_:Number = Number(this.pool.indexOf(param1));
         if(_loc3_ > -1)
         {
            throw new Error("Rectangle already in pool! (wtf) " + _loc3_ + " " + this.counter);
         }
         if(Boolean(param2) && (!this.§_-R2u§[param1] || this.§_-R2u§[param1].indexOf(param2) == -1))
         {
         }
         ++this.counter;
         this.pool.push(param1);
         if(param2)
         {
            if(!this.§_-R2u§[param1])
            {
               this.§_-R2u§[param1] = [];
            }
            else
            {
               _loc4_ = this.§_-R2u§[param1];
               _loc5_ = int(_loc4_.indexOf(param2));
               if(_loc5_ > -1)
               {
                  _loc4_.splice(_loc5_,1);
               }
            }
         }
      }
      
      public function get(param1:Object, param2:Number = 0, param3:Number = 0, param4:Number = 0, param5:Number = 0) : Rectangle
      {
         var _loc6_:Rectangle = null;
         if(this.counter <= 0)
         {
            _loc6_ = Pool.getRectangle(param2,param3,param4,param5);
         }
         else
         {
            --this.counter;
            _loc6_ = this.pool.pop();
            _loc6_.setTo(param2,param3,param4,param5);
         }
         if(param1)
         {
            if(!this.§_-R2u§[_loc6_])
            {
               this.§_-R2u§[_loc6_] = [];
            }
            if(this.§_-R2u§[_loc6_].indexOf(param1) <= -1)
            {
               throw new Error("New parent of rectangle already registered! (wtf) " + param1 + " " + this.§_-R2u§[_loc6_]);
            }
            this.§_-R2u§[_loc6_].push(param1);
         }
         return _loc6_;
      }
   }
}


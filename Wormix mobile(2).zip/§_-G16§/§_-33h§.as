package §_-G16§
{
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-DJ§.§_-fH§;
   import §_-Z1K§.§_-q24§;
   import §_-n1w§.*;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.request.PromoteRankInClanRequest;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.weapons.ammo.DynamiteStick;
   import starling.events.Event;
   import starling.utils.AssetManager;
   
   public class §_-33h§
   {
      
      private var §_-N1s§:Class;
      
      private var §_-r2z§:Vector.<§_-Y2x§>;
      
      private var §_-X1W§:int;
      
      private var _initialCapacity:int;
      
      public function §_-33h§(param1:Class, param2:uint = 0)
      {
         super();
         this.§_-N1s§ = param1;
         this._initialCapacity = param2;
         this.§_-r2z§ = new Vector.<§_-Y2x§>(0);
         this.§_-X1W§ = 0;
         if(param2 > 0)
         {
            this.fill(param2);
         }
      }
      
      public function fill(param1:uint) : void
      {
         var _loc2_:int = int(param1);
         while(--_loc2_ > -1)
         {
            this.put(new this.§_-N1s§());
         }
      }
      
      public function empty(param1:Boolean = false) : void
      {
         var _loc2_:int = int(this.§_-r2z§.length);
         while(--_loc2_ > -1)
         {
            this.§_-r2z§[_loc2_].removeFromPool();
         }
         this.§_-r2z§.splice(0,this.§_-r2z§.length);
         this.§_-X1W§ = 0;
         if(param1)
         {
            this.fill(this._initialCapacity);
         }
      }
      
      public function dispose() : void
      {
         this.empty();
         this.§_-r2z§ = null;
      }
      
      public function put(param1:§_-Y2x§) : void
      {
         ++this.§_-X1W§;
         this.§_-r2z§.push(param1);
      }
      
      public function get() : Object
      {
         if(this.§_-X1W§ <= 0)
         {
            return new this.§_-N1s§();
         }
         --this.§_-X1W§;
         return this.§_-r2z§.pop();
      }
   }
}


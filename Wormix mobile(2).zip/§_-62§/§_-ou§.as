package §_-62§
{
   import §_-C3f§.§_-Z1Y§;
   import §_-Ly§.§_-81L§;
   import §_-lh§.§_-z2A§;
   import §_-r1C§.§_-h2B§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.§_-13q§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import starling.events.Event;
   
   public class §_-ou§
   {
      
      public function §_-ou§()
      {
         super();
      }
      
      public static function §_-n2f§(param1:§_-W1r§) : String
      {
         if(param1 is §_-zF§ || param1 is §_-T1y§)
         {
            return §_-2t§.§_-n2Z§(param1.getId());
         }
         if(param1 is §_-O2H§)
         {
            return §_-s2a§.§_-K3t§(§_-G1p§.§_-I4§(param1.getId()).getName());
         }
         return null;
      }
      
      public static function sort(param1:Array) : void
      {
         param1.sort(itemsComparator);
      }
      
      public static function §_-au§(param1:Array) : void
      {
         if(§_-N1V§.§_-I39§.§_-y1r§())
         {
            param1.sort(§_-o2q§);
         }
         else
         {
            param1.sort(§_-O1e§);
         }
      }
      
      public static function §_-X1B§(param1:§_-13q§, param2:§_-13q§) : int
      {
         return itemsComparator(param1.§_-A39§,param2.§_-A39§);
      }
      
      public static function itemsComparator(param1:§_-W1r§, param2:§_-W1r§) : int
      {
         if(param1.comparator > param2.comparator)
         {
            return 1;
         }
         if(param1.comparator < param2.comparator)
         {
            return -1;
         }
         return 0;
      }
      
      public static function §_-O1e§(param1:§_-W1r§, param2:§_-W1r§) : int
      {
         return itemsComparator(param1,param2);
      }
      
      public static function §_-o2q§(param1:§_-W1r§, param2:§_-W1r§) : int
      {
         if(param1.getState().equals(§_-Z1Y§.§_-v2B§) && param2.getState().equals(§_-Z1Y§.§_-v2B§))
         {
            return §_-21s§(param1.§_-ui§(),param2.§_-ui§());
         }
         if(param1.getState().equals(§_-Z1Y§.§_-v2B§))
         {
            return param2.getState().equals(§_-Z1Y§.§_-v2B§) ? itemsComparator(param1,param2) : -1;
         }
         if(param2.getState().equals(§_-Z1Y§.§_-v2B§))
         {
            return 1;
         }
         if(param1.getState().equals(§_-Z1Y§.§_-Vi§))
         {
            return param2.getState().equals(§_-Z1Y§.§_-Vi§) ? itemsComparator(param1,param2) : -1;
         }
         if(param2.getState().equals(§_-Z1Y§.§_-Vi§))
         {
            return 1;
         }
         return itemsComparator(param1,param2);
      }
      
      private static function §_-21s§(param1:int, param2:int) : int
      {
         if(param1 < param2)
         {
            return 1;
         }
         if(param1 > param2)
         {
            return -1;
         }
         return 0;
      }
   }
}


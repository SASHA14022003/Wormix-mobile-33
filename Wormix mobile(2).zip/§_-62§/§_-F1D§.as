package §_-62§
{
   public class §_-F1D§
   {
      
      private var §_-B10§:int;
      
      private var §_-u1C§:int;
      
      public function §_-F1D§(param1:int, param2:int = -1)
      {
         super();
         this.§_-B10§ = param1;
         this.§_-u1C§ = param2;
      }
      
      public function get id() : int
      {
         return this.§_-B10§;
      }
      
      public function get quantity() : int
      {
         return this.§_-u1C§;
      }
   }
}


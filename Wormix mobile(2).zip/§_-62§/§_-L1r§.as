package §_-62§
{
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-91B§.§_-z2l§;
   import §_-A2U§.§_-r22§;
   import §_-CF§.§_-E19§;
   import §_-Vg§.§_-M11§;
   import §_-qH§.§_-S25§;
   import §_-s1Q§.Artifacts;
   import §_-z20§.§_-Tn§;
   import feathers.controls.Button;
   import feathers.controls.ButtonGroup;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.layout.Direction;
   import feathers.layout.VerticalAlign;
   import feathers.skins.ImageSkin;
   import feathers.themes.styles.AlternateButtonsStyles;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import starling.events.Event;
   import starling.textures.Texture;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-L1r§ extends §_-W1r§ implements §_-r22§
   {
      
      private var §_-b1t§:§_-N1H§;
      
      private var §_-r1s§:§_-N1H§;
      
      public var temp:Boolean;
      
      private var temporalTime:int = -1;
      
      private var prefix:§_-z2l§;
      
      public function §_-L1r§(param1:String)
      {
         super();
         this.§_-b1t§ = new §_-N1H§(param1);
         this.§_-r1s§ = new §_-N1H§(param1);
      }
      
      override public function initFromConfig(param1:Object) : void
      {
         super.initFromConfig(param1);
         if(param1.temporalTime)
         {
            this.§_-o22§(param1.temporalTime);
         }
         if(param1.duration)
         {
            this.temp = true;
            if(this.temporalTime == -1)
            {
               this.§_-o22§(param1.duration * 60);
            }
         }
         this.§_-q1k§(param1);
         §_-83i§(true);
      }
      
      override public function get §_-kE§() : Boolean
      {
         return true;
      }
      
      public function §_-q1k§(param1:Object) : void
      {
         §_-2t§.§_-X1r§(this.§_-b1t§,param1.bonuses || param1);
         if(this.§_-kz§())
         {
            §_-2t§.§_-X1r§(this.§_-r1s§,param1.bonuses || param1,true);
         }
         else
         {
            this.§_-r1s§ = this.§_-b1t§;
         }
      }
      
      public function §_-I18§(param1:§_-L1r§) : void
      {
         var _loc2_:§_-4w§ = null;
         for each(_loc2_ in this.§_-b1t§.§_-b2I§())
         {
            param1.§_-b1t§.addItem(_loc2_);
         }
         for each(_loc2_ in this.§_-r1s§.§_-b2I§())
         {
            param1.§_-r1s§.addItem(_loc2_);
         }
      }
      
      private function §_-kz§() : Boolean
      {
         return this.temp && !§_-Tn§.§_-l2y§(int(id / 10) * 10) && (§_-S25§.§_-23X§(id) || §_-S25§.§_-HE§(id) || Artifacts.§_-HE§(id));
      }
      
      public function §_-V1v§(param1:Boolean = false) : §_-N1H§
      {
         return param1 ? this.§_-r1s§ : this.§_-b1t§;
      }
      
      public function §_-G1B§() : Boolean
      {
         return this.temp || this.temporalTime != -1;
      }
      
      public function §_-n2k§() : int
      {
         return this.temporalTime;
      }
      
      public function §_-o22§(param1:int) : void
      {
         this.temporalTime = param1 * §_-72u§.§_-71e§;
      }
      
      public function §_-t2s§(param1:§_-z2l§) : void
      {
         this.prefix = param1;
      }
      
      public function §_-j12§() : §_-z2l§
      {
         return this.prefix;
      }
   }
}


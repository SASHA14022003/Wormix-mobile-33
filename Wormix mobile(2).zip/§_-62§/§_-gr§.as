package §_-62§
{
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-gr§ extends §_-W1r§
   {
      
      public function §_-gr§()
      {
         super();
      }
   }
}


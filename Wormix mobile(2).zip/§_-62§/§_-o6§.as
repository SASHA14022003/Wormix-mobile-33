package §_-62§
{
   import ru.pragmatix.wormix.controller.§_-J2d§;
   
   public class §_-o6§
   {
      
      private var §_-U2K§:int;
      
      private var §_-025§:int;
      
      private var §_-92Z§:int;
      
      public function §_-o6§(param1:int, param2:int = -1)
      {
         super();
         this.§_-U2K§ = param1;
         this.§_-025§ = param2;
         this.§_-92Z§ = param2 * §_-J2d§.§_-xa§;
      }
      
      public function get id() : int
      {
         return this.§_-U2K§;
      }
      
      public function get amount() : int
      {
         return this.§_-025§;
      }
      
      public function get §_-I1k§() : int
      {
         return this.§_-92Z§;
      }
   }
}


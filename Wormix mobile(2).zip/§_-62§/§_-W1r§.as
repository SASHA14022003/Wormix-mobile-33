package §_-62§
{
   import §_-A1K§.§_-TA§;
   import §_-C3f§.§_-1Y§;
   import §_-C3f§.§_-Z1Y§;
   import §_-L1w§.§_-CD§;
   import §_-YF§.§_-g2W§;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.events.Event;
   
   public class §_-W1r§ extends §_-1Y§ implements §_-g2W§
   {
      
      protected var clipClassName:String;
      
      protected var menuIcon:String;
      
      protected var §_-f20§:String;
      
      protected var §_-Yb§:String;
      
      protected var alignMenuIcon:Boolean;
      
      protected var infinite:Boolean;
      
      private var _requiredRating:§_-TA§;
      
      protected var §_-U1a§:int;
      
      protected var duration:int;
      
      public function §_-W1r§()
      {
         super();
      }
      
      override public function initFromConfig(param1:Object) : void
      {
         super.initFromConfig(param1);
         if(param1.id)
         {
            setId(param1.id);
         }
         if(param1.name)
         {
            setName(param1.name);
         }
         if(param1.description)
         {
            setDescription(param1.description);
         }
         if(Boolean(param1.note) || param1.note == "")
         {
            §_-j1n§(param1.note);
         }
         if(param1.iconClassName)
         {
            this.§_-pV§(param1.iconClassName);
         }
         if(param1.menuIcon)
         {
            this.§_-hM§(param1.menuIcon);
         }
         if(param1.alignMenuIcon)
         {
            this.§_-K34§(true);
         }
         if(param1.requiredFriends)
         {
            §_-k12§(param1.requiredFriends);
         }
         if(param1.requiredLevel)
         {
            §_-s2g§(param1.requiredLevel);
         }
         if(param1.requiredScenario)
         {
            requiredScenario = param1.requiredScenario;
         }
         if(param1.hideInShop)
         {
            §_-z1T§(param1.hideInShop);
         }
         if(param1.isSale)
         {
            setState(§_-Z1Y§.§_-v2B§,param1.isSale);
         }
         if(param1.isNew)
         {
            setState(§_-Z1Y§.§_-Vi§);
         }
         if(param1.category)
         {
            this.§_-Zx§(param1.category);
         }
         if(param1.duration)
         {
            this.§_-4x§(param1.duration);
         }
         this.§_-83i§(param1.infinite);
         if(param1.requiredRating)
         {
            this._requiredRating = new §_-TA§(param1.requiredRating);
         }
      }
      
      public function §_-92P§() : String
      {
         return this.menuIcon;
      }
      
      public function §_-V2D§() : String
      {
         return this.§_-f20§;
      }
      
      public function §_-f2w§() : String
      {
         return this.§_-Yb§;
      }
      
      public function §_-Z2t§() : Boolean
      {
         return this.alignMenuIcon;
      }
      
      public function §_-K34§(param1:Boolean) : void
      {
         this.alignMenuIcon = param1;
      }
      
      public function §_-hM§(param1:String) : void
      {
         this.menuIcon = param1;
      }
      
      public function §_-W1S§(param1:String, param2:String) : void
      {
         this.§_-f20§ = param1;
         this.§_-Yb§ = param2;
      }
      
      public function §_-G3a§() : String
      {
         return this.clipClassName;
      }
      
      public function §_-pV§(param1:String) : void
      {
         this.clipClassName = param1;
      }
      
      public function getInfinite() : Boolean
      {
         return this.infinite;
      }
      
      public function §_-N2E§() : uint
      {
         return this._requiredRating ? uint(this._requiredRating.value) : 0;
      }
      
      public function §_-83i§(param1:Boolean) : void
      {
         this.infinite = param1;
      }
      
      public function §_-n1W§() : int
      {
         return 0;
      }
      
      public function §_-3K§() : int
      {
         return this.§_-U1a§;
      }
      
      public function §_-Zx§(param1:int) : void
      {
         this.§_-U1a§ = param1;
      }
      
      public function §_-4x§(param1:int) : void
      {
         this.duration = param1;
      }
      
      public function §_-x1n§() : int
      {
         return this.duration;
      }
      
      public function §_-K2N§() : Boolean
      {
         var _loc1_:Boolean = false;
         if(this is §_-O2H§ || this is §_-zF§ || this is §_-T1y§)
         {
            _loc1_ = !this.getInfinite() && !§_-O2H§(this).getMaxShots();
         }
         else
         {
            _loc1_ = true;
         }
         return _loc1_;
      }
      
      public function toString() : String
      {
         return "ItemRecord{id=" + String(getId()) + ",name=" + String(getName()) + ",description=" + String(§_-p1§()) + ",iconClass=" + this.clipClassName + (Boolean(getPrice()) && Boolean(§_-91e§()) ? ",price=" + String(§_-91e§()) : "") + (Boolean(getPrice()) && Boolean(§_-gc§()) ? ",realprice=" + String(§_-gc§()) : "") + ",requiredLevel=" + String(§_-T1J§()) + "}";
      }
      
      public function copyTo(param1:§_-W1r§) : void
      {
         if(getPrice())
         {
            param1.§_-I1u§(§_-91e§(),§_-gc§());
         }
         if(comparator)
         {
            param1.comparator = comparator;
         }
         if(id)
         {
            param1.setId(id);
         }
         if(name)
         {
            param1.setName(name);
         }
         if(description)
         {
            param1.setDescription(description);
         }
         if(§_-r13§())
         {
            param1.§_-j1n§(§_-r13§());
         }
         if(this.§_-G3a§())
         {
            param1.§_-pV§(this.§_-G3a§());
         }
         if(this.menuIcon)
         {
            param1.§_-hM§(this.menuIcon);
         }
         if(this.alignMenuIcon)
         {
            param1.§_-K34§(true);
         }
         if(requiredFriends)
         {
            param1.§_-k12§(requiredFriends);
         }
         if(requiredLevel)
         {
            param1.§_-s2g§(requiredLevel);
         }
         if(requiredScenario)
         {
            param1.requiredScenario = requiredScenario;
         }
         if(hideInShop)
         {
            param1.§_-z1T§(hideInShop);
         }
         if(state)
         {
            param1.setState(state);
         }
         if(this.§_-3K§())
         {
            param1.§_-Zx§(this.§_-3K§());
         }
         if(this.duration)
         {
            param1.§_-4x§(this.duration);
         }
         if(this.infinite)
         {
            param1.§_-83i§(this.infinite);
         }
         if(this.§_-N2E§())
         {
            this._requiredRating = new §_-TA§(this.§_-N2E§());
         }
      }
   }
}


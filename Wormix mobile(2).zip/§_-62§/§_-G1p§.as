package §_-62§
{
   import §_-91B§.§_-z2l§;
   import §_-B1y§.§_-ts§;
   import §_-B2z§.*;
   import §_-Y1O§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-lD§;
   import §_-j22§.§_-5g§;
   import §_-z20§.§_-Tn§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import config.§_-V2w§;
   import feathers.controls.List;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import starling.display.Quad;
   
   public class §_-G1p§
   {
      
      private static var instance:§_-G1p§;
      
      private var weapons:Object = new Object();
      
      private var hats:Object = new Object();
      
      private var artifacts:Object = new Object();
      
      private var §_-K3m§:Object = new Object();
      
      private var §_-q1O§:Object = new Object();
      
      public function §_-G1p§()
      {
         super();
         instance = this;
      }
      
      public static function getInstance() : §_-G1p§
      {
         if(!instance)
         {
            instance = new §_-G1p§();
         }
         return instance;
      }
      
      public static function §_-O1b§(param1:int, param2:Boolean = false) : Array
      {
         var _loc4_:§_-O2H§ = null;
         var _loc5_:Object = null;
         var _loc6_:§_-zF§ = null;
         var _loc7_:Object = null;
         var _loc8_:§_-T1y§ = null;
         var _loc3_:Array = new Array();
         for each(_loc4_ in §_-S1n§())
         {
            if(_loc4_.§_-3K§() == param1 && !_loc4_.hideInShop && (param2 || !§_-61d§(_loc4_)))
            {
               _loc3_.push(_loc4_);
            }
         }
         _loc5_ = §_-P2Z§()[§_-lD§.§_-81B§];
         for each(_loc6_ in _loc5_)
         {
            if(_loc6_.§_-3K§() == param1 && !_loc6_.hideInShop && (param2 || !§_-61d§(_loc6_)))
            {
               _loc3_.push(_loc6_);
            }
         }
         _loc7_ = §_-x1a§();
         for each(_loc8_ in _loc7_)
         {
            if(_loc8_.§_-3K§() == param1 && !_loc8_.hideInShop && (param2 || !§_-61d§(_loc8_)))
            {
               _loc3_.push(_loc8_);
            }
         }
         return _loc3_;
      }
      
      public static function §_-61d§(param1:Object) : Boolean
      {
         var _loc4_:§_-O2H§ = null;
         var _loc5_:§_-O2H§ = null;
         var _loc6_:uint = 0;
         var _loc2_:Boolean = false;
         var _loc3_:UserProfile = Application.userProfile;
         if(param1)
         {
            _loc2_ = §_-X1j§.§_-zU§.§_-M1c§(param1 as §_-W1r§) || §_-Cq§.§_-33I§(param1.getId(),_loc3_) || Application.userProfile.§_-XT§().§_-H3E§(param1.getId());
            if(param1 is §_-O2H§)
            {
               var _temp_3:* = §_-O2H§(param1);
               _loc4_ = §_-O2H§(param1);
               if(!_loc4_.getInfinite())
               {
                  if(_loc4_.getRefId() > 0)
                  {
                     _loc5_ = §_-G1p§.§_-I4§(_loc4_.getRefId());
                     _loc2_ = §_-Cq§.§_-33I§(_loc5_.getId(),_loc3_) || §_-X1j§.§_-zU§.§_-M1c§(_loc5_);
                  }
                  else
                  {
                     _loc2_ = false;
                  }
               }
               if(!_loc2_ && !_loc4_.isComplex())
               {
                  _loc2_ = §_-Cq§.§_-33I§(param1.getId(),_loc3_);
               }
               if(_loc4_.isComplex())
               {
                  _loc6_ = §_-Cq§.§_-sj§(_loc4_.getId());
                  _loc2_ = _loc6_ == _loc4_.getMaxLevel();
               }
            }
         }
         return _loc2_;
      }
      
      public static function §_-S1n§() : Object
      {
         return §_-G1p§.getInstance().weapons;
      }
      
      public static function §_-n2G§() : Object
      {
         var _loc2_:String = null;
         var _loc3_:§_-O2H§ = null;
         var _loc1_:Object = {};
         for(_loc2_ in §_-S1n§())
         {
            _loc3_ = §_-O2H§(§_-S1n§()[_loc2_]);
            if(!_loc3_.getInfinite() && Boolean(_loc3_.§_-81c§()))
            {
               _loc1_[_loc2_] = _loc3_;
            }
         }
         return _loc1_;
      }
      
      public static function §_-I4§(param1:int) : §_-O2H§
      {
         return §_-G1p§.§_-S1n§()[param1];
      }
      
      public static function §_-a2h§() : void
      {
         var _loc1_:§_-O2H§ = null;
         for each(_loc1_ in §_-S1n§())
         {
            _loc1_.§_-5I§();
         }
      }
      
      public static function §_-X2k§(param1:§_-zF§) : void
      {
         if(!§_-G1p§.§_-P2Z§()[param1.getCharName()])
         {
            §_-G1p§.§_-P2Z§()[param1.getCharName()] = {};
         }
         §_-G1p§.§_-P2Z§()[param1.getCharName()][param1.getId()] = param1;
      }
      
      public static function §_-P2Z§() : Object
      {
         return §_-G1p§.getInstance().hats;
      }
      
      public static function §_-12J§(param1:int, param2:§_-B2i§) : §_-zF§
      {
         var _loc3_:§_-zF§ = null;
         if(!§_-V2w§.§_-q1F§(param1))
         {
            return null;
         }
         if(§_-G1p§.§_-P2Z§()[param2.configName])
         {
            _loc3_ = §_-G1p§.§_-P2Z§()[param2.configName][param1];
         }
         var _loc4_:Object = §_-G1p§.§_-P2Z§()[§_-lD§.§_-81B§];
         if(!_loc3_ && Boolean(_loc4_))
         {
            _loc3_ = _loc4_[param1];
         }
         return _loc3_;
      }
      
      public static function §_-D2Z§(param1:§_-B2i§) : Array
      {
         var _loc2_:Object = {};
         §_-ts§.§_-03w§(§_-G1p§.§_-P2Z§()[§_-lD§.§_-81B§],_loc2_);
         if(§_-G1p§.§_-P2Z§()[param1.configName])
         {
            §_-ts§.§_-03w§(§_-G1p§.§_-P2Z§()[param1.configName],_loc2_);
         }
         return §_-ts§.§_-z1M§(_loc2_);
      }
      
      public static function §_-x1a§() : Object
      {
         return §_-G1p§.getInstance().artifacts;
      }
      
      public static function §_-J2E§() : Vector.<§_-T1y§>
      {
         var _loc3_:String = null;
         var _loc1_:Vector.<§_-T1y§> = new Vector.<§_-T1y§>(0);
         var _loc2_:Object = §_-G1p§.getInstance().artifacts;
         for(_loc3_ in _loc2_)
         {
            if(!_loc2_[_loc3_].hideInShop)
            {
               _loc1_.push(_loc2_[_loc3_]);
            }
         }
         return _loc1_;
      }
      
      public static function §_-93G§(param1:int) : §_-T1y§
      {
         return §_-G1p§.§_-x1a§()[param1];
      }
      
      public static function §_-713§() : Object
      {
         return §_-G1p§.getInstance().§_-K3m§;
      }
      
      public static function §_-n2w§(param1:§_-B2i§) : Array
      {
         return §_-Jz§(param1,§_-z2l§.LEGENDARY);
      }
      
      public static function §_-62S§(param1:§_-B2i§) : Array
      {
         return §_-Jz§(param1,§_-z2l§.EPIC);
      }
      
      public static function §_-P1k§() : Array
      {
         return §_-L3F§(§_-z2l§.LEGENDARY);
      }
      
      public static function §_-Hm§() : Array
      {
         return §_-L3F§(§_-z2l§.EPIC);
      }
      
      public static function §_-Jz§(param1:§_-B2i§, param2:§_-z2l§) : Array
      {
         var _loc5_:String = null;
         var _loc6_:§_-zF§ = null;
         var _loc3_:Array = [];
         var _loc4_:Array = §_-D2Z§(param1);
         for(_loc5_ in _loc4_)
         {
            _loc6_ = §_-zF§(_loc4_[_loc5_]);
            if(_loc6_.§_-F2d§())
            {
               if(§_-Tn§.§_-31§(_loc6_.getId()))
               {
                  if(§_-2t§.§_-dK§(_loc6_.getId(),param2))
                  {
                     _loc3_.push(_loc4_[_loc5_]);
                  }
               }
            }
         }
         return _loc3_;
      }
      
      public static function §_-L3F§(param1:§_-z2l§) : Array
      {
         var _loc3_:String = null;
         var _loc4_:§_-T1y§ = null;
         var _loc2_:Array = [];
         for(_loc3_ in §_-G1p§.§_-x1a§())
         {
            _loc4_ = §_-T1y§(§_-G1p§.§_-x1a§()[_loc3_]);
            if(_loc4_.§_-F2d§())
            {
               if(§_-Tn§.§_-93k§(_loc4_.getId()))
               {
                  if(§_-2t§.§_-dK§(_loc4_.getId(),param1))
                  {
                     _loc2_.push(§_-G1p§.§_-x1a§()[_loc3_]);
                  }
               }
            }
         }
         return _loc2_;
      }
      
      public static function §_-d0§(param1:int, param2:§_-B2i§) : §_-W1r§
      {
         var _loc3_:§_-W1r§ = null;
         if(§_-V2w§.§_-13I§(param1))
         {
            _loc3_ = §_-I4§(param1);
         }
         else if(§_-V2w§.§_-q1F§(param1))
         {
            _loc3_ = §_-12J§(param1,param2);
         }
         else if(§_-V2w§.§_-Q2a§(param1))
         {
            _loc3_ = §_-93G§(param1);
         }
         return _loc3_;
      }
      
      public static function §_-M1n§() : Object
      {
         return §_-G1p§.getInstance().§_-q1O§;
      }
      
      public static function §_-T2l§(param1:int) : §_-a3§
      {
         return §_-G1p§.§_-M1n§()[param1];
      }
   }
}


package §_-62§
{
   import §_-21p§.§_-N1H§;
   import §_-TF§.§_-y2n§;
   import config.§_-B1K§;
   
   public class §_-T1y§ extends §_-L1r§
   {
      
      private var handFront:Boolean = true;
      
      private var handVisible:Boolean = true;
      
      public function §_-T1y§()
      {
         super(§_-N1H§.OFF_HAND);
      }
      
      override public function initFromConfig(param1:Object) : void
      {
         if(param1.handFront != null)
         {
            this.handFront = param1.handFront;
         }
         if(param1.handVisible != null)
         {
            this.handVisible = param1.handVisible;
         }
         super.initFromConfig(param1);
         §_-Zx§(§_-B1K§.ARTIFACT);
      }
      
      public function §_-rw§() : Boolean
      {
         return this.handFront;
      }
      
      public function §_-zp§() : Boolean
      {
         return this.handVisible;
      }
      
      override public function §_-n1W§() : int
      {
         return §_-y2n§.§_-03q§;
      }
   }
}


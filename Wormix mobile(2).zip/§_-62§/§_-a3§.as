package §_-62§
{
   import §_-YF§.§_-g2W§;
   import §_-p18§.§_-vd§;
   
   public class §_-a3§ implements §_-g2W§
   {
      
      private var id:int;
      
      private var §_-92X§:int;
      
      private var _name:String;
      
      private var §_-K3P§:String;
      
      private var §_-4F§:String;
      
      public function §_-a3§()
      {
         super();
      }
      
      public function getId() : int
      {
         return this.id;
      }
      
      public function initFromConfig(param1:Object) : void
      {
         this.id = param1.id;
         this.§_-92X§ = param1.quantity;
         this._name = param1.name;
         this.§_-K3P§ = param1.folderName;
         this.§_-4F§ = param1.productId;
      }
      
      public function §_-oz§() : String
      {
         var _loc1_:String = §_-vd§.§_-S11§() + "stickers/";
         return _loc1_ + this.§_-K3P§ + "/01.png";
      }
      
      public function §_-H3c§() : Array
      {
         var _loc2_:String = null;
         var _loc1_:String = §_-vd§.§_-S11§() + "stickers/" + this.§_-K3P§ + "/";
         var _loc3_:Array = [];
         var _loc4_:int = 1;
         while(_loc4_ <= this.§_-92X§)
         {
            _loc2_ = _loc4_ < 10 ? "0" + _loc4_.toString() : _loc4_.toString();
            _loc3_.push({
               "label":"",
               "id":_loc4_,
               "iconPath":_loc1_ + _loc2_ + ".png"
            });
            _loc4_++;
         }
         return _loc3_;
      }
      
      public function §_-3i§(param1:int) : String
      {
         var _loc2_:String = param1 < 10 ? "0" + param1.toString() : param1.toString();
         return §_-vd§.§_-S11§() + "stickers/" + this.§_-K3P§ + "/" + _loc2_ + ".png";
      }
      
      public function get quantity() : int
      {
         return this.§_-92X§;
      }
      
      public function set quantity(param1:int) : void
      {
         this.§_-92X§ = param1;
      }
      
      public function get folderName() : String
      {
         return this.§_-K3P§;
      }
      
      public function set folderName(param1:String) : void
      {
         this.§_-K3P§ = param1;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function set name(param1:String) : void
      {
         this._name = param1;
      }
      
      public function get productId() : String
      {
         return this.§_-4F§;
      }
      
      public function set productId(param1:String) : void
      {
         this.§_-4F§ = param1;
      }
   }
}


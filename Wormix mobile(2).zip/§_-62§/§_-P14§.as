package §_-62§
{
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-G2H§.*;
   import §_-T1o§.§_-L3M§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-P14§ extends §_-W1r§
   {
      
      public function §_-P14§()
      {
         super();
         setName(§_-s2a§.RESET_PARAMS_NAME);
         setDescription(§_-s2a§.RESET_PARAMS_DESC);
         §_-W0§(§_-4I§.§_-y1F§);
      }
      
      override public function §_-K2N§() : Boolean
      {
         return false;
      }
   }
}


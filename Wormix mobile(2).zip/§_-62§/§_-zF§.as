package §_-62§
{
   import §_-21p§.§_-N1H§;
   import §_-TF§.§_-y2n§;
   import §_-Vg§.§_-M11§;
   import §_-Vu§.MD5;
   import config.§_-B1K§;
   import feathers.controls.Button;
   import feathers.controls.ButtonGroup;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.layout.Direction;
   import feathers.layout.VerticalAlign;
   import feathers.skins.ImageSkin;
   import feathers.themes.styles.AlternateButtonsStyles;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-zF§ extends §_-L1r§
   {
      
      private static const §_-q14§:Array = ["Ears","Horn","Mouth"];
      
      private var §_-Em§:String;
      
      public var hideFeatures:Array;
      
      private var _scale:Number;
      
      public function §_-zF§()
      {
         super(§_-N1H§.HAT);
      }
      
      public static function §_-a18§() : Array
      {
         return §_-q14§;
      }
      
      override public function initFromConfig(param1:Object) : void
      {
         super.initFromConfig(param1);
         if(param1.charName)
         {
            this.§_-Em§ = param1.charName;
         }
         if(param1.scale)
         {
            this._scale = param1.scale;
         }
         if(param1.hideFeatures)
         {
            this.hideFeatures = param1.hideFeatures;
         }
         §_-Zx§(§_-B1K§.HAT);
         §_-83i§(true);
      }
      
      public function getCharName() : String
      {
         return this.§_-Em§;
      }
      
      public function getScale() : Number
      {
         return this._scale ? this._scale : 1;
      }
      
      public function §_-h1h§() : Array
      {
         return this.hideFeatures ? this.hideFeatures : [];
      }
      
      override public function §_-n1W§() : int
      {
         return §_-y2n§.§_-W1b§;
      }
      
      public function §_-83B§() : void
      {
      }
   }
}


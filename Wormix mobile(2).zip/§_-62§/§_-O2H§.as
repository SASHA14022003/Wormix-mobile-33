package §_-62§
{
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-DJ§.§_-J2l§;
   import §_-J3L§.§_-h1D§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-y1M§;
   import §_-QD§.§_-G2z§;
   import §_-TF§.§_-y2n§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Y1O§.§_-42h§;
   import §_-Z1K§.§_-q24§;
   import flash.utils.getDefinitionByName;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-L2i§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.render.ClipRenderer;
   import ru.pragmatix.wormix.weapons.render.GraphicsRenderer;
   
   public class §_-O2H§ extends §_-W1r§
   {
      
      private var §_-92L§:String;
      
      private var hint:String = "";
      
      private var §_-I25§:Class;
      
      private var refId:uint = 0;
      
      private var dropWeight:uint = 0;
      
      private var dropMinLevel:uint = 1;
      
      private var dropMaxLevel:uint = 30;
      
      private var render:Object = {};
      
      private var §_-23w§:Object = {};
      
      private var §_-63S§:String = "";
      
      public var §_-wF§:§_-C3e§;
      
      public var §_-E38§:§_-C3e§;
      
      private var weapon:Weapon;
      
      public var quantity:int = 0;
      
      public var bagX:uint;
      
      public var bagY:uint;
      
      private var maxShots:§_-TA§ = new §_-TA§(0);
      
      public var shotsPerTurn:§_-TA§ = new §_-TA§(1);
      
      private var §_-O18§:Boolean = false;
      
      public var firstShotDelay:int = -1;
      
      public var property:Object = {};
      
      public var §_-o2E§:§_-6S§;
      
      public var cooldown:int = -1;
      
      public function §_-O2H§()
      {
         super();
      }
      
      override public function initFromConfig(param1:Object) : void
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         var _loc4_:String = null;
         super.initFromConfig(param1);
         if(param1.refId)
         {
            this.§_-71s§(param1.refId);
         }
         if(Boolean(param1.bagX) && Boolean(param1.bagY))
         {
            this.§_-r1T§(param1.bagX,param1.bagY);
         }
         if(param1.dropWeight)
         {
            this.§_-33D§(param1.dropWeight);
         }
         if(param1.dropMinLevel)
         {
            this.§_-Ln§(param1.dropMinLevel);
         }
         if(param1.dropMaxLevel)
         {
            this.§_-31k§(param1.dropMaxLevel);
         }
         if(param1.quantity)
         {
            this.setQuantity(param1.quantity);
         }
         if(param1.maxdamage)
         {
            this.§_-s1H§(param1.maxdamage);
         }
         if(param1.hint)
         {
            this.hint = param1.hint;
         }
         if(param1.classname)
         {
            this.§_-F3W§(getDefinitionByName("ru.pragmatix.wormix.weapons." + param1.classname) as Class);
         }
         if(param1.render)
         {
            this.§_-73T§(param1.render,param1.render.secondaryClip);
         }
         if(param1.name)
         {
            this.§_-53N§(param1.name);
         }
         if(Boolean(param1.altOn) && Boolean(param1.altOff))
         {
            §_-W1S§(param1.altOn,param1.altOff);
         }
         if(param1.params)
         {
            if(!this.§_-wF§)
            {
               this.§_-wF§ = new §_-C3e§();
            }
            for(_loc2_ in param1.params)
            {
               this.§_-wF§[_loc2_] = param1.params[_loc2_];
            }
         }
         if(param1.secondaryParams)
         {
            if(!this.§_-E38§)
            {
               this.§_-E38§ = new §_-C3e§();
            }
            for(_loc3_ in param1.secondaryParams)
            {
               this.§_-E38§[_loc3_] = param1.secondaryParams[_loc3_];
            }
         }
         if(param1.infinite)
         {
            if(!(param1.infinite is Boolean))
            {
               this.§_-cD§(param1.infinite.maxShots);
            }
            else
            {
               this.§_-cD§(0);
            }
            this.setQuantity(-1);
         }
         if(param1.maxShots)
         {
            this.§_-cD§(param1.maxShots);
         }
         if(param1.shotsPerTurn)
         {
            this.shotsPerTurn.value = param1.shotsPerTurn;
         }
         if(param1.isComplex)
         {
            this.§_-O18§ = true;
         }
         if(param1.firstShotDelay)
         {
            this.firstShotDelay = param1.firstShotDelay;
         }
         if(param1.cooldown)
         {
            this.cooldown = param1.cooldown;
         }
         if(param1.property)
         {
            for(_loc4_ in param1.property)
            {
               this.property[_loc4_] = param1.property[_loc4_];
            }
         }
      }
      
      public function getRefId() : uint
      {
         return this.refId;
      }
      
      public function §_-71s§(param1:uint) : void
      {
         this.refId = param1;
      }
      
      public function §_-81c§() : uint
      {
         return this.dropWeight;
      }
      
      public function §_-33D§(param1:uint) : void
      {
         this.dropWeight = param1;
      }
      
      public function §_-M1y§() : uint
      {
         return this.dropMinLevel;
      }
      
      public function §_-Ln§(param1:uint) : void
      {
         this.dropMinLevel = param1;
      }
      
      public function §_-E1S§() : uint
      {
         return this.dropMaxLevel;
      }
      
      public function §_-31k§(param1:uint) : void
      {
         this.dropMaxLevel = param1;
      }
      
      public function §_-53N§(param1:String) : void
      {
         this.§_-63S§ = param1;
      }
      
      public function §_-hw§() : String
      {
         return this.§_-63S§;
      }
      
      public function §_-C33§() : String
      {
         return this.§_-92L§;
      }
      
      public function §_-s1H§(param1:String) : void
      {
         this.§_-92L§ = param1;
      }
      
      public function §_-W2T§() : Class
      {
         return this.§_-I25§;
      }
      
      public function §_-F3W§(param1:Class) : void
      {
         this.§_-I25§ = param1;
      }
      
      public function §_-01k§() : Object
      {
         return this.render;
      }
      
      public function §_-32c§() : Object
      {
         return this.§_-23w§;
      }
      
      public function §_-73T§(param1:Object, param2:Object) : void
      {
         this.render = §_-L2i§.§_-K15§(this.render,param1);
         this.§_-23w§ = §_-L2i§.§_-K15§(this.§_-23w§,param2);
      }
      
      public function §_-8I§() : String
      {
         return this.hint;
      }
      
      public function §_-U1G§(param1:String) : void
      {
         this.hint = param1;
      }
      
      public function getWeapon() : Weapon
      {
         if(this.weapon == null)
         {
            this.weapon = Weapon(new this.§_-I25§());
            if(this.property)
            {
               this.weapon.§_-z2Y§(this.property);
            }
            this.weapon.recordId = new §_-TA§(getId());
            this.weapon.§_-U1G§(this.hint);
            if(this.§_-wF§)
            {
               this.weapon.§_-d1P§(this.§_-wF§);
            }
            if(this.§_-E38§)
            {
               this.weapon.§_-B1G§(this.§_-E38§);
            }
            if(this.render.type == "clip")
            {
               this.weapon.§_-W18§(new ClipRenderer(this.weapon,§_-y1M§.§_-Z1i§(this.render)));
            }
            else if(this.render.type == "graphics")
            {
               this.weapon.§_-W18§(new GraphicsRenderer(this.render.action));
            }
            this.weapon.shots.value = this.shotsPerTurn.value;
         }
         return this.weapon;
      }
      
      public function §_-5I§() : void
      {
         this.weapon = null;
      }
      
      public function setQuantity(param1:int) : void
      {
         this.quantity = param1;
      }
      
      public function §_-8C§() : int
      {
         return this.quantity;
      }
      
      public function getMaxShots() : uint
      {
         return this.maxShots ? uint(this.maxShots.value) : 0;
      }
      
      public function getMaxLevel() : uint
      {
         return this.§_-O18§ ? uint(this.maxShots.value) : 1;
      }
      
      public function isComplex() : Boolean
      {
         return this.§_-O18§;
      }
      
      public function §_-cD§(param1:uint) : void
      {
         this.maxShots.value = param1;
         if(param1 > 6)
         {
            this.maxShots.value = §_-G1p§.§_-I4§(id).getMaxShots() > 6 ? 0 : int(§_-G1p§.§_-I4§(id).getMaxShots());
         }
      }
      
      public function §_-r1T§(param1:uint, param2:uint) : void
      {
         this.bagX = param1;
         this.bagY = param2;
      }
      
      public function §_-A2o§() : Boolean
      {
         return this.refId > 0;
      }
      
      override public function §_-n1W§() : int
      {
         return §_-y2n§.§_-91K§;
      }
      
      override public function get §_-kE§() : Boolean
      {
         return id == §_-q24§.§_-B1§ ? true : super.§_-kE§;
      }
      
      public function §_-m1k§() : String
      {
         if(this.firstShotDelay > 0)
         {
            return §_-s2a§.§_-K3t§(super.§_-p1§()).concat("\n",§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.FIRST_SHOT_DELAY),{"turn":this.firstShotDelay + 1}));
         }
         return §_-s2a§.§_-K3t§(super.§_-p1§());
      }
      
      public function clone() : §_-O2H§
      {
         var _loc1_:§_-O2H§ = new §_-O2H§();
         _loc1_.setId(getId());
         _loc1_.setName(getName());
         _loc1_.setDescription(§_-p1§());
         _loc1_.§_-j1n§(§_-r13§());
         _loc1_.§_-I1u§(getPrice().§_-R1T§,getPrice().realPrice);
         _loc1_.comparator = comparator;
         _loc1_.§_-k12§(§_-P1m§());
         _loc1_.§_-s2g§(§_-T1J§());
         _loc1_.§_-l17§(requiredScenario);
         _loc1_.§_-z1T§(§_-F2d§());
         _loc1_.setState(getState(),§_-ui§());
         _loc1_.§_-pV§(§_-G3a§());
         _loc1_.§_-hM§(§_-92P§());
         _loc1_.§_-W1S§(§_-V2D§(),§_-f2w§());
         _loc1_.§_-K34§(§_-Z2t§());
         _loc1_.§_-83i§(getInfinite());
         _loc1_.§_-s1H§(this.§_-C33§());
         _loc1_.§_-U1G§(this.§_-8I§());
         _loc1_.§_-F3W§(this.§_-W2T§());
         _loc1_.§_-71s§(this.getRefId());
         _loc1_.§_-33D§(this.§_-81c§());
         _loc1_.§_-Ln§(this.§_-M1y§());
         _loc1_.§_-31k§(this.§_-E1S§());
         _loc1_.§_-r1T§(this.bagX,this.bagY);
         _loc1_.§_-53N§(this.§_-hw§());
         _loc1_.setQuantity(this.§_-8C§());
         _loc1_.§_-cD§(this.getMaxShots());
         _loc1_.§_-O18§ = this.§_-O18§;
         _loc1_.shotsPerTurn.value = this.shotsPerTurn.value;
         _loc1_.firstShotDelay = this.firstShotDelay;
         _loc1_.cooldown = this.cooldown;
         _loc1_.§_-wF§ = this.§_-wF§ ? this.§_-wF§.clone() : null;
         _loc1_.§_-E38§ = this.§_-E38§ ? this.§_-E38§.clone() : null;
         _loc1_.§_-73T§(§_-L2i§.§_-P2u§(this.§_-01k§()),§_-L2i§.§_-P2u§(this.§_-32c§()));
         _loc1_.property = §_-L2i§.§_-N1j§(this.property);
         return _loc1_;
      }
   }
}


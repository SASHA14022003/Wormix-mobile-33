package §_-62§
{
   import §_-C3f§.§_-4I§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   
   public class §_-Q2c§ extends §_-W1r§
   {
      
      public function §_-Q2c§()
      {
         super();
         setName(§_-s2a§.REACTION_QTIP);
         setDescription(§_-s2a§.REACTION_DESCRIPTION);
         §_-hM§("ReactionIcon");
         §_-W0§(§_-4I§.REACTION);
      }
      
      override public function §_-K2N§() : Boolean
      {
         return true;
      }
   }
}


package §_-k1u§
{
   import §_-23P§.§_-V2T§;
   import §_-31N§.§_-42G§;
   import §_-31W§.*;
   import §_-31Y§.§_-D3B§;
   import §_-52V§.§_-R9§;
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-ts§;
   import §_-Cl§.§_-L2z§;
   import §_-Ly§.§_-81L§;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-yA§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.*;
   import §_-b1F§.§_-H3Z§;
   import §_-b1F§.§_-v2Q§;
   import §_-bI§.*;
   import §_-g2r§.§_-03A§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-y1s§.§_-P9§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.core.LoaderCore;
   import feathers.controls.List;
   import feathers.core.ITextRenderer;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.flox.social.post.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.scene.ObjectType;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorArcher;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorDefender;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorGeneral;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorSpearman;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorTerracottaWarrior;
   import starling.display.Button;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-by§ extends §_-H2M§
   {
      
      private var §_-d1o§:Object = new Object();
      
      public function §_-by§()
      {
         super();
      }
      
      public function §_-l2e§(param1:§_-W1r§, param2:int = -1, param3:Boolean = false, param4:int = 0) : §_-Oi§
      {
         var _loc6_:int = 0;
         var _loc5_:§_-Oi§ = §_-Um§(param1);
         if(param2 != -1 && !param3)
         {
            this.§_-d1o§[param1.getId()] = param2;
         }
         else if(param1.§_-x1n§() > 0)
         {
            _loc6_ = param3 && param2 > -1 ? param2 : int(int(new Date().getTime() / 1000));
            this.§_-d1o§[param1.getId()] = _loc6_ + (param4 || param1.§_-x1n§()) * §_-72u§.§_-03d§;
         }
         return _loc5_;
      }
      
      override public function removeItem(param1:int, param2:int = -1) : void
      {
         var _loc3_:UserProfile = null;
         super.removeItem(param1);
         if(this.§_-G1B§(param1))
         {
            delete this.§_-d1o§[param1];
         }
         for each(_loc3_ in Application.userProfile.§_-A1U§())
         {
            if(Boolean(_loc3_.getHat()) && _loc3_.getHat().getId() == param1)
            {
               _loc3_.§_-L§(null);
            }
            if(Boolean(_loc3_.§_-32q§()) && _loc3_.§_-32q§().getId() == param1)
            {
               _loc3_.§_-aV§(null);
            }
            if(_loc3_.§_-t2I§() == §_-yA§.§_-e2e§)
            {
               §_-V2T§.§_-N1o§(_loc3_);
            }
         }
      }
      
      public function §_-q2X§(param1:int) : void
      {
         super.removeItem(param1);
         if(this.§_-G1B§(param1))
         {
            delete this.§_-d1o§[param1];
         }
      }
      
      public function §_-n2k§(param1:int) : int
      {
         var _loc2_:int = -1;
         if(this.§_-G1B§(param1))
         {
            _loc2_ = int(this.§_-d1o§[param1]);
         }
         return _loc2_;
      }
      
      public function §_-G1B§(param1:int) : Boolean
      {
         return this.§_-d1o§[param1] != null;
      }
   }
}


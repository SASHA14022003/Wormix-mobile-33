package §_-k1u§
{
   import §_-21p§.§_-4w§;
   import §_-23P§.§_-u1z§;
   import §_-31N§.§_-Yy§;
   import §_-31W§.*;
   import §_-5Y§.§_-Ma§;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-73d§.§_-pT§;
   import §_-9§.§_-52A§;
   import §_-931§.*;
   import §_-A1K§.§_-TA§;
   import §_-A1m§.*;
   import §_-Af§.*;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-02k§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-D14§;
   import §_-H3§.*;
   import §_-J31§.§_-e2J§;
   import §_-K35§.§_-S18§;
   import §_-L1H§.§_-C3e§;
   import §_-N8§.§_-2C§;
   import §_-R2S§.*;
   import §_-SP§.§_-j1f§;
   import §_-T1t§.§_-u19§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-22N§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-M6§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-Bx§;
   import §_-g2r§.§_-03A§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-m1g§.§_-K2W§;
   import §_-q11§.§_-C2n§;
   import §_-qH§.§_-S25§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.*;
   import §_-sQ§.§_-737§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2i§.*;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-82X§;
   import §_-z20§.*;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import flash.display.DisplayObject;
   import flash.events.TimerEvent;
   import flash.geom.Rectangle;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.controller.ICustomInviter;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.§_-P1h§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.ListClansResponse;
   import ru.pragmatix.wormix.messages.client.EndTurn;
   import ru.pragmatix.wormix.messages.client.GetRating;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CancelBattle;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-F3H§ extends §_-2m§
   {
      
      public static const §_-Bw§:uint = 4;
      
      protected var §_-u1f§:Object = new Object();
      
      public function §_-F3H§()
      {
         super();
      }
      
      public function §_-L30§() : Object
      {
         return this.§_-u1f§;
      }
      
      public function §_-b1r§() : Boolean
      {
         return this.§_-84§() < §_-Bw§;
      }
      
      public function §_-J3H§(param1:§_-O2H§, param2:int = -1, param3:uint = 0) : void
      {
         var _loc4_:§_-Oi§ = null;
         var _loc5_:int = 0;
         if(this.§_-u1f§[param1.getId()])
         {
            _loc4_ = §_-Oi§(this.§_-u1f§[param1.getId()]);
            _loc5_ = _loc4_.getCount() + param2;
            §_-Oi§(this.§_-u1f§[param1.getId()]).setCount(param2 < 0 ? 0 : param2);
            _loc4_.setCount(_loc5_ < 0 ? 0 : _loc5_);
         }
         else if(!this.isFull())
         {
            _loc4_ = new §_-Oi§(param1,param2,param3);
            _loc4_.§_-s1k§ = true;
            this.§_-u1f§[_loc4_.getId()] = _loc4_;
         }
         _loc4_.§_-s2V§();
      }
      
      public function §_-84§() : uint
      {
         var _loc2_:§_-Oi§ = null;
         var _loc1_:uint = 0;
         for each(_loc2_ in this.§_-u1f§)
         {
            _loc1_++;
         }
         return _loc1_;
      }
      
      public function isFull() : Boolean
      {
         return this.§_-84§() >= §_-Bw§;
      }
      
      public function reset() : void
      {
         var _loc1_:Boolean = Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.§_-WN§()) ? §_-X1j§.§_-12n§.§_-WN§().battleType == §_-81M§.§_-p1U§ : true;
         this.§_-a2h§(deposit,_loc1_);
         this.§_-u1f§ = {};
      }
      
      private function §_-a2h§(param1:Object, param2:Boolean) : void
      {
         var _loc3_:§_-Oi§ = null;
         for each(_loc3_ in param1)
         {
            this.§_-5I§(_loc3_,param2);
         }
      }
      
      private function §_-5I§(param1:§_-Oi§, param2:Boolean) : void
      {
         if(§_-O2H§(param1.getRecord()).getMaxShots())
         {
            param1.§_-j1l§();
         }
         if(!param1.isInfinite())
         {
            param1.reset(param2);
         }
         if(param1.getCount() != 0)
         {
            param1.§_-s2V§();
         }
         else
         {
            delete deposit[param1.getId()];
         }
      }
      
      override public function §_-d0§(param1:int) : §_-Oi§
      {
         var _loc3_:§_-Oi§ = null;
         var _loc2_:§_-Oi§ = super.§_-d0§(param1);
         if(!_loc2_)
         {
            for each(_loc3_ in this.§_-u1f§)
            {
               if(_loc3_.getId() == param1)
               {
                  return _loc3_;
               }
            }
            return null;
         }
         return _loc2_;
      }
      
      public function §_-Z2g§(param1:int) : void
      {
         var _loc3_:§_-O2H§ = null;
         var _loc2_:§_-Oi§ = this.§_-d0§(param1);
         if(_loc2_)
         {
            _loc3_ = §_-O2H§(_loc2_.getRecord());
            if(!_loc2_.isInfinite() || _loc3_.getMaxShots() > 0)
            {
               _loc2_.§_-A1G§();
               if(_loc2_.isEmpty())
               {
                  delete this.§_-u1f§[_loc2_.getId()];
               }
            }
         }
      }
      
      public function §_-C3w§(param1:int) : void
      {
         var _loc2_:§_-Oi§ = this.§_-d0§(param1);
         if(_loc2_)
         {
            if(!_loc2_.isInfinite() || _loc2_.getMaxShots() > 0)
            {
               _loc2_.§_-2a§();
            }
         }
         else if(param1 >= §_-M6§.§_-H24§)
         {
            this.§_-J3H§(§_-G1p§.§_-I4§(param1),1);
         }
      }
      
      override public function §_-d3§(param1:int) : int
      {
         var _loc2_:int = super.§_-d3§(param1);
         if(_loc2_ == 0)
         {
            _loc2_ = this.§_-u1f§[param1] ? §_-Oi§(this.§_-u1f§[param1]).getCount() : 0;
         }
         return _loc2_;
      }
      
      public function §_-A2v§() : void
      {
         var _loc1_:§_-Oi§ = null;
         for each(_loc1_ in deposit)
         {
            _loc1_.§_-D3T§();
         }
         for each(_loc1_ in this.§_-u1f§)
         {
            _loc1_.§_-D3T§();
         }
      }
      
      public function §_-J2v§() : void
      {
         var _loc1_:§_-Oi§ = null;
         for each(_loc1_ in §_-O2Z§())
         {
            if(!_loc1_.isInfinite() && Boolean(_loc1_.getCount()))
            {
               _loc1_.§_-42L§();
            }
         }
      }
      
      public function §_-9x§() : void
      {
         var _loc2_:§_-Oi§ = null;
         var _loc3_:int = 0;
         var _loc1_:Array = [];
         for each(_loc2_ in deposit)
         {
            if(_loc2_.getCount() == 0)
            {
               _loc1_.push(_loc2_.getId());
            }
         }
         for each(_loc3_ in _loc1_)
         {
            delete deposit[_loc3_];
         }
      }
      
      override public function clone() : §_-H2M§
      {
         var _loc2_:§_-Oi§ = null;
         var _loc1_:§_-F3H§ = new §_-F3H§();
         for each(_loc2_ in §_-P2l§())
         {
            _loc1_.§_-Um§(_loc2_.getRecord(),_loc2_.getCount(),_loc2_.getMaxShots());
         }
         return _loc1_;
      }
   }
}


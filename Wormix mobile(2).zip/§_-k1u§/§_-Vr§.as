package §_-k1u§
{
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-CR§.§_-S2o§;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-C3e§;
   import §_-RE§.§_-qW§;
   import §_-SP§.§_-M4§;
   import §_-TF§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-f1Q§.*;
   import §_-j1w§.§_-L1x§;
   import §_-jF§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-v2t§.§_-73F§;
   import §_-w2i§.§_-Zd§;
   import com.hurlant.math.*;
   import feathers.controls.ScrollPolicy;
   import feathers.data.VectorCollection;
   import feathers.events.FeathersEventType;
   import flash.events.Event;
   import flash.geom.Point;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-P1h§;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.QuitClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.ChargingBullet;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.TouchEvent;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class §_-Vr§ extends §_-H2M§
   {
      
      public function §_-Vr§()
      {
         super();
      }
      
      public function §_-O2n§(param1:int, param2:UserProfile) : §_-Oi§
      {
         var _loc3_:§_-Oi§ = §_-d0§(param1);
         if(this.§_-h2S§(_loc3_,param2))
         {
            return _loc3_;
         }
         return null;
      }
      
      public function §_-h2S§(param1:§_-Oi§, param2:UserProfile) : Boolean
      {
         return Boolean(param1) && param1.getRecord().§_-T1J§() <= param2.getLevel();
      }
      
      override public function clone() : §_-H2M§
      {
         var _loc3_:§_-Oi§ = null;
         var _loc1_:§_-Vr§ = new §_-Vr§();
         var _loc2_:Array = §_-P2l§();
         for each(_loc3_ in _loc2_)
         {
            _loc1_.§_-Um§(_loc3_.getRecord(),_loc3_.getCount(),_loc3_.getMaxShots(),_loc3_.getLevel());
         }
         return _loc1_;
      }
      
      override public function §_-Um§(param1:§_-W1r§, param2:int = -1, param3:uint = 0, param4:uint = 1) : §_-Oi§
      {
         var _temp_1:* = super.§_-Um§(param1,param2,param3,param4);
         var _loc5_:§_-Oi§ = super.§_-Um§(param1,param2,param3,param4);
         if(_loc5_)
         {
            if(param2 < 0 && _loc5_.getCount() != param2)
            {
               _loc5_.setCount(param2);
            }
         }
         return _loc5_;
      }
   }
}


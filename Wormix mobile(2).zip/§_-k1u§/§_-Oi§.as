package §_-k1u§
{
   import §_-12W§.*;
   import §_-12a§.§_-G2l§;
   import §_-21p§.§_-4w§;
   import §_-23P§.*;
   import §_-52L§.§_-u2x§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-ou§;
   import §_-62§.§_-zF§;
   import §_-63U§.§_-412§;
   import §_-73d§.§_-v1o§;
   import §_-82a§.*;
   import §_-82l§.§_-A2Y§;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2F§.§_-4B§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.*;
   import §_-Bv§.§_-G3P§;
   import §_-CF§.*;
   import §_-CR§.§_-S2o§;
   import §_-Cl§.*;
   import §_-DJ§.*;
   import §_-G2H§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1b§.*;
   import §_-Yk§.§_-m2w§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-Z2S§.§_-b8§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-f1G§.§_-kf§;
   import §_-fo§.§_-21L§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.§_-03k§;
   import §_-hO§.§_-y2Z§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-d2j§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-sQ§.§_-H3D§;
   import §_-sQ§.§_-V1n§;
   import §_-u1F§.§_-SE§;
   import §_-u2J§.§_-T1K§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.*;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.ToggleButton;
   import feathers.data.ListCollection;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.media.Sound;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.as3commons.zip.§_-61c§;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.ISocialPaymentController;
   import ru.pragmatix.flox.social.controller.mobile.*;
   import ru.pragmatix.flox.social.model.IUserProfile;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.PumpReactionRate;
   import ru.pragmatix.wormix.messages.client.SetLocale;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-i14§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Jetpack;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.AtomBomb;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.phase.PoisonPhase;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import ru.pragmatix.wormix.weapons.interfaces.§_-jm§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   use namespace gestouch_internal;
   
   public class §_-Oi§
   {
      
      private var record:§_-W1r§;
      
      private var itemId:int;
      
      private var count:§_-TA§;
      
      private var §_-S1B§:int;
      
      private var §_-N2g§:§_-TA§;
      
      private var maxShots:§_-TA§;
      
      private var shotsLeft:§_-TA§ = new §_-TA§(-1);
      
      private var delay:int = -1;
      
      private var level:uint = 1;
      
      private var maxLevel:uint = 1;
      
      private var §_-u2P§:Boolean = false;
      
      public function §_-Oi§(param1:§_-W1r§, param2:int, param3:int)
      {
         super();
         this.record = param1;
         this.itemId = param1.getId();
         this.count = new §_-TA§(param2);
         this.§_-S1B§ = param2;
         this.§_-N2g§ = new §_-TA§(0);
         this.maxShots = new §_-TA§(param3);
         if(param3 > 0)
         {
            this.shotsLeft.value = param3;
         }
      }
      
      public function getRecord() : §_-W1r§
      {
         return this.record;
      }
      
      public function getId() : int
      {
         return this.itemId;
      }
      
      public function isInfinite() : Boolean
      {
         return this.count.value == -1;
      }
      
      public function §_-n1u§() : Boolean
      {
         return this.count.value == -1 && this.maxLevel == this.level;
      }
      
      public function getMaxShots() : int
      {
         return this.maxShots.value;
      }
      
      public function §_-l3§() : int
      {
         return this.shotsLeft.value;
      }
      
      public function §_-j1l§() : void
      {
         this.shotsLeft.value = this.maxShots.value;
      }
      
      public function isEmpty() : Boolean
      {
         return this.shotsLeft.value == 0 || this.count.value == 0;
      }
      
      public function getCount() : int
      {
         if(this.count.value != this.§_-S1B§)
         {
            if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.scene))
            {
               §_-X1j§.§_-12n§.scene.dispatchEvent(new §_-H1K§(§_-A2V§.§_-A2e§,"item quantity hacked"));
            }
            else
            {
               Application.§_-i1N§.dispatchEvent(new §_-H1K§(§_-A2V§.§_-A2e§,"item quantity hacked"));
            }
         }
         return this.count.value;
      }
      
      public function setCount(param1:int) : void
      {
         this.count.value = param1;
         this.§_-S1B§ = param1;
      }
      
      public function §_-A1G§() : void
      {
         if(this.count.value > 0)
         {
            --this.count.value;
            --this.§_-S1B§;
         }
         if(this.shotsLeft.value > 0)
         {
            --this.shotsLeft.value;
         }
      }
      
      public function §_-2a§() : void
      {
         if(!this.isInfinite())
         {
            ++this.count.value;
            var _temp_2:* = this;
            ++this.§_-S1B§;
         }
         if(this.shotsLeft.value != -1)
         {
            ++this.shotsLeft.value;
         }
      }
      
      public function §_-42L§() : void
      {
         if(this.§_-N2g§.value == 0)
         {
            this.§_-N2g§.value = this.count.value;
         }
      }
      
      public function reset(param1:Boolean) : void
      {
         if(param1 && this.§_-N2g§.value != 0)
         {
            this.count.value = this.§_-N2g§.value;
            this.§_-S1B§ = this.§_-N2g§.value;
            this.§_-N2g§.value = 0;
         }
      }
      
      public function §_-s2V§() : void
      {
         var _loc1_:int = 0;
         if(this.record is §_-O2H§)
         {
            _loc1_ = 0;
            if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.gameMaster))
            {
               _loc1_ = int(§_-X1j§.§_-12n§.gameMaster.§_-82g§());
            }
            this.delay = Math.max(-1,§_-O2H§(this.record).firstShotDelay - _loc1_);
         }
      }
      
      public function §_-v2K§() : void
      {
         if(this.record is §_-O2H§)
         {
            this.delay = §_-O2H§(this.record).cooldown;
         }
      }
      
      public function §_-D3T§() : void
      {
         if(this.delay >= 0)
         {
            --this.delay;
         }
      }
      
      public function §_-d1q§() : int
      {
         return this.delay;
      }
      
      public function get §_-L19§() : Boolean
      {
         return this.delay != -1 && !§_-X1j§.§_-12n§.§_-WN§().§_-733§;
      }
      
      public function getMaxLevel() : uint
      {
         return this.maxLevel;
      }
      
      public function getLevel() : uint
      {
         return this.level;
      }
      
      public function §_-41K§(param1:uint, param2:uint) : void
      {
         this.level = Math.min(param1,param2);
         this.maxLevel = param2;
         if(this.maxShots.value != 0 && this.record is §_-O2H§ && §_-O2H§(this.record).isComplex())
         {
            this.maxShots.value = param1;
         }
      }
      
      public function get §_-s1k§() : Boolean
      {
         return this.§_-u2P§;
      }
      
      public function set §_-s1k§(param1:Boolean) : void
      {
         this.§_-u2P§ = param1;
      }
   }
}


package §_-k1u§
{
   import §_-21p§.§_-4w§;
   import §_-62§.*;
   import §_-82l§.§_-1I§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B2z§.§_-63i§;
   import §_-O2L§.§_-C3d§;
   import §_-O2L§.§_-X1T§;
   import §_-RE§.§_-52p§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-XA§;
   import §_-Y1O§.§_-V23§;
   import §_-g1P§.§_-L38§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-oq§.§_-c1o§;
   import §_-r1C§.*;
   import §_-rM§.§_-61j§;
   import §_-z1g§.§_-F4§;
   import com.distriqt.extension.pushnotifications.PushNotifications;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import flash.display.*;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.menu.*;
   import ru.pragmatix.wormix.messages.client.*;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class §_-2m§ extends §_-H2M§
   {
      
      public function §_-2m§()
      {
         super();
      }
      
      override public function §_-Um§(param1:§_-W1r§, param2:int = -1, param3:uint = 0, param4:uint = 1) : §_-Oi§
      {
         var _loc5_:§_-Oi§ = null;
         var _loc6_:§_-O2H§ = null;
         var _loc7_:§_-Oi§ = null;
         if(Boolean(param1) && param1 is §_-O2H§)
         {
            _loc6_ = param1 as §_-O2H§;
            if(_loc6_.getRefId() != 0 && param2 == 0)
            {
               return null;
            }
            if(_loc6_.getRefId() != 0)
            {
               for each(_loc5_ in deposit)
               {
                  if(_loc6_.getRefId() == _loc5_.getId())
                  {
                     return null;
                  }
               }
            }
            else if(_loc6_.getInfinite())
            {
               for each(_loc5_ in deposit)
               {
                  if(!_loc5_.isInfinite() && §_-O2H§(_loc5_.getRecord()).getRefId() == _loc6_.getId())
                  {
                     removeItem(_loc5_.getId());
                  }
               }
            }
            if(§_-O2Z§()[_loc6_.getId()])
            {
               removeItem(_loc6_.getId(),-1);
            }
            _loc7_ = super.§_-Um§(param1,param2,param3,param4);
            _loc7_.§_-s2V§();
            return _loc7_;
         }
         return null;
      }
      
      override public function §_-P2l§() : Array
      {
         var _loc2_:§_-Oi§ = null;
         var _loc1_:Array = [];
         for each(_loc2_ in deposit)
         {
            _loc1_.push(_loc2_);
         }
         _loc1_.sort(§_-D2F§);
         return _loc1_;
      }
      
      public function §_-4Y§(param1:int) : int
      {
         var _loc2_:§_-Oi§ = §_-d0§(param1);
         var _loc3_:int = _loc2_ ? _loc2_.getCount() : 0;
         if(_loc3_ == -1)
         {
            _loc3_ = _loc2_.§_-l3§();
         }
         else if(_loc3_ > 0)
         {
            if(_loc2_.§_-l3§() >= 0)
            {
               _loc3_ = int(Math.min(_loc3_,_loc2_.§_-l3§()));
            }
         }
         return _loc3_;
      }
      
      public function §_-DR§(param1:int) : Boolean
      {
         var _loc2_:§_-Oi§ = §_-d0§(param1);
         return this.§_-4Y§(param1) != 0 && !_loc2_.§_-L19§;
      }
      
      public function §_-n25§(param1:Array) : void
      {
         var _loc2_:WeaponStructure = null;
         var _loc3_:§_-Oi§ = null;
         var _loc4_:§_-O2H§ = null;
         for each(_loc2_ in param1)
         {
            _loc3_ = §_-d0§(_loc2_.getId());
            if(_loc3_)
            {
               _loc4_ = §_-O2H§(_loc3_.getRecord());
               if(!_loc3_.isInfinite() || _loc4_.getMaxShots() > 0)
               {
                  _loc3_.setCount(_loc3_.getCount() - _loc2_.getCount());
                  if(_loc3_.isEmpty())
                  {
                     delete deposit[_loc3_.getId()];
                  }
               }
            }
         }
      }
      
      override public function clone() : §_-H2M§
      {
         var _loc2_:§_-Oi§ = null;
         var _loc1_:§_-2m§ = new §_-2m§();
         for each(_loc2_ in this.§_-P2l§())
         {
            _loc1_.§_-Um§(_loc2_.getRecord(),_loc2_.getCount(),_loc2_.getMaxShots(),_loc2_.getLevel());
         }
         return _loc1_;
      }
   }
}


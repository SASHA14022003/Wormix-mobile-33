package §_-k1u§
{
   import §_-2U§.Alchemist;
   import §_-2U§.AncientGhost;
   import §_-2U§.Archbot;
   import §_-2U§.Assassin;
   import §_-2U§.DarkKnight;
   import §_-2U§.Emperor;
   import §_-2U§.Engineer;
   import §_-2U§.Scientist;
   import §_-2U§.Symbiote;
   import §_-2U§.Yakuza;
   import §_-2U§.§_-217§;
   import §_-2U§.§_-cH§;
   import §_-2U§.§_-d1J§;
   import §_-2U§.§_-t2u§;
   import §_-31W§.*;
   import §_-3D§.§_-E3x§;
   import §_-3D§.§_-a2b§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-Z1Y§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-E29§.*;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-D2p§;
   import §_-N8§.§_-o2w§;
   import §_-O2L§.§_-13p§;
   import §_-P1z§.§_-Cc§;
   import §_-P1z§.§_-E2z§;
   import §_-P1z§.§_-L1s§;
   import §_-P1z§.§_-j2E§;
   import §_-P1z§.§_-k2X§;
   import §_-P2i§.§_-b7§;
   import §_-R2S§.Farmer;
   import §_-R2S§.Hunter;
   import §_-R2S§.Maniacs;
   import §_-R2S§.Miner;
   import §_-R2S§.Sergeant;
   import §_-R2S§.§_-M2x§;
   import §_-R2S§.§_-P1U§;
   import §_-R2S§.§_-z2x§;
   import §_-RE§.*;
   import §_-T1t§.§_-P1F§;
   import §_-Ub§.Vikings;
   import §_-Ub§.VoodooShaman;
   import §_-Ub§.WindMaster;
   import §_-Ub§.§_-W1E§;
   import §_-Ub§.§_-v1t§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-w1D§;
   import §_-ZB§.§_-A10§;
   import §_-aM§.*;
   import §_-fo§.*;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-e1k§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1g§.§_-F1X§;
   import §_-l1g§.§_-L3Q§;
   import §_-nE§.DowngradeCraftWeaponScreen;
   import §_-nE§.InfoCraftWeaponScreen;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.UpgradeCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-sQ§.§_-H3D§;
   import §_-u1T§.§_-33B§;
   import §_-w2i§.§_-Ia§;
   import §_-wD§.*;
   import §_-y1s§.*;
   import §_-z1g§.§_-y1S§;
   import §_-z20§.§_-I3q§;
   import §_-z20§.§_-pl§;
   import §_-z2S§.SafeAreaUtils;
   import com.greensock.*;
   import com.greensock.core.*;
   import config.§_-V2w§;
   import feathers.controls.GroupedList;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.Scroller;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.DisplayObject;
   import flash.errors.IllegalOperationError;
   import flash.events.FullScreenEvent;
   import flash.events.TimerEvent;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.DowngradeWeapon;
   import ru.pragmatix.wormix.messages.server.IncreaseAchievementResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.§_-kQ§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.LaserLineAmmoController;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-52D§ extends EventDispatcher
   {
      
      private var §_-21O§:Array = [];
      
      private var §_-z2P§:Array = [];
      
      private var §_-y2X§:Array = [];
      
      public function §_-52D§()
      {
         super();
      }
      
      public function §_-dQ§(param1:§_-A10§) : void
      {
         var _loc2_:int = 0;
         for each(_loc2_ in param1.§_-A1w§())
         {
            this.§_-Um§(_loc2_);
         }
      }
      
      public function §_-V2R§(param1:UserProfileStructure) : void
      {
         var _loc2_:int = 0;
         for each(_loc2_ in param1.stuff)
         {
            this.§_-Um§(_loc2_);
         }
         for each(_loc2_ in param1.rentedItems.stuff)
         {
            if(§_-V2w§.§_-613§(_loc2_))
            {
               this.§_-z2P§.push(_loc2_);
               this.§_-LV§(_loc2_);
            }
         }
         dispatchEventWith(Event.CHANGE,false,this.§_-y2X§);
      }
      
      public function §_-Um§(param1:int) : void
      {
         if(§_-V2w§.§_-613§(param1) && this.§_-21O§.indexOf(param1) == -1)
         {
            this.§_-21O§.push(param1);
            this.§_-LV§(param1);
         }
         dispatchEventWith(Event.CHANGE,false,this.§_-y2X§);
      }
      
      public function §_-j2Q§(param1:Array) : void
      {
         var _loc3_:int = 0;
         var _loc2_:uint = uint(param1.length);
         var _loc4_:int = 0;
         while(_loc4_ < _loc2_)
         {
            _loc3_ = int(param1[_loc4_]);
            if(§_-V2w§.§_-613§(_loc3_) && this.§_-z2P§.indexOf(_loc3_) == -1)
            {
               this.§_-z2P§.push(_loc3_);
               this.§_-LV§(_loc3_);
            }
            _loc4_++;
         }
         dispatchEventWith(Event.CHANGE,false,this.§_-y2X§);
      }
      
      public function §_-b2q§() : void
      {
         var _loc1_:int = 0;
         this.§_-z2P§.splice(0,this.§_-z2P§.length);
         this.§_-y2X§.splice(0,this.§_-y2X§.length);
         for each(_loc1_ in this.§_-21O§)
         {
            this.§_-y2X§.push(_loc1_);
         }
         dispatchEventWith(Event.CHANGE,false,this.§_-y2X§);
      }
      
      public function §_-C11§() : Array
      {
         return this.§_-y2X§;
      }
      
      public function §_-O29§() : Array
      {
         return this.§_-21O§;
      }
      
      private function §_-LV§(param1:int) : void
      {
         if(this.§_-y2X§.indexOf(param1) == -1)
         {
            this.§_-y2X§.push(param1);
         }
         dispatchEventWith(Event.CHANGE,false,this.§_-y2X§);
      }
   }
}


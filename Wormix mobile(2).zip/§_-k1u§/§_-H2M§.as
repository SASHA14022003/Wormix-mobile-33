package §_-k1u§
{
   import §_-62§.*;
   import §_-73d§.§_-V19§;
   import §_-82a§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-ts§;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-E19§;
   import §_-Cl§.*;
   import §_-P2i§.§_-b7§;
   import §_-TF§.§_-F1B§;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.BuyVipDialog;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-Y1O§.*;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-hO§.§_-y2Z§;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-N1Z§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-H3D§;
   import §_-sQ§.§_-V1n§;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-lp§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.math.*;
   import feathers.controls.*;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.*;
   import feathers.layout.*;
   import flash.display.BitmapData;
   import flash.events.*;
   import flash.geom.Point;
   import flash.media.SoundMixer;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.clearInterval;
   import ru.pragmatix.flox.social.controller.mobile.BaseMobileSocialController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.desktop.*;
   import ru.pragmatix.wormix.messages.clans.*;
   import ru.pragmatix.wormix.messages.clans.request.ListClansRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.BuyReactionRate;
   import ru.pragmatix.wormix.messages.client.PostToChat;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.BossWormStructure;
   import ru.pragmatix.wormix.messages.structures.SimpleProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.utils.Align;
   import starling.utils.Color;
   import starlingbuilder.extensions.uicomponents.CustomLabel;
   
   use namespace bi_internal;
   
   public class §_-H2M§
   {
      
      protected var deposit:Object = new Object();
      
      public function §_-H2M§()
      {
         super();
      }
      
      public function §_-Um§(param1:§_-W1r§, param2:int = -1, param3:uint = 0, param4:uint = 1) : §_-Oi§
      {
         var _loc5_:§_-Oi§ = null;
         var _loc6_:uint = 0;
         if(param1)
         {
            if(this.deposit[param1.getId()])
            {
               _loc5_ = §_-Oi§(this.deposit[param1.getId()]);
               _loc5_.setCount(param2 < 0 ? 0 : int(param2 + _loc5_.getCount()));
            }
            else
            {
               if(param3 > 6)
               {
                  param3 = §_-G1p§.§_-I4§(param1.getId()).getMaxShots() > 6 ? 0 : §_-G1p§.§_-I4§(param1.getId()).getMaxShots();
               }
               _loc5_ = new §_-Oi§(param1,param2,param3);
               this.deposit[param1.getId()] = _loc5_;
            }
            _loc6_ = 1;
            if(param1 is §_-O2H§ && §_-O2H§(param1).isComplex())
            {
               _loc6_ = §_-O2H§(param1).getMaxLevel();
            }
            _loc5_.§_-41K§(param4,_loc6_);
            _loc5_.§_-s2V§();
         }
         return _loc5_;
      }
      
      public function replaceItem(param1:int, param2:§_-W1r§, param3:int = 0, param4:uint = 0) : void
      {
         if(this.deposit[param1])
         {
            this.removeItem(param1);
            this.§_-Um§(param2,param3,param4);
         }
      }
      
      public function removeItem(param1:int, param2:int = -1) : void
      {
         if(this.deposit[param1])
         {
            param2 = param2 == -1 ? -1 : int(§_-Oi§(this.deposit[param1]).getCount() - param2);
            if(param2 < 0)
            {
               delete this.deposit[param1];
            }
            else
            {
               §_-Oi§(this.deposit[param1]).setCount(param2);
            }
         }
      }
      
      public function §_-O2Z§() : Object
      {
         return this.deposit;
      }
      
      public function §_-P2l§() : Array
      {
         var _loc2_:§_-Oi§ = null;
         var _loc1_:Array = [];
         for each(_loc2_ in this.deposit)
         {
            _loc1_[_loc1_.length] = _loc2_;
         }
         _loc1_.sort(this.§_-D2F§);
         return _loc1_;
      }
      
      protected function §_-D2F§(param1:§_-Oi§, param2:§_-Oi§) : int
      {
         return §_-ou§.itemsComparator(param1.getRecord(),param2.getRecord());
      }
      
      public function §_-H3E§(param1:int) : Boolean
      {
         var _loc2_:§_-Oi§ = §_-Oi§(this.deposit[param1]);
         if(Boolean(_loc2_) && (_loc2_.getRecord() is §_-zF§ || _loc2_.getRecord() is §_-T1y§))
         {
            return true;
         }
         return _loc2_ ? !_loc2_.isEmpty() : false;
      }
      
      public function §_-n1e§(param1:int) : Array
      {
         var _loc4_:§_-Oi§ = null;
         var _loc2_:Array = [];
         var _loc3_:Array = this.§_-P2l§();
         for each(_loc4_ in _loc3_)
         {
            if((_loc4_.getRecord() as §_-L1r§).§_-3K§() == param1)
            {
               _loc2_.push(_loc4_);
            }
         }
         return _loc2_;
      }
      
      public function §_-d3§(param1:int) : int
      {
         var _loc2_:§_-Oi§ = this.deposit[param1] as §_-Oi§;
         return _loc2_ ? _loc2_.getCount() : 0;
      }
      
      public function §_-d0§(param1:int) : §_-Oi§
      {
         return this.deposit[param1] as §_-Oi§;
      }
      
      public function clone() : §_-H2M§
      {
         var _loc2_:§_-Oi§ = null;
         var _loc1_:§_-H2M§ = new §_-H2M§();
         for each(_loc2_ in this.§_-P2l§())
         {
            _loc1_.§_-Um§(_loc2_.getRecord(),_loc2_.getCount(),_loc2_.getMaxShots(),_loc2_.getLevel());
         }
         return _loc1_;
      }
   }
}


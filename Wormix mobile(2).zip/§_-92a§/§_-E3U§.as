package §_-92a§
{
   import §_-21p§.§_-4w§;
   import §_-51W§.§_-92y§;
   import §_-5Y§.*;
   import §_-62§.*;
   import §_-63U§.*;
   import §_-931§.§_-02O§;
   import §_-937§.§_-n1b§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-ts§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G3w§.GlobalRatingScreen;
   import §_-G3w§.TodayRatingScreen;
   import §_-G3w§.TopClanRatingScreen;
   import §_-G3w§.YesterdayRatingScreen;
   import §_-H2g§.§_-di§;
   import §_-Ly§.§_-81L§;
   import §_-O2L§.§_-X1T§;
   import §_-T1o§.§_-L3M§;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-W§.§_-z2Q§;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-d26§.§_-d1H§;
   import §_-fo§.§_-r5§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-lD§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.§_-N1y§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.§_-W2D§;
   import §_-t1J§.HotSeatCard;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-82X§;
   import §_-z20§.§_-pl§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.events.DeviceOrientationEvent;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.TweenMax;
   import com.greensock.easing.Linear;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import config.§_-B1K§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.styles.AlternateButtonsStyles;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.MovieClip;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-J1u§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.SimpleProfileStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.BunkerBusterMissile;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class §_-E3U§ extends §_-E2w§
   {
      
      private var §_-O1y§:§_-J1u§;
      
      private var §_-v2O§:Boolean = false;
      
      private var §_-FM§:Button;
      
      private var §_-ww§:Button;
      
      private var §_-AF§:Button;
      
      private var §_-7X§:Button;
      
      private var §_-i1E§:Button;
      
      private var orText11:ITextRenderer;
      
      private var hotSeatCard:HotSeatCard;
      
      public function §_-E3U§(param1:DisplayObjectContainer)
      {
         super(param1);
         this.§_-O1y§ = new §_-J1u§(getChildByName("topPart.greenLine.timerText") as ITextRenderer);
         this.§_-v2O§ = false;
         this.§_-p2W§();
         this.§_-j2K§();
         this.§_-41z§("");
         this.hotSeatCard = new HotSeatCard(§_-YQ§.§_-qM§(§_-q2v§.§_-a27§,§_-q2v§.§_-h2y§));
         this.hotSeatCard.getContainer().scale = 1.25;
      }
      
      private function §_-p2W§() : void
      {
         this.setText("topPart.limitTitle",§_-s2a§.ARENA_DELAY_MESSAGE);
         this.setText("topPart.greenLine.limitDescription",§_-s2a§.ARENA_DELAY_DESC);
         this.setText("buyOneBattleText",§_-s2a§.ARENA_BUY_BATTLE);
         this.orText11 = this.setText("buyOneBattleButtons.orText11",§_-s2a§.ARENA_OR_LABEL);
         this.setText("buyFiveBattles",§_-s2a§.ARENA_BUY_FIVE_BATTLES);
         this.setText("buyOneBattleButtons.orText1",§_-s2a§.ARENA_OR_LABEL);
         this.setText("buyFiveBattleButtons.orText2",§_-s2a§.ARENA_OR_LABEL);
      }
      
      private function setText(param1:String, param2:String) : ITextRenderer
      {
         var _loc3_:ITextRenderer = getChildByName(param1) as ITextRenderer;
         _loc3_.text = §_-s2a§.§_-K3t§(param2);
         return _loc3_;
      }
      
      private function §_-j2K§() : void
      {
         var _loc1_:§_-x2t§ = §_-4I§.§_-C39§;
         var _loc2_:§_-x2t§ = §_-4I§.§_-R10§;
         this.§_-FM§ = this.§_-G3l§("buyOneBattleButtons.buyOneBattleForFuziesBtn",String(_loc1_.§_-R1T§),this.§_-C2H§);
         this.§_-ww§ = this.§_-G3l§("buyOneBattleButtons.buyOneBattleForRubiesBtn",String(_loc1_.realPrice),this.§_-J3W§);
         this.§_-AF§ = this.§_-G3l§("buyOneBattleButtons.buyOneBattleForAdsBtn",§_-s2a§.§_-K3t§(§_-s2a§.FREE_LABEL),null,AlternateButtonsStyles.BUTTON_SHOW_ADS);
         this.§_-7X§ = this.§_-G3l§("buyFiveBattleButtons.buyFiveBattlesForFuziesBtn",String(_loc2_.§_-R1T§),this.§_-oE§);
         this.§_-i1E§ = this.§_-G3l§("buyFiveBattleButtons.buyFiveBattlesForRubiesBtn",String(_loc2_.realPrice),this.§_-32y§);
      }
      
      private function §_-G3l§(param1:String, param2:String, param3:Function, param4:String = "") : Button
      {
         var _loc6_:§_-02O§ = null;
         var _loc5_:Button = getChildByName(param1) as Button;
         _loc5_.addEventListener(starling.events.Event.TRIGGERED,param3);
         if(param4)
         {
            _loc5_.label = param2;
            _loc5_.styleName = param4;
         }
         else
         {
            _loc6_ = new §_-02O§("text");
            _loc6_.text = param2;
            §_-YQ§.§_-S1U§(_loc5_.defaultSkin,_loc6_);
            §_-YQ§.§_-S1U§(_loc5_.downSkin,_loc6_);
         }
         return _loc5_;
      }
      
      private function §_-41z§(param1:String) : void
      {
         if(Boolean(this.orText11) && Boolean(this.orText11.parent))
         {
            this.orText11.parent.removeChild(this.orText11 as DisplayObject);
         }
         if(Boolean(this.§_-AF§) && Boolean(this.§_-AF§.parent))
         {
            this.§_-AF§.parent.removeChild(this.§_-AF§);
         }
      }
      
      private function §_-Tv§(param1:uint) : void
      {
         §_-X1j§.§_-B35§.§_-Tv§(param1);
         var _loc2_:ArenaMenu = §_-X1j§.§_-A24§.§_-73E§();
         if(_loc2_)
         {
            _loc2_.activate();
         }
      }
      
      private function §_-G3F§(param1:Boolean) : void
      {
         this.§_-B3W§(param1 ? 1 : 0);
      }
      
      private function §_-A2z§(param1:Boolean) : void
      {
         this.§_-B3W§(param1 ? 5 : 0);
      }
      
      private function §_-B3W§(param1:int = 0) : void
      {
         if(§_-J2l§.§_-u2b§.§_-h1C§())
         {
            §_-J2l§.§_-u2b§.hide();
         }
         if(this.§_-v2O§ && param1 > 0)
         {
            this.§_-Tv§(param1);
         }
         else
         {
            this.§_-J2A§(false);
         }
         this.§_-v2O§ = false;
      }
      
      private function §_-C2H§(param1:starling.events.Event) : void
      {
         this.§_-e10§(§_-E19§.§_-i2d§);
      }
      
      private function §_-J3W§(param1:starling.events.Event) : void
      {
         this.§_-e10§(§_-E19§.§_-51D§);
      }
      
      private function §_-oE§(param1:starling.events.Event) : void
      {
         this.§_-6O§(§_-E19§.§_-i2d§);
      }
      
      private function §_-32y§(param1:starling.events.Event) : void
      {
         this.§_-6O§(§_-E19§.§_-51D§);
      }
      
      private function §_-e10§(param1:§_-E19§) : void
      {
         if(!this.§_-v2O§)
         {
            this.§_-v2O§ = true;
            §_-J2l§.§_-u2b§.show();
            this.§_-J2A§();
            §_-X1j§.§_-02s§.§_-Hf§(param1,this.§_-G3F§);
         }
      }
      
      private function §_-6O§(param1:§_-E19§) : void
      {
         if(!this.§_-v2O§)
         {
            this.§_-v2O§ = true;
            §_-J2l§.§_-u2b§.show();
            this.§_-J2A§();
            §_-X1j§.§_-02s§.buyFiveBattles(param1,this.§_-A2z§);
         }
      }
      
      public function §_-a1y§() : §_-J1u§
      {
         return this.§_-O1y§;
      }
      
      public function §_-A3U§(param1:uint, param2:Boolean = false) : void
      {
         §_-h2B§.play(§_-d27§.§_-b2H§);
         this.§_-61r§(param1);
         this.§_-G2x§(param2);
         this.§_-3H§(param2);
      }
      
      private function §_-G2x§(param1:Boolean) : void
      {
         if(getContainer() is LayoutGroup)
         {
            ((getContainer() as LayoutGroup).layout as Object).gap = param1 ? 12 : 20;
         }
         getChildByName("line").alpha = param1 ? 0 : 1;
         getChildByName("buyOneBattleButtons").scale = param1 ? 0.8 : 1;
         getChildByName("buyFiveBattleButtons").scale = param1 ? 0.8 : 1;
      }
      
      private function §_-3H§(param1:Boolean) : void
      {
         if(!this.hotSeatCard)
         {
            return;
         }
         if(param1)
         {
            §_-j2l§().addChild(this.hotSeatCard.getContainer());
         }
         else
         {
            §_-j2l§().removeChild(this.hotSeatCard.getContainer());
         }
      }
      
      public function §_-61r§(param1:uint) : void
      {
         this.§_-p2s§();
         TweenMax.to(this.§_-a1y§(),param1 / 1000,{
            "startAt":{"value":param1},
            "value":0,
            "onComplete":this.§_-C7§,
            "ease":Linear.easeNone
         });
      }
      
      public function §_-p2s§() : void
      {
         TweenMax.killTweensOf(this.§_-a1y§());
      }
      
      private function §_-C7§() : void
      {
         dispatchEvent(new §_-92y§(§_-92y§.§_-wH§));
      }
      
      override public function dispose() : void
      {
         this.§_-FM§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-C2H§);
         this.§_-ww§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-J3W§);
         this.§_-7X§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-oE§);
         this.§_-i1E§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-32y§);
         this.§_-p2s§();
         if(this.§_-O1y§)
         {
            this.§_-O1y§.dispose();
            this.§_-O1y§ = null;
         }
         this.§_-FM§ = §_-c1S§.dispose(this.§_-FM§) as Button;
         this.§_-ww§ = §_-c1S§.dispose(this.§_-ww§) as Button;
         this.§_-AF§ = §_-c1S§.dispose(this.§_-AF§) as Button;
         this.§_-7X§ = §_-c1S§.dispose(this.§_-7X§) as Button;
         this.§_-i1E§ = §_-c1S§.dispose(this.§_-i1E§) as Button;
         if(this.hotSeatCard)
         {
            this.hotSeatCard.dispose();
            this.hotSeatCard = null;
         }
         super.dispose();
      }
      
      private function §_-J2A§(param1:Boolean = true) : void
      {
         this.§_-AF§.isEnabled = !param1;
         this.§_-ww§.isEnabled = !param1;
         this.§_-FM§.isEnabled = !param1;
         this.§_-i1E§.isEnabled = !param1;
         this.§_-7X§.isEnabled = !param1;
      }
   }
}


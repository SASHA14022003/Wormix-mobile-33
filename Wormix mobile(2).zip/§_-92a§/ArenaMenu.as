package §_-92a§
{
   import §_-02q§.§_-4s§;
   import §_-2k§.*;
   import §_-31W§.*;
   import §_-51W§.§_-92y§;
   import §_-51W§.§_-G2h§;
   import §_-5Y§.§_-t2O§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-T1y§;
   import §_-73d§.§_-a2s§;
   import §_-82a§.*;
   import §_-82l§.§_-A2Y§;
   import §_-91A§.§_-N2O§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-LE§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-CR§.§_-S2o§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E3c§.§_-8W§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.*;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-Ly§.§_-81L§;
   import §_-N8§.§_-o2w§;
   import §_-Nq§.*;
   import §_-P1B§.§_-b21§;
   import §_-P2i§.§_-b7§;
   import §_-R2I§.PvpTab;
   import §_-RE§.§_-52p§;
   import §_-RE§.§_-qW§;
   import §_-T1o§.§_-n1S§;
   import §_-TF§.§_-F1O§;
   import §_-TF§.§_-q1j§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-22N§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-C3P§;
   import §_-f1G§.§_-kf§;
   import §_-g2r§.§_-03A§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-o14§.§_-Dd§;
   import §_-p24§.MissionTab;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-52k§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-x22§.§_-xY§;
   import §_-z1g§.§_-F4§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.OverwriteManager;
   import com.greensock.TweenLite;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.AutoAlphaPlugin;
   import com.greensock.plugins.BevelFilterPlugin;
   import com.greensock.plugins.BezierPlugin;
   import com.greensock.plugins.BezierThroughPlugin;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.ColorTransformPlugin;
   import com.greensock.plugins.DropShadowFilterPlugin;
   import com.greensock.plugins.EndArrayPlugin;
   import com.greensock.plugins.FrameLabelPlugin;
   import com.greensock.plugins.FramePlugin;
   import com.greensock.plugins.GlowFilterPlugin;
   import com.greensock.plugins.HexColorsPlugin;
   import com.greensock.plugins.RemoveTintPlugin;
   import com.greensock.plugins.RoundPropsPlugin;
   import com.greensock.plugins.ShortRotationPlugin;
   import com.greensock.plugins.TintPlugin;
   import com.greensock.plugins.TweenPlugin;
   import com.greensock.plugins.VisiblePlugin;
   import com.greensock.plugins.VolumePlugin;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.Callout;
   import feathers.controls.LayoutGroup;
   import feathers.controls.TabBar;
   import feathers.core.FeathersControl;
   import feathers.core.IFeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayoutDisplayObject;
   import feathers.layout.LayoutBoundsResult;
   import feathers.layout.RelativePosition;
   import feathers.layout.ViewPortBounds;
   import feathers.utils.touch.TapToTrigger;
   import flash.desktop.NativeApplication;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getTimer;
   import flash.utils.setTimeout;
   import org.gestouch.core.GestureState;
   import org.gestouch.core.§_-H3d§;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-j2C§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-B1m§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class ArenaMenu extends §_-73y§
   {
      
      public static const §_-Or§:Object = {
         "labelId":§_-s2a§.MISSION_TAB_NAME,
         "panel":MissionTab
      };
      
      public static const §_-I2S§:Object = {
         "labelId":§_-s2a§.PVP_TAB_NAME,
         "panel":PvpTab
      };
      
      public static const §_-TW§:Object = {
         "labelId":§_-s2a§.BOSS_TAB_NAME,
         "panel":BossTypesTab
      };
      
      public static const §_-C2r§:Object = §_-I2S§;
      
      public static const §_-yZ§:Object = §_-Or§;
      
      public static const §_-43z§:Number = 179 + 21 + 30;
      
      public static const §_-Qo§:Number = 66;
      
      private var tabs:§_-j2C§;
      
      private var §_-H1T§:DisplayObject;
      
      private var §_-j1e§:Vector.<§_-G2h§>;
      
      private var §_-l2w§:§_-G2h§;
      
      private var §_-e8§:§_-E3U§;
      
      private var isLoaded:Boolean;
      
      private var §_-85§:String;
      
      private var §_-P3§:LayoutGroup;
      
      private var §_-x2c§:§_-8W§;
      
      private var §_-z3§:Boolean;
      
      public function ArenaMenu()
      {
         var _loc1_:Sprite = §_-YQ§.§_-qM§(§_-q2v§.§_-83c§,§_-q2v§.§_-h2y§);
         super(_loc1_);
         this.§_-r2b§([§_-Or§,§_-I2S§,§_-TW§]);
         this.§_-r1e§();
         this.§_-j1e§ = new Vector.<§_-G2h§>(this.tabs.dataProvider.length);
         this.§_-e8§ = new §_-E3U§(getChildByName("delayTab") as DisplayObjectContainer);
         this.§_-e8§.§_-c1v§(false);
         this.§_-e8§.addEventListener(§_-92y§.§_-wH§,this.§_-z4§);
         this.§_-85§ = "";
         this.isLoaded = false;
      }
      
      private function §_-r1e§() : void
      {
         this.§_-x2c§ = new §_-8W§(getChildByName("tokensGroup"));
         this.§_-P3§ = getChildByName("emptyRightGroup") as LayoutGroup;
         this.§_-P3§.visible = false;
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-u2m§ = §_-NY§.§_-w1y§;
         soundOnShow = §_-d27§.ARENA;
         destroyOnRemove = true;
         Application.§_-i1N§.addEventListener(flash.events.Event.ACTIVATE,this.onStageActivated);
         Application.§_-i1N§.addEventListener(flash.events.Event.DEACTIVATE,this.onStageDeactivated);
      }
      
      override protected function §_-q2a§() : void
      {
         super.§_-q2a§();
         var _loc1_:DisplayObject = getContainer();
         var _loc2_:Rectangle = Pool.getRectangle(0,0,_loc1_.width,_loc1_.height);
         var _loc3_:Rectangle = Pool.getRectangle(0,0,Starling.current.stage.stageWidth,Starling.current.stage.stageHeight);
         var _loc4_:Rectangle = RectangleUtil.fit(_loc2_,_loc3_,ScaleMode.SHOW_ALL);
         this.x = _loc4_.x;
         this.y = _loc4_.y;
         this.width = _loc4_.width;
         this.height = _loc4_.height;
         Pool.putRectangle(_loc2_);
         Pool.putRectangle(_loc3_);
         Pool.putRectangle(_loc4_);
      }
      
      public function §_-P2F§() : void
      {
      }
      
      private function §_-r2b§(param1:Array, param2:Object = null) : void
      {
         var _loc3_:Object = null;
         for each(_loc3_ in param1)
         {
            _loc3_.label = §_-s2a§.§_-K3t§(_loc3_.labelId);
         }
         this.tabs = new §_-j2C§(§_-43z§,§_-Qo§,getChildByName("tabs"));
         this.tabs.dataProvider = new ListCollection(param1);
         if(param2)
         {
            this.tabs.selectedItem = param2;
         }
         var _loc4_:int = this.tabs.parent.width;
         if(param1.length == 1)
         {
            this.tabs.x = (_loc4_ - 68 - §_-43z§) / 2 + this.tabs.gap;
         }
         if(param1.length == 2)
         {
            this.tabs.x = _loc4_ - this.tabs.gap / 2 - §_-43z§;
         }
         if(param1.length == 3)
         {
            this.tabs.x = (_loc4_ - (§_-43z§ * 3 + this.tabs.gap * 2)) / 2;
         }
         this.tabs.addEventListener(starling.events.Event.CHANGE,this.§_-w2q§);
         this.tabs.addEventListener(starling.events.Event.TRIGGERED,this.§_-M1§);
         §_-j2l§().addChild(this.tabs);
      }
      
      private function §_-w2q§(param1:starling.events.Event) : void
      {
         var _loc2_:TabBar = TabBar(param1.currentTarget);
         if(_loc2_.selectedIndex < 0)
         {
            return;
         }
         this.§_-VW§(_loc2_);
         dispatchEvent(new starling.events.Event(starling.events.Event.CHANGE));
      }
      
      private function §_-M1§(param1:starling.events.Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
      }
      
      override public function activate() : void
      {
         super.activate();
         if(Boolean(this.tabs) && this.tabs.selectedIndex < 0)
         {
            this.tabs.selectedIndex = 0;
         }
         this.§_-VW§(this.tabs);
         this.§_-2i§();
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         super.§_-Q2j§(param1);
      }
      
      override protected function §_-D3u§() : void
      {
         super.§_-D3u§();
         this.§_-2i§();
         this.§_-x2c§.update();
      }
      
      private function §_-2i§() : void
      {
         if(!this.§_-z3§)
         {
            this.§_-z3§ = true;
            this.§_-x2c§.§_-c1v§(true);
         }
      }
      
      override public function hide() : void
      {
         this.§_-x2c§.§_-r2J§();
         this.§_-hj§();
         super.hide();
      }
      
      private function §_-hj§() : void
      {
         if(this.§_-z3§)
         {
            this.§_-z3§ = false;
            this.§_-x2c§.§_-c1v§(false);
         }
      }
      
      override public function deactivate() : void
      {
         super.deactivate();
         this.§_-hj§();
      }
      
      public function §_-R5§(param1:UserProfile) : void
      {
         if(!param1)
         {
            return;
         }
         var _loc2_:Object = this.tabs.selectedItem;
         this.§_-xH§();
         this.§_-r2b§([§_-TW§],_loc2_);
         this.§_-85§ = StringUtil.§_-jT§(param1.getCharName(),16);
      }
      
      private function §_-VW§(param1:TabBar) : void
      {
         if(!param1)
         {
            return;
         }
         if(param1.selectedItem == §_-C2r§)
         {
            this.§_-21c§();
            return;
         }
         this.§_-x2c§.update();
         if(!this.isLoaded)
         {
            this.§_-sa§();
         }
         else if(§_-X1j§.§_-B35§.§_-M1J§())
         {
            this.§_-21c§();
         }
         else
         {
            this.§_-8w§(§_-X1j§.§_-B35§.§_-d1q§());
         }
      }
      
      private function §_-8w§(param1:uint) : void
      {
         this.§_-Z2Q§();
         if(this.§_-e8§)
         {
            this.§_-e8§.§_-c1v§(true);
            this.§_-e8§.§_-A3U§(param1,this.tabs.selectedItem == §_-yZ§);
         }
      }
      
      private function §_-sa§() : void
      {
         this.§_-H3b§(true);
         §_-X1j§.§_-A24§.§_-I3T§(this.§_-m1h§,this.§_-8w§,this.§_-71q§);
      }
      
      private function §_-m1h§() : void
      {
         this.isLoaded = true;
         SystemUtil.executeWhenApplicationIsActive(this.§_-21c§);
      }
      
      private function §_-71q§() : void
      {
         if(!this.tabs)
         {
            return;
         }
         this.tabs.selectedItem = §_-C2r§;
         this.§_-VW§(this.tabs);
      }
      
      private function §_-21c§() : void
      {
         var _loc1_:§_-G2h§ = null;
         if(!this.tabs || this.tabs.selectedIndex < 0)
         {
            return;
         }
         §_-X1j§.§_-A24§.§_-1S§ = this.tabs.selectedItem;
         this.§_-H3b§(false);
         this.§_-Z2Q§();
         this.§_-e8§.§_-c1v§(false);
         if(this.§_-j1e§.length < this.tabs.selectedIndex || this.§_-j1e§[this.tabs.selectedIndex] == null)
         {
            _loc1_ = new this.tabs.selectedItem.panel();
            if(this.§_-H1T§)
            {
               _loc1_.x = this.§_-H1T§.x;
               _loc1_.y = this.§_-H1T§.y;
            }
            this.§_-j1e§[this.tabs.selectedIndex] = _loc1_;
         }
         else
         {
            _loc1_ = this.§_-j1e§[this.tabs.selectedIndex];
         }
         §_-j2l§().addChild(_loc1_);
         this.§_-l2w§ = _loc1_;
         _loc1_.activate();
         if(this.§_-85§ != "")
         {
            this.§_-81S§(this.§_-85§);
         }
         this.§_-x2c§.update();
      }
      
      private function §_-81S§(param1:String) : void
      {
         if(this.§_-l2w§ is BossTypesTab)
         {
            (this.§_-l2w§ as BossTypesTab).§_-81S§(param1);
         }
      }
      
      private function §_-Z2Q§() : void
      {
         if(Boolean(this.§_-l2w§) && Boolean(this.§_-l2w§.parent))
         {
            this.§_-l2w§.parent.removeChild(this.§_-l2w§);
         }
      }
      
      public function §_-i2x§(param1:Object) : void
      {
         this.tabs.selectedItem = param1;
         this.tabs.validate();
         this.§_-VW§(this.tabs);
      }
      
      private function §_-z4§(param1:starling.events.Event) : void
      {
         this.isLoaded = false;
         setTimeout(this.§_-VW§,500,this.tabs);
      }
      
      public function §_-E3E§() : void
      {
         if(this.§_-l2w§)
         {
            this.§_-l2w§.update();
         }
      }
      
      override public function §_-H3b§(param1:Boolean) : void
      {
         if(§_-J2l§.§_-u2b§.§_-h1C§())
         {
            §_-J2l§.§_-u2b§.hide();
         }
         if(Boolean(this.§_-l2w§) && Boolean(this.§_-l2w§.parent))
         {
            this.§_-l2w§.§_-H3b§(param1);
            return;
         }
         if(param1)
         {
            §_-J2l§.§_-u2b§.show();
         }
      }
      
      override public function §_-X2O§() : void
      {
         if(!(this.§_-l2w§ is BossTypesTab) || !(this.§_-l2w§ as BossTypesTab).§_-31a§())
         {
            this.hide();
         }
      }
      
      private function onStageDeactivated(param1:Object) : void
      {
         if(§_-h1C§())
         {
            this.§_-hj§();
         }
      }
      
      private function onStageActivated(param1:Object) : void
      {
         if(§_-h1C§())
         {
            this.§_-2i§();
         }
      }
      
      public function §_-xH§() : void
      {
         if(this.tabs)
         {
            this.tabs.removeEventListener(starling.events.Event.CHANGE,this.§_-w2q§);
            this.tabs.removeEventListener(starling.events.Event.TRIGGERED,this.§_-M1§);
         }
         this.tabs = §_-c1S§.dispose(this.tabs) as §_-j2C§;
      }
      
      override public function dispose() : void
      {
         var _loc1_:* = 0;
         Application.§_-i1N§.removeEventListener(flash.events.Event.ACTIVATE,this.onStageActivated);
         Application.§_-i1N§.removeEventListener(flash.events.Event.DEACTIVATE,this.onStageDeactivated);
         if(Boolean(this.§_-e8§) && this.§_-e8§.hasEventListener(§_-92y§.§_-wH§))
         {
            this.§_-e8§.removeEventListener(§_-92y§.§_-wH§,this.§_-z4§);
         }
         this.§_-xH§();
         this.§_-H1T§ = §_-c1S§.dispose(this.§_-H1T§);
         this.§_-l2w§ = null;
         if(this.§_-j1e§)
         {
            _loc1_ = int(this.§_-j1e§.length);
            while(_loc1_--)
            {
               §_-c1S§.dispose(this.§_-j1e§[_loc1_]);
            }
            this.§_-j1e§ = null;
         }
         if(this.§_-e8§)
         {
            this.§_-e8§.dispose();
            this.§_-e8§ = null;
         }
         if(this.§_-x2c§)
         {
            this.§_-x2c§.dispose();
            this.§_-x2c§ = null;
         }
      }
   }
}


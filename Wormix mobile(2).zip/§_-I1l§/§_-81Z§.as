package §_-I1l§
{
   import §_-5Y§.§_-91F§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-E1I§.*;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-hv§.*;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.Parasite;
   import starling.events.Event;
   
   public class §_-81Z§
   {
      
      public function §_-81Z§()
      {
         super();
         throw new Error("BossGameOverMessage can\'t be instantiated!");
      }
      
      public static function create(param1:§_-O2i§, param2:§_-hK§) : §_-m2t§
      {
         if(param2.result == §_-J1§.WINNER)
         {
            return new §_-z1E§(param1,param2);
         }
         if(param2.result == §_-J1§.§_-23m§)
         {
            return new §_-F2D§(param1,param2);
         }
         return new §_-41Q§(param1,param2);
      }
   }
}


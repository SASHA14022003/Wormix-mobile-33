package §_-G24§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-51W§.§_-SN§;
   import §_-5Y§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-a3§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-U11§;
   import §_-A2F§.§_-4B§;
   import §_-A2U§.§_-A23§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J1d§;
   import §_-DJ§.§_-J2l§;
   import §_-E1I§.§_-b2n§;
   import §_-G2H§.*;
   import §_-Ly§.§_-81L§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-Y1Q§.§_-vx§;
   import §_-YF§.§_-Zi§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-M6§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-k2s§.§_-e1k§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sQ§.§_-H3D§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-F4§;
   import §_-zI§.§_-X1q§;
   import com.greensock.loading.core.*;
   import com.hurlant.crypto.tls.§_-A3§;
   import com.hurlant.crypto.tls.§_-Zf§;
   import com.hurlant.util.§_-a2P§;
   import com.worlize.websocket.§_-x2j§;
   import config.§_-B1K§;
   import feathers.controls.Button;
   import feathers.controls.Panel;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.TiledColumnsLayout;
   import flash.events.Event;
   import flash.events.SecurityErrorEvent;
   import flash.geom.Rectangle;
   import flash.net.Socket;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.IncomingClanMessage;
   import ru.pragmatix.wormix.messages.clans.main.server.InviteFriendToClan;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.PostToClanChatResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.§_-N1C§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.text.TextField;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-yi§ extends §_-3r§
   {
      
      protected var awardPanel:DisplayObjectContainer;
      
      protected var bonusForAdsBtn:Button;
      
      public function §_-yi§(param1:§_-O2i§, param2:§_-hK§)
      {
         super(§_-YQ§.§_-qM§(§_-q2v§.§_-O1n§,§_-q2v§.§_-22s§),param1,param2);
         this.§_-T1e§(param2);
         §_-u2m§ = §_-NY§.§_-w1y§;
      }
      
      public static function create(param1:§_-O2i§, param2:§_-hK§) : §_-yi§
      {
         return new §_-yi§(param1,param2);
      }
      
      protected function §_-T1e§(param1:§_-hK§, param2:Boolean = false) : void
      {
         this.§_-p1k§(param1,param2);
         this.§_-w20§(param1);
      }
      
      protected function §_-p1k§(param1:§_-hK§, param2:Boolean = false) : void
      {
         this.awardPanel = getChildByName("awardPanel") as DisplayObjectContainer;
         var _loc3_:Boolean = this.§_-UV§(param1,param2);
         if(_loc3_)
         {
            §_-Nn§(this.awardPanel);
         }
         else
         {
            this.§_-pN§();
            §_-Nn§(this.§_-I1L§());
         }
      }
      
      private function §_-pN§() : void
      {
         this.awardPanel.removeFromParent(true);
         this.awardPanel = null;
      }
      
      override protected function §_-W2b§(param1:DisplayObjectContainer, param2:Panel) : void
      {
         super.§_-W2b§(param1,param2);
         this.bonusForAdsBtn = param1.getChildByName("bonusForAdsBtn") as Button;
         if(this.bonusForAdsBtn)
         {
            if(startInfo.battleType == §_-81M§.§_-Y1C§)
            {
               param2.addChild(this.bonusForAdsBtn);
            }
            else
            {
               this.bonusForAdsBtn.removeFromParent(true);
               this.bonusForAdsBtn = null;
            }
         }
      }
      
      protected function §_-I1L§() : DisplayObject
      {
         return getChildByName("winner_title") || getChildByName("loser_title") || getChildByName("op_surrender_title") || getChildByName("draw_title");
      }
      
      protected function §_-w20§(param1:§_-hK§) : void
      {
         var _loc3_:§_-J1d§ = null;
         var _loc4_:Array = null;
         var _loc5_:§_-e1k§ = null;
         var _loc2_:ITextRenderer = getChildByName("reagentsPanelTitle") as ITextRenderer;
         if(!_loc2_ && !getChildByName("reagentsPanel"))
         {
            return;
         }
         if(param1.§_-dV§() > 0)
         {
            _loc3_ = new §_-J1d§(getChildByName("reagentsPanel") as DisplayObjectContainer);
            _loc4_ = [];
            for each(_loc5_ in param1.reagents)
            {
               if(§_-Y2u§.§_-k14§(_loc5_.getId()) != null)
               {
                  _loc4_.push(_loc5_.copy());
               }
            }
            _loc3_.§_-cf§(_loc4_);
            _loc2_.text = §_-s2a§.§_-K3t§(§_-s2a§.CRAFT_REWARD_TITLE);
            §_-Nn§(_loc3_.parent.parent);
         }
         else
         {
            getChildByName("reagentsPanel").removeFromParent(true);
            if(_loc2_)
            {
               _loc2_.removeFromParent(true);
            }
         }
      }
      
      protected function §_-UV§(param1:§_-hK§, param2:Boolean = false) : Boolean
      {
         var _loc3_:Number = 0;
         _loc3_ += this.§_-o1j§("rating",param1.result == §_-J1§.WINNER ? §_-s2a§.WINNER_RATING : §_-s2a§.LOSED_RATING,param1.rating,_loc3_,"",param2);
         _loc3_ += this.§_-o1j§("exp",§_-s2a§.GO_EXP_LABEL,param1.exp,_loc3_,"",param2);
         _loc3_ += this.§_-o1j§("bonusExp",§_-s2a§.GO_BONUS_EXP_LABEL,param1.bonusExp,_loc3_,"+");
         _loc3_ += this.§_-o1j§("money",param1.money > 0 ? §_-s2a§.GO_MONEY_LABEL : §_-s2a§.LOSED_MONEY,param1.money,_loc3_,"",param2);
         return _loc3_ > 0;
      }
      
      private function §_-Kp§(param1:§_-81M§, param2:§_-J1§) : Number
      {
         var _loc5_:DisplayObject = null;
         var _loc8_:§_-SN§ = null;
         var _loc9_:String = null;
         var _loc10_:Image = null;
         var _loc11_:Rectangle = null;
         var _loc12_:Sprite = null;
         var _loc13_:TextFieldTextRenderer = null;
         var _loc14_:TextFieldTextRenderer = null;
         var _loc3_:Array = [];
         switch(param1)
         {
            case §_-81M§.§_-K23§:
               if(param2 == §_-J1§.WINNER && !startInfo.isLearning && !startInfo.§_-Dy§() && startInfo.§_-D3W§)
               {
                  _loc3_.push(§_-SN§.§_-X1D§);
               }
            case §_-81M§.§_-e1C§:
               if(!startInfo.isLearning)
               {
                  _loc3_.push(§_-SN§.§_-C39§);
               }
               break;
            case §_-81M§.§_-Y1C§:
               if(param2 == §_-J1§.WINNER && startInfo.§_-u10§)
               {
                  _loc3_.push(§_-SN§.§_-21i§);
               }
         }
         var _loc4_:DisplayObject = this.awardPanel.getChildByName("expIcon");
         _loc5_ = this.awardPanel.getChildByName("money");
         var _loc6_:DisplayObject = this.awardPanel.getChildByName("moneyLabel");
         var _loc7_:int = 0;
         while(_loc7_ < _loc3_.length)
         {
            _loc8_ = _loc3_[_loc7_];
            _loc9_ = _loc8_.iconName;
            _loc10_ = new Image(Application.assetManager.getTexture(_loc9_));
            _loc11_ = Pool.getRectangle(0,0,32,40);
            RectangleUtil.fit(_loc10_.bounds,_loc11_,ScaleMode.SHOW_ALL,false,_loc11_);
            _loc10_.width = _loc11_.width;
            _loc10_.height = _loc11_.height;
            Pool.putRectangle(_loc11_);
            _loc12_ = new Sprite();
            _loc12_.addChild(_loc10_);
            _loc10_.x = _loc4_.x + 3;
            _loc10_.y = -3;
            _loc13_ = TextInstanceCreator.createTextRenderer(20,16777215,TextFormatAlign.RIGHT) as TextFieldTextRenderer;
            _loc13_.width = _loc5_.width;
            _loc13_.height = _loc10_.height;
            _loc13_.text = "-1";
            _loc13_.x = _loc5_.x;
            _loc12_.addChild(_loc13_);
            _loc14_ = TextInstanceCreator.createTextRenderer(20,16777215,TextFormatAlign.LEFT) as TextFieldTextRenderer;
            _loc14_.width = _loc6_.width;
            _loc14_.height = _loc10_.height;
            _loc14_.text = §_-s2a§.§_-K3t§(§_-s2a§.WASTED);
            _loc14_.x = _loc6_.x;
            _loc12_.addChild(_loc14_);
            this.awardPanel.addChild(_loc12_);
            _loc7_++;
         }
         return _loc3_.length * -40;
      }
      
      private function §_-o1j§(param1:String, param2:String, param3:Number, param4:Number, param5:String = "", param6:Boolean = false) : Number
      {
         var _loc7_:DisplayObject = this.awardPanel.getChildByName(param1);
         var _loc8_:ITextRenderer = this.awardPanel.getChildByName(param1 + "Label") as ITextRenderer;
         var _loc9_:DisplayObject = this.awardPanel.getChildByName(param1 + "Icon");
         var _loc10_:DisplayObject = this.awardPanel.getChildByName(param1 + "Line");
         if(!_loc7_ || !_loc8_ || !_loc9_ || !_loc10_)
         {
            return 0.1;
         }
         if(Boolean(param3) || param6)
         {
            if(_loc7_ is ITextRenderer)
            {
               (_loc7_ as ITextRenderer).text = param5 + param3.toString();
            }
            if(_loc7_ is TextField)
            {
               (_loc7_ as TextField).text = param5 + param3.toString();
            }
            _loc8_.text = §_-s2a§.§_-K3t§(param2);
            _loc8_.y -= param4;
            _loc7_.y -= param4;
            _loc9_.y -= param4;
            _loc10_.y -= param4;
            return 0;
         }
         _loc7_.removeFromParent(true);
         _loc8_.removeFromParent(true);
         _loc9_.removeFromParent(true);
         _loc10_.removeFromParent(true);
         return 50;
      }
      
      override public function dispose() : void
      {
         this.awardPanel = §_-c1S§.dispose(this.awardPanel);
         this.awardPanel = null;
         super.dispose();
      }
   }
}


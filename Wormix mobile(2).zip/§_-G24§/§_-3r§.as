package §_-G24§
{
   import §_-31W§.*;
   import §_-52L§.§_-u2x§;
   import §_-62§.*;
   import §_-73d§.§_-v1o§;
   import §_-79§.§_-sd§;
   import §_-82a§.§_-c2B§;
   import §_-82a§.§_-zv§;
   import §_-9§.§_-52A§;
   import §_-931§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-C2M§.§_-u2T§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H3§.*;
   import §_-L1H§.§_-b2K§;
   import §_-P1z§.*;
   import §_-P2i§.§_-G3J§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-Zi§;
   import §_-Z2S§.§_-b8§;
   import §_-b1F§.§_-G4§;
   import §_-hO§.§_-729§;
   import §_-hO§.§_-y2Z§;
   import §_-hv§.*;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-jF§.*;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-6a§;
   import §_-s20§.§_-J2g§;
   import §_-w2W§.§_-21w§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-X1q§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.Panel;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.model.SocialErrorCode;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.sets.AbstractControlSet;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.messages.client.ReorderGroup;
   import ru.pragmatix.wormix.messages.client.SetLocale;
   import ru.pragmatix.wormix.messages.client.SyncInvestedAwardPoints;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.DailyBonusStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.*;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.Jetpack;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-3r§ extends §_-73y§
   {
      
      private static const §_-T8§:int = 20;
      
      private static const §_-31P§:int = 15;
      
      private static const §_-J3e§:Number = 60;
      
      protected var §_-Z28§:Button;
      
      protected var §_-k1b§:Button;
      
      protected var §_-G3N§:Panel;
      
      protected var resultInfo:§_-hK§;
      
      protected var startInfo:§_-O2i§;
      
      protected var §_-L2p§:Boolean;
      
      public function §_-3r§(param1:DisplayObjectContainer, param2:§_-O2i§, param3:§_-hK§)
      {
         super(this.§_-e4§(param1));
         §_-yp§ = true;
         this.startInfo = param2;
         this.resultInfo = param3;
         outsideClosable = false;
         this.§_-cw§(param3);
         this.§_-C1§(param3);
         soundOnShow = param3.result.equals(§_-J1§.WINNER) ? §_-sd§.§_-zC§(Application.userProfile.§_-P2e§().configName).§_-O2U§() : §_-d27§.§_-lj§;
      }
      
      public static function §_-6X§(param1:DisplayObject, param2:DisplayObject) : void
      {
         var _loc3_:int = param2.parent.getChildIndex(param2);
         param2.parent.setChildIndex(param2,param1.parent.getChildIndex(param1));
         param1.parent.setChildIndex(param1,_loc3_);
      }
      
      private function §_-e4§(param1:DisplayObjectContainer) : Panel
      {
         var _loc2_:Panel = new Panel();
         _loc2_.verticalScrollPolicy = ScrollPolicy.OFF;
         _loc2_.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.§_-b27§(param1,_loc2_);
         _loc2_.layout = this.§_-nj§();
         this.§_-G3N§ = new Panel();
         this.§_-G3N§.height = §_-J3e§;
         this.§_-G3N§.layout = this.§_-N1g§();
         _loc2_.addChild(this.§_-G3N§);
         return _loc2_;
      }
      
      override protected function §_-q2a§() : void
      {
         super.§_-q2a§();
         this.§_-W2b§(§_-j2l§(),this.§_-G3N§);
         this.initButtons(this.startInfo,this.resultInfo);
      }
      
      protected function §_-W2b§(param1:DisplayObjectContainer, param2:Panel) : void
      {
         this.§_-Z28§ = param1.getChildByName("createNote") as Button;
         param2.addChild(this.§_-Z28§);
         this.§_-k1b§ = param1.getChildByName("status") as Button;
         param2.addChild(this.§_-k1b§);
         param2.addChild(okBtn);
      }
      
      private function §_-b27§(param1:DisplayObjectContainer, param2:Panel) : void
      {
         var _loc4_:int = 0;
         var _loc5_:DisplayObject = null;
         var _loc3_:int = param1.numChildren;
         _loc4_ = 0;
         while(_loc4_ < _loc3_)
         {
            _loc5_ = param1.getChildAt(0);
            param2.addChild(_loc5_);
            _loc4_++;
         }
      }
      
      private function §_-nj§() : ILayout
      {
         var _loc1_:VerticalLayout = new VerticalLayout();
         _loc1_.horizontalAlign = HorizontalAlign.CENTER;
         _loc1_.verticalAlign = VerticalAlign.MIDDLE;
         _loc1_.gap = §_-31P§;
         return _loc1_;
      }
      
      private function §_-N1g§() : ILayout
      {
         var _loc1_:HorizontalLayout = new HorizontalLayout();
         _loc1_.gap = §_-T8§;
         return _loc1_;
      }
      
      override protected function §_-b1H§() : void
      {
         hide();
         if(!this.§_-L2p§)
         {
            Application.§_-i1N§.§_-V6§(§_-X1j§.§_-12n§.§_-t1y§.§_-E2h§);
         }
      }
      
      private function §_-k1M§(param1:Event) : void
      {
         var _loc2_:UserProfile = null;
         var _loc3_:§_-81M§ = this.startInfo.battleType;
         switch(_loc3_)
         {
            case §_-81M§.§_-e1C§:
               §§push(0);
               break;
            case §_-81M§.§_-Y1C§:
               §§push(1);
               break;
            default:
               switch(_loc3_)
               {
                  case §_-81M§.§_-p1U§:
                     §§push(2);
                     break;
                  case §_-81M§.§_-K23§:
                     §§push(3);
                     break;
                  default:
                     §§push(4);
               }
         }
         switch(§§pop())
         {
            case 0:
               _loc2_ = §_-X1j§.§_-61i§.§_-T1T§(this.startInfo.§_-11J§);
               §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_MISSION_LOAD,this.§_-G3j§,this.startInfo.battleType,[_loc2_,this.startInfo.§_-11J§]);
               break;
            case 1:
               Application.§_-a1k§(false);
               if(this.startInfo.wager == §_-82X§.§_-F1d§)
               {
                  _loc2_ = this.startInfo.§_-D1h§()[0];
                  if(§_-33r§.§_-ym§(_loc2_))
                  {
                     _loc2_ = this.startInfo.§_-D1h§()[this.startInfo.§_-D1h§().length - 1];
                  }
                  break;
               }
               §_-X1j§.§_-12n§.§_-D1n§(this.startInfo.wager);
               hide();
               break;
            case 2:
               _loc2_ = this.startInfo.§_-D1h§()[this.startInfo.§_-D1h§().length - 1];
               §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_MISSION_LOAD,this.§_-G3j§,this.startInfo.battleType,[_loc2_,!this.startInfo.§_-oR§]);
               break;
            case 3:
               if(this.startInfo.missionIds[0] == -1)
               {
                  §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_MISSION_LOAD,this.§_-G3j§,this.startInfo.battleType,[§_-N1V§.§_-I39§.§_-X1P§().§_-q29§[1]]);
               }
         }
      }
      
      private function §_-G3j§(param1:§_-81M§, param2:Array) : void
      {
         var _loc3_:Function = null;
         switch(param1)
         {
            case §_-81M§.§_-e1C§:
               _loc3_ = §_-X1j§.§_-12n§.§_-2n§;
               break;
            case §_-81M§.§_-p1U§:
               _loc3_ = §_-X1j§.§_-12n§.§_-A1Y§;
               break;
            case §_-81M§.§_-K23§:
               _loc3_ = §_-X1j§.§_-12n§.§_-IT§;
         }
         if(_loc3_ != null)
         {
            Application.§_-a1k§(false);
            _loc3_.apply(this,param2);
            hide();
         }
      }
      
      protected function §_-A3p§(param1:Event) : void
      {
         var e:Event = param1;
         super.hide();
         Application.§_-i1N§.§_-V6§(function():void
         {
            var _loc1_:UserProfile = startInfo.§_-D1h§()[startInfo.§_-D1h§().length - 1];
            Application.§_-a1k§(false);
            §_-X1j§.§_-12n§.§_-y1D§(_loc1_);
         },§_-21w§.§_-01l§);
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-12E§(§_-s2a§.BUTTON_TO_MENU);
         destroyOnRemove = true;
      }
      
      protected function §_-cw§(param1:§_-hK§) : void
      {
         var _loc2_:String = "";
         var _loc3_:String = "";
         var _loc4_:String = §_-s2a§.OPPONENT_SURRENDER_TITLE;
         var _loc5_:Boolean = param1.result.equals(§_-J1§.DRAW_GAME);
         if(this.startInfo.battleType == §_-81M§.§_-p1U§)
         {
            _loc2_ = _loc5_ ? §_-s2a§.DRAW_TITLE : §_-s2a§.WINNER_TITLE;
            _loc3_ = _loc5_ ? §_-s2a§.DRAW_TITLE : §_-s2a§.WINNER_TITLE;
         }
         else
         {
            _loc2_ = _loc5_ ? §_-s2a§.DRAW_TITLE : §_-s2a§.WINNER_TITLE;
            _loc3_ = §_-s2a§.LOOSER_TITLE;
         }
         (this.getChildByName("winner_title.text") as ITextRenderer).text = §_-s2a§.§_-K3t§(_loc2_);
         (this.getChildByName("loser_title.text") as ITextRenderer).text = §_-s2a§.§_-K3t§(_loc3_);
         (this.getChildByName("op_surrender_title.text") as ITextRenderer).text = §_-s2a§.§_-K3t§(_loc4_);
         (this.getChildByName("draw_title.text") as ITextRenderer).text = §_-s2a§.§_-K3t§(_loc2_);
         this.§_-x1l§(param1);
      }
      
      private function §_-x1l§(param1:§_-hK§) : void
      {
         var _loc2_:DisplayObject = this.getChildByName("winner_title");
         var _loc3_:DisplayObject = this.getChildByName("loser_title");
         var _loc4_:DisplayObject = this.getChildByName("op_surrender_title");
         var _loc5_:DisplayObject = this.getChildByName("draw_title");
         var _loc6_:DisplayObject = _loc2_;
         if(param1.result.equals(§_-J1§.§_-23m§))
         {
            _loc6_ = _loc3_;
         }
         if(param1.result.equals(§_-J1§.DRAW_GAME))
         {
            _loc6_ = _loc5_;
         }
         if(param1.status == false)
         {
            _loc6_ = _loc4_;
         }
         if(_loc6_ != _loc2_)
         {
            _loc2_.removeFromParent(true);
         }
         if(_loc6_ != _loc3_)
         {
            _loc3_.removeFromParent(true);
         }
         if(_loc6_ != _loc4_)
         {
            _loc4_.removeFromParent(true);
         }
         if(_loc6_ != _loc5_)
         {
            _loc5_.removeFromParent(true);
         }
         _loc6_.parent.setChildIndex(_loc6_,0);
      }
      
      protected function §_-C1§(param1:§_-hK§) : void
      {
         var _loc2_:String = null;
         var _loc3_:String = null;
         if(this.startInfo.battleType == §_-81M§.§_-p1U§)
         {
            if(param1.result.equals(§_-J1§.DRAW_GAME))
            {
               _loc3_ = §_-s2a§.BOSS_GAMEOVER_DRAW_DESCR;
            }
            else
            {
               _loc2_ = §_-s2a§.BTN_GREAT;
            }
         }
         else if(param1.result.equals(§_-J1§.§_-23m§))
         {
            _loc2_ = §_-s2a§.BOSS_GAMEOVER_LOSE_TITLE_2;
         }
         else if(param1.result.equals(§_-J1§.DRAW_GAME))
         {
            _loc3_ = §_-s2a§.BOSS_GAMEOVER_DRAW_DESCR;
         }
         else
         {
            _loc2_ = §_-s2a§.BTN_GREAT;
         }
         var _loc4_:ITextRenderer = §_-j2l§().getChildByName("winDescription") as ITextRenderer;
         if(_loc4_)
         {
            if(_loc2_)
            {
               _loc4_.text = §_-s2a§.§_-K3t§(_loc2_);
            }
            else
            {
               _loc4_.removeFromParent(true);
            }
         }
         _loc4_ = §_-j2l§().getChildByName("drawDescription") as ITextRenderer;
         if(_loc4_)
         {
            if(_loc3_)
            {
               _loc4_.text = §_-s2a§.§_-K3t§(_loc3_);
            }
            else
            {
               _loc4_.removeFromParent(true);
            }
         }
      }
      
      protected function initButtons(param1:§_-O2i§, param2:§_-hK§) : void
      {
         var _loc6_:UserProfile = null;
         var _loc3_:Boolean = false;
         var _loc4_:Boolean = false;
         var _loc5_:Boolean = false;
         _loc6_ = §_-33r§.§_-t2t§(this.startInfo.§_-b2W§());
         var _loc7_:Boolean = !_loc6_ || !this.startInfo.isAllyFriendOrClanmate;
         if(this.startInfo.battleType != §_-81M§.§_-p1U§)
         {
            _loc3_ = true;
         }
         if(this.§_-L2p§)
         {
            _loc4_ = true;
         }
         if(Boolean(param2.§_-n2J§ > 0 || this.startInfo.wager == §_-82X§.§_-F1d§) || Boolean(§_-X1j§.§_-p1c§.§_-5J§()) || Boolean(§_-X1j§.§_-p1c§.§_-c1Y§()))
         {
            _loc4_ = true;
            _loc3_ = true;
         }
         else if(this.startInfo.battleType == §_-81M§.§_-e1C§ && §_-X1j§.§_-B35§.§_-M1J§() || this.startInfo.battleType == §_-81M§.§_-Y1C§ && _loc7_)
         {
            this.§_-k1b§.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_NEXT_FIGHT);
            this.§_-k1b§.addEventListener(Event.TRIGGERED,this.§_-k1M§);
         }
         else if(this.startInfo.battleType == §_-81M§.§_-p1U§)
         {
            this.§_-k1b§.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_RESTART);
            this.§_-k1b§.addEventListener(Event.TRIGGERED,this.§_-k1M§);
            this.§_-Z28§.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SELECT_MAP);
            this.§_-Z28§.addEventListener(Event.TRIGGERED,this.§_-A3p§);
         }
         else
         {
            _loc4_ = true;
         }
         if(Boolean(param1.missionIds.length) && Boolean(param1.missionIds[0] == -1) && param2.§_-n2J§ == 0)
         {
            _loc4_ = false;
            this.§_-k1b§.addEventListener(Event.TRIGGERED,this.§_-k1M§);
            this.§_-k1b§.label = §_-s2a§.§_-K3t§(§_-u2T§.NEXT_HELP_TEXT_BTN);
            _loc5_ = true;
         }
         if(_loc3_)
         {
            this.§_-Z28§.removeFromParent(true);
            this.§_-Z28§ = null;
         }
         if(_loc4_)
         {
            this.§_-k1b§.removeFromParent(true);
            this.§_-k1b§ = null;
         }
         if(_loc5_)
         {
            okBtn.removeEventListeners();
            okBtn.removeFromParent(true);
            okBtn = null;
         }
      }
      
      protected function §_-Nn§(param1:DisplayObject) : void
      {
         var _loc2_:int = 0;
         if(param1)
         {
            _loc2_ = param1.parent.getChildIndex(param1) + 1;
            this.§_-G3N§.parent.setChildIndex(this.§_-G3N§,_loc2_);
         }
      }
      
      override protected function §_-Eh§() : DisplayObject
      {
         return §_-lY§(0.7);
      }
      
      override public function §_-X2O§() : void
      {
         this.§_-b1H§();
      }
      
      override public function getChildByName(param1:String) : DisplayObject
      {
         return §_-YQ§.getClip(param1,§_-j2l§());
      }
      
      override public function dispose() : void
      {
         if(Boolean(this.§_-k1b§) && this.§_-k1b§.hasEventListener(Event.TRIGGERED))
         {
            this.§_-k1b§.removeEventListener(Event.TRIGGERED,this.§_-k1M§);
         }
         if(Boolean(this.§_-Z28§) && this.§_-Z28§.hasEventListener(Event.TRIGGERED))
         {
            this.§_-Z28§.removeEventListener(Event.TRIGGERED,this.§_-A3p§);
         }
         this.§_-Z28§ = §_-c1S§.dispose(this.§_-Z28§) as Button;
         this.§_-k1b§ = §_-c1S§.dispose(this.§_-k1b§) as Button;
         this.§_-k6§(this.§_-G3N§);
         this.§_-G3N§.dispose();
         super.dispose();
      }
      
      public function §_-92T§() : void
      {
         this.§_-L2p§ = true;
      }
   }
}


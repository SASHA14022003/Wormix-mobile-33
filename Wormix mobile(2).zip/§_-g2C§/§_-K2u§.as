package §_-g2C§
{
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   
   public class §_-K2u§ extends §_-h2O§
   {
      
      private var message:TextFieldTextRenderer;
      
      public function §_-K2u§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.message = TextInstanceCreator.createTextRenderer(FontSize.TINY,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.message.wordWrap = true;
         this.message.isHTML = true;
         defaultIcon = this.message;
         iconOffsetX = §_-UX§;
      }
      
      override protected function commitData() : void
      {
         if(_data == null)
         {
            return;
         }
         var _loc1_:String = _data.text as String;
         if(_loc1_)
         {
            this.message.text = _loc1_;
         }
      }
      
      override protected function resize() : void
      {
         super.resize();
         this.message.width = _owner.width - §_-UX§ * 2;
      }
   }
}


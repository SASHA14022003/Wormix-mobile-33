package §_-g2C§
{
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   
   public class GlobalChatTextMessageItemRenderer extends §_-h2O§
   {
      
      private var message:TextFieldTextRenderer;
      
      private var binder:Binder;
      
      public function GlobalChatTextMessageItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.message = TextInstanceCreator.createTextRenderer(FontSize.TINY,FontColor.WHITE,TextFormatAlign.LEFT) as TextFieldTextRenderer;
         this.message.wordWrap = true;
         this.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         };
         defaultIcon = this.message;
         labelOffsetX = §_-UX§;
         iconOffsetX = §_-UX§;
      }
      
      override protected function commitData() : void
      {
         var _loc2_:String = null;
         var _loc1_:ChatMessage = _data as ChatMessage;
         if(_loc1_)
         {
            _loc2_ = _loc1_.profileName ? _loc1_.profileName : §_-33r§.§_-k2R§;
            label = _loc2_;
            this.message.text = _loc1_.message;
         }
      }
      
      override protected function resize() : void
      {
         super.resize();
         this.message.width = _owner.width - §_-UX§ * 2;
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.LayoutGroup;
import starlingbuilder.extensions.uicomponents.CustomLabel;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _textsLayout:LayoutGroup;
   
   public var _name:CustomLabel;
   
   public var _msg:CustomLabel;
   
   public var _smile:ImageLoader;
   
   public var _line:LayoutGroup;
   
   public function Binder()
   {
      super();
   }
}

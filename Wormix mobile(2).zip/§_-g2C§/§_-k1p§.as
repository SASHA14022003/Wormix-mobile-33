package §_-g2C§
{
   import §_-5Y§.§_-33Y§;
   import §_-82l§.§_-A2Y§;
   import §_-CR§.§_-72p§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import feathers.utils.textures.TextureCache;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import starling.display.Quad;
   import starling.events.Event;
   
   public class §_-k1p§ extends §_-33Y§
   {
      
      private static const TEXT_MSG_RENDERER:String = "msg-text";
      
      private static const CHAT_MSG_RENDERER:String = "msg-chat";
      
      private static const STICKER_MSG_RENDERER:String = "msg-sticker";
      
      private static const CRAFT_LEGENDARY_MSG_RENDERER:String = "msg-legendary";
      
      private static const ADMIN_MSG_RENDERER:String = "msg-admin";
      
      private static const §_-C1u§:String = "msg-admin-pinned";
      
      private static const SYSTEM_MSG_RENDERER:String = "msg-system";
      
      public function §_-k1p§(param1:Array, param2:String, param3:TextureCache = null)
      {
         super(param1,param2,param3);
      }
      
      override protected function §_-o1t§() : void
      {
         §_-C20§ = new List();
         §_-C20§.backgroundSkin = new Quad(16,16,2041646);
         addChild(§_-C20§);
      }
      
      override protected function §_-C3§() : void
      {
         var layout:VerticalLayout;
         var textItemFactory:Function;
         var systemTextItemFactory:Function;
         var craftLegendaryItemFactory:Function;
         var adminItemFactory:Function;
         var adminPinnedItemFactory:Function;
         var textMessageItemFactory:Function;
         var stickerItemFactory:Function;
         var textureCache:TextureCache = null;
         Application.§_-ow§.addEventListener(Event.CLOSE,this.§_-42q§);
         §_-C20§.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         §_-C20§.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.layout = new AnchorLayout();
         §_-C20§.layoutData = new AnchorLayoutData(0,0,0,0);
         layout = §_-y2P§() as VerticalLayout;
         layout.gap = §_-Z2f§;
         §_-C20§.layout = layout;
         this.initList(§_-C20§);
         textItemFactory = function():IListItemRenderer
         {
            return new §_-K2A§();
         };
         systemTextItemFactory = function():IListItemRenderer
         {
            return new §_-K2u§();
         };
         craftLegendaryItemFactory = function():IListItemRenderer
         {
            return new §_-I1R§();
         };
         adminItemFactory = function():IListItemRenderer
         {
            return new §_-62U§();
         };
         adminPinnedItemFactory = function():IListItemRenderer
         {
            return new §_-p8§();
         };
         textMessageItemFactory = function():IListItemRenderer
         {
            return new GlobalChatTextMessageItemRenderer();
         };
         textureCache = §_-g20§.§_-W2i§();
         stickerItemFactory = function():IListItemRenderer
         {
            var _loc1_:§_-w1K§ = new §_-w1K§();
            _loc1_.textureCache = textureCache;
            return _loc1_;
         };
         §_-C20§.setItemRendererFactoryWithID(TEXT_MSG_RENDERER,textItemFactory);
         §_-C20§.setItemRendererFactoryWithID(CHAT_MSG_RENDERER,textMessageItemFactory);
         §_-C20§.setItemRendererFactoryWithID(CRAFT_LEGENDARY_MSG_RENDERER,craftLegendaryItemFactory);
         §_-C20§.setItemRendererFactoryWithID(STICKER_MSG_RENDERER,stickerItemFactory);
         §_-C20§.setItemRendererFactoryWithID(ADMIN_MSG_RENDERER,adminItemFactory);
         §_-C20§.setItemRendererFactoryWithID(§_-C1u§,adminItemFactory);
         §_-C20§.setItemRendererFactoryWithID(SYSTEM_MSG_RENDERER,systemTextItemFactory);
         §_-C20§.factoryIDFunction = function(param1:Object, param2:int):String
         {
            var _loc3_:String = null;
            var _loc4_:ChatMessage = null;
            if(param1 is ChatMessage)
            {
               _loc4_ = param1 as ChatMessage;
               switch(_loc4_.action)
               {
                  case §_-A2Y§.§_-vu§:
                     _loc3_ = CHAT_MSG_RENDERER;
                     break;
                  case §_-A2Y§.§_-92j§:
                     _loc3_ = CRAFT_LEGENDARY_MSG_RENDERER;
                     break;
                  case §_-A2Y§.§_-82y§:
                     _loc3_ = STICKER_MSG_RENDERER;
                     break;
                  case §_-A2Y§.§_-v2j§:
                     _loc3_ = ADMIN_MSG_RENDERER;
                     break;
                  default:
                     _loc3_ = TEXT_MSG_RENDERER;
               }
            }
            else
            {
               _loc3_ = SYSTEM_MSG_RENDERER;
            }
            return _loc3_;
         };
         §_-OU§ = new §_-72p§(§_-C20§,this.§_-Gw§,[RelativePosition.LEFT,RelativePosition.RIGHT],true,Direction.VERTICAL);
         §_-OU§.§_-H2L§ = this.§_-w4§;
      }
      
      override protected function initList(param1:List) : void
      {
         super.initList(param1);
         param1.clipContent = false;
      }
      
      private function §_-42q§(param1:Event) : void
      {
         §_-OU§.§_-d1e§();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         Application.§_-ow§.removeEventListener(Event.CLOSE,this.§_-42q§);
      }
      
      private function §_-Gw§(param1:Object) : int
      {
         var _loc2_:ChatMessage = param1 as ChatMessage;
         return _loc2_ ? _loc2_.profileId : 0;
      }
      
      private function §_-w4§(param1:Object) : int
      {
         var _loc2_:ChatMessage = param1 as ChatMessage;
         return _loc2_ ? int(parseInt(_loc2_.platformId)) : 0;
      }
      
      public function §_-Zu§() : void
      {
         if(!§_-C20§)
         {
            return;
         }
         if(§_-C20§.isScrolling)
         {
         }
         §_-C20§.validate();
         §_-C20§.scrollToPosition(0,§_-C20§.maxVerticalScrollPosition,0);
      }
   }
}


package §_-g2C§
{
   import §_-5Y§.§_-Ma§;
   import feathers.controls.List;
   
   public class §_-h2O§ extends §_-Ma§
   {
      
      protected static const §_-01L§:uint = 4096;
      
      public function §_-h2O§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
      }
      
      override protected function draw() : void
      {
         super.draw();
      }
      
      override protected function resize() : void
      {
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      override protected function get highlightBgColor() : uint
      {
         return §_-01L§;
      }
   }
}


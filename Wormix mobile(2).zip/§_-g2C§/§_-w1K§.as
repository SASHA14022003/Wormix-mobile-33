package §_-g2C§
{
   import §_-Vg§.§_-K3K§;
   import §_-m2s§.§_-R11§;
   import feathers.controls.ImageLoader;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import feathers.utils.textures.TextureCache;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import starling.utils.ScaleMode;
   
   public class §_-w1K§ extends §_-h2O§
   {
      
      private static const §_-PH§:String = "texture_cache";
      
      private var §_-B1M§:ImageLoader;
      
      private var _textureCache:TextureCache;
      
      public function §_-w1K§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         };
         this.§_-B1M§ = new ImageLoader();
         this.§_-B1M§.scaleMode = ScaleMode.SHOW_ALL;
         this.§_-B1M§.scaleContent = false;
         this.§_-B1M§.horizontalAlign = HorizontalAlign.LEFT;
         this.§_-B1M§.verticalAlign = VerticalAlign.MIDDLE;
         this.§_-B1M§.scaleFactor = 1;
         this.§_-B1M§.maintainAspectRatio = true;
         this.§_-B1M§.height = 125;
         defaultIcon = this.§_-B1M§;
         labelOffsetX = §_-UX§;
         iconOffsetX = §_-UX§;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(§_-PH§) && Boolean(this.§_-B1M§))
         {
            this.§_-B1M§.textureCache = this.textureCache;
         }
      }
      
      override protected function commitData() : void
      {
         var _loc2_:String = null;
         var _loc3_:§_-R11§ = null;
         var _loc1_:ChatMessage = _data as ChatMessage;
         if(_loc1_)
         {
            _loc2_ = _loc1_.profileName ? _loc1_.profileName : §_-33r§.§_-k2R§;
            label = _loc2_;
            _loc3_ = §_-R11§.§_-J1V§(_loc1_.message);
            this.§_-B1M§.source = §_-g20§.§_-3i§(_loc3_.§_-t1X§,_loc3_.§_-Wl§);
         }
      }
      
      override protected function resize() : void
      {
         super.resize();
         this.§_-B1M§.width = _owner.width - §_-UX§ * 2;
      }
      
      public function get textureCache() : TextureCache
      {
         return this._textureCache;
      }
      
      public function set textureCache(param1:TextureCache) : void
      {
         this._textureCache = param1;
         invalidate(§_-PH§);
      }
   }
}


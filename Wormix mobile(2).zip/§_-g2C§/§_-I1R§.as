package §_-g2C§
{
   import §_-B1y§.§_-F1P§;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   
   public class §_-I1R§ extends §_-h2O§
   {
      
      private var message:TextFieldTextRenderer;
      
      public function §_-I1R§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.message = TextInstanceCreator.createTextRenderer(FontSize.TINY,6598399,TextFormatAlign.LEFT) as TextFieldTextRenderer;
         this.message.wordWrap = true;
         defaultIcon = this.message;
         iconOffsetX = §_-UX§;
      }
      
      override protected function commitData() : void
      {
         var _loc2_:String = null;
         var _loc3_:int = 0;
         var _loc4_:String = null;
         var _loc5_:String = null;
         var _loc1_:ChatMessage = _data as ChatMessage;
         if(_loc1_)
         {
            _loc2_ = _loc1_.profileName ? _loc1_.profileName : §_-33r§.§_-k2R§;
            _loc3_ = int(int(_loc1_.params));
            if(§_-2t§.§_-k1R§(_loc3_))
            {
               _loc4_ = §_-s2a§.§_-K3t§(§_-s2a§.MEMBER_CRAFT_LEGENDARY_MESSAGE);
               _loc5_ = §_-2t§.§_-n2Z§(_loc3_);
               this.message.text = §_-F1P§.format(_loc4_,{
                  "name":_loc2_,
                  "item":_loc5_
               });
            }
         }
      }
      
      override protected function resize() : void
      {
         super.resize();
         this.message.width = _owner.width - §_-UX§ * 2;
      }
   }
}


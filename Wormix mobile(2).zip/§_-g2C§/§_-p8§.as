package §_-g2C§
{
   import starling.events.Event;
   
   public class §_-p8§ extends §_-62U§
   {
      
      public function §_-p8§()
      {
         super();
         limit = §_-R2P§ * 0.5;
      }
      
      override protected function feathersControl_addedToStageHandler(param1:Event) : void
      {
         super.feathersControl_addedToStageHandler(param1);
         if(parent == null)
         {
            return;
         }
         message.width = parent.width - §_-UX§ * 2;
      }
   }
}


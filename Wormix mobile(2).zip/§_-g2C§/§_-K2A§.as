package §_-g2C§
{
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   
   public class §_-K2A§ extends §_-h2O§
   {
      
      private var message:TextFieldTextRenderer;
      
      public function §_-K2A§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.message = TextInstanceCreator.createTextRenderer(FontSize.TINY,FontColor.WHITE,TextFormatAlign.LEFT) as TextFieldTextRenderer;
         this.message.wordWrap = true;
         this.message.isHTML = true;
         this.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.NORMAL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         };
         defaultIcon = this.message;
         labelOffsetX = §_-UX§;
         iconOffsetX = §_-UX§;
      }
      
      override protected function commitData() : void
      {
         var _loc1_:ChatMessage = _data as ChatMessage;
         if(_loc1_)
         {
            label = _loc1_.profileName ? _loc1_.profileName : §_-33r§.§_-k2R§;
            this.message.text = _loc1_.message;
         }
      }
      
      override protected function resize() : void
      {
         super.resize();
         this.message.width = _owner.width - §_-UX§ * 2;
      }
   }
}


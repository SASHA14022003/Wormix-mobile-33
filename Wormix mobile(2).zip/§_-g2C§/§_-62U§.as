package §_-g2C§
{
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.utils.StringUtil;
   
   public class §_-62U§ extends §_-h2O§
   {
      
      protected static const §_-R2P§:int = 1024;
      
      protected var message:TextFieldTextRenderer;
      
      protected var limit:int = 1024;
      
      public function §_-62U§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.message = TextInstanceCreator.createTextRenderer(FontSize.TINY,11468718,TextFormatAlign.LEFT) as TextFieldTextRenderer;
         this.message.wordWrap = true;
         this.message.isHTML = true;
         this.labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.NORMAL,6986346,TextFormatAlign.LEFT) as TextFieldTextRenderer;
         };
         defaultIcon = this.message;
         labelOffsetX = §_-UX§;
         iconOffsetX = §_-UX§;
      }
      
      override protected function commitData() : void
      {
         label = §_-s2a§.§_-K3t§(§_-s2a§.ADMIN_CHAT_MESSAGE);
         var _loc1_:ChatMessage = _data as ChatMessage;
         if(_loc1_)
         {
            this.message.text = StringUtil.§_-jT§(_loc1_.message,this.limit);
         }
      }
      
      override protected function resize() : void
      {
         super.resize();
         this.message.width = _owner.width - §_-UX§ * 2;
      }
   }
}


package §_-i1D§
{
   import §_-k1u§.§_-Oi§;
   import §_-s20§.§_-J2g§;
   import config.§_-vR§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.CrashLog;
   import ru.pragmatix.wormix.messages.structures.UnitStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-9b§
   {
      
      private static const §_-GC§:int = 10;
      
      private static var §_-C2g§:int = 0;
      
      private static var §_-ra§:Vector.<String> = new Vector.<String>(0);
      
      public function §_-9b§()
      {
         super();
      }
      
      public static function §_-C2N§(param1:String) : void
      {
         var crashLog:CrashLog = null;
         var log:String = param1;
         if(§_-ra§.indexOf(log) > -1)
         {
            return;
         }
         §_-ra§.push(log);
         if(log.indexOf("com.hurlant.crypto.tls") > -1 && §_-vR§.§_-42H§)
         {
            return;
         }
         if(§_-C2g§++ > §_-GC§)
         {
            return;
         }
         crashLog = new CrashLog();
         try
         {
            crashLog.platform = §_-X1j§.§_-It§.getPlatformType().name;
         }
         catch(e:Error)
         {
            crashLog.platform = SystemUtil.platform || §_-vR§.§_-I1d§ || "NaN";
         }
         try
         {
            if(Boolean(Application.userProfile) && Boolean(Application.userProfile.getId()))
            {
               crashLog.userId = Application.userProfile.getId().toString();
            }
            else if(Boolean(§_-X1j§.§_-It§) && Boolean(§_-X1j§.§_-It§.getUserId()))
            {
               crashLog.userId = §_-X1j§.§_-It§.getUserId();
            }
            else
            {
               crashLog.userId = "NaN";
            }
         }
         catch(e:Error)
         {
            §§push(e);
            var _temp_10:* = e;
            e = §§pop();
            crashLog.userId = "NaN";
         }
         crashLog.log = log;
         §_-J2g§.§_-h18§(crashLog);
      }
   }
}


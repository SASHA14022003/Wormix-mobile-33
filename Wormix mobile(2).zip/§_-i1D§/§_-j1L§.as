package §_-i1D§
{
   import §_-31W§.§_-r26§;
   import §_-62§.*;
   import §_-A1K§.§_-TA§;
   import §_-N8§.§_-o2w§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.*;
   import §_-s20§.§_-J2g§;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.messages.client.DesyncLog;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   
   public class §_-j1L§
   {
      
      private var §_-rI§:Array;
      
      private var §_-u1r§:DesyncLog;
      
      public function §_-j1L§()
      {
         super();
         this.§_-rI§ = [];
      }
      
      public function §_-N1p§(... rest) : void
      {
         var _loc4_:* = undefined;
         var _loc5_:String = null;
         var _loc2_:String = "";
         var _loc3_:Boolean = true;
         for each(_loc4_ in rest)
         {
            if(_loc4_ == null)
            {
               _loc5_ = "[null]";
            }
            else if(!("toString" in _loc4_))
            {
               _loc5_ = "[object " + getQualifiedClassName(_loc4_) + "]";
            }
            else
            {
               _loc5_ = _loc4_;
            }
            if(_loc3_)
            {
               _loc2_ = _loc5_;
               _loc3_ = false;
            }
            else
            {
               _loc2_ += ", " + _loc5_;
            }
         }
         this.§_-rI§.push(_loc2_);
      }
      
      public function clear() : void
      {
         this.§_-rI§.splice(0);
      }
      
      public function §_-y2l§(param1:§_-O2i§) : void
      {
         this.§_-u1r§ = new DesyncLog();
         this.§_-u1r§.battleId = param1.battleId;
         if(param1.wager)
         {
            this.§_-u1r§.battleType = param1.wager.battleType ? param1.wager.battleType.value : 2;
         }
         else
         {
            this.§_-u1r§.battleType = param1.battleType.value;
         }
         this.§_-u1r§.wager = param1.wager ? int(param1.wager.id) : 0;
         this.§_-u1r§.mapId = param1.mapId;
         this.§_-u1r§.missionIds = param1.missionIds;
         this.§_-u1r§.battleLogs = this.§_-rI§.concat();
         §_-J2g§.§_-h18§(this.§_-u1r§);
      }
      
      public function §_-vL§() : void
      {
         if(this.§_-u1r§)
         {
            §_-J2g§.§_-h18§(this.§_-u1r§);
         }
      }
      
      public function dispose() : void
      {
         this.§_-rI§ = null;
      }
   }
}


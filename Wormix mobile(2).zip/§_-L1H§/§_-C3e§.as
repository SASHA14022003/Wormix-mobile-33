package §_-L1H§
{
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-91A§.§_-sH§;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-i1i§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-vO§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.TiledColumnsLayout;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.pvp.messages.client.BattleReconnect;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-C3e§
   {
      
      public var ammoClassName:String;
      
      public var damage:§_-TA§;
      
      public var damageRadius:§_-TA§;
      
      public var explosionRadius:§_-TA§;
      
      public var pushForce:§_-TA§;
      
      public function §_-C3e§()
      {
         super();
      }
      
      public static function §_-y1O§(param1:String, param2:int, param3:int, param4:int, param5:int = 0) : §_-C3e§
      {
         var _loc6_:§_-C3e§ = new §_-C3e§();
         _loc6_.ammoClassName = param1;
         _loc6_.damage = new §_-TA§(param2);
         _loc6_.damageRadius = new §_-TA§(param3);
         _loc6_.explosionRadius = new §_-TA§(param4);
         _loc6_.pushForce = new §_-TA§(param5);
         return _loc6_;
      }
      
      public function set clipClassName(param1:String) : void
      {
         this.ammoClassName = param1;
      }
      
      public function clone() : §_-C3e§
      {
         var _loc1_:§_-C3e§ = new §_-C3e§();
         var _loc2_:§_-TA§ = new §_-TA§(0);
         _loc1_.ammoClassName = this.ammoClassName;
         _loc1_.damage = this.damage ? new §_-TA§(this.damage.value) : _loc2_;
         _loc1_.damageRadius = this.damageRadius ? new §_-TA§(this.damageRadius.value) : _loc2_;
         _loc1_.explosionRadius = this.explosionRadius ? new §_-TA§(this.explosionRadius.value) : _loc2_;
         _loc1_.pushForce = this.pushForce ? new §_-TA§(this.pushForce.value) : _loc2_;
         return _loc1_;
      }
   }
}


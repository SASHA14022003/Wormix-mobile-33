package §_-L1H§
{
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-XA§;
   import §_-YF§.§_-q2v§;
   import §_-Yi§.§_-EG§;
   import §_-f1Q§.*;
   import §_-j1w§.§_-lD§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import config.*;
   import feathers.controls.List;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-y1M§
   {
      
      public var clipClass:String;
      
      public var §_-T17§:String;
      
      public var type:String = "clip";
      
      public var action:String;
      
      public var charParams:Array = [new §_-62I§()];
      
      public var secondaryCharParams:Array;
      
      public function §_-y1M§()
      {
         super();
      }
      
      public static function §_-Z1i§(param1:Object) : §_-y1M§
      {
         var _loc3_:String = null;
         var _loc2_:§_-y1M§ = new §_-y1M§();
         if(param1.clipClass)
         {
            _loc2_.clipClass = param1.clipClass;
         }
         if(param1.type)
         {
            _loc2_.type = param1.type;
         }
         if(param1.action)
         {
            _loc2_.action = param1.action;
         }
         if(Boolean(param1.secondaryClip) && Boolean(param1.secondaryClip.clipClass))
         {
            _loc2_.§_-T17§ = param1.secondaryClip.clipClass;
         }
         if(param1.charParams)
         {
            for(_loc3_ in param1.charParams)
            {
               _loc2_.charParams = §_-c2g§(param1.charParams);
            }
            if(Boolean(param1.secondaryClip) && Boolean(param1.secondaryClip.charParams))
            {
               _loc2_.secondaryCharParams = §_-c2g§(param1.secondaryClip.charParams);
            }
         }
         return _loc2_;
      }
      
      private static function §_-c2g§(param1:Object) : Array
      {
         var _loc3_:String = null;
         var _loc4_:Object = null;
         var _loc5_:§_-62I§ = null;
         var _loc2_:Array = [];
         for(_loc3_ in param1)
         {
            if(param1.hasOwnProperty(_loc3_))
            {
               _loc4_ = param1[_loc3_];
               _loc5_ = new §_-62I§();
               _loc5_.charName = _loc3_;
               if(_loc4_.hideHands)
               {
                  _loc5_.hideHands = _loc4_.hideHands;
               }
               if(_loc4_.x)
               {
                  _loc5_.x = _loc4_.x;
               }
               if(_loc4_.y)
               {
                  _loc5_.y = _loc4_.y;
               }
               _loc2_.push(_loc5_);
            }
         }
         return _loc2_;
      }
      
      public function §_-Q1t§(param1:String, param2:Boolean = false) : §_-62I§
      {
         var _loc3_:Array = param2 ? this.secondaryCharParams : this.charParams;
         var _loc4_:§_-62I§ = null;
         var _loc5_:int = 0;
         while(_loc5_ < _loc3_.length)
         {
            if(_loc3_[_loc5_].charName == param1)
            {
               _loc4_ = _loc3_[_loc5_];
               break;
            }
            if(_loc4_ == null && _loc3_[_loc5_].charName == §_-lD§.§_-81B§)
            {
               _loc4_ = _loc3_[_loc5_];
            }
            _loc5_++;
         }
         return _loc4_;
      }
      
      public function §_-83x§(param1:String) : §_-62I§
      {
         return this.§_-Q1t§(param1,true);
      }
   }
}


package §_-o14§
{
   import §_-5Y§.§_-91y§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-Dd§ extends §_-91y§
   {
      
      public var profile:UserProfile;
      
      public var isTeamMsg:Boolean;
      
      public var §_-Q2i§:String;
      
      public function §_-Dd§(param1:String, param2:int, param3:UserProfile, param4:Boolean = false, param5:String = "")
      {
         super(param1,param2);
         this.profile = param3;
         this.isTeamMsg = param4;
         this.§_-Q2i§ = param5;
      }
   }
}


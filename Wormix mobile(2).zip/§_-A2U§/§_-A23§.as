package §_-A2U§
{
   import §_-62§.§_-G1p§;
   import §_-91B§.§_-QK§;
   import §_-D3A§.§_-TZ§;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-ZP§.§_-H1H§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-y1s§.§_-p6§;
   import §_-z1g§.*;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalLayout;
   import flash.display.DisplayObject;
   import flash.geom.Point;
   import flash.net.LocalConnection;
   import flash.system.Capabilities;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-B1m§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-A23§ implements §_-SG§
   {
      
      private static var instance:§_-A23§;
      
      private static var §_-8X§:ClanTO;
      
      public static var startSeasonDate:int;
      
      public static var finishSeasonDate:int;
      
      private var clans:Object = {};
      
      private var invites:Vector.<ClanInviteStructure> = new Vector.<ClanInviteStructure>();
      
      private var §_-U9§:Vector.<ClanChatMessageTO> = new Vector.<ClanChatMessageTO>();
      
      private var news:ClanNewsTO;
      
      public function §_-A23§()
      {
         super();
      }
      
      public static function getInstance() : §_-A23§
      {
         if(!instance)
         {
            instance = new §_-A23§();
         }
         return instance;
      }
      
      public static function §_-o2G§(param1:ClanTO) : void
      {
         var _loc2_:ClanTO = getInstance().clans[param1.id];
         getInstance().clans[param1.id] = param1;
         if(Boolean(_loc2_) && param1.members.length == 0)
         {
            param1.members = _loc2_.members;
         }
         if(Boolean(§_-8X§) && param1.id == §_-8X§.id)
         {
            §_-8X§.copyFrom(param1);
         }
      }
      
      public static function §_-J3a§(param1:int) : void
      {
         var _loc2_:ClanTO = getInstance().clans[param1];
         if(_loc2_)
         {
            delete getInstance().clans[param1];
         }
      }
      
      public static function §_-q2R§(param1:UserProfile) : ClanTO
      {
         if(param1.§_-ia§())
         {
            return getInstance().clans[param1.clanMember.clanId];
         }
         return null;
      }
      
      public static function §_-Y1d§(param1:int) : ClanTO
      {
         return getInstance().clans[param1];
      }
      
      public static function §_-q2B§(param1:ClanChatMessageTO) : void
      {
         getInstance().§_-U9§.push(param1);
      }
      
      public static function §_-82c§() : Vector.<ClanChatMessageTO>
      {
         return getInstance().§_-U9§;
      }
      
      public static function §_-Yc§() : void
      {
         getInstance().§_-U9§.length = 0;
      }
      
      public static function §_-x1D§(param1:Vector.<ClanInviteStructure>) : void
      {
         getInstance().invites = param1;
      }
      
      public static function §_-k5§(param1:ClanInviteStructure) : void
      {
         getInstance().invites.push(param1);
      }
      
      public static function §_-r20§() : void
      {
         getInstance().invites.length = 0;
      }
      
      public static function §_-E2Z§() : Vector.<ClanInviteStructure>
      {
         return getInstance().invites;
      }
      
      public static function §_-K3I§() : Boolean
      {
         return §_-E2Z§().length > 0;
      }
      
      public static function §_-93c§(param1:ClanNewsTO) : void
      {
         getInstance().news = param1;
      }
      
      public static function §_-P1s§() : ClanNewsTO
      {
         return getInstance().news;
      }
      
      public static function §_-m2G§() : int
      {
         return §_-8X§.treasury;
      }
      
      public static function get userClan() : ClanTO
      {
         return §_-8X§;
      }
      
      public static function set userClan(param1:ClanTO) : void
      {
         §_-8X§ = param1;
      }
   }
}


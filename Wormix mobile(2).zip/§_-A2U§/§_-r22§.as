package §_-A2U§
{
   import §_-21p§.§_-N1H§;
   
   public interface §_-r22§
   {
      
      function §_-V1v§(param1:Boolean = false) : §_-N1H§;
      
      function §_-q1k§(param1:Object) : void;
   }
}


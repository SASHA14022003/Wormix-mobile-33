package §_-Cl§
{
   import §_-12a§.§_-lc§;
   import §_-F39§.§_-a2W§;
   import feathers.controls.Button;
   import feathers.controls.TextInput;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import flash.media.SoundMixer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.utils.Align;
   
   public class §_-S20§
   {
      
      public function §_-S20§()
      {
         super();
      }
      
      public static function §_-Ho§(param1:XML) : DisplayObject
      {
         var _loc2_:DisplayObject = null;
         var _loc14_:TextInput = null;
         var _loc15_:ITextRenderer = null;
         var _loc16_:Number = NaN;
         var _loc17_:Number = NaN;
         var _loc18_:String = null;
         var _loc19_:TextFormat = null;
         var _loc20_:TextField = null;
         var _loc3_:String = param1.@fieldType;
         var _loc4_:Boolean = param1.@normaltextfield == "true";
         var _loc5_:String = param1.@font;
         var _loc6_:uint = uint(param1.@size);
         var _loc7_:uint = uint(param1.@color);
         var _loc8_:uint = param1.@promptColor.toString() != "" ? uint(param1.@promptColor) : uint(param1.@color);
         var _loc9_:String = param1.@align;
         var _loc10_:Boolean = param1.@ishtml == "true";
         var _loc11_:Boolean = param1.@wordWrap == "true";
         var _loc12_:int = int(param1.@letterSpacing);
         var _loc13_:String = param1.@text;
         if(_loc3_ == "input")
         {
            _loc14_ = new TextInput();
            _loc14_.text = _loc13_;
            _loc2_ = _loc14_;
         }
         else if(_loc4_ != true)
         {
            _loc15_ = §_-R2g§.createTextRenderer(_loc5_,_loc6_,_loc7_,_loc9_,_loc11_,_loc10_,_loc12_);
            _loc15_.text = _loc13_;
            _loc2_ = _loc15_ as FeathersControl;
            _loc2_.touchable = false;
         }
         else
         {
            _loc16_ = Number(param1.@width);
            _loc17_ = Number(param1.@height);
            _loc18_ = param1.@bold;
            _loc19_ = new TextFormat(_loc5_,_loc6_,_loc7_,_loc18_);
            _loc20_ = new TextField(_loc16_,_loc17_,_loc13_,_loc19_);
            _loc20_.format.verticalAlign = Align.TOP;
            _loc20_.format.horizontalAlign = _loc9_;
            _loc20_.batchable = true;
            _loc20_.text = _loc13_;
            _loc2_ = _loc20_;
            _loc2_.touchable = false;
         }
         §_-K3v§.§_-v28§(_loc2_,param1);
         return _loc2_;
      }
   }
}


package §_-Cl§
{
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-63U§.*;
   import §_-73I§.*;
   import §_-73d§.§_-V19§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-83E§;
   import §_-D3A§.§_-TZ§;
   import §_-L1H§.§_-C3e§;
   import §_-P1B§.§_-b21§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-fo§.§_-r5§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-t1R§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-zI§.§_-g1a§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.hurlant.crypto.tls.§_-21v§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ButtonGroup;
   import feathers.controls.GroupedList;
   import feathers.controls.ImageLoader;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScrollContainer;
   import feathers.controls.TabBar;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.ILayout;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.MovieClip;
   import flash.display.StageDisplayState;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.ArenaLocked;
   import ru.pragmatix.wormix.messages.server.StartBattleResult;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.AmmoPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-G2L§
   {
      
      public function §_-G2L§()
      {
         super();
      }
      
      public static function §_-E1b§(param1:XML) : List
      {
         var _loc2_:List = null;
         _loc2_ = new List();
         _loc2_.layout = §_-y2P§(param1);
         §_-036§(_loc2_,param1);
         §_-j1v§(_loc2_,param1);
         return _loc2_;
      }
      
      public static function §_-93R§(param1:XML) : GroupedList
      {
         var _loc2_:GroupedList = new GroupedList();
         _loc2_.layout = §_-y2P§(param1);
         §_-036§(_loc2_,param1);
         §_-j1v§(_loc2_,param1);
         return _loc2_;
      }
      
      public static function §_-y2C§(param1:XML) : LayoutGroup
      {
         var _loc2_:LayoutGroup = new LayoutGroup();
         _loc2_.layout = §_-y2P§(param1);
         §_-036§(_loc2_,param1);
         §_-j1v§(_loc2_,param1);
         return _loc2_;
      }
      
      public static function §_-227§(param1:XML) : ScrollContainer
      {
         var _loc2_:ScrollContainer = new ScrollContainer();
         _loc2_.layout = §_-y2P§(param1);
         §_-036§(_loc2_,param1);
         §_-j1v§(_loc2_,param1);
         return _loc2_;
      }
      
      public static function §_-l2x§(param1:XML) : TabBar
      {
         var _loc2_:TabBar = new TabBar();
         §_-036§(_loc2_,param1);
         §_-j1v§(_loc2_,param1);
         if(param1.hasOwnProperty("@gap"))
         {
            _loc2_.gap = Number(param1.@gap);
         }
         if(param1.hasOwnProperty("@direction"))
         {
            _loc2_.direction = String(param1.@direction);
         }
         return _loc2_;
      }
      
      public static function §_-U1v§(param1:XML) : ImageLoader
      {
         var _loc2_:ImageLoader = new ImageLoader();
         §_-036§(_loc2_,param1);
         var _loc3_:String = param1.@textureName.toString();
         _loc2_.source = Application.assetManager.getTexture(_loc3_);
         return _loc2_;
      }
      
      public static function §_-12c§(param1:XML) : ButtonGroup
      {
         var _loc2_:ButtonGroup = new ButtonGroup();
         §_-036§(_loc2_,param1);
         if(param1.hasOwnProperty("@gap"))
         {
            _loc2_.gap = Number(param1.@gap);
         }
         if(param1.hasOwnProperty("@direction"))
         {
            _loc2_.direction = String(param1.@direction);
         }
         return _loc2_;
      }
      
      private static function §_-036§(param1:DisplayObject, param2:XML) : void
      {
         param1.x = Number(param2.@x);
         param1.y = Number(param2.@y);
         param1.scaleX = Number(param2.@scaleX);
         param1.scaleY = Number(param2.@scaleY);
         param1.rotation = Number(param2.@rotation) * MathUtil.PI_ONE_180;
         if(param2.hasOwnProperty("@width"))
         {
            param1.width = Number(param2.@width);
         }
         if(param2.hasOwnProperty("@height"))
         {
            param1.height = Number(param2.@height);
         }
         if(param2.@maxWidth.toString() != "")
         {
            §_-K3v§.setProperty(param1,"maxWidth",Math.floor(param2.@maxWidth));
         }
         if(param2.@minWidth.toString() != "")
         {
            §_-K3v§.setProperty(param1,"minWidth",Math.floor(param2.@minWidth));
         }
         if(param2.@maxHeight.toString() != "")
         {
            §_-K3v§.setProperty(param1,"maxHeight",Math.floor(param2.@maxHeight));
         }
         if(param2.@minHeight.toString() != "")
         {
            §_-K3v§.setProperty(param1,"minHeight",Math.floor(param2.@minHeight));
         }
      }
      
      private static function §_-y2P§(param1:XML) : ILayout
      {
         var _loc2_:Object = null;
         var _loc3_:String = param1.@layout;
         switch(_loc3_)
         {
            case "vertical":
               _loc2_ = new VerticalLayout();
               break;
            case "horizontal":
               _loc2_ = new HorizontalLayout();
               break;
            case "tiledColumns":
               _loc2_ = new TiledColumnsLayout();
               TiledColumnsLayout(_loc2_).useSquareTiles = false;
               break;
            case "anchor":
               _loc2_ = new AnchorLayout();
               break;
            case "none":
               break;
            default:
               throw new Error("LayoutGroup description has no layout type description!");
         }
         if(Boolean(_loc2_) && _loc3_ != "anchor")
         {
            §_-K3v§.setProperty(_loc2_,"horizontalAlign",param1.@hAlign,HorizontalAlign.CENTER);
            §_-K3v§.setProperty(_loc2_,"verticalAlign",param1.@vAlign,VerticalAlign.MIDDLE);
            §_-K3v§.setProperty(_loc2_,"gap",param1.@gap,0);
            §_-K3v§.setProperty(_loc2_,"padding",param1.@padding.toString(),0);
            §_-K3v§.setProperty(_loc2_,"paddingTop",param1.@paddingTop.toString(),_loc2_.padding);
            §_-K3v§.setProperty(_loc2_,"paddingBottom",param1.@paddingBottom.toString(),_loc2_.padding);
            §_-K3v§.setProperty(_loc2_,"paddingLeft",param1.@paddingLeft.toString(),_loc2_.padding);
            §_-K3v§.setProperty(_loc2_,"paddingRight",param1.@paddingRight.toString(),_loc2_.padding);
         }
         return ILayout(_loc2_);
      }
      
      private static function §_-j1v§(param1:Object, param2:XML) : void
      {
         var backgroundSkinXML:XML = null;
         var objectXml:XML = null;
         var restoredSpriteWithSkin:Sprite = null;
         var backgroundSkin:DisplayObject = null;
         var feathersObject:Object = param1;
         var xml:XML = param2;
         backgroundSkinXML = xml.object.(@name == "backgroundSkin")[0];
         objectXml = <object/>;
         objectXml.appendChild(backgroundSkinXML);
         restoredSpriteWithSkin = §_-K3v§.restore(objectXml);
         delete objectXml.object.(@name == "backgroundSkin")[0];
         backgroundSkin = restoredSpriteWithSkin.getChildByName("backgroundSkin") as DisplayObject;
         if(backgroundSkin)
         {
            feathersObject.backgroundSkin = backgroundSkin;
         }
      }
   }
}


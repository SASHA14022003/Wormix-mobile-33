package §_-Cl§
{
   import §_-12a§.§_-f1J§;
   import §_-21A§.§_-A2x§;
   import §_-31N§.§_-42G§;
   import §_-3D§.§_-a2b§;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-L1r§;
   import §_-91B§.§_-z2l§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-1Y§;
   import §_-C3f§.§_-4I§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.*;
   import §_-F39§.*;
   import §_-J3L§.§_-h1D§;
   import §_-K3q§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-P2i§.§_-b7§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Vg§.§_-X7§;
   import §_-YF§.§_-q2v§;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-F1X§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.*;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import §_-wD§.*;
   import §_-z1g§.§_-C32§;
   import §_-zI§.§_-A1s§;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.hurlant.math.BigInteger;
   import config.§_-vR§;
   import feathers.controls.Button;
   import feathers.controls.ButtonState;
   import feathers.controls.Label;
   import feathers.controls.ToggleButton;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.VerticalAlign;
   import feathers.skins.ImageSkin;
   import flash.display.Sprite;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.system.SecurityDomain;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.gui.menu.§_-i2l§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.GetAchievementsResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.CatPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   public class §_-li§
   {
      
      public function §_-li§()
      {
         super();
      }
      
      public static function restore(param1:XML) : Button
      {
         var _loc2_:String = param1.@type;
         if(_loc2_ == "button")
         {
            return §_-n2B§(param1);
         }
         if(_loc2_ == "toggleButton")
         {
            return §_-L2Y§(param1);
         }
         return §_-s1c§(param1);
      }
      
      private static function §_-n2B§(param1:XML) : Button
      {
         var _loc2_:Button = param1.@sound == undefined ? new Button() : new §_-i2l§(param1.@sound);
         return §_-lH§(param1,_loc2_);
      }
      
      private static function §_-L2Y§(param1:XML) : Button
      {
         var _loc2_:ToggleButton = param1.@sound == undefined ? new ToggleButton() : new §_-738§();
         return §_-lH§(param1,_loc2_);
      }
      
      private static function §_-lH§(param1:XML, param2:Button) : Button
      {
         var _loc3_:XMLList = §_-gW§(param1);
         var _loc4_:XMLList = §_-I2Z§(param1);
         if(_loc3_.length())
         {
            §_-22T§(_loc3_[0],param2);
         }
         if(_loc4_.length())
         {
            §_-TJ§(_loc4_[0],param2);
         }
         param2.validate();
         §_-02W§(param1,param2);
         §_-K3v§.§_-v28§(param2,param1);
         param2.validate();
         return param2;
      }
      
      private static function §_-s1c§(param1:XML) : Button
      {
         var buttons:XMLList = null;
         var toggleButtons:XMLList = null;
         var icons:XMLList = null;
         var labels:XMLList = null;
         var result:Button = null;
         var xml:XML = param1;
         buttons = xml.object.(@type == "button" && @name != "icon");
         toggleButtons = xml.object.(@type == "toggleButton" && @name != "icon");
         icons = §_-gW§(xml);
         labels = §_-I2Z§(xml);
         result = toggleButtons.length() ? §_-L2Y§(toggleButtons[0]) : §_-n2B§(buttons[0]);
         §_-02W§(xml,result);
         if(icons.length())
         {
            §_-22T§(icons[0],result);
         }
         if(labels.length())
         {
            §_-TJ§(labels[0],result);
         }
         §_-K3v§.§_-v28§(result,xml);
         result.validate();
         return result;
      }
      
      private static function §_-02W§(param1:XML, param2:Button) : void
      {
         var _loc3_:XML = getState("upState",param1);
         var _loc4_:XML = getState("downState",param1);
         var _loc5_:XML = getState("disabled",param1);
         var _loc6_:Boolean = param1.@isASwitch != "true";
         restoreState(_loc3_,param2);
         if(param2 is ToggleButton)
         {
            §_-13c§(_loc4_,param2,_loc6_);
         }
         else
         {
            restoreState(_loc4_,param2,ButtonState.DOWN);
         }
         restoreState(_loc5_,param2,ButtonState.DISABLED);
      }
      
      private static function §_-13c§(param1:XML, param2:Button, param3:Boolean) : void
      {
         if(param3)
         {
            restoreState(param1,param2,ButtonState.DOWN);
            §_-W1C§(param2,ButtonState.UP_AND_SELECTED,ButtonState.DOWN);
            §_-W1C§(param2,ButtonState.HOVER_AND_SELECTED,ButtonState.DOWN);
            §_-W1C§(param2,ButtonState.DOWN_AND_SELECTED,ButtonState.DOWN);
         }
         else
         {
            §_-W1C§(param2,ButtonState.DOWN);
            §_-W1C§(param2,ButtonState.UP);
            restoreState(param1,param2,ButtonState.UP_AND_SELECTED);
            §_-W1C§(param2,ButtonState.HOVER_AND_SELECTED,ButtonState.UP_AND_SELECTED);
            §_-W1C§(param2,ButtonState.DOWN_AND_SELECTED,ButtonState.UP_AND_SELECTED);
         }
      }
      
      private static function §_-W1C§(param1:Button, param2:String, param3:String = "") : void
      {
         var _loc5_:Texture = null;
         var _loc4_:ImageSkin = param1.defaultSkin as ImageSkin;
         if(param3 == "")
         {
            if(_loc4_)
            {
               _loc4_.setTextureForState(param2,_loc4_.defaultTexture);
            }
            else
            {
               param1.setSkinForState(param2,param1.defaultSkin);
            }
         }
         else
         {
            if(_loc4_)
            {
               _loc5_ = _loc4_.getTextureForState(param3);
               if(_loc5_)
               {
                  _loc4_.setTextureForState(param2,_loc5_);
                  return;
               }
            }
            param1.setSkinForState(param2,param1.getSkinForState(param3));
         }
      }
      
      private static function restoreState(param1:XML, param2:Button, param3:String = "") : void
      {
         var _loc4_:XML = null;
         var _loc5_:ImageSkin = null;
         var _loc6_:Texture = null;
         if(param1)
         {
            _loc4_ = §_-bC§(param1);
            if(_loc4_)
            {
               if(!§_-u3§(_loc4_))
               {
                  _loc6_ = §_-L2z§.getTexture(_loc4_.@url);
                  if(param3 == "")
                  {
                     _loc5_ = new ImageSkin(_loc6_);
                     if(_loc4_.@type == "3slice")
                     {
                        _loc5_.scale9Grid = Pool.getRectangle(_loc4_.@paddingLeft,Math.floor((_loc6_.height - 1) * 0.5),_loc4_.@bodyEndWidth,1);
                     }
                     if(_loc4_.@type == "9slice")
                     {
                        _loc5_.scale9Grid = Pool.getRectangle(_loc4_.@paddingLeft,_loc4_.@paddingTop,_loc4_.@bodyEndWidth,_loc4_.@bodyEndHeight);
                     }
                     §_-K3v§.§_-v28§(_loc5_,_loc4_);
                     §_-K3v§.§_-v28§(_loc5_,param1);
                     param2.defaultSkin = _loc5_;
                     return;
                  }
                  _loc5_ = param2.defaultSkin as ImageSkin;
                  if((Boolean(_loc5_)) && (!_loc5_.scale9Grid || §_-b2Y§(_loc5_.scale9Grid,_loc4_)))
                  {
                     _loc5_.setTextureForState(param3,_loc6_);
                     return;
                  }
               }
            }
            §_-no§(param1,param2,param3);
         }
      }
      
      private static function §_-b2Y§(param1:Rectangle, param2:XML) : Boolean
      {
         return param1.x == param2.@paddingLeft && (param2.@type != "9slice" || param1.y == param2.@paddingTop) && param1.width == param2.@bodyEndWidth && (param2.@type != "9slice" || param1.height == param2.@bodyEndHeight);
      }
      
      private static function §_-bC§(param1:XML) : XML
      {
         var _loc2_:XML = null;
         var _loc4_:XML = null;
         if(param1.@url != undefined)
         {
            return param1;
         }
         var _loc3_:int = 0;
         for each(_loc4_ in param1.*)
         {
            if(_loc4_.@url != undefined)
            {
               _loc2_ = _loc4_;
            }
            _loc3_++;
         }
         if(_loc3_ == 1 && Boolean(_loc2_))
         {
            return _loc2_;
         }
         return null;
      }
      
      private static function §_-no§(param1:XML, param2:Button, param3:String) : void
      {
         if(param3 == "")
         {
            param2.defaultSkin = §_-w1j§(param1);
         }
         if(param3 == ButtonState.UP)
         {
            param2.upSkin = §_-w1j§(param1);
         }
         if(param3 == ButtonState.DOWN)
         {
            param2.downSkin = §_-w1j§(param1);
         }
         if(param3 == ButtonState.DISABLED)
         {
            param2.disabledSkin = §_-w1j§(param1);
         }
         if(param3 == ButtonState.UP_AND_SELECTED && param2 is ToggleButton)
         {
            (param2 as ToggleButton).selectedUpSkin = §_-w1j§(param1);
         }
         if(param3 == ButtonState.DOWN_AND_SELECTED && param2 is ToggleButton)
         {
            (param2 as ToggleButton).selectedDownSkin = §_-w1j§(param1);
         }
         if(param3 == ButtonState.HOVER_AND_SELECTED && param2 is ToggleButton)
         {
            (param2 as ToggleButton).selectedHoverSkin = §_-w1j§(param1);
         }
      }
      
      private static function §_-w1j§(param1:XML) : DisplayObject
      {
         var _loc2_:DisplayObject = §_-K3v§.restore(param1);
         §_-K3v§.§_-v28§(_loc2_,param1);
         return _loc2_;
      }
      
      private static function getState(param1:String, param2:XML) : XML
      {
         var stateName:String = param1;
         var xml:XML = param2;
         if(xml.object.(@type == stateName).length)
         {
            return xml.object.(@type == stateName)[0];
         }
         return null;
      }
      
      private static function §_-22T§(param1:XML, param2:Button) : void
      {
         var _loc4_:Button = null;
         if(param1.@type == "button")
         {
            _loc4_ = restore(param1);
            param2.defaultIcon = _loc4_.defaultSkin;
            param2.downIcon = _loc4_.downSkin;
            param2.disabledIcon = _loc4_.disabledSkin;
            return;
         }
         var _loc3_:XML = §_-bC§(param1);
         if(Boolean(_loc3_) && _loc3_.@url != undefined)
         {
            param2.defaultIcon = new Image(§_-L2z§.getTexture(_loc3_.@url));
            §_-K3v§.§_-v28§(param2.defaultIcon,_loc3_);
         }
         else
         {
            param2.defaultIcon = §_-w1j§(param1);
         }
         §_-K3v§.§_-v28§(param2.defaultIcon,param1);
      }
      
      private static function §_-TJ§(param1:XML, param2:Button) : void
      {
         §_-N20§(param2,param1);
         if(param1.@labelOffsetX != undefined)
         {
            param2.labelOffsetX = param1.@labelOffsetX;
         }
         if(param1.@labelOffsetY != undefined)
         {
            param2.labelOffsetY = param1.@labelOffsetY;
         }
         if(param1.@font == BitmapFonts.GROBOLD_WITH_SHADOWS || param1.@font == BitmapFonts.GROBOLD_NORMAL)
         {
            param2.labelOffsetY -= param1.@height * 0.5;
         }
         param2.label = param1.@text;
      }
      
      private static function §_-gW§(param1:XML) : XMLList
      {
         var xml:XML = param1;
         return xml.object.(@name == "icon");
      }
      
      private static function §_-I2Z§(param1:XML) : XMLList
      {
         var xml:XML = param1;
         return xml.object.(@name == "label");
      }
      
      private static function §_-N20§(param1:Button, param2:XML) : void
      {
         var button:Button = param1;
         var xml:XML = param2;
         button.labelFactory = function():ITextRenderer
         {
            var _loc1_:FeathersControl = §_-R2g§.createTextRenderer(xml.@font,xml.@size,xml.@color,xml.@align) as FeathersControl;
            if(xml.@align != "center")
            {
               _loc1_.width = xml.@width;
            }
            return _loc1_ as ITextRenderer;
         };
      }
      
      private static function §_-u3§(param1:XML) : Boolean
      {
         return Number(param1.@alpha) < 0.99 || param1.@rotation != 0;
      }
   }
}


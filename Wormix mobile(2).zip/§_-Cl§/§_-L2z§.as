package §_-Cl§
{
   import §_-12a§.§_-B16§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-l1g§.§_-L3Q§;
   import com.hurlant.math.BigInteger;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-L2z§
   {
      
      public function §_-L2z§()
      {
         super();
      }
      
      public static function §_-g1E§(param1:XML) : Image
      {
         var _loc2_:Texture = getTexture(param1.@url);
         var _loc3_:Image = new Image(_loc2_);
         if(String(param1.@color))
         {
            _loc3_.color = param1.@color;
         }
         _loc3_.readjustSize();
         return _loc3_;
      }
      
      public static function §_-h1W§(param1:XML) : DisplayObject
      {
         var _loc4_:DisplayObject = null;
         var _loc5_:Rectangle = null;
         var _loc6_:Image = null;
         var _loc7_:Image = null;
         var _loc2_:Boolean = param1.@type == "9slice";
         var _loc3_:Texture = getTexture(param1.@url);
         if(_loc2_)
         {
            _loc5_ = Pool.getRectangle(param1.@paddingLeft,param1.@paddingTop,param1.@bodyEndWidth,param1.@bodyEndHeight);
            _loc6_ = new Image(_loc3_);
            _loc6_.scale9Grid = _loc5_;
            if(String(param1.@color))
            {
               _loc6_.color = param1.@color;
            }
            _loc4_ = _loc6_;
         }
         else
         {
            _loc7_ = new Image(_loc3_);
            _loc7_.scale9Grid = Pool.getRectangle(param1.@paddingLeft,Math.floor((_loc3_.height - 1) * 0.5),param1.@bodyEndWidth,1);
            if(String(param1.@color))
            {
               _loc7_.color = param1.@color;
            }
            _loc4_ = _loc7_;
         }
         §_-K3v§.§_-v28§(_loc4_,param1);
         return _loc4_;
      }
      
      public static function §_-i1X§(param1:XML) : Image
      {
         var _loc2_:XML = param1.object[0];
         var _loc3_:Image = new Image(getTexture(_loc2_.@url));
         _loc3_.tileGrid = Pool.getRectangle();
         §_-K3v§.§_-v28§(_loc3_,param1);
         return _loc3_;
      }
      
      public static function getTexture(param1:String) : Texture
      {
         var _loc2_:int = int(param1.lastIndexOf("."));
         var _loc3_:String = param1.substring(0,_loc2_ < 0 ? Number(param1.length) : _loc2_);
         return Application.assetManager.getTexture(_loc3_);
      }
   }
}


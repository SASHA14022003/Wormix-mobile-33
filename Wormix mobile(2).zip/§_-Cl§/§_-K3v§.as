package §_-Cl§
{
   import §_-02q§.§_-4s§;
   import §_-21p§.§_-N1H§;
   import §_-62§.§_-W1r§;
   import §_-937§.§_-BO§;
   import §_-A1K§.§_-TA§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-k1u§.§_-2m§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-sQ§.*;
   import §_-u1T§.*;
   import §_-w2i§.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import feathers.controls.ScrollContainer;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalLayout;
   import feathers.utils.textures.TextureCache;
   import flash.display.DisplayObject;
   import flash.display.Sprite;
   import flash.events.Event;
   import flash.filters.*;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-81K§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.render.IRenderer;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-K3v§
   {
      
      private static const TYPE_SCALE_9:String = "9slice";
      
      private static const TYPE_SCALE_3:String = "3slice";
      
      private static const §_-C3L§:String = "text";
      
      private static const §_-y1Z§:String = "button";
      
      private static const §_-d1V§:String = "toggleButton";
      
      private static const §_-k2C§:String = "scroll";
      
      private static const §_-w1E§:String = "tiled";
      
      private static const §_-Zc§:String = "object";
      
      private static const §_-sp§:String = "feathersLayoutGroup";
      
      private static const §_-77§:String = "feathersScrollContainer";
      
      private static const §_-c1x§:String = "feathersList";
      
      private static const §_-Fn§:String = "feathersGroupedList";
      
      private static const §_-81a§:String = "feathersTabBar";
      
      private static const §_-m2H§:String = "feathersImageLoader";
      
      private static const §_-kA§:String = "feathersButtonGroup";
      
      private static const §_-j2H§:String = "common";
      
      private static const §_-q2K§:String = "quad";
      
      private static const ANCHOR_LAYOUT_DATA:String = "anchorLayoutData";
      
      private static const SCALE_9_GRID:String = "scale9Grid";
      
      public function §_-K3v§()
      {
         super();
      }
      
      public static function restore(param1:XML, param2:Boolean = false, param3:Object = null) : starling.display.Sprite
      {
         var _loc4_:starling.display.Sprite = new starling.display.Sprite();
         draw(param1,_loc4_,param2,param3);
         _loc4_.name = param1.@name;
         return _loc4_;
      }
      
      private static function draw(param1:XML, param2:DisplayObjectContainer, param3:Boolean = false, param4:Object = null) : void
      {
         var child:starling.display.DisplayObject = null;
         var childType:String = null;
         var setTouchable:Boolean = false;
         var childXML:XML = null;
         var skipChildrenRestore:Boolean = false;
         var name:String = null;
         var layoutDataXML:XML = null;
         var scale9GridXml:XML = null;
         var xml:XML = param1;
         var result:DisplayObjectContainer = param2;
         var touchable:Boolean = param3;
         var binder:Object = param4;
         if(!result || !xml)
         {
            return;
         }
         for each(childXML in xml.*)
         {
            child = null;
            skipChildrenRestore = false;
            setTouchable = false;
            childType = String(childXML.@type);
            switch(childType)
            {
               case §_-j2H§:
                  child = §_-i28§.restore(childXML);
                  skipChildrenRestore = true;
                  setTouchable = child.touchable;
                  break;
               case TYPE_SCALE_9:
                  child = §_-L2z§.§_-h1W§(childXML);
                  break;
               case TYPE_SCALE_3:
                  child = §_-L2z§.§_-h1W§(childXML);
                  break;
               case §_-C3L§:
                  child = §_-S20§.§_-Ho§(childXML);
                  break;
               case §_-y1Z§:
               case §_-d1V§:
                  child = §_-li§.restore(childXML);
                  setTouchable = true;
                  skipChildrenRestore = true;
                  break;
               case §_-k2C§:
                  child = §_-227§(childXML);
                  §_-v28§(child,childXML);
                  break;
               case §_-w1E§:
                  child = §_-L2z§.§_-i1X§(childXML);
                  §_-v28§(child,childXML);
                  skipChildrenRestore = true;
                  break;
               case §_-Zc§:
                  child = §_-bk§(childXML);
                  §_-v28§(child,childXML);
                  setTouchable = §_-s2Q§(childXML);
                  if(setTouchable)
                  {
                     skipChildrenRestore = true;
                  }
                  break;
               case §_-sp§:
                  child = §_-G2L§.§_-y2C§(childXML);
                  setTouchable = true;
                  break;
               case §_-77§:
                  child = §_-G2L§.§_-227§(childXML);
                  setTouchable = true;
                  break;
               case §_-81a§:
                  child = §_-G2L§.§_-l2x§(childXML);
                  setTouchable = true;
                  break;
               case §_-m2H§:
                  child = §_-G2L§.§_-U1v§(childXML);
                  setTouchable = true;
                  break;
               case §_-kA§:
                  child = §_-G2L§.§_-12c§(childXML);
                  setTouchable = true;
                  break;
               case §_-c1x§:
                  child = §_-G2L§.§_-E1b§(childXML);
                  setTouchable = true;
                  break;
               case §_-Fn§:
                  child = §_-G2L§.§_-93R§(childXML);
                  setTouchable = true;
                  break;
               case §_-q2K§:
                  child = §_-SY§.§_-U1n§(childXML);
                  break;
               default:
                  child = new starling.display.Sprite();
                  §_-v28§(child,childXML);
            }
            name = childXML.@name;
            child.name = name;
            if(child is FeathersControl && Boolean(childXML.object.(@name == ANCHOR_LAYOUT_DATA)[0]))
            {
               layoutDataXML = childXML.object.(@name == ANCHOR_LAYOUT_DATA)[0];
               delete childXML.object.(@name == ANCHOR_LAYOUT_DATA)[0];
               §_-J39§(child as FeathersControl,layoutDataXML);
            }
            if(child is starling.display.DisplayObject && Boolean(childXML.object.(@name == SCALE_9_GRID)[0]))
            {
               scale9GridXml = childXML.object.(@name == SCALE_9_GRID)[0];
               delete childXML.object.(@name == SCALE_9_GRID)[0];
               §_-Z4§(child as starling.display.DisplayObject,scale9GridXml);
            }
            if(Boolean(binder) && Boolean(name) && name.charAt(0) == "_")
            {
               bind(binder,child,name);
            }
            child.touchable = touchable || setTouchable;
            if(skipChildrenRestore)
            {
               result.touchable = true;
            }
            else
            {
               draw(childXML,child as DisplayObjectContainer,touchable,binder);
            }
            if(String(childXML.@grayscale) == "true")
            {
               §_-MN§.§_-lM§(child);
            }
            result.addChild(child);
         }
      }
      
      private static function §_-bk§(param1:XML) : starling.display.DisplayObject
      {
         var _loc2_:starling.display.DisplayObject = null;
         if(§_-s2Q§(param1))
         {
            _loc2_ = §_-li§.restore(param1);
         }
         else if(§_-z1P§(param1))
         {
            _loc2_ = §_-L2z§.§_-g1E§(param1);
         }
         else
         {
            _loc2_ = new starling.display.Sprite();
         }
         return _loc2_;
      }
      
      private static function §_-227§(param1:XML) : ScrollContainer
      {
         var _loc3_:ILayout = null;
         var _loc2_:ScrollContainer = new ScrollContainer();
         if(param1.@layout == "horizontal")
         {
            _loc3_ = new HorizontalLayout();
            _loc2_.verticalScrollPolicy = ScrollPolicy.OFF;
         }
         else
         {
            _loc3_ = new VerticalLayout();
            if(param1.@align == "center")
            {
               (_loc3_ as VerticalLayout).horizontalAlign = HorizontalAlign.CENTER;
            }
            else if(param1.@align == "right")
            {
               (_loc3_ as VerticalLayout).horizontalAlign = HorizontalAlign.RIGHT;
            }
            else
            {
               (_loc3_ as VerticalLayout).horizontalAlign = HorizontalAlign.LEFT;
            }
            _loc2_.horizontalScrollPolicy = ScrollPolicy.OFF;
         }
         _loc2_.layout = _loc3_;
         return _loc2_;
      }
      
      private static function §_-s2Q§(param1:XML) : Boolean
      {
         var buttons:XMLList = null;
         var icons:XMLList = null;
         var labels:XMLList = null;
         var childXML:XML = param1;
         buttons = childXML.object.(String(@type) == "button" && String(@name) != "icon");
         if(buttons.length() == 0)
         {
            buttons = childXML.object.(String(@type) == "toggleButton" && String(@name) != "icon");
         }
         icons = childXML.object.(String(@name) == "icon");
         labels = childXML.object.(String(@name) == "label");
         return Boolean(buttons) && buttons.length() == 1 && (Boolean(icons) && icons.length() <= 1) && (Boolean(labels) && labels.length() <= 1) && buttons.length() + icons.length() + labels.length() == childXML.object.length();
      }
      
      private static function §_-z1P§(param1:XML) : Boolean
      {
         return String(param1.@url) != "";
      }
      
      internal static function §_-v28§(param1:starling.display.DisplayObject, param2:XML) : void
      {
         var _loc3_:Boolean = param1 is FeathersControl;
         setProperty(param1,"x",_loc3_ ? Math.floor(param2.@x) : param2.@x,0);
         setProperty(param1,"y",_loc3_ ? Math.floor(param2.@y) : param2.@y,0);
         if(param2.@width != "NaN")
         {
            setProperty(param1,"width",_loc3_ ? Math.floor(param2.@width) : param2.@width);
         }
         if(param2.@height != "NaN")
         {
            setProperty(param1,"height",_loc3_ ? Math.floor(param2.@height) : param2.@height);
         }
         if(param2.@scaleX != "NaN" && param2.@scaleX != "1")
         {
            setProperty(param1,"scaleX",Number(param2.@scaleX),1);
         }
         if(param2.@scaleY != "NaN" && param2.@scaleY != "1")
         {
            setProperty(param1,"scaleY",Number(param2.@scaleY),1);
         }
         setProperty(param1,"rotation",Number(param2.@rotation) * MathUtil.PI_ONE_180,0);
         setProperty(param1,"alpha",Math.min(0.9999,Number(param2.@alpha)),1);
         setProperty(param1,"pivotX",_loc3_ ? -Math.floor(param2.@pivotX) : -param2.@pivotX,0);
         setProperty(param1,"pivotY",_loc3_ ? -Math.floor(param2.@pivotY) : -param2.@pivotY,0);
         if(param2.@maxWidth.toString() != "")
         {
            setProperty(param1,"maxWidth",Math.floor(param2.@maxWidth));
         }
         if(param2.@minWidth.toString() != "")
         {
            setProperty(param1,"minWidth",Math.floor(param2.@minWidth));
         }
         if(param2.@maxHeight.toString() != "")
         {
            setProperty(param1,"maxHeight",Math.floor(param2.@maxHeight));
         }
         if(param2.@minHeight.toString() != "")
         {
            setProperty(param1,"minHeight",Math.floor(param2.@minHeight));
         }
         if(typeof param1 == "Quad")
         {
            setProperty(param1,"color",uint(param2.@color));
         }
      }
      
      internal static function setProperty(param1:Object, param2:String, param3:*, param4:* = null) : void
      {
         if(param1.hasOwnProperty(param2))
         {
            if(param3 != null && param3 != undefined && param3.toString() != "")
            {
               param1[param2] = param3;
            }
            else if(param4)
            {
               param1[param2] = param4;
            }
         }
      }
      
      private static function §_-J39§(param1:FeathersControl, param2:XML) : void
      {
         var _loc4_:String = null;
         var _loc5_:XML = null;
         var _loc3_:AnchorLayoutData = new AnchorLayoutData();
         for each(_loc5_ in param2.attributes())
         {
            _loc4_ = _loc5_.name().toString();
            if(_loc4_ != "name" && _loc4_ != "type")
            {
               _loc3_[_loc4_] = int(_loc5_);
            }
         }
         param1.layoutData = _loc3_;
      }
      
      private static function §_-Z4§(param1:starling.display.DisplayObject, param2:XML) : void
      {
         var _loc3_:Rectangle = param1[SCALE_9_GRID] ? param1[SCALE_9_GRID] : Pool.getRectangle();
         setProperty(_loc3_,"x",Math.floor(param2.@x),0);
         setProperty(_loc3_,"y",Math.floor(param2.@y),0);
         setProperty(_loc3_,"width",Math.floor(param2.@y),0);
         setProperty(_loc3_,"height",Math.floor(param2.@y),0);
         param1[SCALE_9_GRID] = _loc3_;
      }
      
      private static function bind(param1:Object, param2:Object, param3:String) : void
      {
         var binder:Object = param1;
         var bindableObject:Object = param2;
         var name:String = param3;
         try
         {
            if(binder.hasOwnProperty(name))
            {
               binder[name] = bindableObject;
            }
         }
         catch(e:Error)
         {
            throw new Error("Can\'t bind object: ",name);
         }
      }
   }
}


package §_-Cl§
{
   import §_-21p§.§_-N1H§;
   import §_-73d§.§_-pT§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-YF§.§_-q2v§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-d2j§;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   
   public class §_-i28§
   {
      
      public function §_-i28§()
      {
         super();
      }
      
      public static function restore(param1:XML) : DisplayObject
      {
         var objectXml:XMLList = null;
         var xmlToRestore:XML = null;
         var attributes:XMLList = null;
         var attributesCount:int = 0;
         var attributeName:String = null;
         var i:int = 0;
         var restoreXml:XML = null;
         var restoredObject:DisplayObjectContainer = null;
         var result:DisplayObject = null;
         var xml:XML = param1;
         var sourceObjectName:String = xml.@commonSource;
         if(sourceObjectName)
         {
            objectXml = Application.assetManager.getXml(§_-q2v§.§_-iW§).object.(@commonSource == sourceObjectName);
            xmlToRestore = objectXml.children()[0].copy();
            attributes = xml.attributes();
            attributesCount = int(attributes.length());
            i = 0;
            while(i < attributesCount)
            {
               attributeName = attributes[i].name();
               if(attributeName != "type" && attributeName != "commonSource" && Boolean(xmlToRestore.attribute(attributeName)))
               {
                  xmlToRestore[attributeName] = attributes[i].valueOf().toString();
               }
               i++;
            }
            restoreXml = new XML(<object/>);
            restoreXml.appendChild(xmlToRestore);
            restoredObject = §_-K3v§.restore(restoreXml);
            result = restoredObject.getChildAt(0);
            result.name = restoreXml.@name;
            return result;
         }
         return new Sprite();
      }
   }
}


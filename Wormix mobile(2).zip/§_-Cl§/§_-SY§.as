package §_-Cl§
{
   import §_-31N§.§_-Yy§;
   import §_-82l§.§_-1I§;
   import §_-B2z§.§_-63i§;
   import §_-H3§.*;
   import §_-Y1O§.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.ListClansResponse;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import starling.display.Quad;
   
   public class §_-SY§
   {
      
      public function §_-SY§()
      {
         super();
      }
      
      public static function §_-U1n§(param1:XML) : Quad
      {
         var _loc2_:int = int(int(param1.@width));
         var _loc3_:int = int(int(param1.@height));
         var _loc4_:Number = Number(int(param1.@alpha));
         var _loc5_:uint = uint(uint(param1.@color));
         var _loc6_:Quad = new Quad(_loc2_,_loc3_,_loc5_);
         _loc6_.alpha = _loc4_;
         _loc6_.x = int(param1.@x);
         _loc6_.y = int(param1.@y);
         return _loc6_;
      }
   }
}


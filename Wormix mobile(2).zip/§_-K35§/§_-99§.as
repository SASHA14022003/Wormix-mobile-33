package §_-K35§
{
   import §_-82a§.*;
   import §_-B2z§.§_-63i§;
   import §_-YF§.§_-q2v§;
   import §_-Yi§.§_-EG§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-H3D§;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import feathers.controls.Button;
   import flash.utils.clearInterval;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.textures.Texture;
   
   public class §_-99§
   {
      
      public static const §_-C3M§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_DUEL,"icon_mini_duel",§_-EG§.§_-C3M§);
      
      public static const §_-q1N§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_TEAM_BATTLE,"icon_mini_2x2",§_-EG§.§_-q1N§);
      
      public static const §_-93E§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_COOP_BOSS,"icon_mini_boss",§_-EG§.§_-93E§);
      
      public static const §_-G2D§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_HEROIC_BOSS,"icon_mini_suber_boss",§_-EG§.§_-G2D§);
      
      public static const §_-01W§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_HOTSEAT,"icon_mini_hotseat",§_-EG§.§_-01W§);
      
      public static const §_-8i§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_VISIT,"icon_mini_home",§_-EG§.§_-8i§);
      
      public static const §_-q2z§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_VISIT_PAGE,"icon_mini_user_page",§_-EG§.§_-q2z§);
      
      public static const §_-y2b§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_TOGGLE_STICKERS,"icon_stickers_on",§_-EG§.TOGGLE_STICKERS);
      
      public static const §_-g1l§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_TOGGLE_STICKERS,"icon_stickers_off",§_-EG§.TOGGLE_STICKERS);
      
      public static const §_-97§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_SHOW_CLAN_INFO,"icon_clan_info",§_-EG§.§_-97§);
      
      public static const §_-lX§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_SHOW_CLAN_INFO_ANOTHER_PLATFORM,"icon_clan_info",§_-EG§.§_-lX§);
      
      public static const §_-13C§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_INCREASE_RANK,"icon_clan_increase",§_-EG§.§_-13C§);
      
      public static const §_-n2S§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_REDUCE_RANK,"icon_clan_reduce",§_-EG§.§_-n2S§);
      
      public static const §_-y1H§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_EXPEL_PERMISSION_ON,"icon_clan_expel_on",§_-EG§.§_-3k§);
      
      public static const §_-C21§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_EXPEL_PERMISSION_OFF,"icon_clan_expel_off",§_-EG§.§_-3k§);
      
      public static const §_-62O§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_MUTE_MODE_ON,"icon_clan_mute_on",§_-EG§.§_-a2Y§);
      
      public static const §_-12D§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_MUTE_MODE_OFF,"icon_clan_mute_off",§_-EG§.§_-a2Y§);
      
      public static const §_-RQ§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_FIRE_FROM_CLAN,"icon_clan_kick",§_-EG§.§_-RQ§);
      
      public static const §_-b1P§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_MAKE_LEADER,"icon_clan_delegate",§_-EG§.§_-13C§);
      
      public static const §_-9j§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_INVITE_TO_CLAN,"icon_clan_invite",§_-EG§.§_-9j§);
      
      public static const §_-82k§:§_-99§ = new §_-99§(§_-s2a§.CONTEXT_MENU_INVITE_TO_CLAN_ANOTHER_PLATFORM,"icon_clan_invite",§_-EG§.§_-82k§);
      
      public var stringId:String;
      
      public var icon:String;
      
      public var eventType:String;
      
      public function §_-99§(param1:String, param2:String, param3:String)
      {
         super();
         this.stringId = param1;
         this.icon = param2;
         this.eventType = param3;
      }
   }
}


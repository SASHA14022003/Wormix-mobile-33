package §_-K35§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-02k§;
   import §_-D3A§.§_-UK§;
   import §_-DJ§.§_-73§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E1Z§.§_-E2i§;
   import §_-F39§.*;
   import §_-L2F§.§_-D2p§;
   import §_-T2h§.§_-92J§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-Yk§.§_-m2w§;
   import §_-d26§.§_-d1H§;
   import §_-f1G§.§_-kf§;
   import §_-j1w§.§_-B2i§;
   import §_-j1y§.§_-i1b§;
   import §_-j22§.§_-5g§;
   import §_-j2R§.§_-73G§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m0§.§_-X1F§;
   import §_-m1g§.§_-K2W§;
   import §_-n1w§.*;
   import §_-r1C§.*;
   import §_-s1Q§.§_-W2D§;
   import §_-x2Q§.§_-dU§;
   import §_-xu§.§_-91H§;
   import §_-z1g§.§_-82X§;
   import §_-z20§.§_-pl§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.application.Application;
   import com.hurlant.math.*;
   import feathers.controls.BasicButton;
   import feathers.controls.Button;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScrollBar;
   import feathers.controls.ScrollBarDisplayMode;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.IListCollection;
   import feathers.data.ListCollection;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.FontColor;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import org.gestouch.core.GestureState;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.profilePage.IProfilePageShower;
   import ru.pragmatix.flox.social.response.LoadFriendsResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.ListClansRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.ZombieGrave;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.utils.SocialUtils;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.ammo.BunkerBusterMissile;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.utils.Align;
   import starling.utils.Color;
   import starling.utils.MathUtil;
   import starling.utils.SystemUtil;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   use namespace gestouch_internal;
   use namespace bi_internal;
   
   public class AvatarHintActionsPanel extends §_-21T§
   {
      
      private static const §_-92g§:String = "avatar-hint-actions-screen";
      
      private var §_-2J§:Array;
      
      private var binder:Binder;
      
      private var §_-O13§:Boolean;
      
      private var §_-02S§:int;
      
      public function AvatarHintActionsPanel(param1:UserProfile, param2:Array)
      {
         super(param1);
         this.§_-2J§ = param2 ? param2 : [];
      }
      
      public static function §_-z2O§(param1:UserProfile, param2:Array) : Array
      {
         var _loc8_:§_-m2w§ = null;
         var _loc9_:§_-D2p§ = null;
         var _loc10_:Boolean = false;
         var _loc11_:int = 0;
         var _loc12_:Boolean = false;
         var _loc13_:ClanMemberTO = null;
         var _loc14_:ClanMemberTO = null;
         var _loc15_:int = 0;
         var _loc16_:int = 0;
         var _loc17_:§_-99§ = null;
         var _loc18_:§_-D14§ = null;
         var _loc19_:Boolean = false;
         var _loc3_:UserProfile = param1;
         if(§_-33r§.§_-ym§(_loc3_))
         {
            return [];
         }
         var _loc4_:UserProfile = Application.userProfile;
         var _loc5_:Boolean = §_-X1j§.§_-12n§.inBattle;
         var _loc6_:Array = [];
         if(!_loc5_)
         {
            _loc6_.push(§_-99§.§_-C3M§);
            if(§_-82X§.valueOf(§_-K2W§.§_-Ss§).isAvailable(_loc4_) && §_-82X§.valueOf(§_-K2W§.§_-Ss§).isAvailable(_loc3_))
            {
               _loc6_.push(§_-99§.§_-q1N§);
            }
            _loc8_ = §_-N1V§.§_-I39§.§_-N1i§();
            _loc9_ = _loc8_.§_-A2A§(0)[0] as §_-D2p§;
            _loc10_ = Application.userProfile.getLevel() >= _loc9_.§_-eH§();
            if(_loc10_)
            {
               _loc6_.push(§_-99§.§_-93E§);
            }
            _loc11_ = §_-N1V§.§_-I39§.§_-X1P§().§_-7k§(1).§_-eH§();
            _loc12_ = Application.userProfile.getLevel() >= _loc11_;
            if(_loc12_)
            {
               _loc6_.push(§_-99§.§_-G2D§);
            }
            _loc6_.push(§_-99§.§_-01W§);
            _loc6_.push(§_-99§.§_-8i§);
            if(§_-6A§.§_-s1U§(_loc4_,_loc3_))
            {
               _loc13_ = §_-6A§.§_-k1a§(_loc4_.getId());
               _loc14_ = §_-6A§.§_-k1a§(_loc3_.getId());
               _loc15_ = _loc3_.clanMember.rank;
               _loc16_ = _loc4_.clanMember.rank;
               if(_loc16_ == §_-X1q§.§_-O2V§)
               {
                  if(_loc15_ != §_-X1q§.§_-O2V§)
                  {
                     _loc17_ = _loc15_ == §_-X1q§.OFFICER ? §_-99§.§_-b1P§ : §_-99§.§_-13C§;
                     _loc6_.push(_loc17_);
                  }
                  if(_loc15_ != §_-X1q§.§_-CM§)
                  {
                     _loc6_.push(§_-99§.§_-n2S§);
                  }
                  if(_loc15_ == §_-X1q§.OFFICER)
                  {
                     _loc17_ = _loc14_.expelPermit ? §_-99§.§_-C21§ : §_-99§.§_-y1H§;
                     _loc6_.push(_loc17_);
                  }
                  _loc17_ = _loc14_.muteMode ? §_-99§.§_-12D§ : §_-99§.§_-62O§;
                  _loc6_.push(_loc17_);
               }
               if(_loc13_.expelPermit && _loc16_ < _loc15_)
               {
                  _loc6_.push(§_-99§.§_-RQ§);
               }
            }
            else
            {
               if(_loc4_.§_-ia§() && _loc4_.clanMember.rank != §_-X1q§.§_-CM§ && !_loc3_.§_-ia§())
               {
                  if(_loc3_.§_-d1C§)
                  {
                     _loc6_.push(§_-99§.§_-82k§);
                  }
                  else
                  {
                     _loc6_.push(§_-99§.§_-9j§);
                  }
               }
               if(_loc3_.§_-ia§())
               {
                  if(_loc3_.§_-d1C§)
                  {
                     _loc6_.push(§_-99§.§_-lX§);
                  }
                  else
                  {
                     _loc6_.push(§_-99§.§_-97§);
                  }
               }
            }
         }
         else
         {
            if(_loc3_.getId() > 0 && §_-X1j§.§_-12n§.§_-WN§().online)
            {
               _loc18_ = §_-X1j§.§_-12n§.scene.gameInterface.§_-p10§(_loc3_.getId());
               if(_loc18_)
               {
                  _loc19_ = _loc18_.§_-k21§;
                  _loc6_.push(_loc19_ ? §_-99§.§_-y2b§ : §_-99§.§_-g1l§);
               }
            }
            if(_loc4_.§_-ia§() && _loc4_.clanMember.rank != §_-X1q§.§_-CM§ && !_loc3_.§_-ia§())
            {
               if(_loc3_.§_-d1C§)
               {
                  _loc6_.push(§_-99§.§_-82k§);
               }
               else
               {
                  _loc6_.push(§_-99§.§_-9j§);
               }
            }
         }
         var _loc7_:IProfilePageShower = §_-N1V§.socialController as IProfilePageShower;
         if((Boolean(_loc7_)) && _loc7_.isProfilePageAvailable())
         {
            _loc6_.push(§_-99§.§_-q2z§);
         }
         §_-p1g§(_loc6_,param2);
         return _loc6_;
      }
      
      private static function §_-p1g§(param1:Array, param2:Array) : void
      {
         var _loc4_:§_-99§ = null;
         var _loc3_:int = int(param1.length);
         while(--_loc3_ > -1)
         {
            _loc4_ = param1[_loc3_] as §_-99§;
            if(_loc4_)
            {
               if(param2.indexOf(_loc4_) > -1)
               {
                  param1.removeAt(_loc3_);
               }
            }
         }
      }
      
      override protected function initialize() : void
      {
         var up:UserProfile;
         var actionsLayout:VerticalLayout;
         var inBattle:Boolean;
         var vipActive:Boolean;
         var data:Array;
         super.initialize();
         up = §_-z2g§;
         if(§_-33r§.§_-ym§(up))
         {
            return;
         }
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject(§_-92g§),true,this.binder);
         addChild(this.binder._container);
         actionsLayout = new VerticalLayout();
         actionsLayout.horizontalAlign = HorizontalAlign.LEFT;
         actionsLayout.verticalAlign = VerticalAlign.TOP;
         this.binder._actionsList.layout = actionsLayout;
         this.binder._actionsList.itemRendererType = §_-D3S§;
         this.binder._actionsList.addEventListener(Event.CHANGE,this.§_-y§);
         this.binder._actionsList.horizontalScrollBarPosition = RelativePosition.RIGHT;
         this.binder._actionsList.scrollBarDisplayMode = ScrollBarDisplayMode.FIXED_FLOAT;
         this.binder._actionsList.verticalScrollBarFactory = function():ScrollBar
         {
            var width:int = 0;
            var scrollBar:ScrollBar = new ScrollBar();
            width = 6;
            scrollBar.thumbFactory = function():BasicButton
            {
               var _loc1_:BasicButton = new BasicButton();
               _loc1_.defaultSkin = new Quad(4,4,10132122);
               _loc1_.width = width;
               return _loc1_;
            };
            scrollBar.minimumTrackFactory = function():Button
            {
               var _loc1_:Button = new Button();
               _loc1_.width = 0;
               _loc1_.height = 0;
               return _loc1_;
            };
            scrollBar.maximumTrackFactory = function():Button
            {
               var _loc1_:Button = new Button();
               _loc1_.width = 0;
               _loc1_.height = 0;
               return _loc1_;
            };
            scrollBar.incrementButtonFactory = function():BasicButton
            {
               var _loc1_:BasicButton = new BasicButton();
               _loc1_.width = 0;
               _loc1_.height = 0;
               return _loc1_;
            };
            scrollBar.decrementButtonFactory = function():BasicButton
            {
               var _loc1_:BasicButton = new BasicButton();
               _loc1_.width = 0;
               _loc1_.height = 0;
               return _loc1_;
            };
            scrollBar.width = width;
            return scrollBar;
         };
         this.binder._name.text = §_-z2g§.getCharName();
         this.binder._id.text = "#" + §_-z2g§.getId().toString();
         if(§_-z2g§.§_-V1K§())
         {
            this.binder._id.text += " (" + SocialUtils.getSocialTypeName(§_-z2g§.§_-V1K§()) + ")";
         }
         this.binder._clanName.text = §_-z2g§.§_-ia§() ? §_-z2g§.clanMember.clanName : "";
         this.binder._rank.text = §_-z2g§.§_-ia§() ? §_-6A§.§_-R1w§(§_-z2g§.clanMember.rank) : "";
         inBattle = §_-X1j§.§_-12n§.inBattle;
         vipActive = up.§_-33n§();
         this.binder._vipIndicator.visible = vipActive && !inBattle;
         this.binder._panel.y = vipActive && !inBattle ? 30 : 0;
         data = §_-z2O§(§_-z2g§,this.§_-2J§);
         this.binder._actionsList.dataProvider = new ArrayCollection(data);
         this.binder._actionsList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._actionsList.verticalScrollPolicy = ScrollPolicy.AUTO;
         if(this.§_-SL§())
         {
            this.§_-mc§();
         }
      }
      
      private function §_-mc§() : void
      {
         var _loc1_:Sprite = new Sprite();
         var _loc2_:Image = new Image(Application.assetManager.getTexture("PointerArrow_neutral"));
         var _loc3_:int = this.binder._switchButton.height;
         var _loc4_:Quad = new Quad(_loc3_,_loc3_,Color.BLACK);
         var _loc5_:int = (_loc3_ - _loc2_.width) * 0.5;
         _loc1_.addChild(_loc4_);
         _loc1_.addChild(_loc2_);
         _loc4_.alpha = 0;
         _loc2_.color = 6130616;
         _loc2_.pivotX = _loc2_.width * 0.5;
         _loc2_.pivotY = _loc2_.height * 0.5;
         _loc2_.rotation = -Math.PI * 0.5;
         _loc2_.x = _loc2_.pivotX + _loc5_;
         _loc2_.y = _loc2_.pivotX + _loc5_;
         _loc1_.addEventListener(TouchEvent.TOUCH,this.§_-r6§);
         this.binder._switchButton.parent.addChildAt(_loc1_,0);
         this.binder._arrowImage = _loc2_;
         this.binder._arrowSprite = _loc1_;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            §_-b1z§(this.binder._container,this.binder._panel);
         }
      }
      
      private function §_-r6§(param1:TouchEvent) : void
      {
         var _loc2_:DisplayObject = param1.currentTarget as DisplayObject;
         var _loc3_:Touch = param1.getTouch(_loc2_,TouchPhase.ENDED);
         if(!_loc3_)
         {
            return;
         }
         §_-h2B§.play(§_-d27§.§_-S29§);
         if(!this.§_-O13§)
         {
            this.§_-G3h§();
         }
         else
         {
            this.§_-v29§();
         }
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      private function §_-SL§() : Boolean
      {
         var _loc1_:IListCollection = this.binder._actionsList.dataProvider;
         var _loc2_:LayoutGroup = this.binder._actionsList.parent as LayoutGroup;
         var _loc3_:Number = _loc1_.length * §_-D3S§.HEIGHT;
         return _loc2_.height < _loc3_;
      }
      
      private function §_-G3h§() : void
      {
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:§_-02k§ = null;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         var _loc1_:IListCollection = this.binder._actionsList.dataProvider;
         var _loc2_:LayoutGroup = this.binder._actionsList.parent as LayoutGroup;
         var _loc3_:Number = _loc1_.length * §_-D3S§.HEIGHT;
         if(_loc2_.height < _loc3_)
         {
            _loc4_ = _loc3_ - _loc2_.height;
            §_-uu§(this.binder._container,_loc4_);
            this.binder._arrowImage.rotation = Math.PI * 0.5;
            _loc5_ = Starling.current.stage.stageHeight;
            _loc6_ = (parent as §_-S18§).parent as §_-02k§;
            _loc7_ = _loc6_.y + _loc6_.height + _loc4_;
            _loc8_ = _loc7_ - _loc5_;
            if(_loc8_ > 0)
            {
               _loc6_.y -= _loc8_;
            }
            this.§_-02S§ = _loc2_.height;
            _loc2_.height = _loc3_;
            this.§_-O13§ = true;
         }
      }
      
      private function §_-v29§() : void
      {
         var _loc1_:LayoutGroup = this.binder._actionsList.parent as LayoutGroup;
         if(_loc1_.height > this.§_-02S§)
         {
            §_-uu§(this.binder._container,this.§_-02S§ - _loc1_.height);
            this.binder._arrowImage.rotation = -Math.PI * 0.5;
            _loc1_.height = this.§_-02S§;
            this.§_-O13§ = false;
         }
      }
      
      private function §_-y§(param1:Event) : void
      {
         §_-h2B§.play(§_-d27§.§_-S29§);
         var _loc2_:§_-99§ = this.binder._actionsList.selectedItem as §_-99§;
         if(_loc2_)
         {
            dispatchEventWith(Event.SELECT,true,{
               "action":this.binder._actionsList.selectedItem,
               "profile":§_-z2g§
            });
         }
      }
      
      override public function dispose() : void
      {
         if(this.binder)
         {
            if(this.binder._arrowSprite)
            {
               this.binder._arrowSprite.removeEventListener(TouchEvent.TOUCH,this.§_-r6§);
            }
         }
         super.dispose();
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import starling.display.Button;
import starling.display.Image;
import starling.display.Sprite;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _panel:LayoutGroup;
   
   public var _actionsList:List;
   
   public var _name:Label;
   
   public var _id:Label;
   
   public var _clanName:Label;
   
   public var _rank:Label;
   
   public var _vipIndicator:Image;
   
   public var _switchButton:Button;
   
   public var _arrowImage:Image;
   
   public var _arrowSprite:Sprite;
   
   public function Binder()
   {
      super();
   }
}

package §_-K35§
{
   import §_-31N§.§_-42G§;
   import §_-31N§.§_-Yy§;
   import §_-31Y§.§_-D3B§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-L1H§.§_-C3e§;
   import §_-fo§.*;
   import §_-hO§.§_-02h§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-M2v§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.*;
   import feathers.controls.ImageLoader;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontSize;
   import flash.errors.IllegalOperationError;
   import flash.globalization.DateTimeFormatter;
   import flash.globalization.LocaleID;
   import flash.system.LoaderContext;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import org.gestouch.core.GestureState;
   import org.gestouch.core.Touch;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.PostToChat;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-D3S§ extends DefaultListItemRenderer
   {
      
      private static const §_-23Q§:int = 9211020;
      
      private static const §_-d2J§:uint = 2961717;
      
      private static const §_-oY§:uint = 3225146;
      
      public static const HEIGHT:int = 40;
      
      private var §_-31g§:Quad;
      
      private var §_-1A§:ImageLoader;
      
      public function §_-D3S§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasLabel = false;
         itemHasIcon = false;
         itemHasAccessory = false;
         _isQuickHitAreaEnabled = true;
         this.§_-31g§ = new Quad(16,16,§_-d2J§);
         defaultSkin = this.§_-31g§;
         this.§_-1A§ = new ImageLoader();
         this.§_-1A§.height = 25;
         this.§_-1A§.width = 25;
         this.§_-1A§.maintainAspectRatio = true;
         this.§_-1A§.scaleMode = ScaleMode.SHOW_ALL;
         this.§_-1A§.verticalAlign = VerticalAlign.MIDDLE;
         this.§_-1A§.horizontalAlign = HorizontalAlign.CENTER;
         defaultIcon = this.§_-1A§;
         labelFactory = function():ITextRenderer
         {
            return TextInstanceCreator.createTextRenderer(FontSize.SMALL,§_-23Q§,TextFormatAlign.LEFT);
         };
         horizontalAlign = HorizontalAlign.LEFT;
         verticalAlign = VerticalAlign.MIDDLE;
         gap = 10;
         paddingLeft = 10;
         paddingRight = 10;
         height = HEIGHT;
      }
      
      override protected function commitData() : void
      {
         super.commitData();
         this.§_-31g§.color = _index % 2 == 0 ? §_-oY§ : §_-d2J§;
         var _loc1_:§_-99§ = _data as §_-99§;
         if(_loc1_)
         {
            this.§_-1A§.source = Application.assetManager.getTexture(_loc1_.icon);
            label = §_-s2a§.§_-K3t§(_loc1_.stringId);
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(_owner))
         {
            this.width = _owner.width;
         }
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         if(owner)
         {
            owner.addEventListener(Event.RESIZE,this.§_-32E§);
         }
         invalidate(INVALIDATION_FLAG_SIZE);
      }
      
      private function §_-32E§(param1:Event) : void
      {
         invalidate(INVALIDATION_FLAG_SIZE);
      }
   }
}


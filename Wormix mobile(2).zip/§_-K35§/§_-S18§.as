package §_-K35§
{
   import §_-12a§.§_-41b§;
   import §_-62§.§_-G1p§;
   import §_-73I§.§_-Z2e§;
   import §_-73d§.§_-pT§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-R2I§.*;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-gG§.§_-5R§;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-p14§.§_-U1D§;
   import §_-qH§.*;
   import §_-r1C§.*;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ToggleButton;
   import feathers.core.PopUpManager;
   import feathers.layout.Direction;
   import feathers.skins.ImageSkin;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.system.SecurityDomain;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.particle.ParticleEffect;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.messages.client.SteamTransactionInitRequest;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-S18§ extends LayoutGroup
   {
      
      private var §_-b2b§:int;
      
      private var §_-72z§:int;
      
      private var §_-z2g§:UserProfile;
      
      private var §_-810§:Boolean;
      
      private var §_-K3s§:DisplayObject;
      
      private var §_-2J§:Array = [];
      
      private var §_-Iq§:Boolean = true;
      
      public function §_-S18§(param1:int, param2:UserProfile = null)
      {
         super();
         this.§_-b2b§ = param1;
         this.§_-z2g§ = param2;
         this.§_-810§ = true;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(this.§_-K3s§))
         {
            this.width = this.§_-K3s§.width;
            this.height = this.§_-K3s§.height;
            readjustLayout();
         }
         if(isInvalid(INVALIDATION_FLAG_DATA) && this.§_-z2g§ != null)
         {
            this.§_-e2L§();
            this.§_-ze§(this.§_-810§);
            invalidate(INVALIDATION_FLAG_SIZE);
         }
      }
      
      public function clear() : void
      {
         this.§_-e2L§();
         this.§_-810§ = true;
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-e2L§();
      }
      
      private function §_-j2T§(param1:starling.events.Event) : void
      {
         this.§_-810§ = !this.§_-810§;
         invalidate(INVALIDATION_FLAG_DATA);
         §_-h2B§.play(§_-d27§.§_-S29§);
      }
      
      private function §_-ze§(param1:Boolean) : void
      {
         var _loc2_:Boolean = false;
         if(param1)
         {
            _loc2_ = AvatarHintActionsPanel.§_-z2O§(this.§_-z2g§,this.§_-2J§).length > 0;
            this.§_-K3s§ = new AvatarHintParamsPanel(this.§_-z2g§,this.§_-Iq§ && _loc2_);
         }
         else
         {
            this.§_-K3s§ = new AvatarHintActionsPanel(this.§_-z2g§,this.§_-2J§);
         }
         addChild(this.§_-K3s§);
         this.§_-K3s§.addEventListener(starling.events.Event.TRIGGERED,this.§_-j2T§);
      }
      
      private function §_-e2L§() : void
      {
         if(this.§_-K3s§)
         {
            this.§_-K3s§.removeFromParent(true);
            this.§_-K3s§.removeEventListener(starling.events.Event.TRIGGERED,this.§_-j2T§);
         }
         this.§_-K3s§ = null;
      }
      
      public function get profileId() : int
      {
         return this.§_-b2b§;
      }
      
      public function set profileId(param1:int) : void
      {
         this.§_-b2b§ = param1;
         this.§_-z2g§ = null;
      }
      
      public function get platformId() : int
      {
         return this.§_-72z§;
      }
      
      public function set platformId(param1:int) : void
      {
         this.§_-72z§ = param1;
         if(Boolean(this.§_-z2g§) && !this.§_-z2g§.§_-V1K§())
         {
            this.§_-z2g§.§_-bo§(this.§_-72z§);
         }
      }
      
      public function get userProfile() : UserProfile
      {
         return this.§_-z2g§;
      }
      
      public function set userProfile(param1:UserProfile) : void
      {
         this.§_-z2g§ = param1;
         if(Boolean(this.§_-72z§) && !this.§_-z2g§.§_-V1K§())
         {
            this.§_-z2g§.§_-bo§(this.§_-72z§);
         }
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      public function close() : void
      {
         if(PopUpManager.isPopUp(this))
         {
            SystemUtil.executeWhenApplicationIsActive(PopUpManager.removePopUp,this);
         }
         else if(PopUpManager.isPopUp(this.parent))
         {
            SystemUtil.executeWhenApplicationIsActive(PopUpManager.removePopUp,this.parent);
         }
      }
      
      public function set §_-y1y§(param1:Array) : void
      {
         this.§_-2J§ = param1;
      }
      
      public function set §_-x21§(param1:Boolean) : void
      {
         this.§_-Iq§ = param1;
      }
   }
}


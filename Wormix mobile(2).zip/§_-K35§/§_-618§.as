package §_-K35§
{
   import §_-5P§.§_-h2i§;
   import §_-5P§.§_-qg§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-zF§;
   import §_-63U§.§_-NV§;
   import §_-73I§.*;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-1Y§;
   import §_-Cl§.§_-i28§;
   import §_-D3A§.§_-TZ§;
   import §_-H2g§.§_-S2O§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-Jd§.BonusStat;
   import §_-Jd§.§_-11K§;
   import §_-OJ§.§_-L3B§;
   import §_-OJ§.§_-sY§;
   import §_-P2i§.§_-b7§;
   import §_-Y1O§.*;
   import §_-YF§.§_-N3§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-b1F§.*;
   import §_-hO§.§_-v24§;
   import §_-hv§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-qH§.§_-AC§;
   import §_-s1Q§.§_-W2D§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.loading.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.math.*;
   import com.worlize.websocket.§_-x2j§;
   import dragonBones.Armature;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.data.VectorCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.skins.ImageSkin;
   import flash.display.Bitmap;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.system.SecurityDomain;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.gestouch.core.Touch;
   import ru.pragmatix.flox.gui.controls.*;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.server.Pong;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-618§ extends §_-di§
   {
      
      public static const §_-QU§:Number = 0 * MathUtil.PI_ONE_180;
      
      private static const §_-Z1Q§:String = "dummies";
      
      private static const §_-B1S§:String = "Dummy";
      
      private var profile:UserProfile;
      
      private var race:§_-B2i§;
      
      private var §_-f1M§:§_-di§;
      
      private var §_-G1S§:§_-di§;
      
      public function §_-618§(param1:UserProfile, param2:§_-B2i§)
      {
         super();
         this.profile = param1;
         this.race = param2 ? param2 : param1.§_-P2e§();
         var _loc3_:Armature = Application.factory.buildArmature(§_-Z1Q§ + "/" + this.race.configName + §_-B1S§,§_-K1t§.§_-IP§);
         init(_loc3_);
      }
      
      public function §_-11e§(param1:DisplayObjectContainer) : void
      {
         if(param1)
         {
            this.§_-k23§(param1);
         }
      }
      
      public function §_-L§(param1:§_-zF§) : void
      {
         var _loc2_:§_-zF§ = param1 || (this.profile ? this.profile.getHat() : null);
         _loc2_ = _loc2_ ? §_-G1p§.§_-12J§(_loc2_.getId(),this.race) : null;
         this.§_-E3p§(_loc2_);
         this.§_-T1B§(_loc2_);
      }
      
      public function §_-aV§(param1:§_-T1y§) : void
      {
         this.§_-y2y§(param1 || (this.profile ? this.profile.§_-32q§() : null));
      }
      
      private function §_-E3p§(param1:§_-zF§) : void
      {
         var _loc3_:DisplayObject = null;
         var _loc2_:Point = Pool.getPoint();
         var _loc4_:Slot = getSlot("hat");
         if(!param1)
         {
            if(_loc4_.display)
            {
               _loc4_.display.dispose();
            }
            return;
         }
         if(§_-q15§.§_-Q2T§(param1))
         {
            this.§_-f1M§ = §_-q15§.§_-b1m§(param1);
            if(this.§_-f1M§)
            {
               _loc3_ = new Sprite();
               (_loc3_ as Sprite).addChild(this.§_-f1M§.display);
               WorldClock.clock.add(this.§_-f1M§);
            }
         }
         else
         {
            _loc2_ = §_-AC§.§_-1Q§(param1.§_-G3a§(),_loc2_);
            _loc3_ = §_-q15§.§_-Fd§(param1);
         }
         _loc4_.display = _loc3_;
         _loc4_.display.x = _loc4_.global.x + _loc2_.x / §_-K1t§.§_-h2z§;
         _loc4_.display.y = _loc4_.global.y + _loc2_.y / §_-K1t§.§_-h2z§;
         Pool.putPoint(_loc2_);
      }
      
      private function §_-T1B§(param1:§_-zF§) : void
      {
         var _loc2_:§_-S2O§ = getBone("ears");
         if(_loc2_)
         {
            _loc2_.visible = !param1 || param1.§_-h1h§().indexOf("Ears") == -1;
         }
      }
      
      private function §_-y2y§(param1:§_-T1y§) : void
      {
         var _loc2_:DisplayObject = null;
         var _loc3_:Slot = getSlot("artifact");
         if(!param1)
         {
            if(_loc3_.display)
            {
               _loc3_.display.dispose();
            }
            return;
         }
         var _loc4_:Point = Pool.getPoint();
         if(§_-q15§.§_-O1m§(param1))
         {
            this.§_-G1S§ = §_-q15§.§_-pC§(param1);
            if(this.§_-G1S§)
            {
               WorldClock.clock.add(this.§_-G1S§);
               _loc2_ = this.§_-G1S§.display;
            }
         }
         else
         {
            _loc2_ = §_-q15§.§_-01K§(param1);
            _loc4_ = §_-W2D§.§_-lI§(param1.§_-G3a§(),_loc4_);
         }
         _loc3_.display = _loc2_;
         _loc3_.display.pivotX = -_loc4_.x / §_-K1t§.§_-h2z§;
         _loc3_.display.pivotY = -_loc4_.y / §_-K1t§.§_-h2z§;
         _loc3_.display.rotation = §_-QU§;
         _loc3_.display.x = _loc3_.global.x;
         _loc3_.display.y = _loc3_.global.y;
         Pool.putPoint(_loc4_);
         this.§_-g1e§(param1);
      }
      
      private function §_-g1e§(param1:§_-T1y§) : void
      {
         var _loc2_:DisplayObjectContainer = display as DisplayObjectContainer;
         var _loc3_:int = _loc2_.numChildren - (param1.§_-rw§() ? 2 : 1);
         var _loc4_:int = _loc2_.numChildren - (param1.§_-rw§() ? 1 : 2);
         §_-23D§(_loc4_,"hand");
         §_-23D§(_loc3_,"artifact");
      }
      
      private function §_-k23§(param1:DisplayObjectContainer) : void
      {
         param1.addChild(display);
      }
      
      override public function dispose() : void
      {
         if(this.§_-f1M§)
         {
            WorldClock.clock.remove(this.§_-f1M§);
            if(this.§_-f1M§.display)
            {
               this.§_-f1M§.display.removeFromParent();
            }
            this.§_-f1M§.dispose();
         }
         this.§_-f1M§ = null;
         if(this.§_-G1S§)
         {
            WorldClock.clock.remove(this.§_-G1S§);
            if(this.§_-G1S§.display)
            {
               this.§_-G1S§.display.removeFromParent();
            }
            this.§_-G1S§.dispose();
         }
         this.§_-G1S§ = null;
         clear();
      }
   }
}


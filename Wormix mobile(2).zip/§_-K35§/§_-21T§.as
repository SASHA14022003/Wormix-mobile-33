package §_-K35§
{
   import §_-5P§.*;
   import §_-62§.§_-W1r§;
   import §_-937§.§_-n1b§;
   import §_-Af§.§_-k1I§;
   import §_-B2z§.§_-63i§;
   import §_-C2t§.§_-92W§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-TZ§;
   import §_-J31§.§_-R1h§;
   import §_-S1N§.§_-R1U§;
   import §_-U1i§.§_-hK§;
   import §_-W§.§_-Ap§;
   import §_-W§.§_-ix§;
   import §_-X14§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-kS§.*;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-rM§.§_-61j§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.events.DeviceOrientationEvent;
   import com.greensock.loading.*;
   import com.greensock.loading.core.*;
   import com.hurlant.math.*;
   import feathers.controls.LayoutGroup;
   import feathers.controls.TabBar;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import flash.events.Event;
   import flash.filters.BitmapFilterQuality;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import flash.system.Capabilities;
   import flash.system.LoaderContext;
   import flash.system.Security;
   import flash.system.SecurityDomain;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.system.AbstractControlSystem;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.controls.system.TouchControlSystem;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.BuyUnlockMission;
   import ru.pragmatix.wormix.messages.client.DistributePoints;
   import ru.pragmatix.wormix.messages.structures.AwardTypes;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.LoginAwardStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.type.missile.homing.HomingMissile;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.filters.BlurFilter;
   import starling.filters.DropShadowFilter;
   import starling.filters.FragmentFilter;
   import starling.utils.Color;
   
   use namespace bi_internal;
   
   public class §_-21T§ extends LayoutGroup
   {
      
      private static const §_-W2L§:int = 5;
      
      private static const §_-61F§:int = 2;
      
      private static const §_-B3Z§:String = "shadow";
      
      private static const §_-Z3§:String = "border";
      
      protected var §_-z2g§:UserProfile;
      
      public function §_-21T§(param1:UserProfile)
      {
         super();
         this.§_-z2g§ = param1;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
      }
      
      override protected function draw() : void
      {
         super.draw();
      }
      
      protected function §_-b1z§(param1:LayoutGroup, param2:LayoutGroup, param3:int = 0) : void
      {
         var _loc5_:Quad = null;
         if(param1.getChildAt(0).name == §_-Z3§)
         {
            return;
         }
         var _loc4_:int = §_-61F§ * 2;
         _loc5_ = new Quad(param2.width + _loc4_,param2.height + _loc4_ + param3,Color.rgb(67,107,147));
         _loc5_.name = §_-Z3§;
         _loc5_.x = -1 * §_-61F§;
         _loc5_.y = param2.y - §_-61F§;
         param1.addChildAt(_loc5_,0);
         var _loc6_:FragmentFilter = new BlurFilter(2,2);
         var _loc7_:DropShadowFilter = new DropShadowFilter(4,Math.PI * 0.25,7191039,0.8,3,BitmapFilterQuality.HIGH);
         _loc5_.filter = _loc7_;
      }
      
      protected function §_-uu§(param1:LayoutGroup, param2:int) : void
      {
         var _loc3_:DisplayObject = param1.getChildAt(0);
         if(_loc3_.name != §_-Z3§)
         {
            return;
         }
         _loc3_.height += param2;
      }
      
      override public function dispose() : void
      {
         super.dispose();
      }
   }
}


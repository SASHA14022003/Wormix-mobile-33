package §_-K35§
{
   import §_-12W§.*;
   import §_-52V§.§_-R9§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-zF§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-ZP§.§_-YG§;
   import §_-g2r§.§_-03A§;
   import §_-hv§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.§_-K2W§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-82X§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.core.*;
   import dragonBones.animation.WorldClock;
   import feathers.core.ITextRenderer;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.GetRating;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-p1m§
   {
      
      protected var §_-t2p§:§_-di§;
      
      private var _container:DisplayObjectContainer;
      
      public function §_-p1m§(param1:DisplayObjectContainer = null)
      {
         super();
         this._container = param1;
      }
      
      public function setIcon(param1:UserProfile, param2:§_-B2i§ = null, param3:§_-zF§ = null, param4:§_-T1y§ = null) : void
      {
         this.§_-83m§();
         this.§_-t2p§ = §_-L1O§.§_-Yx§(param1,this._container,param2,param3,param4);
      }
      
      private function §_-83m§() : void
      {
         if(this.§_-t2p§)
         {
            if(this.§_-t2p§.display)
            {
               this.§_-t2p§.display.removeFromParent();
            }
            this.§_-t2p§.dispose();
            this.§_-t2p§ = null;
         }
      }
      
      public function get display() : starling.display.DisplayObject
      {
         return this.§_-t2p§.display;
      }
      
      public function set container(param1:DisplayObjectContainer) : void
      {
         this._container = param1;
      }
      
      public function dispose() : void
      {
         this.§_-83m§();
         this._container = null;
      }
   }
}


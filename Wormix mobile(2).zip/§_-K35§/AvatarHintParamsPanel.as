package §_-K35§
{
   import §_-61n§.*;
   import §_-91A§.*;
   import §_-937§.§_-81u§;
   import §_-937§.§_-BO§;
   import §_-937§.§_-T15§;
   import §_-B1y§.Cookie;
   import §_-CR§.§_-72p§;
   import §_-H2g§.§_-di§;
   import §_-P1B§.§_-b21§;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-I3t§;
   import §_-Vg§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-l1K§.§_-cZ§;
   import §_-z1g§.§_-Uc§;
   import feathers.controls.ScrollPolicy;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.ProfileDoubleKeyStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.social.utils.SocialUtils;
   import ru.pragmatix.wormix.utils.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.text.TextFieldAutoSize;
   import starling.utils.Pool;
   
   public class AvatarHintParamsPanel extends §_-21T§
   {
      
      private static const §_-92g§:String = "avatar-hint-params-screen";
      
      private static const §_-gP§:int = 60;
      
      private var §_-Iq§:Boolean;
      
      private var binder:Binder;
      
      private var iconSource:§_-di§;
      
      private var clanEmblem:§_-M11§;
      
      public function AvatarHintParamsPanel(param1:UserProfile, param2:Boolean = true)
      {
         super(param1);
         this.§_-Iq§ = param2;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject(§_-92g§),true,this.binder);
         addChild(this.binder._container);
      }
      
      override protected function draw() : void
      {
         var _loc1_:Boolean = false;
         var _loc2_:Boolean = false;
         var _loc3_:Boolean = false;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc1_ = §_-X1j§.§_-12n§.inBattle;
            _loc2_ = §_-z2g§.§_-33n§();
            this.binder._name.text = §_-z2g§.getCharName();
            this.binder._id.text = §_-z2g§.getId() > 0 ? "#" + §_-z2g§.getId().toString() : "";
            if(§_-z2g§.§_-V1K§())
            {
               this.binder._id.text += " (" + SocialUtils.getSocialTypeName(§_-z2g§.§_-V1K§()) + ")";
            }
            this.binder._fuzyValue.text = §_-z2g§.§_-51e§().toString();
            this.binder._rubyValue.text = §_-z2g§.§_-o1N§().toString();
            this.binder._reactionValue.text = §_-z2g§.§_-u2l§().toString();
            this.binder._hpLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.HP);
            this.binder._hpValue.text = §_-z2g§.§_-N23§() ? §_-33r§.§_-jA§(§_-z2g§.§_-N23§(),§_-z2g§.stats.§_-q1G§.value) : StringUtil.§_-43t§;
            this.binder._armorLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.ARMOR);
            this.binder._armorValue.text = §_-33r§.§_-jA§(§_-z2g§.§_-h2m§(),§_-z2g§.stats.§_-v2n§.value);
            this.binder._attackLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.ATTACK);
            this.binder._attackValue.text = §_-33r§.§_-jA§(§_-z2g§.§_-w1p§(),§_-z2g§.stats.bonusAttack.value);
            this.binder._ratingLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING);
            this.binder._ratingValue.text = §_-Uc§.§_-Zp§(§_-z2g§);
            if(!_loc1_)
            {
               this.binder._teamLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_LABEL);
               this.binder._teamValue.text = §_-z2g§.§_-A1U§() ? §_-z2g§.§_-n26§().length.toString() : StringUtil.§_-43t§;
            }
            else
            {
               this.binder._teamData.removeFromParent();
            }
            _loc3_ = §_-z2g§.getId() == 0;
            if(_loc3_)
            {
               this.binder._ratingData.removeFromParent();
               this.binder._base_params.visible = false;
               this.binder._content.height -= §_-gP§;
            }
            if(§_-z2g§.§_-ia§())
            {
               this.binder._clanName.text = §_-z2g§.clanMember.clanName;
               this.binder._rank.text = §_-6A§.§_-R1w§(§_-z2g§.clanMember.rank);
               this.clanEmblem = new §_-M11§();
               this.clanEmblem.size = this.binder._clanEmblem.height;
               this.clanEmblem.§_-6B§ = §_-z2g§.clanMember.clanEmblem;
               this.binder._clanEmblem.addChild(this.clanEmblem);
            }
            this.binder._vipIndicator.visible = _loc2_ && !_loc1_;
            this.binder._switchButton.visible = this.§_-Iq§ && !§_-33r§.§_-ym§(§_-z2g§) && §_-z2g§.getId() > 0;
            this.iconSource = §_-L1O§.§_-Yx§(§_-z2g§,this.binder._avatarPos,§_-z2g§.§_-P2e§(),§_-z2g§.getHat(),§_-z2g§.§_-32q§());
            this.binder._panel.y = _loc2_ && !_loc1_ ? 30 : 0;
            §_-b1z§(this.binder._container,this.binder._panel,_loc3_ ? int(-1 * §_-gP§) : 0);
         }
      }
      
      override public function dispose() : void
      {
         super.dispose();
         if(this.clanEmblem)
         {
            this.clanEmblem.dispose();
            this.clanEmblem = null;
         }
         if(this.iconSource)
         {
            this.iconSource.dispose();
            this.iconSource = null;
         }
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import starling.display.Button;
import starling.display.Image;
import starling.display.Sprite;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _teamData:LayoutGroup;
   
   public var _ratingData:LayoutGroup;
   
   public var _base_params:LayoutGroup;
   
   public var _panel:LayoutGroup;
   
   public var _avatarPos:Sprite;
   
   public var _clanEmblem:Sprite;
   
   public var _content:Sprite;
   
   public var _vipIndicator:Image;
   
   public var _name:Label;
   
   public var _id:Label;
   
   public var _clanName:Label;
   
   public var _rank:Label;
   
   public var _hpLabel:Label;
   
   public var _hpValue:Label;
   
   public var _armorLabel:Label;
   
   public var _armorValue:Label;
   
   public var _attackLabel:Label;
   
   public var _attackValue:Label;
   
   public var _teamLabel:Label;
   
   public var _teamValue:Label;
   
   public var _ratingLabel:Label;
   
   public var _ratingValue:Label;
   
   public var _fuzyValue:Label;
   
   public var _rubyValue:Label;
   
   public var _reactionValue:Label;
   
   public var _switchButton:Button;
   
   public function Binder()
   {
      super();
   }
}

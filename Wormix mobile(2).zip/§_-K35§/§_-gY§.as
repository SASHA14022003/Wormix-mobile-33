package §_-K35§
{
   import §_-31N§.§_-42G§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-937§.§_-n1b§;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-H3§.*;
   import §_-J3L§.§_-h1D§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-v2Q§;
   import §_-g2r§.§_-03A§;
   import §_-hv§.*;
   import §_-jF§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-rM§.§_-61j§;
   import §_-z1g§.§_-4l§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.events.DeviceOrientationEvent;
   import com.worlize.websocket.§_-03n§;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import feathers.controls.Button;
   import feathers.controls.ButtonState;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ToggleButton;
   import feathers.core.ITextRenderer;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.events.NativeWindowDisplayStateEvent;
   import flash.events.TimerEvent;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import flash.utils.getQualifiedClassName;
   import flash.utils.getTimer;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.client.GetWhoPumpedReaction;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.ScaleMode;
   
   public class §_-gY§ extends §_-E2w§
   {
      
      private static const §_-ca§:Number = 1;
      
      private var userProfile:UserProfile;
      
      private var unit:§_-01J§;
      
      private var loading:DisplayObject;
      
      private var §_-hg§:LayoutGroup;
      
      private var §_-U1e§:ImageLoader;
      
      private var §_-C1S§:Object;
      
      private var §_-jd§:Texture;
      
      private var §_-d2K§:Sprite;
      
      private var §_-t2p§:§_-p1m§;
      
      private var §_-Su§:Boolean;
      
      private var §_-T2z§:uint;
      
      private var §_-M9§:uint;
      
      private var §_-ex§:ITextRenderer;
      
      private var §_-U18§:ITextRenderer;
      
      public function §_-gY§(param1:DisplayObjectContainer, param2:Boolean = false)
      {
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         super(param1);
         this.§_-Su§ = param2;
         this.loading = getChildByName("loading");
         this.§_-M9§ = this.loading.height;
         this.§_-T2z§ = this.loading.width;
         §_-j2l§().setChildIndex(this.loading,0);
         this.§_-hg§ = new LayoutGroup();
         this.§_-hg§.clipContent = true;
         this.§_-d2K§ = new Sprite();
         this.§_-U1e§ = new ImageLoader();
         this.§_-U1e§.source = "";
         this.§_-U1e§.addEventListener(starling.events.Event.COMPLETE,this.§_-bE§);
         §_-13K§(this.§_-hg§,1);
         this.§_-hg§.addChild(this.§_-d2K§);
         this.§_-hg§.addChild(this.§_-U1e§);
         this.§_-ex§ = §_-j2l§().getChildByName("level") as ITextRenderer;
         this.§_-U18§ = §_-j2l§().getChildByName("level_shadow") as ITextRenderer;
         _loc3_ = this.loading.width;
         _loc4_ = this.loading.height;
         this.§_-hg§.x = this.loading.x + §_-ca§;
         this.§_-hg§.y = this.loading.y + §_-ca§;
         this.§_-hg§.width = _loc3_ - §_-ca§ * 2;
         this.§_-hg§.height = _loc4_ - §_-ca§ * 2;
         this.§_-d2K§.x = _loc3_ * 0.5;
         this.§_-d2K§.y = _loc4_;
         this.§_-U1e§.width = this.§_-hg§.width;
         this.§_-U1e§.height = this.§_-hg§.height;
         this.§_-U1e§.maintainAspectRatio = true;
         this.§_-U1e§.scaleMode = ScaleMode.SHOW_ALL;
         this.§_-t2p§ = new §_-p1m§();
      }
      
      private function §_-bE§(param1:starling.events.Event) : void
      {
         §_-c1v§(true);
         this.§_-d2K§.visible = false;
      }
      
      public function §_-82v§(param1:UserProfile, param2:§_-01J§ = null) : void
      {
         this.userProfile = param1;
         this.unit = param2;
         this.§_-v1L§(param1);
         this.§_-tH§(param1);
         if(this.§_-ex§)
         {
            this.§_-ex§.text = param1.getLevel().toString();
         }
         if(this.§_-U18§)
         {
            this.§_-U18§.text = param1.getLevel().toString();
         }
         dispatchEventWith(starling.events.Event.COMPLETE);
      }
      
      override public function §_-G1l§() : DisplayObject
      {
         return container;
      }
      
      private function §_-v1L§(param1:UserProfile) : void
      {
         var userProfile:UserProfile = param1;
         var newPhotoData:Object = userProfile.getSocialData() ? userProfile.getSocialData().getPhotoBig() : null;
         if(this.§_-C1S§ != newPhotoData)
         {
            this.§_-C1S§ = newPhotoData;
            this.§_-222§();
            if(this.§_-C1S§ is String)
            {
               this.§_-U1e§.source = this.§_-C1S§;
            }
            else if(this.§_-C1S§ is BitmapData)
            {
               this.§_-jd§ = Texture.fromBitmapData(this.§_-C1S§ as BitmapData);
               this.§_-U1e§.source = this.§_-jd§;
               Starling.juggler.delayCall(function():void
               {
                  if(Boolean(§_-U1e§) && Boolean(§_-U1e§.source))
                  {
                     §_-U1e§.dispatchEventWith(starling.events.Event.COMPLETE);
                  }
               },3);
            }
            else
            {
               this.§_-U1e§.source = "";
            }
         }
      }
      
      private function §_-tH§(param1:UserProfile) : void
      {
         if(this.§_-Su§)
         {
            §_-c1v§(false);
            return;
         }
         if(Boolean(param1) && Boolean(param1.§_-P2e§()))
         {
            this.§_-d2K§.removeChildren(0,-1,true);
            this.§_-t2p§.setIcon(param1);
            this.§_-t2p§.display.scaleX = this.§_-t2p§.display.scaleY = this.loading.width * §_-K1t§.§_-h2z§ / 40;
            this.§_-t2p§.display.y = -this.§_-hg§.height * 0.5;
            this.§_-d2K§.addChild(this.§_-t2p§.display);
            this.§_-d2K§.visible = true;
         }
      }
      
      private function §_-w1w§() : void
      {
         if(this.§_-t2p§)
         {
            this.§_-t2p§.dispose();
            this.§_-t2p§ = null;
         }
      }
      
      private function §_-222§() : void
      {
         if(this.§_-jd§)
         {
            this.§_-jd§.dispose();
            this.§_-jd§ = null;
         }
      }
      
      override public function dispose() : void
      {
         if(this.§_-U1e§)
         {
            this.§_-U1e§.removeEventListener(starling.events.Event.COMPLETE,this.§_-bE§);
         }
         if(this.§_-hg§)
         {
            this.§_-hg§.dispose();
         }
         this.§_-w1w§();
         this.§_-222§();
         this.userProfile = null;
         this.§_-U1e§ = null;
         this.§_-hg§ = null;
         this.§_-d2K§ = null;
         this.loading = null;
         this.§_-ex§ = null;
         this.§_-U18§ = null;
         super.dispose();
      }
   }
}


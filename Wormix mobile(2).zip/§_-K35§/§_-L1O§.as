package §_-K35§
{
   import §_-02q§.§_-4s§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-zF§;
   import §_-91A§.*;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.*;
   import §_-Y1O§.§_-yA§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-d26§.*;
   import §_-eW§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-Vr§;
   import §_-k2s§.§_-e1k§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m0§.§_-a1O§;
   import §_-n1w§.*;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-Uc§;
   import §_-z1g§.§_-lp§;
   import com.greensock.loading.*;
   import dragonBones.animation.WorldClock;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.ProgressEvent;
   import flash.geom.Point;
   import flash.net.URLLoader;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.UfoTargetPointer;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.client.RemoveFromGroup;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.phase.HarmBolt;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.textures.TextureSmoothing;
   
   public class §_-L1O§
   {
      
      private static const §_-Qj§:String = "N/A";
      
      private static const §_-X4§:Number = 80;
      
      private static const §_-O1G§:String = "back";
      
      public static const §_-a1h§:String = "worm";
      
      public static const §_-L1Z§:String = "wormGround";
      
      private static var §_-Q1f§:Number = 0;
      
      private static var §_-93Q§:Number = 0;
      
      private static var §_-2r§:Array = ["money","fuzes","realMoney","ruby","reactionRate","reaction","rating","ratingLabel","lineRating","ratingIcon","ratingIconShadow"];
      
      public function §_-L1O§()
      {
         super();
      }
      
      public static function §_-z1Z§(param1:DisplayObjectContainer, param2:UserProfile, param3:§_-01J§ = null) : void
      {
         §_-K3N§(param1,param2.getId() != 0);
         var _loc4_:String = "";
         §_-zc§(param1,"userName",(param2.§_-K3u§() || §_-Qj§) + _loc4_);
         §_-zc§(param1,"userName_short",param2 ? §_-33r§.§_-KQ§(param2) : §_-Qj§);
         §_-zc§(param1,"level",param2.getLevel() ? param2.getLevel().toString() : §_-Qj§);
         §_-zc§(param1,"hp",param3 ? §_-33r§.§_-jA§(param3.attributes.hp.§_-53§(),param3.attributes.hp.§_-a§()) : §_-33r§.§_-jA§(param2.stats.§_-g2I§.value,param2.stats.§_-q1G§.value));
         §_-zc§(param1,"hpLabel",§_-s2a§.§_-K3t§(§_-s2a§.HP));
         §_-zc§(param1,"teamHp",param2.§_-e2A§() ? param2.§_-e2A§().toString() : §_-Qj§);
         §_-zc§(param1,"teamHpLabel",§_-s2a§.§_-K3t§(§_-s2a§.TEAM_HP_LABEL));
         §_-zc§(param1,"teamSize",param2.§_-n26§() ? param2.§_-n26§().length.toString() : §_-Qj§);
         §_-zc§(param1,"teamLabel",§_-s2a§.§_-K3t§(§_-s2a§.TEAM_LABEL));
         §_-zc§(param1,"armor",param3 ? §_-33r§.§_-jA§(param3.attributes.armor.§_-53§(),param3.attributes.armor.§_-a§()) : §_-33r§.§_-jA§(param2.stats.§_-Z2U§.value,param2.stats.§_-v2n§.value));
         §_-zc§(param1,"armorLabel",§_-s2a§.§_-K3t§(§_-s2a§.ARMOR));
         §_-zc§(param1,"attack",param3 ? §_-33r§.§_-jA§(param3.attributes.attack.§_-53§(),param3.attributes.attack.§_-a§()) : §_-33r§.§_-jA§(param2.stats.§_-A3Z§.value,param2.stats.bonusAttack.value));
         §_-zc§(param1,"attackLabel",§_-s2a§.§_-K3t§(§_-s2a§.ATTACK));
         §_-zc§(param1,"rating",§_-Uc§.§_-Zp§(param2));
         §_-zc§(param1,"ratingLabel",§_-s2a§.§_-K3t§(§_-s2a§.RATING));
         §_-zc§(param1,"race",§_-s2a§.§_-K3t§(param2.§_-P2e§().getName()));
         §_-zc§(param1,"raceLabel",§_-s2a§.§_-K3t§(§_-s2a§.RACE));
         §_-zc§(param1,"money",param2.§_-51e§().toString());
         §_-zc§(param1,"realMoney",param2.§_-o1N§().toString());
         §_-zc§(param1,"reactionRate",param2.§_-u2l§().toString());
      }
      
      public static function §_-y1Y§(param1:DisplayObjectContainer, param2:String, param3:UserProfile, param4:§_-01J§) : void
      {
         var _loc5_:§_-zF§ = param4 ? param4.getHat() : param3.getHat();
         var _loc6_:§_-T1y§ = param4 ? param4.§_-32q§() : param3.§_-32q§();
         var _loc7_:DisplayObjectContainer = §_-YQ§.getClip(param2,param1) as DisplayObjectContainer;
         §_-L1O§.§_-Yx§(param3,_loc7_,param3.§_-P2e§(),_loc5_,_loc6_);
      }
      
      private static function §_-K3N§(param1:DisplayObjectContainer, param2:Boolean) : void
      {
         if(!param1)
         {
            return;
         }
         var _loc3_:DisplayObject = param1.getChildByName(§_-O1G§);
         var _loc4_:DisplayObject = param1.getChildByName(§_-a1h§);
         if(§_-Q1f§ == 0 && Boolean(_loc3_))
         {
            §_-Q1f§ = _loc3_.height;
         }
         if(§_-93Q§ == 0 && Boolean(_loc4_))
         {
            §_-93Q§ = _loc4_.y;
         }
         §_-Zm§(param1,§_-2r§,param2);
      }
      
      private static function §_-Zm§(param1:DisplayObjectContainer, param2:Array, param3:Boolean = false) : void
      {
         var _loc5_:DisplayObject = null;
         var _loc9_:Number = NaN;
         var _loc4_:* = int(param2.length);
         while(_loc4_--)
         {
            _loc5_ = param1.getChildByName(param2[_loc4_]);
            if(_loc5_)
            {
               _loc5_.visible = param3;
            }
         }
         var _loc6_:DisplayObject = param1.getChildByName(§_-O1G§);
         var _loc7_:DisplayObject = param1.getChildByName(§_-a1h§);
         var _loc8_:DisplayObject = param1.getChildByName(§_-L1Z§);
         if(_loc6_)
         {
            _loc6_.height = §_-Q1f§ - (param3 ? 0 : §_-X4§);
         }
         if(_loc7_)
         {
            _loc9_ = _loc8_ ? _loc8_.y - _loc7_.y : 0;
            _loc7_.y = §_-93Q§ - (param3 ? 0 : §_-X4§ * 0.5);
            if(_loc8_)
            {
               _loc8_.y = _loc7_.y + _loc9_;
            }
         }
      }
      
      public static function §_-Yx§(param1:UserProfile, param2:DisplayObjectContainer, param3:§_-B2i§ = null, param4:§_-zF§ = null, param5:§_-T1y§ = null) : §_-di§
      {
         var _loc6_:§_-618§ = new §_-618§(param1,param3);
         _loc6_.§_-L§(param4);
         _loc6_.§_-aV§(param5);
         _loc6_.§_-11e§(param2);
         return _loc6_;
      }
      
      private static function §_-zc§(param1:DisplayObjectContainer, param2:String, param3:String) : void
      {
         if(§_-73b§(param1,param2))
         {
            param1.getChildByName(param2)["text"] = param3;
         }
      }
      
      private static function §_-73b§(param1:DisplayObjectContainer, param2:String) : Boolean
      {
         return param1 == null ? false : param1.getChildByName(param2) != null;
      }
   }
}


package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-L1w§.§_-J2w§;
   import §_-QD§.§_-G2z§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-f1o§.§_-d29§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.menu.clans.chat.§_-D2t§;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-22H§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:§_-D2t§;
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      [Inject]
      public var §_-R2C§:§_-d29§;
      
      public function §_-22H§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(§_-D2t§.§_-kZ§,this.§_-W2X§);
         §_-32S§(§_-D2t§.§_-M2p§,this.§_-x2o§);
         §_-32S§(§_-D2t§.SEND_MESSAGE,this.§_-h9§);
         §_-32S§(§_-D2t§.SEND_STICKER,this.§_-d1j§);
         §_-g2k§(§_-tc§.§_-33G§,this.§_-p1o§);
         §_-g2k§(§_-aG§.§_-Y6§,this.§_-P1X§);
         §_-g2k§(§_-aG§.§_-52W§,this.§_-c21§);
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-G1n§);
         this.§_-2f§.§_-C2Y§ = §_-A23§.userClan.id;
         this.§_-2f§.userProfile = Application.userProfile;
         this.§_-j1r§.setData(§_-A23§.userClan,this.§_-2f§.userProfile);
         Starling.juggler.delayCall(this.§_-j1r§.update,0.1,this.§_-R2C§.§_-111§(),this.§_-R2C§.§_-P1s§());
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      private function §_-G1n§(param1:Event) : void
      {
         this.§_-j1r§.invalidate(§_-dU§.§_-h26§);
      }
      
      private function §_-W2X§() : void
      {
         dispatchWith(§_-61Z§.§_-b2d§);
      }
      
      private function §_-x2o§() : void
      {
         dispatchWith(§_-61Z§.§_-n10§);
      }
      
      private function §_-h9§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-4i§,false,param1.data);
      }
      
      private function §_-d1j§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-73z§,false,param1.data);
      }
      
      private function §_-p1o§() : void
      {
         this.§_-j1r§.setData(§_-A23§.userClan,this.§_-2f§.userProfile);
      }
      
      private function §_-P1X§(param1:Event) : void
      {
         var _loc2_:ClanChatMessageTO = param1.data as ClanChatMessageTO;
         if(_loc2_)
         {
            this.§_-j1r§.§_-o2B§(_loc2_);
         }
      }
      
      private function §_-c21§(param1:Event) : void
      {
         this.§_-j1r§.§_-x1S§(this.§_-R2C§.§_-P1s§());
      }
   }
}


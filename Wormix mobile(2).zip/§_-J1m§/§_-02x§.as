package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-A2U§.§_-A23§;
   import §_-H16§.*;
   import §_-L1w§.§_-J2w§;
   import §_-SP§.§_-M4§;
   import §_-Vg§.ClanInfoView;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-f1o§.§_-k2c§;
   import §_-f1o§.§_-p2X§;
   import §_-q26§.§_-52J§;
   import §_-z1w§.*;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import starling.events.Event;
   import starling.utils.MathUtil;
   
   public class §_-02x§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanInfoView;
      
      [Inject]
      public var §_-yK§:§_-p2X§;
      
      [Inject]
      public var §_-Z2Z§:§_-k2c§;
      
      [Inject]
      public var clanParamHelper:§_-52J§;
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      public function §_-02x§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(ClanInfoView.§_-vE§,this.§_-7d§);
         §_-32S§(ClanInfoView.§_-43i§,this.§_-A2H§);
         §_-32S§(ClanInfoView.§_-w8§,this.§_-a17§);
         §_-g2k§(§_-F1g§.§_-gL§,this.§_-93g§);
         §_-g2k§(§_-F1g§.§_-921§,this.§_-h13§);
         §_-g2k§(§_-aG§.§_-D2Y§,this.§_-vN§);
         §_-g2k§(§_-aG§.§_-91N§,this.§_-q23§);
         §_-g2k§(§_-aG§.§_-jf§,this.§_-e1i§);
         §_-g2k§(§_-tc§.§_-33G§,this.§_-D2N§);
         this.§_-Z2Z§.§_-u2B§(this.§_-2f§.§_-E24§);
      }
      
      private function §_-93g§() : void
      {
         this.§_-Z2Z§.§_-u2B§(this.§_-2f§.§_-E24§);
      }
      
      private function §_-h13§() : void
      {
         this.§_-l24§();
      }
      
      override public function onRemove() : void
      {
         this.§_-2f§.§_-23u§();
      }
      
      private function §_-vN§(param1:Event) : void
      {
         this.§_-l24§();
      }
      
      private function §_-7d§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-42B§);
      }
      
      private function §_-A2H§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-43i§);
      }
      
      private function §_-e1i§(param1:Event) : void
      {
         this.§_-j1r§.dispatchEventWith(§_-M4§.WINDOW_CLOSE);
      }
      
      private function §_-a17§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-w8§,false,param1.data);
      }
      
      private function §_-q23§(param1:Event) : void
      {
         this.§_-l24§();
      }
      
      private function §_-D2N§() : void
      {
         this.§_-Z2Z§.§_-u2B§(this.§_-2f§.§_-E24§);
      }
      
      private function §_-l24§() : void
      {
         var _loc1_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-E24§);
         if(_loc1_)
         {
            this.§_-j1r§.setData(_loc1_,this.§_-2f§.userProfile,this.clanParamHelper,§_-A23§.§_-E2Z§());
         }
      }
   }
}


package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-A2S§.§_-52j§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-l1K§.*;
   import feathers.controls.List;
   import feathers.layout.VerticalLayout;
   import feathers.layout.VerticalLayoutData;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-Y2S§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:§_-52j§;
      
      public function §_-Y2S§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-g2k§(§_-F1g§.§_-n15§,this.§_-a0§);
         §_-g2k§(§_-F1g§.§_-51G§,this.§_-a0§);
         §_-g2k§(§_-F1g§.§_-C3B§,this.§_-a0§);
      }
      
      private function §_-a0§() : void
      {
         this.§_-j1r§.hide();
      }
   }
}


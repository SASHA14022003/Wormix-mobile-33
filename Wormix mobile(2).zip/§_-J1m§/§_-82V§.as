package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-L1H§.§_-C3e§;
   import §_-L1w§.§_-CD§;
   import §_-L1w§.§_-J2w§;
   import §_-SP§.§_-M4§;
   import §_-Vg§.ClanCreateView;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-F3q§;
   import feathers.events.FeathersEventType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import starling.events.Event;
   
   public class §_-82V§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanCreateView;
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      [Inject]
      public var §_-21d§:§_-CD§;
      
      private var §_-I2f§:Boolean = false;
      
      public function §_-82V§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         this.§_-j1r§.§_-o2M§(§_-F3q§.getInstance());
         this.§_-j1r§.§_-e2D§(this.§_-21d§);
         this.§_-j1r§.§_-318§(§_-8D§.§_-L1L§.price);
         §_-32S§(ClanCreateView.§_-d10§,this.§_-Y1T§);
         §_-32S§(ClanCreateView.§_-Z2c§,this.§_-43x§);
         §_-g2k§(§_-aG§.§_-A1i§,this.§_-63x§);
         §_-g2k§(§_-tc§.§_-93r§,this.§_-C1D§);
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         if(this.§_-I2f§)
         {
            this.§_-21d§.clear();
         }
         else
         {
            this.§_-j1r§.§_-B20§(this.§_-21d§);
         }
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      private function §_-Y1T§(param1:Event) : void
      {
         this.§_-j1r§.§_-B20§(this.§_-21d§);
         dispatchWith(§_-61Z§.§_-f1v§);
      }
      
      private function §_-43x§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-22f§);
      }
      
      private function §_-63x§() : void
      {
         this.§_-I2f§ = true;
         this.§_-j1r§.dispatchEventWith(§_-M4§.WINDOW_CLOSE);
      }
      
      private function §_-C1D§() : void
      {
         this.§_-21d§.§_-6B§ = this.§_-21d§.§_-o9§.concat();
         this.§_-j1r§.§_-D1s§(this.§_-21d§.§_-6B§);
      }
      
      private function §_-G1n§(param1:Event) : void
      {
         this.§_-j1r§.invalidate(§_-dU§.§_-h26§);
      }
   }
}


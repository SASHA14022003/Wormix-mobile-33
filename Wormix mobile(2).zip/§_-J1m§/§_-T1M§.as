package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-DJ§.§_-J2l§;
   import §_-J3L§.§_-h1D§;
   import §_-L1H§.§_-b2K§;
   import §_-L1w§.§_-CD§;
   import §_-Vg§.ClanEditEmblemView;
   import §_-Y1Q§.§_-tc§;
   import §_-u1T§.§_-r1F§;
   import §_-zI§.§_-F3q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import starling.events.Event;
   
   public class §_-T1M§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanEditEmblemView;
      
      [Inject]
      public var §_-21d§:§_-CD§;
      
      public function §_-T1M§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         if(this.§_-j1r§ is §_-r1F§)
         {
            (this.§_-j1r§ as §_-r1F§).§_-DW§(§_-X1j§.localizationService);
         }
         this.§_-j1r§.§_-o2M§(§_-F3q§.getInstance());
         this.§_-j1r§.setData(this.§_-21d§.§_-o9§);
         §_-32S§(Event.COMPLETE,this.§_-NH§);
         §_-32S§(Event.CANCEL,this.§_-3h§);
      }
      
      private function §_-NH§(param1:Event) : void
      {
         var _loc2_:Vector.<uint> = param1.data as Vector.<uint>;
         if(_loc2_)
         {
            this.§_-21d§.§_-o9§ = _loc2_;
         }
         dispatchWith(§_-tc§.§_-93r§);
         this.§_-j1r§.dispatchEventWith(§_-h1D§.WINDOW_CLOSE);
      }
      
      private function §_-3h§(param1:Event) : void
      {
         this.§_-j1r§.dispatchEventWith(§_-h1D§.WINDOW_CLOSE);
      }
   }
}


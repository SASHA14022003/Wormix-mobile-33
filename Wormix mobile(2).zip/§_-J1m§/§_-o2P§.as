package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-B2z§.*;
   import §_-Vg§.ClanActivityView;
   import §_-Y1Q§.§_-aG§;
   import §_-f1o§.§_-k2c§;
   import §_-r1C§.§_-h2B§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import starling.events.Event;
   
   public class §_-o2P§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanActivityView;
      
      [Inject]
      public var §_-Z2Z§:§_-k2c§;
      
      public function §_-o2P§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-g2k§(§_-aG§.§_-C1N§,this.§_-W1T§);
         this.§_-j1r§.§_-DW§(§_-X1j§.localizationService);
         this.§_-Z2Z§.§_-o1s§();
      }
      
      private function §_-W1T§(param1:Event) : void
      {
         var _loc2_:Vector.<ClanAuditActionTO> = param1.data as Vector.<ClanAuditActionTO>;
         this.§_-j1r§.setData(§_-6A§.§_-Jr§(_loc2_));
      }
   }
}


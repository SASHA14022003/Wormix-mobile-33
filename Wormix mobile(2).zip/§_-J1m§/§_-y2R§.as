package §_-J1m§
{
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-71F§.§_-kk§;
   import §_-B1y§.§_-F1P§;
   import §_-H2g§.§_-di§;
   import §_-N8§.*;
   import §_-SP§.§_-M4§;
   import §_-X14§.MainSidePanel;
   import §_-X14§.§_-r2o§;
   import §_-X14§.§_-y2U§;
   import §_-j1y§.§_-i1b§;
   import §_-u1P§.ShopResultEvent;
   import dragonBones.animation.WorldClock;
   import feathers.controls.List;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.logger.ConsolePublisher;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.§_-1F§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.events.TouchEvent;
   
   public class §_-y2R§ extends §_-kk§
   {
      
      private static var selectedItemIndex:int = 0;
      
      [Inject]
      public var §_-j1r§:MainSidePanel;
      
      public function §_-y2R§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(Event.TRIGGERED,this.§_-r1l§);
         §_-32S§(Event.SELECT,this.§_-31w§);
         §_-32S§(TouchEvent.TOUCH,this.§_-92i§);
         §_-g2k§(§_-M4§.§_-U1m§,this.§_-61Q§);
         this.§_-j1r§.§_-DW§(§_-X1j§.localizationService);
         var _loc1_:Array = [];
         if(§_-N1V§.settings.§_-03F§)
         {
            _loc1_.push({
               "id":§_-s2a§.FRIENDS_TAB,
               "screenClass":new §_-r2o§()
            });
         }
         _loc1_.push({
            "id":§_-s2a§.GLOBAL_CHAT_TAB,
            "screenClass":new §_-y2U§()
         });
         _loc1_.push({
            "id":§_-s2a§.CLAN_CHAT_TAB,
            "screenClass":new §_-1F§()
         });
         if(§_-N1V§.settings.§_-03F§)
         {
            selectedItemIndex = 1;
         }
         else if(Application.userProfile.§_-ia§())
         {
            selectedItemIndex = §_-N1V§.settings.§_-03F§ ? 2 : 1;
         }
         this.§_-j1r§.setData(_loc1_,selectedItemIndex);
      }
      
      private function §_-r1l§(param1:Event) : void
      {
         if(!Application.§_-ow§.isLeftDrawerOpen)
         {
            this.§_-j1r§.§_-w1h§(selectedItemIndex);
         }
         Application.§_-ow§.toggleLeftDrawer();
      }
      
      private function §_-31w§(param1:Event) : void
      {
         selectedItemIndex = param1.data as int;
      }
      
      private function §_-92i§(param1:TouchEvent) : void
      {
         Application.§_-ow§.isEnabled = !param1.interactsWith(this.§_-j1r§);
      }
      
      private function §_-61Q§() : void
      {
         if(Application.§_-ow§.isLeftDrawerOpen)
         {
            Application.§_-ow§.toggleLeftDrawer(0);
         }
      }
   }
}


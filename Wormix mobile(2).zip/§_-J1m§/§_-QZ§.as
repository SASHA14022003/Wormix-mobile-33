package §_-J1m§
{
   import §_-3D§.§_-E3x§;
   import §_-71F§.§_-kk§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-K3q§.*;
   import §_-Vg§.ClanTreasuryView;
   import §_-W§.§_-ix§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-tc§;
   import §_-l1K§.§_-W2f§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-F3q§;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import starling.events.Event;
   
   public class §_-QZ§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanTreasuryView;
      
      public function §_-QZ§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(ClanTreasuryView.§_-V2o§,this.§_-jY§);
         §_-32S§(ClanTreasuryView.§_-f29§,this.§_-H2x§);
         §_-32S§(ClanTreasuryView.§_-Y1I§,this.§_-lf§);
         §_-g2k§(§_-tc§.§_-33G§,this.§_-D2N§);
         this.§_-j1r§.setData(§_-A23§.userClan,Application.userProfile,§_-F3q§.getInstance());
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-G1n§);
      }
      
      private function §_-jY§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-Q21§,false,int(param1.data));
      }
      
      private function §_-H2x§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-E1d§);
      }
      
      private function §_-lf§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-Rd§,false,param1.data);
      }
      
      private function §_-D2N§() : void
      {
         this.§_-j1r§.setData(§_-A23§.userClan,Application.userProfile,§_-F3q§.getInstance());
      }
      
      private function §_-G1n§(param1:Event) : void
      {
         this.§_-j1r§.invalidate(§_-dU§.§_-h26§);
      }
   }
}


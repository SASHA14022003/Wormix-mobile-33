package §_-J1m§
{
   import §_-31W§.§_-r26§;
   import §_-71F§.§_-kk§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.*;
   import §_-L1w§.§_-CD§;
   import §_-L1w§.§_-J2w§;
   import §_-Vg§.ClanEditView;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-A3S§;
   import §_-Y1Q§.§_-C2D§;
   import §_-Y1Q§.§_-O2s§;
   import §_-Y1Q§.§_-U2m§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1Q§.§_-u4§;
   import §_-Y1Q§.§_-y2e§;
   import §_-l1K§.§_-sV§;
   import §_-p24§.*;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-F3q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.MathUtil;
   
   public class §_-V1C§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanEditView;
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      [Inject]
      public var §_-21d§:§_-CD§;
      
      public function §_-V1C§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(ClanEditView.EDIT_EMBLEM,this.§_-43x§);
         §_-32S§(ClanEditView.§_-e1D§,this.§_-538§);
         §_-32S§(ClanEditView.§_-hP§,this.§_-sh§);
         §_-32S§(ClanEditView.§_-Y2n§,this.§_-a2J§);
         §_-32S§(ClanEditView.§_-v2p§,this.§_-B6§);
         §_-32S§(ClanEditView.§_-vv§,this.§_-aL§);
         §_-32S§(ClanEditView.§_-xn§,this.§_-t18§);
         §_-g2k§(§_-aG§.§_-02p§,this.§_-4p§);
         §_-g2k§(§_-aG§.§_-S2i§,this.§_-x2x§);
         §_-g2k§(§_-tc§.§_-33G§,this.§_-x2x§);
         §_-g2k§(§_-tc§.§_-93r§,this.§_-o1T§);
         this.§_-j1r§.§_-o2M§(§_-F3q§.getInstance());
         this.§_-x2x§();
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         this.§_-21d§.clear();
      }
      
      private function §_-x2x§() : void
      {
         var _loc1_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         this.§_-21d§.§_-XF§(_loc1_);
         this.§_-j1r§.§_-h2g§(this.§_-21d§,this.§_-2f§.userProfile);
      }
      
      private function §_-43x§(param1:Event) : void
      {
         dispatchWith(§_-61Z§.§_-22f§);
      }
      
      private function §_-o1T§() : void
      {
         this.§_-j1r§.§_-h2g§(this.§_-21d§,this.§_-2f§.userProfile);
      }
      
      private function §_-538§(param1:Event) : void
      {
         var _loc2_:String = §_-X1j§.§_-sO§.§_-gO§(param1.data as String);
         var _loc3_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         var _loc4_:UserProfile = this.§_-2f§.userProfile;
         var _loc5_:§_-u4§ = new §_-u4§(_loc2_,_loc3_,_loc4_);
         dispatch(_loc5_);
      }
      
      private function §_-sh§(param1:Event) : void
      {
         var _loc2_:String = §_-X1j§.§_-sO§.§_-gO§(param1.data as String);
         var _loc3_:ClanTO = §_-A23§.userClan;
         var _loc4_:UserProfile = Application.userProfile;
         var _loc5_:§_-U2m§ = new §_-U2m§(_loc2_,_loc3_,_loc4_);
         dispatch(_loc5_);
      }
      
      private function §_-a2J§(param1:Event) : void
      {
         var _loc2_:Vector.<uint> = Vector.<uint>(param1.data);
         var _loc3_:ClanTO = §_-A23§.userClan;
         var _loc4_:UserProfile = Application.userProfile;
         var _loc5_:§_-A3S§ = new §_-A3S§(_loc2_,_loc3_,_loc4_);
         dispatch(_loc5_);
      }
      
      private function §_-4p§() : void
      {
         var _loc1_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         this.§_-21d§.§_-XF§(_loc1_);
         this.§_-j1r§.§_-h2g§(this.§_-21d§,this.§_-2f§.userProfile);
      }
      
      private function §_-B6§(param1:Event) : void
      {
         var _loc2_:int = int(param1.data as int);
         var _loc3_:ClanTO = §_-A23§.userClan;
         var _loc4_:UserProfile = Application.userProfile;
         var _loc5_:§_-y2e§ = new §_-y2e§(_loc2_,_loc3_,_loc4_);
         dispatch(_loc5_);
      }
      
      private function §_-EZ§() : void
      {
         this.§_-j1r§.invalidate(§_-dU§.§_-Mf§);
      }
      
      private function §_-aL§(param1:Event) : void
      {
         var _loc2_:Boolean = Boolean(param1.data as Boolean);
         var _loc3_:ClanTO = §_-A23§.userClan;
         var _loc4_:UserProfile = Application.userProfile;
         var _loc5_:§_-C2D§ = new §_-C2D§(_loc2_,_loc3_,_loc4_);
         dispatch(_loc5_);
      }
      
      private function §_-t18§(param1:Event) : void
      {
         var _loc2_:ClanTO = §_-A23§.userClan;
         var _loc3_:UserProfile = Application.userProfile;
         var _loc4_:§_-O2s§ = new §_-O2s§(_loc2_,_loc3_);
         dispatch(_loc4_);
      }
      
      private function §_-j1a§() : void
      {
         this.§_-j1r§.invalidate(§_-dU§.§_-F9§);
      }
   }
}


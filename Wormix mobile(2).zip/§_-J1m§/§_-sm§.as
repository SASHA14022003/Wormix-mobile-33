package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-A2U§.§_-A23§;
   import §_-L1H§.§_-b2K§;
   import §_-L1w§.§_-J2w§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-f1o§.§_-k2c§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.BillingService;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.InAppBillingServiceTypes;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import config.§_-vR§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.NotInClanChatScreen;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.events.Event;
   
   public class §_-sm§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:NotInClanChatScreen;
      
      [Inject]
      public var §_-yx§:§_-J2w§;
      
      [Inject]
      public var §_-Z2Z§:§_-k2c§;
      
      private var §_-23M§:ClanInviteStructure;
      
      public function §_-sm§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         this.§_-yx§.userProfile = Application.userProfile;
         §_-32S§(NotInClanChatScreen.§_-L1L§,this.§_-U1O§);
         §_-32S§(NotInClanChatScreen.§_-u2h§,this.§_-Xi§);
         §_-32S§(NotInClanChatScreen.§_-91u§,this.§_-13H§);
         §_-g2k§(§_-F1g§.§_-921§,this.§_-m8§);
         §_-g2k§(§_-aG§.§_-D2Y§,this.§_-vN§);
         §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-Z1X§);
         this.§_-l24§();
         this.§_-j1r§.invalidate(§_-dU§.§_-h26§);
      }
      
      private function §_-l24§() : void
      {
         this.§_-j1r§.setData(§_-A23§.§_-E2Z§());
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-Z1X§);
      }
      
      private function §_-Z1X§(param1:Event) : void
      {
         this.§_-j1r§.invalidate(§_-dU§.§_-h26§);
      }
      
      private function §_-U1O§() : void
      {
         dispatchWith(§_-61Z§.§_-51C§);
      }
      
      private function §_-Xi§() : void
      {
         dispatchWith(§_-61Z§.§_-DZ§);
      }
      
      private function §_-13H§(param1:Event) : void
      {
         this.§_-23M§ = param1.data as ClanInviteStructure;
         if(this.§_-23M§)
         {
            this.§_-Z2Z§.§_-u2B§(this.§_-23M§.clanId);
         }
      }
      
      private function §_-vN§(param1:Event) : void
      {
         var _loc2_:ClanTO = param1.data as ClanTO;
         if(Boolean(_loc2_) && Boolean(this.§_-23M§) && _loc2_.id == this.§_-23M§.clanId)
         {
            this.§_-23M§ = null;
            dispatchWith(§_-61Z§.§_-bg§,false,_loc2_);
         }
      }
      
      private function §_-m8§(param1:Event) : void
      {
         this.§_-l24§();
      }
   }
}


package §_-J1m§
{
   import §_-71F§.§_-kk§;
   import §_-L1w§.§_-CD§;
   import §_-SP§.§_-M4§;
   import §_-Vg§.MainClanWindow;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-ZP§.§_-b23§;
   import feathers.events.FeathersEventType;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.Align;
   
   public class §_-m1a§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:MainClanWindow;
      
      public function §_-m1a§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-g2k§(§_-F1g§.§_-51G§,this.§_-A1f§);
         §_-g2k§(§_-aG§.§_-jf§,this.§_-A2H§);
         §_-g2k§(§_-M4§.§_-U1m§,this.§_-61Q§);
         Application.§_-E1k§.addEventListener(FeathersEventType.TRANSITION_START,this.§_-13D§);
      }
      
      override public function onRemove() : void
      {
         super.onRemove();
         Application.§_-E1k§.removeEventListener(FeathersEventType.TRANSITION_START,this.§_-13D§);
      }
      
      private function §_-13D§(param1:Event) : void
      {
         this.§_-j1r§.hide();
      }
      
      private function §_-A2H§() : void
      {
         this.§_-j1r§.§_-4r§();
      }
      
      private function §_-A1f§() : void
      {
         this.§_-j1r§.hide();
      }
      
      private function §_-61Q§() : void
      {
         this.§_-j1r§.hide();
      }
   }
}


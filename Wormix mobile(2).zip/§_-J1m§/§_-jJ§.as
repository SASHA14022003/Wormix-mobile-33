package §_-J1m§
{
   import §_-62§.*;
   import §_-71F§.§_-kk§;
   import §_-Ly§.§_-81L§;
   import §_-SP§.§_-M4§;
   import §_-Vg§.ClanSearchView;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-aG§;
   import §_-f1o§.§_-k2c§;
   import §_-l1K§.§_-cZ§;
   import §_-o14§.*;
   import §_-q26§.§_-52J§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-jJ§ extends §_-kk§
   {
      
      [Inject]
      public var §_-j1r§:ClanSearchView;
      
      [Inject]
      public var §_-Z2Z§:§_-k2c§;
      
      [Inject]
      public var clanParamHelper:§_-52J§;
      
      public function §_-jJ§()
      {
         super();
      }
      
      override public function §_-b2M§() : void
      {
         §_-32S§(ClanSearchView.§_-L2E§,this.§_-i2A§);
         §_-32S§(ClanSearchView.§_-zQ§,this.§_-t1d§);
         §_-32S§(ClanSearchView.§_-G1t§,this.§_-M1b§);
         §_-g2k§(§_-aG§.§_-2E§,this.§_-A2t§);
         §_-g2k§(§_-aG§.§_-91N§,this.§_-q23§);
         this.§_-j1r§.init(§_-F3q§.getInstance(),this.clanParamHelper);
         this.§_-Z2Z§.§_-WX§();
      }
      
      private function §_-i2A§(param1:Event) : void
      {
         var _loc2_:String = param1.data as String;
         this.§_-Z2Z§.§_-S1W§(_loc2_);
      }
      
      private function §_-t1d§(param1:Event) : void
      {
         this.§_-Z2Z§.§_-WX§();
      }
      
      private function §_-M1b§(param1:Event) : void
      {
         var _loc2_:ClanTO = param1.data as ClanTO;
         if(_loc2_)
         {
            dispatchWith(§_-61Z§.§_-bg§,false,_loc2_);
         }
      }
      
      private function §_-A2t§(param1:Event) : void
      {
         var _loc2_:Vector.<ClanTO> = param1.data as Vector.<ClanTO>;
         if(_loc2_)
         {
            this.§_-j1r§.setData(_loc2_);
         }
      }
      
      private function §_-q23§(param1:Event) : void
      {
         this.§_-j1r§.dispatchEventWith(§_-M4§.WINDOW_CLOSE);
      }
   }
}


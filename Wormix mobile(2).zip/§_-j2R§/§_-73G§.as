package §_-j2R§
{
   import §_-2U§.*;
   import §_-31W§.§_-r26§;
   import §_-5Y§.§_-h2c§;
   import §_-82a§.§_-c2B§;
   import §_-82a§.§_-zv§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.§_-63i§;
   import §_-CR§.§_-72p§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-F39§.*;
   import §_-G2H§.*;
   import §_-K35§.§_-99§;
   import §_-L1H§.§_-b2K§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-y1o§;
   import §_-Z1K§.§_-A2n§;
   import §_-Z1K§.§_-I1T§;
   import §_-aM§.§_-51L§;
   import §_-aM§.§_-P1N§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-s20§.§_-J2g§;
   import §_-sQ§.§_-H3D§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.display.SimpleButton;
   import flash.errors.IllegalOperationError;
   import flash.events.*;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialErrorCode;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.gui.menu.shop.desktop.§_-11V§;
   import ru.pragmatix.wormix.messages.clans.request.treasury.CashMedalsClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.Disconnect;
   import ru.pragmatix.wormix.messages.structures.ReconnectToSimpleBattleResultStructure;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-73G§
   {
      
      public static const §_-Jg§:int = -1;
      
      public static const §_-U2t§:int = 1;
      
      protected var name:String;
      
      protected var duration:int;
      
      protected var value:int;
      
      protected var §_-kG§:Boolean = false;
      
      protected var counter:uint;
      
      protected var unit:§_-01J§;
      
      public function §_-73G§(param1:String, param2:int, param3:int)
      {
         super();
         this.name = param1;
         this.duration = param2;
         this.value = param3;
      }
      
      public function getName() : String
      {
         return this.name;
      }
      
      public function §_-y2Y§() : uint
      {
         return this.duration;
      }
      
      public function getValue() : int
      {
         return this.value;
      }
      
      public function isCleared() : Boolean
      {
         return this.§_-kG§;
      }
      
      public function §_-E15§() : int
      {
         return this.duration - this.counter;
      }
      
      public function reset() : void
      {
         this.counter = 0;
      }
      
      public function place(param1:§_-01J§) : void
      {
         this.unit = param1;
         this.reset();
         this.§_-BK§();
      }
      
      public function §_-W1g§(param1:int) : void
      {
         this.value += param1;
      }
      
      public function §_-U1s§(param1:§_-01J§) : void
      {
      }
      
      public function clear() : void
      {
         if(!this.§_-kG§)
         {
            this.§_-QE§();
            this.§_-kG§ = true;
            this.unit = null;
         }
      }
      
      protected function §_-BK§() : void
      {
      }
      
      protected function §_-QE§() : void
      {
      }
   }
}


package §_-j2R§
{
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-62§.§_-L1r§;
   import §_-73I§.§_-K2s§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-D3A§.§_-UK§;
   import §_-L1H§.§_-b2K§;
   import §_-V1H§.§_-m1d§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-Y23§.*;
   import §_-Z1K§.*;
   import §_-d2p§.§_-Sw§;
   import §_-e2r§.*;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m0§.§_-X1F§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-U1A§;
   import §_-zI§.§_-X1q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.util.der.*;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.themes.FontColor;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.client.AchieveLogin;
   import ru.pragmatix.wormix.messages.client.GetProfiles;
   import ru.pragmatix.wormix.messages.server.AchieveLoginError;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.ammo.phase.HarmPhase;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.Color;
   
   public class §_-v1T§
   {
      
      private var worm:§_-01J§;
      
      private var buffs:Object = {};
      
      public function §_-v1T§(param1:§_-01J§)
      {
         super();
         this.worm = param1;
      }
      
      public function place(param1:§_-73G§) : void
      {
         if(!this.worm.disposed)
         {
            if(!this.hasBuff(param1.getName()))
            {
               this.buffs[param1.getName()] = param1;
               param1.place(this.worm);
            }
            else
            {
               §_-73G§(this.buffs[param1.getName()]).reset();
            }
         }
      }
      
      public function add(param1:§_-73G§) : void
      {
         var _loc2_:§_-73G§ = null;
         if(!this.worm.disposed)
         {
            _loc2_ = this.worm.buffs.getBuff(param1.getName());
            if(_loc2_)
            {
               param1.§_-W1g§(_loc2_.getValue());
               this.worm.buffs.§_-e1z§(param1.getName());
            }
            this.place(param1);
         }
      }
      
      public function §_-O1h§(param1:Array) : Boolean
      {
         var _loc2_:§_-73G§ = null;
         for each(_loc2_ in this.buffs)
         {
            if(param1.indexOf(_loc2_.getName()) > -1 && !_loc2_.isCleared())
            {
               return true;
            }
         }
         return false;
      }
      
      public function hasBuff(param1:String) : Boolean
      {
         var _loc2_:§_-73G§ = null;
         for each(_loc2_ in this.buffs)
         {
            if(_loc2_.getName() == param1)
            {
               return !_loc2_.isCleared();
            }
         }
         return false;
      }
      
      public function getBuff(param1:String) : §_-73G§
      {
         var _loc2_:§_-73G§ = null;
         for each(_loc2_ in this.buffs)
         {
            if(_loc2_.getName() == param1 && !_loc2_.isCleared())
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public function §_-e1z§(param1:String) : void
      {
         var _loc2_:§_-73G§ = null;
         for each(_loc2_ in this.buffs)
         {
            if(_loc2_.getName() == param1)
            {
               _loc2_.clear();
            }
         }
      }
      
      public function clearAll() : void
      {
         var _loc1_:§_-73G§ = null;
         for each(_loc1_ in this.buffs)
         {
            if(!_loc1_.isCleared())
            {
               _loc1_.clear();
            }
         }
         this.buffs = [];
      }
      
      public function §_-K1S§(param1:§_-01J§) : void
      {
         var _loc2_:§_-73G§ = null;
         for each(_loc2_ in this.buffs)
         {
            if(!_loc2_.isCleared())
            {
               _loc2_.§_-U1s§(param1);
            }
         }
      }
      
      public function §_-b2x§() : void
      {
         var _loc1_:§_-73G§ = null;
         for each(_loc1_ in this.buffs)
         {
            if(!_loc1_.getName())
            {
            }
         }
      }
   }
}


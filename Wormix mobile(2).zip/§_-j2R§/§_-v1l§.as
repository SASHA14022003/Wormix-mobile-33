package §_-j2R§
{
   import §_-12W§.§_-221§;
   import §_-21p§.§_-4w§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-63U§.§_-412§;
   import §_-91B§.§_-z2l§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-E29§.*;
   import §_-GQ§.§_-31v§;
   import §_-RE§.*;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-YF§.§_-q2v§;
   import §_-fo§.§_-r5§;
   import §_-k13§.§_-j23§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.*;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-g1a§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import flash.display.MovieClip;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-v1l§ extends §_-73G§
   {
      
      public function §_-v1l§(param1:String, param2:int, param3:int = 1)
      {
         super(param1,param2,param3);
      }
      
      override public function place(param1:§_-01J§) : void
      {
         super.place(param1);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.onNextTurn);
      }
      
      override public function clear() : void
      {
         if(!§_-kG§)
         {
            §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.onNextTurn);
            super.clear();
         }
      }
      
      protected function onNextTurn(param1:starling.events.Event) : void
      {
         this.§_-S2M§();
         var _loc2_:* = §§findproperty(counter);
         var _temp_2:* = Number(_loc2_.counter);
         var _loc3_:Number = _temp_2 + 1;
         _loc2_.counter = _loc3_;
         if(_temp_2 >= duration && duration != -1)
         {
            this.clear();
         }
      }
      
      protected function §_-S2M§() : void
      {
      }
      
      public function §_-B3k§() : int
      {
         return duration - counter;
      }
      
      public function §_-C1d§(param1:§_-01J§) : void
      {
         this.place(param1);
      }
   }
}


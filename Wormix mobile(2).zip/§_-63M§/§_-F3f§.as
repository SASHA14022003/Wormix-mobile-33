package §_-63M§
{
   import §_-B1y§.*;
   import §_-Y1b§.§_-OP§;
   import §_-b1F§.§_-v2Q§;
   import §_-l1g§.§_-L3Q§;
   import com.greensock.loading.LoaderMax;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-F3f§
   {
      
      private static const §_-W2c§:String = "Skeleton";
      
      private static const §_-U1§:String = "Texture";
      
      private static const §_-Y1p§:String = ".json";
      
      private static const §_-GR§:String = ".xml";
      
      private static const §_-82A§:String = ".png";
      
      private static const §_-A3b§:String = ".atf";
      
      private var _name:String;
      
      public function §_-F3f§(param1:String)
      {
         super();
         this._name = param1;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get §_-A3W§() : String
      {
         return this._name + §_-W2c§;
      }
      
      public function get §_-BC§() : String
      {
         return this.§_-A3W§ + §_-Y1p§;
      }
      
      public function get textureAtlas() : String
      {
         return this._name + §_-U1§;
      }
      
      public function get §_-F1n§() : String
      {
         return this.textureAtlas + §_-GR§;
      }
      
      public function get §_-9o§() : String
      {
         return this.textureAtlas + §_-82A§;
      }
   }
}


package §_-eW§
{
   import §_-5Y§.§_-h2c§;
   import §_-82l§.§_-A2Y§;
   import §_-A1m§.MultipartURLLoader;
   import §_-DJ§.§_-fH§;
   import §_-OA§.§_-k2K§;
   import §_-P1B§.§_-b21§;
   import §_-X14§.*;
   import §_-ZB§.§_-A10§;
   import §_-gG§.*;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-Rs§;
   import §_-z1g§.*;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.core.PopUpManager;
   import flash.events.ErrorEvent;
   import flash.events.Event;
   import flash.net.URLLoader;
   import ru.pragmatix.flox.social.controller.*;
   import ru.pragmatix.flox.social.model.ResponseFormat;
   import ru.pragmatix.flox.social.model.SocialErrorCode;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.server.ChatMessageEvent;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-g2b§ extends §_-S21§ implements §_-A10§
   {
      
      private var §_-U15§:Boolean = true;
      
      public function §_-g2b§(param1:ISocialController)
      {
         super(param1);
      }
      
      override public function §_-L37§() : String
      {
         return §_-X1j§.context.§_-K3U§() + "data/social/{social}/photostatus/";
      }
      
      override public function §_-Y1o§() : String
      {
         return §_-X1j§.socialController.getDomain() + "/settings";
      }
      
      override public function §_-Z1N§() : String
      {
         return §_-X1j§.socialController.getDomain() + "/feed#/album-13842325_111888926";
      }
      
      override public function §_-r1u§() : void
      {
         this.§_-U15§ = Application.userProfile.getLevel() >= §_-hF§();
      }
      
      override public function §_-l9§() : Boolean
      {
         return this.§_-U15§;
      }
      
      override public function §_-k2A§() : Boolean
      {
         return true;
      }
   }
}


package §_-eW§
{
   import §_-62§.§_-G1p§;
   import §_-91B§.§_-QK§;
   import §_-937§.§_-BO§;
   import §_-D3A§.§_-TZ§;
   import §_-L1H§.§_-b2K§;
   import §_-T2h§.§_-43C§;
   import §_-T2h§.§_-C1R§;
   import §_-Tm§.§_-RF§;
   import §_-YF§.§_-q2v§;
   import §_-ZB§.§_-A10§;
   import §_-d26§.§_-d1H§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import config.§_-B1K§;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-V2n§ extends §_-S21§ implements §_-A10§
   {
      
      private var §_-U15§:Boolean = true;
      
      public function §_-V2n§(param1:ISocialController)
      {
         super(param1);
      }
      
      override public function §_-L37§() : String
      {
         return §_-X1j§.context.§_-K3U§() + "data/social/{social}/photostatus/";
      }
      
      override public function §_-Y1o§() : String
      {
         return §_-X1j§.socialController.getDomain() + "/settings";
      }
      
      override public function §_-Z1N§() : String
      {
         return §_-X1j§.socialController.getDomain() + "/feed#/album-13842325_111888926";
      }
      
      override public function §_-r1u§() : void
      {
         this.§_-U15§ = Application.userProfile.getLevel() >= §_-hF§();
      }
      
      override public function §_-l9§() : Boolean
      {
         return this.§_-U15§;
      }
      
      override public function §_-k2A§() : Boolean
      {
         return true;
      }
      
      override public function §_-A1w§() : Array
      {
         return [4001,4002];
      }
      
      override public function §_-1n§() : Boolean
      {
         return false;
      }
   }
}


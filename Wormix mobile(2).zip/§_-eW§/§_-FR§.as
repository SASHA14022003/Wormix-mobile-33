package §_-eW§
{
   import §_-21p§.§_-N1H§;
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-73I§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2F§.*;
   import §_-E29§.§_-32G§;
   import §_-E29§.§_-n11§;
   import §_-G1h§.DesktopMainOverlayScreen;
   import §_-K3q§.§_-L3A§;
   import §_-L1H§.§_-C3e§;
   import §_-N8§.§_-o2w§;
   import §_-T1t§.§_-A2h§;
   import §_-T1t§.§_-aQ§;
   import §_-Y1b§.§_-OP§;
   import §_-Yk§.§_-A2R§;
   import §_-Yk§.§_-m2w§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-fo§.§_-r5§;
   import §_-p14§.§_-pP§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-6a§;
   import §_-sK§.*;
   import §_-w2i§.§_-Zd§;
   import §_-z20§.§_-V7§;
   import §_-z20§.§_-p4§;
   import feathers.controls.Screen;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.events.FeathersEventType;
   import flash.display.MovieClip;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-FR§ extends §_-rK§
   {
      
      public function §_-FR§()
      {
         super();
      }
      
      override public function §_-OG§() : §_-A2h§
      {
         return new §_-aQ§();
      }
      
      override protected function §_-W1l§() : §_-32G§
      {
         return new §_-n11§();
      }
      
      override protected function §_-J§() : §_-m2w§
      {
         return new §_-A2R§();
      }
      
      override public function §_-12I§() : §_-V7§
      {
         return new §_-p4§();
      }
   }
}


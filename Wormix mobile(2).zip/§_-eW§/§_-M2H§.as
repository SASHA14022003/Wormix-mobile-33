package §_-eW§
{
   import §_-62§.*;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-yG§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-E29§.§_-32G§;
   import §_-E29§.§_-Cd§;
   import §_-T1t§.§_-A2h§;
   import §_-T1t§.§_-i3§;
   import §_-Yk§.§_-5D§;
   import §_-Yk§.§_-m2w§;
   import §_-Z1K§.§_-q24§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.§_-03k§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import §_-r1C§.*;
   import §_-rM§.§_-61j§;
   import §_-z20§.§_-51i§;
   import §_-z20§.§_-V7§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import feathers.events.FeathersEventType;
   import flash.events.Event;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.IDataInput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.server.BuyVipResult;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.events.Event;
   
   public class §_-M2H§ extends §_-rK§
   {
      
      public function §_-M2H§()
      {
         super();
      }
      
      override public function §_-OG§() : §_-A2h§
      {
         return new §_-i3§();
      }
      
      override protected function §_-W1l§() : §_-32G§
      {
         return new §_-Cd§();
      }
      
      override protected function §_-J§() : §_-m2w§
      {
         return new §_-5D§();
      }
      
      override public function §_-12I§() : §_-V7§
      {
         return new §_-51i§();
      }
   }
}


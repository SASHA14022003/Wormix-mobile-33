package §_-eW§
{
   import §_-02q§.§_-11O§;
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-23P§.§_-u1z§;
   import §_-31W§.*;
   import §_-5P§.§_-H1u§;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-P14§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-72p§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-G2H§.*;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-99§;
   import §_-L1H§.§_-C3e§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-P1z§.*;
   import §_-R2I§.PvpTab;
   import §_-RE§.§_-r2q§;
   import §_-S§.*;
   import §_-S1N§.§_-C14§;
   import §_-TF§.§_-q1j§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-ZB§.§_-R2Y§;
   import §_-e2r§.*;
   import §_-fo§.§_-21L§;
   import §_-fo§.§_-A29§;
   import §_-j1w§.§_-L1x§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-p24§.MissionTab;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-y1S§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import com.hurlant.util.§_-F2L§;
   import com.hurlant.util.§_-a2P§;
   import config.§_-V2w§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.Scroller;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.display.DisplayObjectContainer;
   import flash.display.Sprite;
   import flash.events.*;
   import flash.geom.Point;
   import flash.net.SharedObject;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.controller.ISocialPaymentController;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.structures.PositionStructure;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starlingbuilder.engine.tween.WormixTweenBuilder;
   
   use namespace bi_internal;
   
   public class §_-Zt§ extends EventDispatcher implements §_-R2Y§
   {
      
      protected static const §_-12x§:int = 4;
      
      protected var §_-a1H§:Boolean;
      
      public function §_-Zt§()
      {
         super();
      }
      
      public function dispose() : void
      {
      }
      
      public function §_-B1f§(param1:int = -1) : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),"Bank in test mode");
      }
      
      public function get isBankOpened() : Boolean
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),"Bank in test mode");
         return false;
      }
      
      public function §_-O1W§() : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),"Bank in test mode");
      }
      
      public function §_-I19§() : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),"Bank in test mode");
      }
      
      protected function §_-8S§(param1:PaymentOption, param2:String, param3:String = "") : void
      {
         var _loc4_:String = param1.moneyType == §_-E19§.§_-51D§ ? §_-s2a§.RUBY_PRICE : §_-s2a§.FUZZES_PRICE;
         param1.name = §_-F1P§.format(_loc4_,{
            "count":param1.count + param1.bonus,
            "price":param1.price
         }) + " " + param2;
      }
      
      public function §_-F1I§(param1:String) : void
      {
         var _loc2_:PaymentOption = this.§_-L2T§(param1);
         (§_-X1j§.socialController as ISocialPaymentController).pay(_loc2_,this.§_-e1Y§);
      }
      
      protected function §_-e1Y§(param1:SocialResponse) : void
      {
         if(!param1.success)
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_BUY),§_-s2a§.§_-K3t§(§_-s2a§.PAYMENT_MSG_FAILED));
         }
      }
      
      public function §_-j1E§() : void
      {
      }
      
      public function §_-Ea§() : void
      {
      }
      
      public function §_-JC§() : Boolean
      {
         return false;
      }
      
      public function §_-L2T§(param1:String) : PaymentOption
      {
         return null;
      }
      
      public function §_-B12§(param1:String) : PaymentOption
      {
         return null;
      }
      
      public function §_-71Z§(param1:uint) : Array
      {
         return [];
      }
      
      public function §_-71P§() : String
      {
         return "";
      }
      
      public function §_-WE§() : Array
      {
         return [];
      }
      
      public function §_-G1j§(param1:String) : String
      {
         return "";
      }
      
      public function get §_-51y§() : Boolean
      {
         return this.§_-a1H§;
      }
      
      public function updateSubscribe() : void
      {
      }
   }
}


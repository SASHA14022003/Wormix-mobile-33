package §_-eW§
{
   import §_-03T§.§_-2p§;
   import §_-31W§.*;
   import §_-5Y§.*;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-83E§;
   import §_-CF§.§_-p2U§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-J3L§.§_-h1D§;
   import §_-L2F§.§_-I1q§;
   import §_-L2F§.§_-t2Z§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.*;
   import §_-ZB§.§_-A10§;
   import §_-ZP§.§_-w1J§;
   import §_-b1F§.*;
   import §_-d26§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sK§.*;
   import §_-w2i§.§_-52k§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-5c§;
   import §_-zI§.§_-8D§;
   import com.hurlant.math.*;
   import dragonBones.objects.DragonBonesData;
   import feathers.controls.Button;
   import feathers.controls.ButtonState;
   import feathers.controls.ToggleButton;
   import flash.events.IEventDispatcher;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.clearTimeout;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.GetWhoPumpedReaction;
   import ru.pragmatix.wormix.messages.server.AssembleStuffResult;
   import ru.pragmatix.wormix.messages.server.BuyUnlockMissionResult;
   import ru.pragmatix.wormix.messages.structures.*;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   public class §_-S21§ implements §_-A10§
   {
      
      private static const §_-5F§:Object = {"mobile":[§_-p2U§.§_-qr§,§_-p2U§.§_-w13§]};
      
      protected var controller:ISocialController;
      
      public function §_-S21§(param1:ISocialController)
      {
         super();
         this.controller = param1;
      }
      
      public function dispose() : void
      {
         this.controller = null;
      }
      
      public function §_-L37§() : String
      {
         return "";
      }
      
      public function §_-Y1o§() : String
      {
         return "";
      }
      
      public function §_-Z1N§() : String
      {
         return "";
      }
      
      public function §_-M1N§() : String
      {
         return "";
      }
      
      public function §_-V1G§(param1:§_-B2i§) : Boolean
      {
         return true;
      }
      
      public function §_-bB§() : Boolean
      {
         return false;
      }
      
      public function §_-L2e§() : Array
      {
         return §_-5F§["mobile"];
      }
      
      public function §_-e2n§() : §_-p2U§
      {
         return §_-X1j§.§_-82T§.§_-I9§();
      }
      
      public function §_-r1u§() : void
      {
      }
      
      public function §_-l9§() : Boolean
      {
         return true;
      }
      
      public function §_-1n§() : Boolean
      {
         return true;
      }
      
      public function §_-21D§() : Vector.<§_-5c§>
      {
         var _temp_3:* = new <§_-5c§>[new §_-5c§(§_-s2a§.LOWER_RATING_LEAGUE,§_-s2a§.DESCR_LOWER_RATING_LEAGUE,10,"league_icon_0"),new §_-5c§(§_-s2a§.FIGHTER_RATING_LEAGUE,§_-s2a§.DESCR_FIGHTER_RATING_LEAGUE,50,"league_icon_1"),new §_-5c§(§_-s2a§.VETERAN_RATING_LEAGUE,§_-s2a§.DESCR_VETERAN_RATING_LEAGUE,200,"league_icon_2"),new §_-5c§(§_-s2a§.MASTER_RATING_LEAGUE,§_-s2a§.DESCR_MASTER_RATING_LEAGUE,500,"league_icon_3"),new §_-5c§(§_-s2a§.ACE_RATING_LEAGUE,§_-s2a§.DESCR_ACE_RATING_LEAGUE,2000,"league_icon_4"),new §_-5c§(§_-s2a§.RUBY_RATING_LEAGUE,§_-s2a§.DESCR_RUBY_RATING_LEAGUE,10000,"league_icon_5")];
         var _temp_5:* = new <§_-5c§>[new §_-5c§(§_-s2a§.LOWER_RATING_LEAGUE,§_-s2a§.DESCR_LOWER_RATING_LEAGUE,10,"league_icon_0"),new §_-5c§(§_-s2a§.FIGHTER_RATING_LEAGUE,§_-s2a§.DESCR_FIGHTER_RATING_LEAGUE,50,"league_icon_1"),new §_-5c§(§_-s2a§.VETERAN_RATING_LEAGUE,§_-s2a§.DESCR_VETERAN_RATING_LEAGUE,200,"league_icon_2"),new §_-5c§(§_-s2a§.MASTER_RATING_LEAGUE,§_-s2a§.DESCR_MASTER_RATING_LEAGUE,500,"league_icon_3"),new §_-5c§(§_-s2a§.ACE_RATING_LEAGUE,§_-s2a§.DESCR_ACE_RATING_LEAGUE,2000,"league_icon_4"),new §_-5c§(§_-s2a§.RUBY_RATING_LEAGUE,§_-s2a§.DESCR_RUBY_RATING_LEAGUE,10000,"league_icon_5")];
         return new <§_-5c§>[new §_-5c§(§_-s2a§.LOWER_RATING_LEAGUE,§_-s2a§.DESCR_LOWER_RATING_LEAGUE,10,"league_icon_0"),new §_-5c§(§_-s2a§.FIGHTER_RATING_LEAGUE,§_-s2a§.DESCR_FIGHTER_RATING_LEAGUE,50,"league_icon_1"),new §_-5c§(§_-s2a§.VETERAN_RATING_LEAGUE,§_-s2a§.DESCR_VETERAN_RATING_LEAGUE,200,"league_icon_2"),new §_-5c§(§_-s2a§.MASTER_RATING_LEAGUE,§_-s2a§.DESCR_MASTER_RATING_LEAGUE,500,"league_icon_3"),new §_-5c§(§_-s2a§.ACE_RATING_LEAGUE,§_-s2a§.DESCR_ACE_RATING_LEAGUE,2000,"league_icon_4"),new §_-5c§(§_-s2a§.RUBY_RATING_LEAGUE,§_-s2a§.DESCR_RUBY_RATING_LEAGUE,10000,"league_icon_5")];
      }
      
      public function §_-k2A§() : Boolean
      {
         return false;
      }
      
      public function §_-A1w§() : Array
      {
         return [];
      }
      
      public function §_-p2G§() : Date
      {
         return new Date(2018,5);
      }
      
      public function §_-hF§() : int
      {
         return 0;
      }
      
      public function get §_-03F§() : Boolean
      {
         return false;
      }
   }
}


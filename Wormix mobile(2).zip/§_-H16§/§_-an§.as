package §_-H16§
{
   import §_-F2Q§.GestureEvent;
   import §_-P1z§.*;
   import §_-l1K§.*;
   import flash.geom.Point;
   import org.gestouch.core.GestureState;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.objects.Direction;
   import starling.display.DisplayObject;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   
   public class §_-an§ extends §_-L9§
   {
      
      protected var §_-W23§:String;
      
      protected var §_-43U§:int;
      
      public function §_-an§(param1:XML, param2:Injector = null)
      {
         super(param1,param2);
      }
      
      public function get order() : int
      {
         return this.§_-43U§;
      }
      
      override public function §_-bp§(param1:Object, param2:Injector) : Object
      {
         param1[this.§_-W23§]();
         return param1;
      }
      
      override protected function §_-rb§(param1:XML) : void
      {
         var orderArg:XMLList = null;
         var methodNode:XML = null;
         var node:XML = param1;
         orderArg = node.arg.(@key == "order");
         methodNode = node.parent();
         this.§_-43U§ = int(orderArg.@value);
         this.§_-W23§ = methodNode.@name.toString();
      }
   }
}


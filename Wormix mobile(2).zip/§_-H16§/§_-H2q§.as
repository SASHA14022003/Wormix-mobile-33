package §_-H16§
{
   import §_-Y1O§.*;
   import flash.utils.getQualifiedClassName;
   import org.swiftsuspenders.Injector;
   
   public class §_-H2q§ extends §_-L9§
   {
      
      public function §_-H2q§()
      {
         super(null,null);
      }
      
      override public function §_-bp§(param1:Object, param2:Injector) : Object
      {
         return new (param1 as Class)();
      }
   }
}


package §_-H16§
{
   import §_-b1F§.§_-G4§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import flash.utils.describeType;
   import flash.utils.getDefinitionByName;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   
   public class §_-n2j§ extends MethodInjectionPoint
   {
      
      public function §_-n2j§(param1:XML, param2:Class, param3:Injector = null)
      {
         var node:XML = param1;
         var clazz:Class = param2;
         var injector:Injector = param3;
         var _loc6_:int = 0;
         var _loc7_:* = §§checkfilter(node.parameter);
         var _loc5_:* = new XMLList("");
         while(§§hasnext(_loc7_,_loc6_))
         {
            var _temp_1:* = §§nextvalue(_loc6_,_loc7_);
            var _loc8_:* = §§nextvalue(_loc6_,_loc7_);
            with(_loc8_)
            {
               
               if(@type == "*")
               {
                  _loc5_[_loc6_] = _loc8_;
               }
            }
         }
         if(_loc5_.length() == node.parameter.@type.length())
         {
            this.§_-42o§(node,clazz);
         }
         super(node,injector);
      }
      
      override public function §_-bp§(param1:Object, param2:Injector) : Object
      {
         var _loc3_:Class = Class(param1);
         var _loc4_:Array = §_-02C§(param1,param2);
         switch(_loc4_.length)
         {
            case 0:
               return new _loc3_();
            case 1:
               return new _loc3_(_loc4_[0]);
            case 2:
               return new _loc3_(_loc4_[0],_loc4_[1]);
            case 3:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2]);
            case 4:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3]);
            case 5:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3],_loc4_[4]);
            case 6:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3],_loc4_[4],_loc4_[5]);
            case 7:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3],_loc4_[4],_loc4_[5],_loc4_[6]);
            case 8:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3],_loc4_[4],_loc4_[5],_loc4_[6],_loc4_[7]);
            case 9:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3],_loc4_[4],_loc4_[5],_loc4_[6],_loc4_[7],_loc4_[8]);
            case 10:
               return new _loc3_(_loc4_[0],_loc4_[1],_loc4_[2],_loc4_[3],_loc4_[4],_loc4_[5],_loc4_[6],_loc4_[7],_loc4_[8],_loc4_[9]);
            default:
               return null;
         }
      }
      
      override protected function §_-rb§(param1:XML) : void
      {
         var nameArgs:XMLList = null;
         var node:XML = param1;
         nameArgs = node.parent().metadata.(@name == "Inject").arg.(@key == "name");
         §_-W23§ = "constructor";
         §_-923§(node,nameArgs);
      }
      
      private function §_-42o§(param1:XML, param2:Class) : void
      {
         var constructorNode:XML = param1;
         var clazz:Class = param2;
         try
         {
            switch(constructorNode.children().length())
            {
               case 0:
                  new clazz();
                  break;
               case 1:
                  new clazz(null);
                  break;
               case 2:
                  new clazz(null,null);
                  break;
               case 3:
                  new clazz(null,null,null);
                  break;
               case 4:
                  new clazz(null,null,null,null);
                  break;
               case 5:
                  new clazz(null,null,null,null,null);
                  break;
               case 6:
                  new clazz(null,null,null,null,null,null);
                  break;
               case 7:
                  new clazz(null,null,null,null,null,null,null);
                  break;
               case 8:
                  new clazz(null,null,null,null,null,null,null,null);
                  break;
               case 9:
                  new clazz(null,null,null,null,null,null,null,null,null);
                  break;
               case 10:
                  new clazz(null,null,null,null,null,null,null,null,null,null);
            }
         }
         catch(error:Error)
         {
            trace("Exception caught while trying to create dummy instance for constructor " + "injection. It\'s almost certainly ok to ignore this exception, but you " + "might want to restructure your constructor to prevent errors from " + "happening. See the SwiftSuspenders documentation for more details. " + "The caught exception was:\n" + error);
         }
         constructorNode.setChildren(describeType(clazz).factory.constructor[0].children());
      }
   }
}


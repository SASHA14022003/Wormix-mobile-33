package §_-H16§
{
   import §_-62§.§_-W1r§;
   import §_-lh§.§_-z2A§;
   import flash.events.TimerEvent;
   import org.swiftsuspenders.Injector;
   
   public class §_-L9§
   {
      
      public function §_-L9§(param1:XML, param2:Injector)
      {
         super();
         this.§_-rb§(param1);
      }
      
      public function §_-bp§(param1:Object, param2:Injector) : Object
      {
         return param1;
      }
      
      protected function §_-rb§(param1:XML) : void
      {
      }
   }
}


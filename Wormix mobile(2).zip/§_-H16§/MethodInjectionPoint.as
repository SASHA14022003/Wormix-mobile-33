package §_-H16§
{
   import flash.utils.getQualifiedClassName;
   import org.swiftsuspenders.Injector;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import starling.events.Event;
   
   public class MethodInjectionPoint extends §_-L9§
   {
      
      protected var §_-W23§:String;
      
      protected var §_-k1W§:Array;
      
      protected var §_-Z2D§:int = 0;
      
      public function MethodInjectionPoint(param1:XML, param2:Injector = null)
      {
         super(param1,param2);
      }
      
      override public function §_-bp§(param1:Object, param2:Injector) : Object
      {
         var _loc3_:Array = this.§_-02C§(param1,param2);
         var _loc4_:Function = param1[this.§_-W23§];
         _loc4_.apply(param1,_loc3_);
         return param1;
      }
      
      override protected function §_-rb§(param1:XML) : void
      {
         var nameArgs:XMLList = null;
         var methodNode:XML = null;
         var node:XML = param1;
         nameArgs = node.arg.(@key == "name");
         methodNode = node.parent();
         this.§_-W23§ = methodNode.@name.toString();
         this.§_-923§(methodNode,nameArgs);
      }
      
      protected function §_-923§(param1:XML, param2:XMLList) : void
      {
         var _loc4_:XML = null;
         var _loc5_:String = null;
         var _loc6_:String = null;
         this.§_-k1W§ = [];
         var _loc3_:int = 0;
         for each(_loc4_ in param1.parameter)
         {
            _loc5_ = "";
            if(param2[_loc3_])
            {
               _loc5_ = param2[_loc3_].@value.toString();
            }
            _loc6_ = _loc4_.@type.toString();
            if(_loc6_ == "*")
            {
               if(_loc4_.@optional.toString() == "false")
               {
                  throw new §_-71M§("Error in method definition of injectee. " + "Required parameters can\'t have type \"*\".");
               }
               _loc6_ = null;
            }
            this.§_-k1W§.push(new ParameterInjectionConfig(_loc6_,_loc5_));
            if(_loc4_.@optional.toString() == "false")
            {
               ++this.§_-Z2D§;
            }
            _loc3_++;
         }
      }
      
      protected function §_-02C§(param1:Object, param2:Injector) : Array
      {
         var _loc6_:ParameterInjectionConfig = null;
         var _loc7_:§_-T1p§ = null;
         var _loc8_:Object = null;
         var _loc3_:Array = [];
         var _loc4_:int = int(this.§_-k1W§.length);
         var _loc5_:int = 0;
         while(_loc5_ < _loc4_)
         {
            _loc6_ = this.§_-k1W§[_loc5_];
            _loc7_ = param2.§_-TE§(Class(param2.§_-73r§().getDefinition(_loc6_.typeName)),_loc6_.injectionName);
            _loc8_ = _loc7_.§_-832§(param2);
            if(_loc8_ == null)
            {
               if(_loc5_ >= this.§_-Z2D§)
               {
                  break;
               }
               throw new §_-71M§("Injector is missing a rule to handle injection into target " + param1 + ". Target dependency: " + getQualifiedClassName(_loc7_.request) + ", method: " + this.§_-W23§ + ", parameter: " + (_loc5_ + 1));
            }
            _loc3_[_loc5_] = _loc8_;
            _loc5_++;
         }
         return _loc3_;
      }
   }
}

final class ParameterInjectionConfig
{
   
   public var typeName:String;
   
   public var injectionName:String;
   
   public function ParameterInjectionConfig(param1:String, param2:String)
   {
      super();
      this.typeName = param1;
      this.injectionName = param2;
   }
}

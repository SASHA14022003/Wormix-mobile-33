package §_-H16§
{
   import org.swiftsuspenders.Injector;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-i1L§ extends §_-L9§
   {
      
      private var §_-B2G§:String;
      
      private var §_-62m§:String;
      
      private var §_-n1m§:String;
      
      public function §_-i1L§(param1:XML, param2:Injector = null)
      {
         super(param1,null);
      }
      
      override public function §_-bp§(param1:Object, param2:Injector) : Object
      {
         var _loc3_:§_-T1p§ = param2.§_-TE§(Class(param2.§_-73r§().getDefinition(this.§_-62m§)),this.§_-n1m§);
         var _loc4_:Object = _loc3_.§_-832§(param2);
         if(_loc4_ == null)
         {
            throw new §_-71M§("Injector is missing a rule to handle injection into property \"" + this.§_-B2G§ + "\" of object \"" + param1 + "\". Target dependency: \"" + this.§_-62m§ + "\", named \"" + this.§_-n1m§ + "\"");
         }
         param1[this.§_-B2G§] = _loc4_;
         return param1;
      }
      
      override protected function §_-rb§(param1:XML) : void
      {
         this.§_-62m§ = param1.parent().@type.toString();
         this.§_-B2G§ = param1.parent().@name.toString();
         this.§_-n1m§ = param1.arg.attribute("value").toString();
      }
   }
}


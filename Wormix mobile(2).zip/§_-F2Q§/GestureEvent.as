package §_-F2Q§
{
   import §_-02q§.§_-4s§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-U11§;
   import §_-gG§.§_-M2S§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import flash.events.Event;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.server.ConnectResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   
   public class GestureEvent extends Event
   {
      
      public static const §_-82P§:String = "gesturePossible";
      
      public static const §_-m28§:String = "gestureRecognized";
      
      public static const §_-c10§:String = "gestureBegan";
      
      public static const §_-f1w§:String = "gestureChanged";
      
      public static const §_-o2m§:String = "gestureEnded";
      
      public static const §_-T2U§:String = "gestureCancelled";
      
      public static const §_-a1W§:String = "gestureFailed";
      
      public static const §_-D1§:String = "gestureStateChange";
      
      public var newState:GestureState;
      
      public var oldState:GestureState;
      
      public function GestureEvent(param1:String, param2:GestureState, param3:GestureState)
      {
         super(param1,false,false);
         this.newState = param2;
         this.oldState = param3;
      }
      
      override public function clone() : Event
      {
         return new GestureEvent(type,this.newState,this.oldState);
      }
      
      override public function toString() : String
      {
         return formatToString("GestureEvent","type","oldState","newState");
      }
   }
}


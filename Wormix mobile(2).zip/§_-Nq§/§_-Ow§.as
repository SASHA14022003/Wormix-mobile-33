package §_-Nq§
{
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.VectorCollection;
   import feathers.layout.RelativePosition;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.system.SecurityDomain;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-Ow§ extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      private var itemIcon:§_-3m§;
      
      public function §_-Ow§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         width = 65;
         height = 90;
         iconPosition = RelativePosition.TOP;
         labelOffsetY = 30;
         iconFunction = function(param1:Object):DisplayObject
         {
            var _loc3_:Rectangle = null;
            var _loc2_:§_-W1r§ = param1.item as §_-W1r§;
            if(_loc2_)
            {
               _loc3_ = Pool.getRectangle(0,0,65,90);
               itemIcon = new §_-3m§(getOrigin());
               itemIcon.setItem(_loc2_);
               itemIcon.width = _loc3_.width;
               itemIcon.height = _loc3_.height;
               Pool.putRectangle(_loc3_);
               return new Sprite();
            }
            return new Sprite();
         };
         labelFactory = function():ITextRenderer
         {
            var _loc1_:ITextRenderer = §_-R2g§.createTextRenderer(BitmapFonts.GROBOLD_WITH_SHADOWS,20);
            _loc1_.width = 65;
            _loc1_.height = 25;
            return _loc1_;
         };
         labelFunction = function(param1:Object):String
         {
            var _loc4_:int = 0;
            var _loc5_:int = 0;
            var _loc6_:int = 0;
            var _loc7_:int = 0;
            var _loc2_:§_-L1r§ = param1.item as §_-L1r§;
            var _loc3_:int = int(int(param1.count) || _loc2_.§_-n2k§());
            if(_loc3_ > -1)
            {
               _loc4_ = _loc2_.§_-n2k§();
               _loc5_ = _loc4_ / §_-72u§.§_-E1O§;
               _loc6_ = _loc5_ / §_-72u§.§_-w2h§;
               _loc7_ = _loc6_ / §_-72u§.§_-M0§;
               if(_loc7_ > 0)
               {
                  return _loc7_.toString();
               }
               if(_loc6_ > 0)
               {
                  return _loc6_.toString();
               }
               return _loc3_.toString();
            }
            return "";
         };
         §_-q1j§.register(this);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-q1j§.remove(this);
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         var _loc2_:int = 0;
         var _loc1_:§_-W1r§ = _data.item as §_-W1r§;
         if(_loc1_)
         {
            _loc2_ = int(_data.count);
            return §_-y2n§.§_-i1N§.§_-8N§(_loc1_);
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return null;
      }
   }
}


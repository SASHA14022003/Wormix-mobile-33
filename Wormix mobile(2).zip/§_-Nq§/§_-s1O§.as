package §_-Nq§
{
   import §_-62§.*;
   import §_-CF§.§_-E19§;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-n1w§.*;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.events.CollectionEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import flash.geom.Rectangle;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.KeyboardEvent;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-s1O§ extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      public function §_-s1O§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         width = 70;
         height = 100;
         iconPosition = RelativePosition.TOP;
         horizontalAlign = HorizontalAlign.CENTER;
         iconFunction = function(param1:Object):DisplayObject
         {
            var _loc4_:Image = null;
            var _loc5_:Sprite = null;
            var _loc2_:Image = new Image(Application.assetManager.getTexture(param1.icon));
            var _loc3_:Rectangle = Pool.getRectangle(0,0,40,50);
            RectangleUtil.fit(_loc2_.bounds,_loc3_,ScaleMode.SHOW_ALL,false,_loc3_);
            _loc2_.width = _loc3_.width;
            _loc2_.height = _loc3_.height;
            Pool.putRectangle(_loc3_);
            if(param1.bg)
            {
               if(!getChildByName(param1.bg))
               {
                  _loc4_ = new Image(Application.assetManager.getTexture(param1.bg));
                  _loc4_.name = param1.bg;
                  _loc4_.width = width;
                  _loc4_.scaleY = _loc4_.scaleX;
                  if(param1.bgColor)
                  {
                     _loc4_.color = param1.bgColor;
                  }
                  _loc5_ = new Sprite();
                  _loc5_.addChild(_loc4_);
                  _loc5_.addChild(_loc2_);
                  §_-k1h§.§_-k1B§(_loc2_);
                  return _loc5_;
               }
            }
            return _loc2_;
         };
         labelFactory = function():ITextRenderer
         {
            var _loc3_:§_-E19§ = null;
            var _loc1_:uint = Color.GRAY;
            if(_data)
            {
               if(_data.rewardItem is §_-8c§)
               {
                  if(_data.rewardItem is §_-fG§)
                  {
                     _loc1_ = 4622215;
                  }
                  else if(_data.rewardItem is §_-C3A§)
                  {
                     _loc1_ = 1480928;
                  }
               }
               else if(_data.bonusType is §_-E19§)
               {
                  _loc3_ = _data.bonusType as §_-E19§;
                  switch(_loc3_)
                  {
                     case §_-E19§.§_-i2d§:
                        _loc1_ = 7975936;
                        break;
                     case §_-E19§.§_-51D§:
                        _loc1_ = 15489056;
                        break;
                     case §_-E19§.§_-qt§:
                        _loc1_ = 1480928;
                  }
               }
            }
            var _loc2_:ITextRenderer = §_-R2g§.createTextRenderer(BitmapFonts.GROBOLD_NORMAL,20,_loc1_);
            _loc2_.height = 25;
            _loc2_.name = "textRenderer";
            return _loc2_;
         };
         labelFunction = function(param1:Object):String
         {
            var _loc2_:int = int(param1.count);
            if(_loc2_ > 0)
            {
               return _loc2_.toString();
            }
            return "";
         };
         §_-q1j§.register(this);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-q1j§.remove(this);
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         var _loc1_:§_-8c§ = null;
         var _loc2_:§_-E19§ = null;
         if(_data.rewardItem is §_-8c§)
         {
            _loc1_ = _data.rewardItem as §_-8c§;
            if(_loc1_)
            {
               return §_-y2n§.§_-i1N§.§_-gD§(_loc1_);
            }
         }
         else if(_data.bonusType is §_-E19§)
         {
            _loc2_ = _data.bonusType as §_-E19§;
            if(_loc2_)
            {
               return §_-y2n§.§_-i1N§.§_-O2K§(_loc2_);
            }
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return null;
      }
   }
}


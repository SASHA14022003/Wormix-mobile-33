package §_-Nq§
{
   import §_-62§.§_-gr§;
   import §_-73I§.§_-q15§;
   import §_-82l§.*;
   import §_-A1K§.§_-7u§;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import com.hurlant.crypto.tls.§_-21v§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-uh§ extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      public function §_-uh§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         width = 65;
         height = 90;
         iconPosition = RelativePosition.TOP;
         iconFunction = function(param1:Object):DisplayObject
         {
            var _loc3_:DisplayObject = null;
            var _loc4_:Rectangle = null;
            var _loc5_:Sprite = null;
            var _loc6_:Quad = null;
            var _loc2_:§_-gr§ = param1.item as §_-gr§;
            if(_loc2_)
            {
               _loc3_ = §_-q15§.§_-71V§(_loc2_);
               _loc4_ = Pool.getRectangle(0,0,65,40);
               RectangleUtil.fit(_loc3_.bounds,_loc4_,ScaleMode.SHOW_ALL,false,_loc4_);
               _loc3_.pivotX = 0;
               _loc3_.pivotY = 0;
               _loc3_.x = _loc4_.x;
               _loc3_.width = _loc4_.width;
               _loc3_.height = _loc4_.height;
               Pool.putRectangle(_loc4_);
               _loc5_ = new Sprite();
               _loc6_ = new Quad(width,height - 30);
               _loc6_.alpha = 0;
               _loc3_.y = _loc6_.height - _loc3_.height;
               _loc5_.addChild(_loc6_);
               _loc5_.addChild(_loc3_);
               return _loc5_;
            }
            return new Sprite();
         };
         labelFactory = function():ITextRenderer
         {
            var _loc1_:ITextRenderer = §_-R2g§.createTextRenderer(BitmapFonts.GROBOLD_WITH_SHADOWS,20);
            _loc1_.width = 65;
            _loc1_.height = 25;
            return _loc1_;
         };
         labelFunction = function(param1:Object):String
         {
            var _loc2_:int = int(param1.count);
            if(_loc2_ > 0)
            {
               return _loc2_.toString();
            }
            return "";
         };
         §_-q1j§.register(this);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-q1j§.remove(this);
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         var _loc1_:§_-gr§ = _data.item as §_-gr§;
         if(_loc1_)
         {
            return §_-y2n§.§_-i1N§.§_-X24§(_loc1_);
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return null;
      }
   }
}


package §_-Nq§
{
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-q15§;
   import §_-G2H§.*;
   import §_-T1o§.§_-L3M§;
   import §_-TF§.§_-Z1U§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-lp§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import flash.geom.Rectangle;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-G1J§ extends DefaultListItemRenderer implements §_-Z1U§
   {
      
      public function §_-G1J§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         width = 65;
         height = 90;
         iconPosition = RelativePosition.TOP;
         iconFunction = function(param1:Object):DisplayObject
         {
            var _loc3_:DisplayObject = null;
            var _loc4_:Rectangle = null;
            var _loc5_:Sprite = null;
            var _loc6_:Quad = null;
            var _loc2_:§_-O2H§ = param1.item as §_-O2H§;
            if(_loc2_)
            {
               _loc3_ = §_-q15§.§_-82W§(_loc2_);
               _loc4_ = Pool.getRectangle(0,0,65,40);
               RectangleUtil.fit(_loc3_.bounds,_loc4_,ScaleMode.SHOW_ALL,false,_loc4_);
               _loc3_.pivotX = 0;
               _loc3_.pivotY = 0;
               _loc3_.x = _loc4_.x;
               _loc3_.width = _loc4_.width;
               _loc3_.height = _loc4_.height;
               Pool.putRectangle(_loc4_);
               _loc5_ = new Sprite();
               _loc6_ = new Quad(width,height - 30);
               _loc6_.alpha = 0;
               _loc3_.y = _loc6_.height - _loc3_.height;
               _loc5_.addChild(_loc6_);
               _loc5_.addChild(_loc3_);
               return _loc5_;
            }
            return new Sprite();
         };
         labelFactory = function():ITextRenderer
         {
            var _loc1_:ITextRenderer = §_-R2g§.createTextRenderer(BitmapFonts.GROBOLD_WITH_SHADOWS,20);
            _loc1_.width = 65;
            _loc1_.height = 25;
            return _loc1_;
         };
         labelFunction = function(param1:Object):String
         {
            var _loc2_:§_-O2H§ = param1.item as §_-O2H§;
            var _loc3_:int = int(param1.count);
            if(_loc3_ > -1)
            {
               return _loc3_.toString() + (_loc2_.isComplex() ? "/" + _loc2_.getMaxLevel() : "");
            }
            return "";
         };
         §_-q1j§.register(this);
      }
      
      override protected function draw() : void
      {
         super.draw();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-q1j§.remove(this);
      }
      
      public function getOrigin() : DisplayObject
      {
         return this;
      }
      
      public function §_-8I§() : DisplayObject
      {
         var _loc1_:§_-O2H§ = _data.item as §_-O2H§;
         if(_loc1_)
         {
            return §_-y2n§.§_-i1N§.§_-e21§(_loc1_,_loc1_.isComplex() ? 1 : -1);
         }
         return null;
      }
      
      public function §_-52e§() : Object
      {
         return null;
      }
   }
}


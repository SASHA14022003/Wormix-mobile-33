package §_-aM§
{
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-zF§;
   import §_-82a§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2S§.§_-L1N§;
   import §_-A2U§.§_-A23§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-92W§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-R1h§;
   import §_-Ly§.§_-81L§;
   import §_-S1N§.§_-R1U§;
   import §_-T2h§.*;
   import §_-U1i§.§_-O2i§;
   import §_-W§.§_-Ap§;
   import §_-X14§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-d26§.§_-d1H§;
   import §_-dS§.§_-D3a§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-L1x§;
   import §_-jF§.ClanInviteRenderer;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-u1m§.*;
   import §_-zI§.§_-8D§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.core.*;
   import com.hurlant.crypto.tls.§_-A3§;
   import feathers.controls.Button;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.errors.IllegalOperationError;
   import flash.net.Socket;
   import flash.system.ApplicationDomain;
   import flash.system.Capabilities;
   import flash.system.LoaderContext;
   import flash.system.Security;
   import flash.system.SecurityDomain;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.server.SteamTransactionInitResponse;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-C1e§ extends §_-P1N§
   {
      
      private var mainBoss:§_-01J§;
      
      private var map:§_-D3a§;
      
      private var §_-336§:Vector.<§_-V23§>;
      
      private var §_-9V§:Vector.<GuardingBot> = new Vector.<GuardingBot>();
      
      public function §_-C1e§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:§_-k1I§ = new §_-k1I§(0,0,0,param1);
         var _loc5_:uint = heroic ? uint(5 + (_loc4_.§_-sL§ + _loc4_.level) / 4) : uint(5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4);
         var _loc6_:Number = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _loc7_:§_-81l§ = new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_WIND1"),[UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_WIND1"),5 + _loc5_ * 2,§_-L1x§.§_-l2G§,230 + _loc5_ * 39,_loc5_ * 2,10 + _loc5_ * 2,§_-S25§.§_-C3R§),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_WIND2"),_loc5_ * 2,§_-L1x§.§_-p21§,212 + _loc5_ * 29,_loc5_ * 1.8,_loc5_ * 2.1,§_-S25§.§_-p2J§)]);
         var _loc8_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         if(heroic)
         {
            _loc8_.push(_loc7_);
         }
         else
         {
            _loc8_.push(_loc7_);
            _loc8_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_WIND2"),[UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_WIND3"),_loc5_ * 1.2,§_-L1x§.§_-AU§,200 + 18 * _loc5_,_loc5_,1.3 * _loc5_,§_-S25§.§_-v1z§),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_WIND3"),_loc5_ * 1.2,§_-L1x§.§_-AU§,180 + 19 * _loc5_,1.15 * _loc5_,1.15 * _loc5_,§_-S25§.SAMURAI),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_WIND3"),_loc5_ * 1.2,§_-L1x§.§_-I1h§,150 + 20 * _loc5_,1.3 * _loc5_,_loc5_,§_-S25§.SAMURAI)]));
         }
         return _loc8_;
      }
      
      public function setMap(param1:§_-D3a§) : void
      {
         this.map = param1;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc2_:int = 0;
         var _loc3_:§_-01J§ = null;
         var _loc4_:§_-V23§ = null;
         this.§_-336§ = param1;
         this.mainBoss = §_-01J§(param1[0].getUnits()[0]);
         this.mainBoss.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-42a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.§_-i2k§),new §_-de§(§_-q24§.BANDAGE,0.2,2)]);
         _loc2_ = 0;
         while(_loc2_ < this.map.§_-Mr§.length)
         {
            this.§_-9V§[_loc2_] = new GuardingBot(this.mainBoss,this.map.§_-Mr§[_loc2_].x,this.map.§_-Mr§[_loc2_].y,§_-73v§.getWeapon(60).§_-Q2H§(),false);
            this.§_-9V§[_loc2_].addEventListener(§_-L3Q§.§_-kl§,this.§_-a1n§);
            _loc2_++;
         }
         this.mainBoss.buffs.place(new §_-92W§());
         this.mainBoss.addEventListener(§_-L3Q§.DISPOSED,this.§_-f1k§);
         §_-TZ§.addListener(this.mainBoss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-Xl§);
         _loc2_ = 0;
         while(_loc2_ < param1.length)
         {
            for each(_loc3_ in param1[_loc2_].getUnits())
            {
               _loc3_.aiMissFactor = 1;
               _loc3_.aiShotPower = 5;
            }
            _loc2_++;
         }
         if(!heroic)
         {
            this.mainBoss.buffs.place(new §_-Ap§());
         }
         for each(_loc4_ in param1)
         {
            for each(_loc3_ in _loc4_.getUnits())
            {
               _loc3_.addEventListener(§_-L3Q§.§_-kl§,this.§_-p1h§);
            }
         }
         §_-X1j§.§_-12n§.scene.setWeather(Weather.SNOW);
         super.initBeforeBattle(param1);
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         super.§_-03f§(param1,param2);
         if(param1 == 1)
         {
            this.§_-Xl§();
         }
         if(!this.mainBoss.disposed && !gameMaster.§_-y2v§())
         {
            Force.setWind(-600);
         }
         else
         {
            Force.setWind(§_-X1j§.randomSeed.§_-Fh§(-200,200));
         }
      }
      
      private function §_-Xl§(param1:Event = null) : void
      {
         var _loc2_:§_-01J§ = null;
         if(!gameMaster || this.mainBoss.disposed)
         {
            return;
         }
         for each(_loc2_ in gameMaster.§_-83I§(this.mainBoss))
         {
            _loc2_.physParams.addForce(Force.WIND);
         }
      }
      
      private function §_-f1k§(param1:Event) : void
      {
         var _loc2_:§_-01J§ = null;
         if(!gameMaster)
         {
            return;
         }
         if(Boolean(§_-X1j§.§_-12n§) && Boolean(§_-X1j§.§_-12n§.scene))
         {
            §_-X1j§.§_-12n§.scene.setWeather(Weather.CLEAR);
         }
         for each(_loc2_ in gameMaster.§_-83I§(this.mainBoss))
         {
            if(!_loc2_.disposed && Boolean(_loc2_.physParams))
            {
               _loc2_.physParams.removeForce(Force.WIND_NAME);
            }
         }
      }
      
      private function §_-p1h§(param1:Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-s1x§.WIND_MASTER_DONT_DROWN_ENEMIES));
      }
      
      private function §_-a1n§(param1:Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-s1x§.WIND_MASTER_DROWN_GUARDIANS));
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-V23§ = null;
         var _loc2_:GuardingBot = null;
         var _loc3_:§_-01J§ = null;
         super.clear();
         for each(_loc1_ in this.§_-336§)
         {
            for each(_loc3_ in _loc1_.getUnits())
            {
               _loc3_.removeEventListener(§_-L3Q§.§_-kl§,this.§_-p1h§);
            }
         }
         this.mainBoss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-f1k§);
         §_-TZ§.removeListener(this.mainBoss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-Xl§);
         this.mainBoss = null;
         for each(_loc2_ in this.§_-9V§)
         {
            _loc2_.removeEventListener(§_-L3Q§.§_-kl§,this.§_-a1n§);
         }
         this.§_-9V§ = null;
      }
   }
}


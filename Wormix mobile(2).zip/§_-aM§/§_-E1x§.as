package §_-aM§
{
   import §_-5Y§.§_-h2c§;
   import §_-5Y§.§_-t2O§;
   import §_-931§.*;
   import §_-937§.§_-BO§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-Tm§.§_-RF§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-v2Q§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-kP§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.*;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-73F§;
   import §_-w2i§.§_-Ia§;
   import com.greensock.loading.core.LoaderCore;
   import com.hurlant.math.BigInteger;
   import com.hurlant.util.der.§_-p1B§;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.media.Sound;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.QuitClanResponse;
   import ru.pragmatix.wormix.messages.client.WipeProfile;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.JumpingMine;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-E1x§ extends §_-P1N§
   {
      
      private const §_-Jp§:Number = 0.5;
      
      private const §_-c2r§:§_-TA§ = new §_-TA§(1);
      
      private const §_-Z2o§:§_-TA§ = new §_-TA§(30);
      
      private const §_-4K§:§_-TA§ = new §_-TA§(24);
      
      private const §_-p2y§:§_-TA§ = new §_-TA§(8);
      
      private const §_-U1t§:§_-TA§ = new §_-TA§(150);
      
      private const §_-N2Y§:§_-TA§ = new §_-TA§(90);
      
      private const §_-V2r§:§_-TA§ = new §_-TA§(300);
      
      private const §_-N27§:§_-TA§ = new §_-TA§(2);
      
      private var boss:§_-01J§;
      
      private var §_-11v§:Array = [];
      
      private var §_-X0§:§_-C3e§;
      
      private var §_-C2G§:§_-C3e§;
      
      private var §_-W2§:GuardingBot;
      
      public function §_-E1x§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:uint = uint(Application.userProfile.getLevel());
         var _loc5_:uint = Application.userProfile.§_-hz§();
         var _loc6_:uint = heroic ? uint(uint(6 + 1.6 * param2)) : uint(5 + 1.1 * param2 + 0.9 * _loc4_);
         this.§_-X0§ = new §_-C3e§();
         this.§_-X0§.clipClassName = "AmGravityGun";
         this.§_-X0§.damage = new §_-TA§(Math.round(this.§_-c2r§.value + this.§_-Jp§ * _loc6_));
         this.§_-X0§.damageRadius = new §_-TA§(45);
         this.§_-X0§.explosionRadius = new §_-TA§(35);
         this.§_-X0§.pushForce = new §_-TA§(0);
         this.§_-C2G§ = new §_-C3e§();
         this.§_-C2G§.clipClassName = "AmGuardingBot";
         this.§_-C2G§.damage = new §_-TA§(Math.round(this.§_-Z2o§.value + this.§_-Jp§ * _loc6_));
         this.§_-C2G§.damageRadius = new §_-TA§(50);
         this.§_-C2G§.explosionRadius = new §_-TA§(30);
         this.§_-C2G§.pushForce = new §_-TA§(0);
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_MINER"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_MINER"),_loc6_ * 0.9,§_-L1x§.§_-AU§,heroic ? uint(60 + 6 * param2 + 12 * param2 * param3) : uint(180 + 10 * _loc5_ + 4 * _loc4_),_loc6_ * 1.2,_loc6_ * 1.1,§_-S25§.§_-L24§)])];
         return new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_MINER"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_MINER"),_loc6_ * 0.9,§_-L1x§.§_-AU§,heroic ? uint(60 + 6 * param2 + 12 * param2 * param3) : uint(180 + 10 * _loc5_ + 4 * _loc4_),_loc6_ * 1.2,_loc6_ * 1.1,§_-S25§.§_-L24§)])];
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         this.boss = §_-01J§(param1[0].getUnits()[0]);
         this.boss.aiMissFactor = 1;
         this.boss.aiShotPower = 5;
         §§push(this.boss);
         §§push(§§findproperty(§_-A1l§));
         var _temp_3:* = new <§_-de§>[new §_-de§(§_-q24§.§_-82U§),new §_-de§(§_-q24§.§_-K3z§),new §_-de§(§_-q24§.MOLOTOV,0.6),new §_-de§(§_-q24§.SNIPER_RIFLE,0.8),new §_-de§(§_-q24§.§_-w1k§,0.5),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-82U§),new §_-de§(§_-q24§.§_-K3z§),new §_-de§(§_-q24§.MOLOTOV,0.6),new §_-de§(§_-q24§.SNIPER_RIFLE,0.8),new §_-de§(§_-q24§.§_-w1k§,0.5),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE)]);
         §_-TZ§.addListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Jc§,§_-4V§.§_-fV§);
         if(!heroic)
         {
            this.boss.buffs.place(new §_-Ap§());
         }
         super.initBeforeBattle(param1);
      }
      
      private function §_-Jc§(param1:starling.events.Event) : void
      {
         §_-OP§.§_-ST§(param1,param1.data as §_-v2Q§);
         dispatchEvent(param1);
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         var _loc2_:JumpingMine = null;
         var _loc3_:Boolean = false;
         var _loc4_:uint = 0;
         var _loc5_:uint = 0;
         var _loc6_:§_-01J§ = null;
         if(currentUnit == this.boss && !this.boss.disposed)
         {
            this.§_-Wk§();
         }
         else if(!§_-X1j§.§_-12n§.gameMaster.§_-y2v§())
         {
            _loc4_ = uint(this.§_-11v§.length);
            _loc5_ = 0;
            while(_loc5_ < _loc4_)
            {
               _loc2_ = this.§_-11v§[_loc5_];
               _loc3_ = true;
               if(!_loc2_.disposed)
               {
                  for each(_loc6_ in §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss))
                  {
                     if(MathUtil.distance(_loc2_.x,_loc2_.y,_loc6_.x,_loc6_.y) <= this.§_-V2r§.value)
                     {
                        _loc2_.turnLive = 0;
                        _loc3_ = false;
                        break;
                     }
                  }
                  if(_loc3_)
                  {
                     ++_loc2_.turnLive;
                  }
                  if(_loc2_.turnLive >= this.§_-N27§.value)
                  {
                     _loc2_.removeEventListener(§_-L3Q§.DISPOSED,this.§_-Q2e§);
                     _loc2_.destroy();
                     this.§_-11v§.splice(_loc5_,1);
                     _loc4_--;
                  }
               }
               _loc5_++;
            }
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:§_-01J§ = null;
         if(param1 == 1)
         {
            this.§_-Wk§();
            this.§_-23b§(this.§_-4K§.value);
         }
         if(param2 == this.boss && !this.boss.disposed)
         {
            this.§_-23b§(this.§_-p2y§.value);
            for each(_loc3_ in §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss))
            {
               if(MathUtil.distance(this.boss.x,this.boss.y,_loc3_.x,_loc3_.y) <= this.§_-U1t§.value)
               {
                  §_-OP§.§_-n2Q§(_loc3_,16763904,80,false);
               }
            }
         }
         super.§_-03f§(param1,param2);
      }
      
      private function §_-H1g§(param1:Point) : void
      {
         var _loc2_:JumpingMine = null;
         if(Boolean(param1 != null) && Boolean(this.boss) && !this.boss.disposed)
         {
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_SMOKE,param1.x,param1.y,16);
            _loc2_ = new JumpingMine(this.boss,param1.x,param1.y,this.§_-X0§,§_-X1j§.randomSeed.§_-Fh§(1,12),!heroic);
            _loc2_.addEventListener(§_-L3Q§.DISPOSED,this.§_-Q2e§);
            this.§_-11v§.push(_loc2_);
            _loc2_.setSpeedXY(0,0);
            Pool.putPoint(param1);
         }
      }
      
      private function §_-23b§(param1:int) : void
      {
         var _loc2_:Point = null;
         var _loc3_:uint = 0;
         while(_loc3_ < param1)
         {
            _loc2_ = §_-OP§.§_-pa§(120,false,10);
            if(_loc2_ != null)
            {
               §_-Ia§.§_-33o§(2 * _loc3_,this.§_-H1g§,_loc2_);
            }
            _loc3_++;
         }
      }
      
      private function §_-Q2e§(param1:starling.events.Event) : void
      {
         JumpingMine(param1.currentTarget).removeEventListener(§_-L3Q§.DISPOSED,this.§_-Q2e§);
         if(currentUnit != this.boss)
         {
            dispatchEvent(param1);
         }
      }
      
      private function §_-Wk§() : void
      {
         if(this.§_-W2§ == null || this.§_-W2§.disposed)
         {
            this.§_-W2§ = new GuardingBot(this.boss,this.boss.x,this.boss.y,this.§_-C2G§);
            this.§_-W2§.setSpeedXY(0,0);
            this.§_-W2§.§_-92S§ = false;
         }
         else if(MathUtil.distance(this.boss.x,this.boss.y,this.§_-W2§.x,this.§_-W2§.y) >= this.§_-N2Y§.value)
         {
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_LARGE,this.§_-W2§.x,this.§_-W2§.y,24);
            this.§_-W2§.disposed = true;
            this.§_-Wk§();
         }
      }
      
      override public function clear() : void
      {
         this.§_-11v§.length = 0;
         §_-TZ§.removeListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         this.boss = null;
         this.§_-W2§ = null;
      }
   }
}


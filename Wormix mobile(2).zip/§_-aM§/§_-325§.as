package §_-aM§
{
   import §_-12W§.*;
   import §_-12a§.§_-E1Q§;
   import §_-12a§.§_-G2l§;
   import §_-51j§.§_-C1L§;
   import §_-51j§.§_-X19§;
   import §_-51j§.§_-w17§;
   import §_-62§.§_-gr§;
   import §_-73I§.*;
   import §_-931§.§_-02O§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-A2F§.§_-4B§;
   import §_-B1y§.§_-o2k§;
   import §_-C2t§.§_-92W§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-J31§.§_-R1h§;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Vu§.MD5;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-hv§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-x22§.§_-xY§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-F4§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Button;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.RelativePosition;
   import flash.desktop.NativeApplication;
   import flash.filters.BlurFilter;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-B1m§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.client.JoinToChat;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-325§ extends §_-P1N§
   {
      
      private var mainBoss:§_-01J§;
      
      private var §_-K1C§:Vector.<§_-01J§>;
      
      public function §_-325§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc5_:uint = 0;
         var _loc6_:Number = NaN;
         var _loc4_:uint = heroic ? uint(2.2 + 1.2 * param2) : uint(5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4);
         _loc5_ = 200 + 7 * param2 + 8 * param2 * param3;
         _loc6_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _loc7_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         var _loc8_:Array = [UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE1"),10 + _loc4_ * 2,§_-L1x§.§_-AU§,heroic ? uint(140 + _loc5_) : uint(460 + _loc4_ * 37),15 + _loc4_ * 1.9,5 + _loc4_ * 1.9,§_-S25§.BOSS_PIRATE),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE2"),_loc4_ * 1.2,§_-L1x§.§_-AU§,heroic ? uint(80 + _loc5_) : uint(165 + 19 * _loc4_),1.2 * _loc4_,1.2 * _loc4_,§_-S25§.AQUALUNG),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,heroic ? uint(65 + _loc5_) : uint(200 + 17 * _loc4_),1.3 * _loc4_,1.2 * _loc4_,§_-S25§.AQUALUNG),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE2"),_loc4_ * 1.2,§_-L1x§.§_-I1h§,heroic ? _loc5_ : uint(140 + 20 * _loc4_),1.4 * _loc4_,_loc4_,§_-S25§.AQUALUNG)];
         if(heroic)
         {
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_PIRATE1"),[_loc8_[0],_loc8_[1],_loc8_[2]]));
         }
         else
         {
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_PIRATE1"),[_loc8_[0]]));
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_PIRATE2"),[_loc8_[1],_loc8_[2],_loc8_[3]]));
         }
         return _loc7_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc3_:§_-01J§ = null;
         this.mainBoss = §_-01J§(param1[0].getUnits()[0]);
         this.mainBoss.getPhysicModel().addEventListener(§_-L3Q§.§_-kl§,this.§_-AL§);
         this.mainBoss.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-m1P§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1),new §_-de§(§_-q24§.WATERMELON,0.5),new §_-de§(§_-q24§.§_-F2c§,0.3)]);
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(!heroic)
         {
            _loc2_ = param1[1].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[1]);
            _loc2_.push(param1[0].getUnits()[2]);
         }
         this.§_-K1C§ = new Vector.<§_-01J§>();
         for each(_loc3_ in _loc2_)
         {
            this.§_-K1C§.push(_loc3_);
            _loc3_.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.WATERMELON,0.5,1),new §_-de§(§_-q24§.CANNON_UPG_1,0.3)]);
            _loc3_.aiMissFactor = 1;
            _loc3_.aiShotPower = 5;
            _loc3_.addEventListener(§_-L3Q§.§_-kl§,this.§_-i1M§);
            §_-TZ§.addListener(_loc3_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-F2C§,§_-4V§.§_-CO§);
         }
         §_-X1j§.§_-12n§.scene.setWeather(Weather.RAIN);
         super.initBeforeBattle(param1);
         this.mainBoss.buffs.§_-e1z§(§_-92W§.NAME);
      }
      
      private function §_-i1M§(param1:Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-s1x§.PIRATE_DROWN_SUPPORTS));
      }
      
      private function §_-F2C§(param1:Event) : void
      {
         dispatchEvent(param1);
      }
      
      private function §_-AL§(param1:Event = null) : void
      {
         this.mainBoss.disposed = false;
         this.mainBoss.x = this.§_-a7§();
         this.mainBoss.y -= 10;
         this.mainBoss.§_-ab§(0);
         this.mainBoss.setSpeedXY(0,-40);
         this.mainBoss.physParams.collidesWith = PhysParams.COLLIDES_WITH_NOTHING;
         this.§_-h1K§();
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.FRAME,this.§_-h1K§);
      }
      
      private function §_-a7§() : int
      {
         var _loc1_:int = 0;
         var _loc2_:Boolean = false;
         var _loc3_:§_-01J§ = null;
         do
         {
            _loc1_ = 1100 + §_-X1j§.randomSeed.§_-H3r§(0,1) * 700;
            _loc2_ = true;
            for each(_loc3_ in §_-X1j§.§_-12n§.gameMaster.§_-D3n§())
            {
               if(Math.abs(_loc3_.x - _loc1_) < 20)
               {
                  _loc2_ = false;
                  break;
               }
            }
         }
         while(!_loc2_);
         return _loc1_;
      }
      
      private function §_-h1K§(param1:Event = null) : void
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         var _loc4_:Number = NaN;
         var _loc5_:int = 0;
         if(this.mainBoss != null && !this.mainBoss.disposed)
         {
            _loc2_ = this.mainBoss.x;
            _loc3_ = this.mainBoss.y;
            _loc4_ = this.mainBoss.speedY;
            if(_loc4_ > 0)
            {
               §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.§_-h1K§);
               §_-4B§.§_-O3§(_loc2_,_loc3_ + 120,90);
               this.mainBoss.physParams.collidesWith = PhysParams.COLLIDES_WITH_GROUND;
            }
            else
            {
               _loc5_ = 0;
               while(_loc5_ < 3)
               {
                  §_-X1j§.§_-12n§.scene.drawDamage(_loc2_,_loc3_ + _loc5_ * 10,10);
                  Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_DRILL,_loc2_,_loc3_ + _loc5_ * 10,10);
                  _loc5_++;
               }
            }
            §_-h2B§.play(§_-d27§.§_-S3§);
         }
         else
         {
            §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.FRAME,this.§_-h1K§);
         }
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = super.§_-H1J§();
         _loc1_.water = new §_-A18§(20,3,30);
         return _loc1_;
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         this.mainBoss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-AL§);
         for each(_loc1_ in this.§_-K1C§)
         {
            _loc1_.removeEventListener(§_-L3Q§.§_-kl§,this.§_-i1M§);
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-F2C§);
         }
         this.§_-K1C§ = null;
         this.mainBoss = null;
      }
   }
}


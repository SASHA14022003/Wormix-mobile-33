package §_-aM§
{
   import §_-03T§.§_-2p§;
   import §_-62§.§_-zF§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F2Q§.GestureEvent;
   import §_-J31§.§_-R1h§;
   import §_-Ty§.§_-83N§;
   import §_-Ty§.§_-K3a§;
   import §_-Ty§.§_-SC§;
   import §_-Ty§.§_-U2T§;
   import §_-Ty§.§_-n1U§;
   import §_-Ty§.§_-o1U§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-nZ§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Zd§;
   import feathers.controls.List;
   import feathers.controls.TabBar;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.layout.AnchorLayout;
   import flash.display.Stage;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.HarmBolt;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   
   use namespace gestouch_internal;
   
   public class §_-I26§ extends §_-P1N§
   {
      
      public static const §_-EU§:uint = 1;
      
      public static const §_-zs§:uint = 2;
      
      private const §_-f1l§:uint = 50;
      
      private const §_-I14§:uint = 50;
      
      private const §_-53h§:uint = 200;
      
      private var mainBoss:§_-01J§;
      
      private var §_-ML§:Array = [];
      
      private var §_-K1R§:Vector.<int> = new Vector.<int>();
      
      public function §_-I26§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc5_:Number = NaN;
         var _loc4_:uint = heroic ? uint(uint(5 + 1.8 * param2)) : uint(5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4);
         _loc5_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _loc6_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         var _loc7_:Array = [UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_SHAMAN1"),5 + _loc4_ * 1.8,§_-L1x§.§_-I1h§,200 + _loc4_ * 35,_loc4_ * 2,10 + _loc4_ * 1.74,§_-S25§.§_-Mz§),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_SHAMAN2"),_loc4_ * 1.2,§_-L1x§.§_-l2G§,200 + 17 * _loc4_,_loc4_,1.4 * _loc4_),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_SHAMAN2"),_loc4_ * 1.2,§_-L1x§.§_-l2G§,180 + 18 * _loc4_,1.2 * _loc4_,1.2 * _loc4_),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_SHAMAN2"),_loc4_ * 1.2,§_-L1x§.§_-l2G§,154 + 18 * _loc4_,1.4 * _loc4_,_loc4_)];
         if(heroic)
         {
            _loc6_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_SHAMAN1"),[_loc7_[0],_loc7_[1],_loc7_[2]]));
         }
         else
         {
            _loc6_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_SHAMAN1"),[_loc7_[0]]));
            _loc6_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_SHAMAN2"),[_loc7_[1],_loc7_[2],_loc7_[3]]));
         }
         return _loc6_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(heroic)
         {
            _loc2_ = param1[0].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[1]);
            _loc2_.push(param1[1].getUnits()[2]);
         }
         var _loc4_:uint = 1;
         while(_loc4_ < _loc2_.length)
         {
            this.§_-K1R§[_loc4_ - 1] = 0;
            _loc3_ = _loc2_[_loc4_];
            §_-TZ§.addListener(_loc3_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-n2Q§,-20);
            §_-TZ§.addListener(_loc3_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-t2g§,-10);
            §§push(_loc3_);
            §§push(§§findproperty(§_-A1l§));
            var _temp_6:* = new <§_-de§>[new §_-de§(§_-q24§.MORTAR),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW,0.5),new §_-de§(§_-q24§.§_-d25§),new §_-de§(§_-q24§.MOLOTOV,0.5),new §_-de§(§_-q24§.RIFLE),new §_-de§(§_-q24§.AK_47,0.5),new §_-de§(§_-q24§.SNIPER_RIFLE),new §_-de§(§_-q24§.§_-82U§)];
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.MORTAR),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW,0.5),new §_-de§(§_-q24§.§_-d25§),new §_-de§(§_-q24§.MOLOTOV,0.5),new §_-de§(§_-q24§.RIFLE),new §_-de§(§_-q24§.AK_47,0.5),new §_-de§(§_-q24§.SNIPER_RIFLE),new §_-de§(§_-q24§.§_-82U§)]);
            this.§_-ML§.push(_loc3_);
            _loc4_++;
         }
         for each(_loc3_ in _loc2_)
         {
            _loc3_.aiMissFactor = 1;
            _loc3_.aiShotPower = 5;
         }
         this.mainBoss = _loc2_[0];
         §§push(this.mainBoss);
         §§push(§§findproperty(§_-A1l§));
         var _temp_16:* = new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.CANNON_UPG_1,0.3),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.RIFLE)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.CANNON_UPG_1,0.3),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.RIFLE)]);
         §_-TZ§.addListener(this.mainBoss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         super.initBeforeBattle(param1);
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:§_-01J§ = null;
         if(§_-X1j§.§_-12n§.gameMaster.activeUnit == this.mainBoss && !this.mainBoss.disposed)
         {
            for each(_loc3_ in §_-X1j§.§_-12n§.gameMaster.§_-b2W§(this.mainBoss))
            {
               new HealBolt(this.mainBoss,this.mainBoss.x,this.mainBoss.y,_loc3_,this.§_-I14§);
            }
            new HealBolt(this.mainBoss,this.mainBoss.x,this.mainBoss.y,this.mainBoss,this.§_-f1l§);
         }
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         var _loc2_:int = 0;
         var _loc3_:int = int(this.§_-ML§.length);
         var _loc4_:int = 0;
         var _loc5_:int = int(this.§_-ML§.length);
         while(_loc4_ < _loc5_)
         {
            if(this.§_-K1R§[_loc4_] > 0)
            {
               this.§_-K1R§[_loc4_] = -1;
            }
            _loc2_ += this.§_-K1R§[_loc4_];
            _loc4_++;
         }
         if(_loc2_ == -_loc3_)
         {
            dispatchEvent(new §_-R1h§(§_-zs§));
         }
      }
      
      private function §_-t2g§(param1:Event, param2:§_-v2Q§) : void
      {
         if(Boolean(param2.victim.disposed) && Boolean(this.mainBoss) && !this.mainBoss.disposed)
         {
            new HarmBolt(§_-01J§(param2.victim),param2.victim.x,param2.victim.y,this.mainBoss,this.§_-53h§);
            if(this.§_-K1R§[this.§_-ML§.indexOf(param2.victim)] == 1)
            {
               dispatchEvent(new §_-R1h§(§_-EU§));
            }
         }
      }
      
      private function §_-n2Q§(param1:Event, param2:§_-v2Q§) : void
      {
         var _loc4_:PhaseAmmo = null;
         var _loc5_:Point = null;
         var _loc3_:§_-01J§ = §_-01J§(param2.victim);
         if(!_loc3_.disposed)
         {
            if(this.§_-K1R§[this.§_-ML§.indexOf(_loc3_)] != -1)
            {
               var _loc6_:Vector.<int> = this.§_-K1R§;
               var _loc7_:*;
               var _loc8_:Number = _loc6_[_loc7_ = this.§_-ML§.indexOf(_loc3_)] + 1;
               _loc6_[_loc7_] = _loc8_;
            }
            _loc4_ = new PhaseAmmo(_loc3_,_loc3_.x,_loc3_.y,true,_loc3_ as §_-F3o§,11289911,80);
            _loc4_.§_-C2P§ = false;
            _loc5_ = §_-OP§.§_-pa§();
            Physics.teleportUnit(_loc3_ as §_-F3o§,_loc5_.x,_loc5_.y);
            Pool.putPoint(_loc5_);
            _loc3_.setSpeedXY(0,_loc3_.speed);
         }
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         §_-TZ§.removeListener(this.mainBoss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         this.mainBoss = null;
         for each(_loc1_ in this.§_-ML§)
         {
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-n2Q§);
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-t2g§);
         }
         this.§_-K1R§ = null;
         this.§_-ML§ = null;
      }
   }
}


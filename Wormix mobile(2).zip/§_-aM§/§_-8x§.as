package §_-aM§
{
   import §_-21p§.*;
   import §_-31Y§.§_-D3B§;
   import §_-5Y§.ChatInputPanel;
   import §_-5Y§.StickerPanel;
   import §_-5Y§.§_-81g§;
   import §_-5Y§.§_-h2c§;
   import §_-5Y§.§_-t2O§;
   import §_-63U§.§_-W1L§;
   import §_-63U§.§_-y2O§;
   import §_-A1K§.§_-7u§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.Cookie;
   import §_-C2M§.*;
   import §_-C2t§.§_-92W§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-F2Q§.GestureEvent;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-p1m§;
   import §_-X14§.§_-J2b§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z2S§.§_-b8§;
   import §_-g2C§.§_-k1p§;
   import §_-g2C§.§_-p8§;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.§_-y2Z§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-Rs§;
   import §_-m0§.§_-v21§;
   import §_-p18§.§_-vd§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-sK§.*;
   import §_-w2i§.§_-52k§;
   import §_-w2i§.§_-Ia§;
   import §_-y1s§.§_-O1z§;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollContainer;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.layout.VerticalLayoutData;
   import feathers.themes.styles.AlternateTextStyles;
   import feathers.utils.textures.TextureCache;
   import flash.display.StageDisplayState;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.controller.mobile.BaseMobileSocialController;
   import ru.pragmatix.flox.social.profilePage.IProfilePageShower;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.ArmatureAuraEffect;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.EndBattleStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.Girder;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-8x§ extends §_-P1N§
   {
      
      private static const §_-y1z§:uint = 15;
      
      private static const §_-Y1j§:uint = 150;
      
      private static const §_-la§:uint = 120;
      
      private static const §_-yy§:uint = 210;
      
      private var §_-P1K§:int = -1;
      
      private var §_-gB§:Boolean = false;
      
      private var aura:ArmatureAuraEffect;
      
      private var §_-k8§:Vector.<§_-y2O§> = new Vector.<§_-y2O§>();
      
      private var §_-VB§:§_-01J§;
      
      public function §_-8x§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var stats:§_-k1I§ = null;
         var playerSquads:Vector.<§_-V23§> = param1;
         var maxLevel:uint = param2;
         var unitCount:uint = param3;
         stats = new §_-k1I§(5,1.1,0.9,playerSquads);
         var mainTeam:Function = function():UserProfile
         {
            return UserProfile.custom(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PSIONICS_BOT_NAME_1),stats.level * 1.35,§_-L1x§.§_-AU§,500 + 7 * stats.§_-sL§ + 3 * stats.§_-Z2r§,stats.level * 1.5,stats.level * 0.8,§_-S25§.BOSS_PSI_TELEPATHIST);
         };
         var createMinionBoss:Function = function():UserProfile
         {
            return UserProfile.custom(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PSIONICS_BOT_NAME_2),stats.level,§_-L1x§.§_-I1h§,150 + 6 * stats.§_-sL§ + 3 * stats.§_-Z2r§,stats.level * 0.8,stats.level * 0.9,§_-S25§.PSI_BIOTIC);
         };
         var aiTeams:Vector.<§_-81l§> = new Vector.<§_-81l§>(0);
         if(heroic)
         {
            aiTeams.push(new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PSIONICS_BOT_NAME_1),[mainTeam(),createMinionBoss(),createMinionBoss()]));
         }
         else
         {
            aiTeams.push(new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PSIONICS_BOT_NAME_1),[mainTeam()]));
            aiTeams.push(new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PSIONICS_TEAM_BOT_2),[createMinionBoss(),createMinionBoss(),createMinionBoss()]));
         }
         return aiTeams;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc4_:uint = 0;
         var _loc5_:uint = 0;
         var _loc6_:Vector.<§_-01J§> = null;
         var _loc2_:Vector.<§_-01J§> = param1[0].getUnits();
         var _loc3_:§_-01J§ = _loc2_[0];
         §§push(_loc3_);
         §§push(§§findproperty(§_-A1l§));
         var _temp_5:* = new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,0.5),new §_-de§(§_-q24§.§_-ZW§,0.5),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7),new §_-de§(§_-q24§.ANTITOXIN,0.9),new §_-de§(§_-q24§.BANDAGE,0.3,1)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,0.5),new §_-de§(§_-q24§.§_-ZW§,0.5),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7),new §_-de§(§_-q24§.ANTITOXIN,0.9),new §_-de§(§_-q24§.BANDAGE,0.3,1)]);
         _loc3_.buffs.place(new §_-92W§());
         this.§_-VB§ = _loc3_;
         if(heroic)
         {
            _loc4_ = uint(_loc2_.length);
            _loc5_ = 1;
            while(_loc5_ < _loc4_)
            {
               _loc3_ = _loc2_[_loc5_];
               this.§_-M§(_loc3_);
               _loc5_++;
            }
         }
         else
         {
            _loc6_ = param1[1].getUnits();
            for each(_loc3_ in _loc6_)
            {
               this.§_-M§(_loc3_);
            }
         }
         super.initBeforeBattle(param1);
      }
      
      private function §_-M§(param1:§_-01J§) : void
      {
         §§push(param1);
         §§push(§§findproperty(§_-A1l§));
         var _temp_3:* = new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.§_-F31§,0.6),new §_-de§(§_-q24§.AK_47,0.4),new §_-de§(§_-q24§.CROSSBOW,0.4),new §_-de§(§_-q24§.ANTITOXIN,0.6),new §_-de§(§_-q24§.BANDAGE,0.3,1)];
         var _temp_5:* = new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.§_-F31§,0.6),new §_-de§(§_-q24§.AK_47,0.4),new §_-de§(§_-q24§.CROSSBOW,0.4),new §_-de§(§_-q24§.ANTITOXIN,0.6),new §_-de§(§_-q24§.BANDAGE,0.3,1)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.§_-F31§,0.6),new §_-de§(§_-q24§.AK_47,0.4),new §_-de§(§_-q24§.CROSSBOW,0.4),new §_-de§(§_-q24§.ANTITOXIN,0.6),new §_-de§(§_-q24§.BANDAGE,0.3,1)]);
         param1.buffs.place(new §_-92W§());
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         var _loc2_:Vector.<§_-01J§> = null;
         var _loc3_:§_-01J§ = null;
         if(gameMaster.§_-y2v§() && currentUnit != this.§_-VB§)
         {
            _loc2_ = gameMaster.§_-b2W§(this.§_-VB§);
            for each(_loc3_ in _loc2_)
            {
               if(this.§_-k8§.length >= §_-y1z§)
               {
                  if(!this.§_-k8§[0].disposed)
                  {
                     this.§_-k8§[0].disposed = true;
                  }
                  this.§_-k8§.splice(0,1);
               }
               this.§_-k8§.push(new §_-y2O§(_loc3_,§_-la§));
               §_-OP§.§_-n2Q§(_loc3_,16777215,80);
            }
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:Boolean = false;
         var _loc4_:Array = null;
         var _loc5_:§_-V23§ = null;
         super.§_-03f§(param1,param2);
         if(!gameMaster.§_-y2v§())
         {
            if(!this.§_-gB§ && param1 > 2 && !this.§_-VB§.disposed)
            {
               if(this.§_-P1K§ == -1)
               {
                  this.§_-h1z§(param2);
                  this.§_-P1K§ = param2.squad.getNumber();
               }
               else
               {
                  _loc3_ = false;
                  if(this.§_-P1K§ == param2.squad.getNumber())
                  {
                     _loc4_ = gameMaster.§_-12G§();
                     for each(_loc5_ in _loc4_)
                     {
                        if(!_loc5_.isAi() && _loc5_.eliminated)
                        {
                           _loc3_ = true;
                           break;
                        }
                     }
                  }
                  else
                  {
                     _loc3_ = true;
                  }
                  if(_loc3_)
                  {
                     this.§_-h1z§(param2);
                     this.§_-P1K§ = param2.squad.getNumber();
                  }
               }
            }
         }
         else
         {
            if(param2 != this.§_-VB§)
            {
               this.§_-t2o§(param2);
            }
            this.§_-gB§ = false;
         }
      }
      
      private function §_-h1z§(param1:§_-01J§) : §_-01J§
      {
         var _loc2_:§_-01J§ = null;
         var _loc5_:§_-eX§ = null;
         var _loc6_:uint = 0;
         var _loc7_:* = 0;
         var _loc3_:Vector.<§_-01J§> = gameMaster.§_-b2W§(param1);
         var _loc4_:uint = §_-yy§;
         if(_loc3_.length == 0)
         {
            _loc2_ = param1;
            _loc5_ = gameMaster;
            if((Boolean(_loc5_)) && Boolean(!_loc5_.§_-Rk§()) && !_loc5_.§_-U2O§())
            {
               currentUnit.§_-vp§ = false;
            }
            _loc4_ = 0;
         }
         else if(_loc3_.length > 1)
         {
            _loc6_ = param1.squad.getNumber();
            _loc7_ = int(_loc3_.length - 1);
            while(_loc7_ >= 0)
            {
               _loc2_ = _loc3_[_loc7_];
               if(_loc2_.squad.getNumber() == _loc6_)
               {
                  _loc3_.splice(_loc7_,1);
                  break;
               }
               _loc7_--;
            }
         }
         if(_loc3_.length != 0)
         {
            _loc2_ = _loc3_[randomSeed.§_-Fh§(0,_loc3_.length - 1)];
         }
         this.§_-EK§(_loc2_,_loc4_);
         return _loc2_;
      }
      
      private function §_-EK§(param1:§_-01J§, param2:uint) : void
      {
         var _loc4_:Number = NaN;
         var _loc3_:Number = §_-X1j§.§_-12n§.scene.getWaterLevel();
         _loc4_ = randomSeed.§_-Fh§(0,param1.y + §_-W1L§.RADIUS >= _loc3_ ? 1 : 2) * Math.PI;
         var _loc5_:Point = MathUtil.§_-UW§(§_-W1L§.RADIUS,_loc4_);
         new §_-W1L§(param1,param1.x + _loc5_.x,param1.y + _loc5_.y,param2);
         Pool.putPoint(_loc5_);
         this.§_-gB§ = true;
      }
      
      private function §_-t2o§(param1:§_-01J§) : void
      {
         var area:§_-y2O§ = null;
         var unit:§_-01J§ = null;
         var owner:§_-01J§ = param1;
         var mentalAreas:Vector.<§_-F3o§> = §_-X1j§.§_-12n§.scene.gameObjectProcessor.cache.§_-MM§([§_-y2O§]);
         var enemies:Vector.<§_-01J§> = gameMaster.§_-83I§(owner);
         for each(area in mentalAreas)
         {
            for each(unit in enemies)
            {
               if(MathUtil.distance(area.x,area.y,unit.x,unit.y) <= §_-Y1j§)
               {
                  §_-Ia§.§_-33o§(8,function():void
                  {
                     onBeginAnimationPlay(owner,area,unit);
                  });
                  this.aura = new ArmatureAuraEffect(owner,"LoopTime");
                  this.aura.onAppear();
                  §_-Ia§.§_-33o§(32,function():void
                  {
                     onBeginAnimationPlay(owner,area,unit);
                  });
                  return;
               }
            }
         }
      }
      
      private function onBeginAnimationPlay(param1:§_-01J§, param2:§_-y2O§, param3:§_-01J§) : void
      {
         if(!param2.disposed)
         {
            param2.§_-tI§(§_-Y1j§);
            param2.disposed = true;
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_ELECTRIC,param3.x,param3.y,§_-Y1j§ - §_-Y1j§ * 0.3);
            param3.buffs.§_-e1z§(§_-8u§.NAME);
            param3.buffs.§_-e1z§(§_-M2S§.NAME);
            param3.buffs.§_-e1z§(§_-Z2z§.NAME);
            §_-52k§.single(param1 as EventDispatcher,§_-L3Q§.TELEPORT,this.onTeleport,this,[param1],true);
            Physics.teleportUnit(param1 as §_-F3o§,param2.x,param2.y);
         }
      }
      
      private function onTeleport(param1:§_-v21§, param2:§_-01J§) : void
      {
         this.§_-T21§();
      }
      
      private function §_-T21§() : void
      {
         if(this.aura)
         {
            this.aura.onFading();
         }
      }
      
      override public function clear() : void
      {
         if(this.aura)
         {
            this.aura.dispose();
            this.aura = null;
         }
         this.§_-VB§ = null;
      }
   }
}


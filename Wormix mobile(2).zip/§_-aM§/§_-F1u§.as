package §_-aM§
{
   import §_-51W§.§_-SN§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-79§.§_-ps§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-F1P§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-P2i§.§_-b7§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-bI§.§_-d2V§;
   import §_-j1w§.§_-L1x§;
   import §_-jF§.*;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-e1k§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-52k§;
   import com.mesmotronic.ane.AndroidFullScreen;
   import feathers.controls.ScrollPolicy;
   import feathers.layout.AnchorLayout;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.media.SoundMixer;
   import flash.media.SoundTransform;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.AwardTypes;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.ammo.InvisibleGuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.boss.emperor.EmperorTerracottaWarrior;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealPhase;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.extensions.ParticleAura;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-F1u§ extends §_-P1N§
   {
      
      private static const §_-R1N§:§_-TA§ = new §_-TA§(17);
      
      private static const §_-s2v§:§_-TA§ = new §_-TA§(15);
      
      private static const §_-W28§:§_-TA§ = new §_-TA§(10);
      
      private var §_-o1x§:§_-TA§ = new §_-TA§(29);
      
      private var bonusAttack:§_-TA§ = new §_-TA§(2);
      
      private var paramSet:§_-C3e§;
      
      private var §_-f2t§:Vector.<§_-01J§> = new Vector.<§_-01J§>();
      
      private var boss:§_-01J§;
      
      public function §_-F1u§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:uint = 0;
         _loc4_ = uint(uint(7 + 1.6 * param2));
         this.paramSet = §_-C3e§.§_-y1O§("AmGuardingBot",§_-s2v§ + MathUtil.§_-na§(§_-W28§.value / 2,0.7 * _loc4_),50,30);
         this.§_-o1x§.value += MathUtil.§_-na§(§_-W28§.value,_loc4_);
         this.bonusAttack.value += MathUtil.§_-na§(§_-W28§.value,_loc4_);
         var _loc5_:UserProfile = UserProfile.custom(§_-s2a§.§_-K3t§("BOT_SERGEANT_NAME_1"),_loc4_,§_-L1x§.§_-AU§,60 + 6 * param2 + 11 * param2 * param3,5 + _loc4_,_loc4_ * 0.6,§_-S25§.§_-F3z§);
         var _loc6_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         if(heroic)
         {
            _loc6_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_SERGEANT_NAME_1"),[_loc5_,this.§_-LZ§(§_-L1x§.§_-I1h§,param2,param3),this.§_-LZ§(§_-L1x§.§_-AU§,param2,param3)]));
         }
         else
         {
            _loc6_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_SERGEANT_NAME_1"),[_loc5_]));
            _loc6_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_SERGEANT_NAME_2"),[this.§_-LZ§(§_-L1x§.§_-I1h§,param2,param3),this.§_-LZ§(§_-L1x§.§_-AU§,param2,param3)]));
         }
         return _loc6_;
      }
      
      private function §_-LZ§(param1:§_-L1x§, param2:uint, param3:uint) : UserProfile
      {
         var _loc4_:uint = uint(uint(5 + 1.5 * param2));
         return UserProfile.custom(§_-s2a§.§_-K3t§("BOT_SERGEANT_NAME_2"),4 + _loc4_ * 0.85,param1,18 + 4 * param2 + 8 * param2 * param3,2 + _loc4_ * 0.8,2 + _loc4_ * 0.4,§_-S25§.§_-c2F§);
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(heroic)
         {
            _loc2_ = param1[0].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[1]);
         }
         this.boss = _loc2_[0];
         this.boss.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.7),new §_-de§(§_-q24§.GRENADE,0.5),new §_-de§(§_-q24§.MINIGUN,0.5),new §_-de§(§_-q24§.§_-K3z§,0.5),new §_-de§(§_-q24§.§_-82U§,0.5),new §_-de§(§_-q24§.SNIPER_RIFLE,0.7),new §_-de§(§_-q24§.§_-w1k§,0.7)]);
         if(!heroic)
         {
            this.boss.buffs.place(new §_-Ap§());
         }
         §_-TZ§.addListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         var _loc4_:uint = 1;
         while(_loc4_ < _loc2_.length)
         {
            _loc3_ = _loc2_[_loc4_];
            _loc3_.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.7),new §_-de§(§_-q24§.MINIGUN,0.7),new §_-de§(§_-q24§.§_-82U§,0.7),new §_-de§(§_-q24§.§_-d25§,0.5),new §_-de§(§_-q24§.§_-w1k§,0.3),new §_-de§(§_-q24§.CANNON,0.1)]);
            _loc3_.aiArsenal.§_-R29§([§_-q24§.§_-B3l§]);
            §_-TZ§.addListener(_loc3_ as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
            if(!heroic)
            {
               _loc3_.buffs.place(new §_-Ap§());
            }
            this.§_-f2t§[_loc4_ - 1] = _loc3_;
            _loc4_++;
         }
         super.initBeforeBattle(param1);
         this.boss.aiMissFactor = 2;
         this.boss.aiShotPower = 3;
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:Vector.<§_-01J§> = null;
         var _loc4_:§_-01J§ = null;
         var _loc5_:uint = 0;
         super.§_-03f§(param1,param2);
         if(param1 == 1)
         {
            _loc3_ = gameMaster.§_-b2W§(this.boss,false,true);
            for each(_loc4_ in _loc3_)
            {
               this.§_-23O§(_loc4_);
               if(_loc4_ == this.boss)
               {
                  this.§_-23O§(_loc4_);
               }
            }
         }
         if(param2.squad.getUnits(true).indexOf(this.boss) >= 0)
         {
            _loc3_ = gameMaster.§_-b2W§(this.boss,false,true);
            _loc5_ = uint(§_-X1j§.§_-12n§.scene.gameObjectProcessor.cache.§_-MM§([InvisibleGuardingBot]).length);
            if(_loc5_ < §_-R1N§.value)
            {
               for each(_loc4_ in _loc3_)
               {
                  this.§_-23O§(_loc4_);
               }
            }
            for each(_loc4_ in _loc3_)
            {
               if(this.§_-f2t§.indexOf(_loc4_) == -1)
               {
                  this.§_-Z13§(_loc4_);
               }
            }
         }
         if(this.§_-f2t§.indexOf(param2) != -1)
         {
            _loc3_ = gameMaster.§_-b2W§(param2);
            for each(_loc4_ in _loc3_)
            {
               if(this.§_-f2t§.indexOf(_loc4_) == -1)
               {
                  new HealPhase(param2,param2.x,param2.y,_loc4_,this.§_-o1x§.value);
               }
            }
         }
      }
      
      private function §_-23O§(param1:§_-01J§) : void
      {
         var _loc2_:Point = §_-OP§.§_-63A§(param1.x,param1.y,250,50,50);
         if(!_loc2_)
         {
            _loc2_ = Pool.getPoint(param1.x,param1.y);
         }
         new InvisibleGuardingBot(this.boss,_loc2_.x,_loc2_.y,this.paramSet);
         Pool.putPoint(_loc2_);
      }
      
      private function §_-Z13§(param1:§_-01J§) : void
      {
         param1.attributes.attack.§_-Y2z§(this.bonusAttack.value);
         Effects.floatingText(§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.BONUS_ATTACK),{"value":this.bonusAttack.value}),Effects.ATTACK_BONUS_COLOR,this.boss.x + this.boss.width * 0.5,this.boss.y + this.boss.height * 0.5,20,BitmapFonts.AD_LIB);
         new ParticleAura(Effects.AURA_RAGE,"ParticleTexture",this.boss as §_-F3o§,80);
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         §_-TZ§.removeListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         this.boss = null;
         for each(_loc1_ in this.§_-f2t§)
         {
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         }
         this.§_-f2t§.length = 0;
      }
      
      public function getSergeant() : §_-01J§
      {
         return this.boss;
      }
   }
}


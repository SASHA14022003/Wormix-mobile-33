package §_-aM§
{
   import §_-92a§.ArenaMenu;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.*;
   import §_-RE§.§_-r2q§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.*;
   import §_-W§.§_-Ap§;
   import §_-W§.§_-qS§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-v2Q§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-n1w§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import com.hurlant.crypto.tls.§_-21v§;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.TextInput;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.VectorCollection;
   import flash.geom.Point;
   import flash.media.SoundMixer;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.clearTimeout;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.request.treasury.ChangeClanMedalPriceRequest;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.GenericPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import ru.pragmatix.wormix.weapons.ammo.LaserLineAmmoController;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-43E§ extends §_-P1N§
   {
      
      private static const §_-U1t§:§_-TA§ = new §_-TA§(150);
      
      private static const §_-I3Y§:§_-TA§ = new §_-TA§(100);
      
      public static const §_-v1g§:uint = 1;
      
      private const §_-x2I§:Vector.<Point>;
      
      private var boss:§_-01J§;
      
      private var §_-P2T§:Vector.<§_-F3o§>;
      
      private var §_-j8§:§_-C3e§;
      
      public function §_-43E§(param1:Boolean = false)
      {
         §§push(this);
         var _temp_2:* = new <Point>[Pool.getPoint(-§_-I3Y§.value,-§_-I3Y§.value),Pool.getPoint(§_-I3Y§.value,-§_-I3Y§.value),Pool.getPoint(§_-I3Y§.value,§_-I3Y§.value),Pool.getPoint(-§_-I3Y§.value,§_-I3Y§.value)];
         var _temp_4:* = new <Point>[Pool.getPoint(-§_-I3Y§.value,-§_-I3Y§.value),Pool.getPoint(§_-I3Y§.value,-§_-I3Y§.value),Pool.getPoint(§_-I3Y§.value,§_-I3Y§.value),Pool.getPoint(-§_-I3Y§.value,§_-I3Y§.value)];
         §§pop().§_-x2I§ = new <Point>[Pool.getPoint(-§_-I3Y§.value,-§_-I3Y§.value),Pool.getPoint(§_-I3Y§.value,-§_-I3Y§.value),Pool.getPoint(§_-I3Y§.value,§_-I3Y§.value),Pool.getPoint(-§_-I3Y§.value,§_-I3Y§.value)];
         this.§_-P2T§ = new Vector.<§_-F3o§>();
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:uint = uint(Application.userProfile.getLevel());
         var _loc5_:uint = Application.userProfile.§_-hz§();
         var _loc6_:uint = heroic ? uint(uint(5 + 1.4 * param2)) : uint(5 + 1.1 * param2 + 0.9 * _loc4_);
         this.§_-j8§ = new §_-C3e§();
         this.§_-j8§.damage = new §_-TA§(_loc6_ * 1.5);
         this.§_-j8§.damageRadius = new §_-TA§(0);
         this.§_-j8§.explosionRadius = new §_-TA§(0);
         var _loc7_:int = heroic ? int(60 + 8 * param2 + 9 * param2 * param3) : int(120 + 9 * _loc5_ + 4 * _loc4_);
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("BOT_NAME_HUNTER"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_HUNTER"),_loc6_ * 0.8,§_-L1x§.§_-l2G§,_loc7_,_loc6_ * 1.3,_loc6_ * 0.8,§_-S25§.INDIAN)])];
         return new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("BOT_NAME_HUNTER"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_HUNTER"),_loc6_ * 0.8,§_-L1x§.§_-l2G§,_loc7_,_loc6_ * 1.3,_loc6_ * 0.8,§_-S25§.INDIAN)])];
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         this.boss = §_-01J§(param1[0].getUnits()[0]);
         this.boss.aiMissFactor = 1;
         this.boss.aiShotPower = 5;
         §§push(this.boss);
         §§push(§§findproperty(§_-A1l§));
         var _temp_4:* = new <§_-de§>[new §_-de§(§_-q24§.§_-K3z§),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE),new §_-de§(§_-q24§.§_-w1k§,0.6),new §_-de§(§_-q24§.§_-Qf§,0.2),new §_-de§(§_-q24§.MINIGUN,0.4),new §_-de§(§_-q24§.SNIPER_RIFLE,0.5),new §_-de§(§_-q24§.CROSSBOW,0.7)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-K3z§),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE),new §_-de§(§_-q24§.§_-w1k§,0.6),new §_-de§(§_-q24§.§_-Qf§,0.2),new §_-de§(§_-q24§.MINIGUN,0.4),new §_-de§(§_-q24§.SNIPER_RIFLE,0.5),new §_-de§(§_-q24§.CROSSBOW,0.7)]);
         §_-TZ§.addListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         if(!heroic)
         {
            this.boss.buffs.place(new §_-Ap§());
         }
         this.boss.buffs.place(new §_-qS§());
         super.initBeforeBattle(param1);
         LaserLineAmmoController.getInstance();
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:§_-01J§ = null;
         super.§_-03f§(param1,param2);
         if(param2 == this.boss)
         {
            for each(_loc3_ in §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss))
            {
               if(MathUtil.distance(this.boss.x,this.boss.y,_loc3_.x,_loc3_.y) <= §_-U1t§.value)
               {
                  §_-OP§.§_-n2Q§(_loc3_);
               }
            }
         }
         if(!gameMaster.§_-y2v§() && !param2.disposed)
         {
            this.§_-o1O§();
            for each(_loc3_ in gameMaster.§_-83I§(this.boss))
            {
               this.§_-V2C§(_loc3_);
            }
         }
      }
      
      private function §_-V2C§(param1:§_-01J§) : void
      {
         var _loc4_:Point = null;
         var _loc2_:int = int(this.§_-P2T§.length);
         var _loc3_:int = 0;
         while(_loc3_ < this.§_-x2I§.length)
         {
            _loc4_ = MathUtil.§_-41E§(§_-I3Y§.value - Physics.UNIT_HEIGHT,param1.x + this.§_-x2I§[_loc3_].x,param1.y + this.§_-x2I§[_loc3_].y);
            this.§_-X2Y§(_loc4_);
            Pool.putPoint(_loc4_);
            if(_loc3_ > 0)
            {
               LaserLineAmmoController.getInstance().addPair(this.boss,this.§_-j8§,this.§_-P2T§[_loc2_ + _loc3_],this.§_-P2T§[_loc2_ + _loc3_ - 1],65535,false,false);
            }
            if(_loc3_ == this.§_-x2I§.length - 1)
            {
               LaserLineAmmoController.getInstance().addPair(this.boss,this.§_-j8§,this.§_-P2T§[_loc2_ + _loc3_],this.§_-P2T§[_loc2_],65535,false,false);
            }
            _loc3_++;
         }
         LaserLineAmmoController.getInstance().draw();
         §_-h2B§.play(§_-d27§.§_-21k§);
      }
      
      private function §_-X2Y§(param1:Point) : void
      {
         Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_ELECTRIC,param1.x,param1.y,10);
         var _loc2_:LaserActivatorDestructible = new LaserActivatorDestructible(this.boss,param1);
         §_-TZ§.addListener(_loc2_,§_-L3Q§.§_-Qw§,this.§_-Iy§,§_-4V§.§_-CO§);
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-L2X§(_loc2_);
         this.§_-P2T§[this.§_-P2T§.length] = _loc2_;
      }
      
      private function §_-Iy§(param1:Event, param2:§_-v2Q§) : void
      {
         if(param2.power > 0)
         {
            this.§_-eJ§(param2.victim);
            dispatchEvent(new §_-R1h§(§_-v1g§));
         }
         else
         {
            param2.victim.stable = true;
         }
      }
      
      private function §_-eJ§(param1:§_-F3o§) : void
      {
         Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_ELECTRIC,param1.x,param1.y,15);
         §_-TZ§.removeListener(param1,§_-L3Q§.§_-Qw§,this.§_-Iy§);
         param1.disposed = true;
      }
      
      private function §_-o1O§() : void
      {
         var _loc1_:§_-F3o§ = null;
         for each(_loc1_ in this.§_-P2T§)
         {
            if(!_loc1_.disposed)
            {
               this.§_-eJ§(_loc1_);
            }
         }
         this.§_-P2T§.length = 0;
      }
      
      override public function clear() : void
      {
         this.§_-o1O§();
         this.§_-j8§ = null;
         §_-TZ§.removeListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         this.boss = null;
         this.§_-P2T§.length = 0;
      }
   }
}


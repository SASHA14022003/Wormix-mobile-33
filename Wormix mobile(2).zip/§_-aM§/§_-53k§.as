package §_-aM§
{
   import §_-12W§.§_-221§;
   import §_-2H§.§_-91a§;
   import §_-2H§.§_-A1R§;
   import §_-2H§.§_-N15§;
   import §_-2H§.§_-Y1i§;
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-73I§.*;
   import §_-92a§.§_-Y2Y§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-A2F§.§_-4B§;
   import §_-B1y§.§_-o2k§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-H9§.§_-NX§;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-U1i§.§_-U16§;
   import §_-Vg§.ClanEditView;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-G4§;
   import §_-e2r§.§_-02G§;
   import §_-e2r§.§_-lR§;
   import §_-e2r§.§_-n1§;
   import §_-f1G§.§_-kf§;
   import §_-j1w§.§_-L1x§;
   import §_-k1u§.§_-2m§;
   import §_-l1K§.§_-F3m§;
   import §_-l1K§.§_-I7§;
   import §_-l1K§.§_-cZ§;
   import §_-l1K§.§_-d2j§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-F4§;
   import §_-zI§.§_-F3q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.hurlant.math.*;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.*;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.ScreenShake;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.MeteorStrike;
   import ru.pragmatix.wormix.weapons.§_-N1C§;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   use namespace bi_internal;
   
   public class §_-53k§ extends §_-P1N§
   {
      
      private const §_-Q24§:uint = 4;
      
      private const §_-f2B§:§_-A18§ = new §_-A18§(20,2,15);
      
      private var §_-SM§:UserProfile;
      
      private var mainBoss:§_-01J§;
      
      private var §_-K1C§:§_-V23§;
      
      public function §_-53k§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:uint = 0;
         var _loc5_:Number = NaN;
         _loc4_ = uint(uint(5 + 1.2 * param2));
         _loc5_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_PIRATE2"),[UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,170 + 4 * _loc4_ + 7 * _loc4_ * param3,1.2 * _loc4_,1.2 * _loc4_,§_-S25§.AQUALUNG),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,185 + 4 * _loc4_ + 7 * _loc4_ * param3,1.2 * _loc4_,1.3 * _loc4_,§_-S25§.AQUALUNG),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,200 + 4 * _loc4_ + 7 * _loc4_ * param3,1.3 * _loc4_,1.2 * _loc4_,§_-S25§.AQUALUNG)])];
         var _loc6_:Vector.<§_-81l§> = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_PIRATE2"),[UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,170 + 4 * _loc4_ + 7 * _loc4_ * param3,1.2 * _loc4_,1.2 * _loc4_,§_-S25§.AQUALUNG),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,185 + 4 * _loc4_ + 7 * _loc4_ * param3,1.2 * _loc4_,1.3 * _loc4_,§_-S25§.AQUALUNG),UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,200 + 4 * _loc4_ + 7 * _loc4_ * param3,1.3 * _loc4_,1.2 * _loc4_,§_-S25§.AQUALUNG)])];
         if(!heroic)
         {
            _loc6_[0].units.push(UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE3"),_loc4_ * 1.2,§_-L1x§.§_-p21§,140 + 4 * _loc4_ + 7 * _loc4_ * param3,1.4 * _loc4_,_loc4_,§_-S25§.AQUALUNG));
         }
         this.§_-SM§ = UserProfile.§_-bR§(_loc5_,§_-s2a§.§_-K3t§("BOT_NAME_PIRATE1"),10 + _loc4_ * 2,§_-L1x§.§_-p21§,450 + 4 * _loc4_ + 15 * _loc4_ * param3,15 + _loc4_ * 2,5 + _loc4_ * 2,§_-S25§.BOSS_DEAD_PIRATE);
         return _loc6_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc2_:§_-01J§ = null;
         if(§_-X1j§.§_-12n§.scene)
         {
            §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         }
         this.§_-K1C§ = param1[0];
         for each(_loc2_ in this.§_-K1C§.getUnits())
         {
            §§push(_loc2_);
            §§push(§§findproperty(§_-A1l§));
            var _temp_1:* = new <§_-de§>[new §_-de§(§_-q24§.§_-42a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-s26§),new §_-de§(§_-q24§.WATERMELON,0.5,2),new §_-de§(§_-q24§.CANNON_UPG_2,0.3)];
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-42a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-s26§),new §_-de§(§_-q24§.WATERMELON,0.5,2),new §_-de§(§_-q24§.CANNON_UPG_2,0.3)]);
            _loc2_.aiMissFactor = 1;
            _loc2_.aiShotPower = 51;
            this.§_-C2z§(_loc2_);
         }
         super.initBeforeBattle(param1);
      }
      
      private function §_-C2z§(param1:§_-01J§) : void
      {
         §_-TZ§.addListener(param1 as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-r1g§,§_-4V§.§_-CO§);
         param1.addEventListener(§_-L3Q§.§_-kl§,this.§_-i1M§);
      }
      
      private function §_-i1M§(param1:Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-s1x§.PIRATE_REVENGE_DROWN_SUPPORTS));
      }
      
      private function §_-r1g§(param1:Event = null) : void
      {
         if(Boolean(param1) && (param1.currentTarget as §_-01J§).disposed)
         {
            §_-TZ§.removeListener(param1.currentTarget as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-r1g§);
            (param1.currentTarget as §_-01J§).removeEventListener(§_-L3Q§.§_-kl§,this.§_-i1M§);
         }
         if(param1)
         {
            dispatchEvent(param1);
         }
         if(this.§_-K1C§.§_-Z2G§() == 0 && this.mainBoss == null)
         {
            this.mainBoss = this.§_-p27§();
            this.§_-K1C§.§_-D3t§(this.mainBoss);
            this.§_-AL§();
         }
      }
      
      private function §_-fZ§(param1:Event) : void
      {
         var _loc2_:§_-01J§ = param1.data as §_-01J§;
         if(Boolean(_loc2_) && this.§_-K1C§.getTeamId() == _loc2_.squad.getTeamId())
         {
            this.§_-C2z§(_loc2_);
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         this.currentUnit = param2;
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         var _loc2_:§_-F3o§ = null;
         var _loc3_:int = 0;
         var _loc4_:uint = 0;
         this.§_-r1g§();
         if(this.mainBoss != null && !this.mainBoss.disposed && currentUnit == this.mainBoss)
         {
            _loc2_ = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
            _loc3_ = 1000;
            _loc4_ = 1;
            while(_loc4_ <= this.§_-Q24§)
            {
               §_-Ia§.§_-33o§(20 * _loc4_,this.§_-w1g§,this.§_-a7§(false),_loc3_,_loc4_ == this.§_-Q24§ ? _loc2_ : null);
               _loc4_++;
            }
         }
      }
      
      private function §_-w1g§(param1:int, param2:int, param3:§_-F3o§) : void
      {
         this.§_-da§(param1,param2);
         if(param3)
         {
            param3.disposed = true;
         }
      }
      
      private function §_-da§(param1:Number, param2:Number = 0) : void
      {
         var _loc5_:Object = null;
         var _loc3_:int = -50;
         var _loc4_:§_-C3e§ = §_-G1p§.§_-I4§(§_-q24§.METEOR).§_-wF§;
         _loc5_ = MeteorStrike.§_-E2D§(param1,param2,§_-X1j§.randomSeed.§_-Fh§(0,90));
         var _loc6_:Number = MathUtil.PI_HALF + MathUtil.PI_ONE_18 * §_-X1j§.randomSeed.§_-Fh§(-3,3);
         var _loc7_:Point = Pool.getPoint(_loc5_.x,§_-X1j§.§_-12n§.scene.height - 50);
         if(HitTest.point(_loc7_.x,_loc7_.y))
         {
            §_-G4§.§_-Ee§(null,_loc7_.x,_loc7_.y + 25,null,_loc4_.damage.value,60,50,true);
         }
         new Meteor(null,_loc4_,_loc7_.x,_loc7_.y - 50,_loc3_ * Math.cos(_loc6_),_loc3_ * Math.sin(_loc6_));
         §_-X1j§.§_-12n§.scene.dispatchEventWith(§_-L3Q§.DAMAGE_TRIGGER,false,§_-N1C§.create(§_-q24§.METEOR,false,true));
         Pool.putPoint(_loc7_);
      }
      
      private function §_-p27§() : §_-01J§
      {
         var _loc1_:§_-01J§ = null;
         var _loc2_:§_-01J§ = null;
         for each(_loc1_ in this.§_-K1C§.getUnits())
         {
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-r1g§);
         }
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         §_-X1j§.§_-12n§.scene.setWeather(Weather.RAIN);
         §_-X1j§.§_-12n§.gameMaster.§_-W2j§().water = this.§_-f2B§;
         _loc2_ = §_-L1x§.create(this.§_-SM§,0,-10);
         _loc2_.getPhysicModel().addEventListener(§_-L3Q§.§_-kl§,this.§_-AL§);
         _loc2_.§_-vt§ = false;
         §§push(_loc2_);
         §§push(§§findproperty(§_-A1l§));
         var _temp_5:* = new <§_-de§>[new §_-de§(§_-q24§.BLIZZARD),new §_-de§(§_-q24§.§_-m1P§),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.8),new §_-de§(§_-q24§.WATERMELON,0.5),new §_-de§(§_-q24§.§_-F2c§,0.3),new §_-de§(§_-q24§.ANTITOXIN,0.05,1)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.BLIZZARD),new §_-de§(§_-q24§.§_-m1P§),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.8),new §_-de§(§_-q24§.WATERMELON,0.5),new §_-de§(§_-q24§.§_-F2c§,0.3),new §_-de§(§_-q24§.ANTITOXIN,0.05,1)]);
         return _loc2_;
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         if(§_-X1j§.§_-12n§.scene)
         {
            §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         }
         if(this.mainBoss != null)
         {
            this.mainBoss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-AL§);
            this.mainBoss = null;
         }
         for each(_loc1_ in this.§_-K1C§.getUnits())
         {
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-r1g§);
            _loc1_.removeEventListener(§_-L3Q§.§_-kl§,this.§_-i1M§);
         }
      }
      
      private function §_-AL§(param1:Event = null) : void
      {
         var e:Event = param1;
         this.mainBoss.disposed = false;
         this.mainBoss.x = this.§_-a7§(e != null);
         this.mainBoss.y = -10;
         this.mainBoss.setSpeedXY(0,10);
         §_-Zd§.once(this.mainBoss.getPhysicModel() as EventDispatcher,§_-42G§.§_-K2J§,function(param1:Event):void
         {
            ScreenShake.go(30,true,0.07);
            mainBoss.setSpeedXY(0,0);
         });
         this.mainBoss.rotateUntilStable(false);
         §_-X1j§.§_-12n§.scene.sceneCamera.moveToObject(this.mainBoss as §_-F3o§);
         if(e)
         {
            dispatchEvent(new §_-R1h§(§_-s1x§.PIRATE_REVENGE_DROWN_THREE_TIMES));
         }
      }
      
      private function §_-a7§(param1:Boolean = true) : int
      {
         var _loc2_:Point = §_-OP§.§_-pa§();
         while(!_loc2_)
         {
            _loc2_ = §_-OP§.§_-pa§(55,true,20,false);
         }
         if(param1)
         {
            §_-4B§.§_-O3§(_loc2_.x,_loc2_.y,0);
         }
         var _loc3_:Number = Number(_loc2_.x);
         Pool.putPoint(_loc2_);
         return _loc3_;
      }
   }
}


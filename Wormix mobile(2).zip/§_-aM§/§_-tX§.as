package §_-aM§
{
   import §_-12W§.*;
   import §_-43V§.Random;
   import §_-5Y§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-a3§;
   import §_-62§.§_-o6§;
   import §_-63M§.§_-F3f§;
   import §_-82a§.*;
   import §_-931§.§_-sz§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-fM§;
   import §_-C2t§.§_-92W§;
   import §_-C2t§.§_-i1V§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-T1o§.§_-L3M§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.*;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-G4§;
   import §_-dS§.§_-D3a§;
   import §_-f1G§.§_-kf§;
   import §_-fo§.§_-r5§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-y1s§.*;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.hurlant.util.§_-a2P§;
   import feathers.controls.Button;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.errors.IllegalOperationError;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.net.LocalConnection;
   import flash.system.Capabilities;
   import flash.text.TextFormatAlign;
   import flash.utils.IDataOutput;
   import flash.utils.setTimeout;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.structures.PositionStructure;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.MeteorStrike;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.§_-N1C§;
   import ru.pragmatix.wormix.weapons.ammo.BurningOil;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   use namespace gestouch_internal;
   
   public class §_-tX§ extends §_-P1N§
   {
      
      private static const §_-g1X§:§_-TA§ = new §_-TA§(3);
      
      private var bosses:Vector.<§_-01J§> = new Vector.<§_-01J§>();
      
      private var §_-82s§:uint;
      
      private var §_-NQ§:uint;
      
      private var map:§_-D3a§;
      
      public function §_-tX§(param1:Boolean = false)
      {
         super(param1);
      }
      
      public function setMap(param1:§_-D3a§) : void
      {
         this.map = param1;
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_ELDER_DEMONS"),[this.§_-LZ§(param2,param3),this.§_-LZ§(param2,param3),this.§_-LZ§(param2,param3)])];
         return new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_ELDER_DEMONS"),[this.§_-LZ§(param2,param3),this.§_-LZ§(param2,param3),this.§_-LZ§(param2,param3)])];
      }
      
      private function §_-LZ§(param1:uint, param2:uint) : UserProfile
      {
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:Number = NaN;
         var _loc6_:Number = NaN;
         var _loc8_:uint = 0;
         if(heroic)
         {
            _loc3_ = Number(uint(6 + 1.6 * param1));
            _loc4_ = 60 + 7 * param1 + 9 * param1 * param2;
            _loc5_ = _loc3_ * 0.75;
            _loc6_ = _loc3_ * 0.9;
         }
         else
         {
            _loc8_ = 5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4;
            _loc3_ = 6 + _loc8_ * 2;
            _loc4_ = _loc8_ * 24;
            _loc5_ = 3 + _loc8_ * 1.15;
            _loc6_ = 5 + _loc8_ * 1.44;
         }
         var _loc7_:uint = §_-S25§.§_-T2F§;
         return UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_DEMON"),_loc3_,§_-L1x§.§_-p21§,_loc4_,_loc5_,_loc6_,_loc7_);
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:uint = 0;
         while(_loc3_ < param1[0].getUnits().length)
         {
            _loc2_ = §_-01J§(param1[0].getUnits()[_loc3_]);
            _loc2_.aiMissFactor = 1;
            _loc2_.aiShotPower = 5;
            §§push(_loc2_);
            §§push(§§findproperty(§_-A1l§));
            var _temp_3:* = new <§_-de§>[new §_-de§(§_-q24§.§_-82U§),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.§_-xS§,0.3),new §_-de§(§_-q24§.§_-Qf§,0.4),new §_-de§(§_-q24§.§_-w1k§,0.7),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE)];
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-82U§),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.§_-xS§,0.3),new §_-de§(§_-q24§.§_-Qf§,0.4),new §_-de§(§_-q24§.§_-w1k§,0.7),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE)]);
            _loc2_.§_-q2T§();
            _loc2_.buffs.place(new §_-92W§());
            this.bosses[_loc3_] = _loc2_;
            _loc3_++;
         }
         super.initBeforeBattle(param1);
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         if(param1 == 1)
         {
            this.§_-82s§ = 0;
            this.§_-NQ§ = §_-X1j§.§_-12n§.scene.width;
         }
         super.§_-03f§(param1,param2);
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         var _loc2_:Array = null;
         var _loc3_:int = 0;
         var _loc4_:§_-F3o§ = null;
         var _loc5_:uint = 0;
         if(param1 == 1)
         {
            §_-TZ§.addListener(§_-X1j§.§_-12n§.scene as EventDispatcher,§_-L3Q§.DAMAGE,this.§_-Jc§,§_-4V§.§_-DA§);
         }
         if(!§_-X1j§.§_-12n§.gameMaster.§_-y2v§())
         {
            _loc2_ = this.§_-63s§();
            if(_loc2_.length >= 3)
            {
               dispatchEvent(new §_-R1h§(§_-s1x§.§_-F2h§));
            }
            _loc3_ = int(_loc2_.length);
            _loc4_ = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
            _loc5_ = 0;
            while(_loc5_ < _loc3_)
            {
               §_-Ia§.§_-33o§(5 + 40 * _loc5_,this.§_-w1g§,_loc2_[_loc5_].x,_loc2_[_loc5_].y,_loc5_ + 1 == _loc3_ ? _loc4_ : null);
               _loc5_++;
            }
         }
      }
      
      private function §_-Jc§(param1:Event) : void
      {
         var _loc2_:§_-01J§ = null;
         if(!param1.data.source.owner)
         {
            _loc2_ = param1.data.victim as §_-01J§;
            if(_loc2_.buffs.hasBuff(§_-i1V§.NAME))
            {
               return;
            }
            if(this.bosses.indexOf(_loc2_) != -1 && param1.data.source is Meteor)
            {
               dispatchEvent(new §_-R1h§(§_-s1x§.§_-NK§));
            }
         }
      }
      
      private function §_-w1g§(param1:int, param2:int, param3:§_-F3o§) : void
      {
         this.§_-da§(param1,param2);
         if(param3)
         {
            param3.disposed = true;
         }
      }
      
      private function §_-63s§() : Array
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:Array = null;
         var _loc4_:Vector.<§_-01J§> = null;
         var _loc5_:int = 0;
         var _loc6_:uint = 0;
         var _loc7_:int = 0;
         if(!gameMaster)
         {
            return [];
         }
         var _loc1_:uint = 0;
         for each(_loc2_ in this.bosses)
         {
            if(!_loc2_.disposed)
            {
               _loc1_++;
            }
         }
         _loc3_ = [];
         _loc4_ = gameMaster.§_-83I§(this.bosses[0]);
         _loc5_ = §_-g1X§.value - _loc1_ + 1;
         _loc6_ = 0;
         while(_loc6_ < _loc5_)
         {
            _loc7_ = randomSeed.§_-Fh§(1,3);
            if(Boolean(_loc7_ & 1) && _loc4_.length != 0)
            {
               _loc7_ = randomSeed.§_-Fh§(0,_loc4_.length - 1);
               _loc3_.push(Pool.getPoint(_loc4_[_loc7_].x,_loc4_[_loc7_].y));
               _loc4_.splice(_loc7_,1);
            }
            else
            {
               _loc7_ = randomSeed.§_-Fh§(this.§_-82s§,this.§_-NQ§);
               _loc3_.push(Pool.getPoint(_loc7_,Math.floor(§_-X1j§.§_-12n§.scene.width)));
            }
            _loc6_++;
         }
         return _loc3_;
      }
      
      private function §_-da§(param1:int, param2:int = 0) : void
      {
         var _loc4_:int = 0;
         var _loc3_:§_-C3e§ = §_-G1p§.§_-I4§(§_-q24§.METEOR).§_-wF§;
         _loc4_ = randomSeed.§_-Fh§(0,90);
         var _loc5_:Object = MeteorStrike.§_-E2D§(param1,param2,_loc4_);
         new Meteor(null,_loc3_,_loc5_.x,_loc5_.y,_loc5_.vx,_loc5_.vy);
         §_-X1j§.§_-12n§.scene.dispatchEventWith(§_-L3Q§.DAMAGE_TRIGGER,false,§_-N1C§.create(§_-q24§.METEOR,false,true));
      }
      
      override public function clear() : void
      {
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.DAMAGE,this.§_-Jc§);
         this.bosses = null;
         super.clear();
      }
   }
}


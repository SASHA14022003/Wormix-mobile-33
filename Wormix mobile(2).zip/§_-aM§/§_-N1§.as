package §_-aM§
{
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-31W§.*;
   import §_-52L§.*;
   import §_-5P§.§_-H1u§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-o6§;
   import §_-73I§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.*;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-Z1Y§;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-J31§.§_-R1h§;
   import §_-V1H§.§_-m1d§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-v2Q§;
   import §_-hv§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-p14§.§_-A3Y§;
   import §_-qH§.§_-S25§;
   import §_-u1T§.*;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-lp§;
   import §_-z1g§.§_-y1S§;
   import §_-z20§.§_-51i§;
   import §_-z20§.§_-V7§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-A3§;
   import com.hurlant.crypto.tls.§_-Zf§;
   import com.worlize.websocket.§_-x2j§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.GroupedList;
   import feathers.controls.Scroller;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.PopUpManager;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import org.gestouch.core.Touch;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.*;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.structures.*;
   import ru.pragmatix.wormix.messages.structures.BossWormStructure;
   import ru.pragmatix.wormix.messages.structures.ReconnectToSimpleBattleResultStructure;
   import ru.pragmatix.wormix.messages.structures.TurnStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.serialization.structures.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import ru.pragmatix.wormix.weapons.ammo.phase.PoisonPhase;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.extensions.ParticleAura;
   
   public class §_-N1§ extends §_-P1N§
   {
      
      public static const §_-80§:uint = 1;
      
      public static const §_-Gh§:uint = 2;
      
      private static const §_-f2g§:§_-TA§ = new §_-TA§(25);
      
      private static const §_-z1S§:§_-TA§ = new §_-TA§(5);
      
      private var bosses:Vector.<§_-01J§>;
      
      private var §_-S16§:ParticleAura;
      
      private var §_-D2y§:§_-01J§;
      
      public function §_-N1§(param1:Boolean = false)
      {
         super(param1);
      }
      
      private static function §_-px§(param1:§_-01J§) : uint
      {
         if(param1)
         {
            return MathUtil.§_-na§(§_-f2g§.value,param1.attributes.hp.§_-33H§());
         }
         return 0;
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         var _loc5_:Array = [this.§_-LZ§(§_-L1x§.§_-AU§,1.1,param2,param3),this.§_-LZ§(§_-L1x§.§_-I1h§,1,param2,param3),this.§_-LZ§(§_-L1x§.§_-l2G§,1,param2,param3)];
         _loc4_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_SOUL_1"),[_loc5_[0],_loc5_[1],_loc5_[2]]));
         return _loc4_;
      }
      
      private function §_-LZ§(param1:§_-L1x§, param2:Number, param3:uint, param4:uint) : UserProfile
      {
         var _loc5_:uint = 0;
         _loc5_ = uint(uint(param2 * (5 + 1.7 * param3)));
         var _loc6_:uint = -30 + 3 * _loc5_ + 5 * _loc5_ * param4;
         var _loc7_:uint = 0.6 * _loc5_;
         var _loc8_:uint = 0.73 * _loc5_;
         return UserProfile.custom(§_-s2a§.§_-K3t§("BOT_NAME_SOUL_1"),_loc5_,param1,_loc6_,_loc7_,_loc8_,§_-S25§.§_-c16§);
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc2_:Vector.<§_-01J§> = param1[0].getUnits();
         this.bosses = new Vector.<§_-01J§>(0);
         var _loc3_:uint = 0;
         while(_loc3_ < _loc2_.length)
         {
            this.bosses[_loc3_] = _loc2_[_loc3_];
            §§push(this.bosses[_loc3_]);
            §§push(§§findproperty(§_-A1l§));
            var _temp_2:* = new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.§_-d25§,0.3),new §_-de§(§_-q24§.CAT_BAZOOKA,1),new §_-de§(§_-q24§.MOLOTOV,0.4),new §_-de§(§_-q24§.CANNON,0.1)];
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,1),new §_-de§(§_-q24§.§_-d25§,0.3),new §_-de§(§_-q24§.CAT_BAZOOKA,1),new §_-de§(§_-q24§.MOLOTOV,0.4),new §_-de§(§_-q24§.CANNON,0.1)]);
            this.bosses[_loc3_].buffs.place(new §_-92W§());
            §_-Zd§.once(this.bosses[_loc3_] as §_-F3o§,§_-L3Q§.DISPOSED,this.§_-u29§);
            _loc3_++;
         }
         super.initBeforeBattle(param1);
      }
      
      private function §_-u29§(param1:starling.events.Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-Gh§));
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         super.§_-03f§(param1,param2);
         if(!gameMaster.§_-y2v§())
         {
            this.§_-81C§();
         }
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         if(Boolean(!gameMaster.§_-y2v§()) && Boolean(this.§_-D2y§) && !this.§_-D2y§.disposed)
         {
            dispatchEvent(new §_-R1h§(§_-80§));
            this.§_-G20§();
         }
      }
      
      private function §_-G20§() : void
      {
         var _loc1_:§_-01J§ = null;
         if(Boolean(this.§_-D2y§) && !this.§_-D2y§.disposed)
         {
            for each(_loc1_ in gameMaster.§_-b2W§(this.§_-D2y§))
            {
               if(Boolean(_loc1_) && !_loc1_.disposed)
               {
                  new HealBolt(this.§_-D2y§,this.§_-D2y§.x,this.§_-D2y§.y,_loc1_,§_-px§(_loc1_));
               }
            }
            new HealBolt(this.§_-D2y§,this.§_-D2y§.x,this.§_-D2y§.y,this.§_-D2y§,§_-px§(this.§_-D2y§));
         }
      }
      
      private function §_-81C§() : void
      {
         var _loc1_:§_-01J§ = this.§_-D2y§;
         this.§_-Wz§(this.§_-D2y§);
         this.§_-D2y§ = null;
         var _loc2_:Vector.<§_-01J§> = gameMaster.§_-b2W§(this.bosses[0],false,true);
         if(Boolean(_loc1_) && _loc2_.length > 1)
         {
            _loc2_.splice(_loc2_.indexOf(_loc1_),1);
         }
         if(_loc2_.length > 0)
         {
            this.§_-D2y§ = _loc2_[randomSeed.§_-Fh§(0,_loc2_.length - 1)];
            if(Boolean(this.§_-S16§) && Boolean(this.§_-S16§.particleSystem))
            {
               this.§_-S16§.unit = this.§_-D2y§;
               this.§_-S16§.particleSystem.start();
            }
            else
            {
               this.§_-E1i§();
            }
            this.§_-D2y§.buffs.§_-e1z§(§_-92W§.NAME);
            §_-TZ§.addListener(this.§_-D2y§ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Jc§);
            this.§_-D2y§.addEventListener(§_-L3Q§.DISPOSED,this.§_-Wo§);
         }
      }
      
      private function §_-Wo§(param1:starling.events.Event) : void
      {
         if(Boolean(this.§_-S16§) && Boolean(this.§_-S16§.particleSystem))
         {
            this.§_-S16§.particleSystem.stop(true);
         }
      }
      
      private function §_-Jc§(param1:starling.events.Event, param2:§_-v2Q§) : void
      {
         var _loc5_:§_-01J§ = null;
         var _loc6_:Vector.<§_-01J§> = null;
         var _loc3_:§_-01J§ = param2.source.owner;
         var _loc4_:§_-01J§ = param2.victim as §_-01J§;
         for each(_loc5_ in gameMaster.§_-b2W§(_loc4_,true,true))
         {
            if(_loc5_ == _loc3_)
            {
               return;
            }
         }
         if(!_loc3_ || _loc3_.disposed)
         {
            _loc6_ = gameMaster.§_-83I§(_loc4_);
            if(_loc6_.length > 0)
            {
               _loc3_ = _loc6_[0];
            }
         }
         if(Boolean(_loc3_) && !_loc3_.disposed)
         {
            new PoisonPhase(this.§_-D2y§,this.§_-D2y§.x,this.§_-D2y§.y,false,_loc3_,MathUtil.§_-na§(§_-z1S§.value,_loc3_.attributes.hp.§_-53§()),0);
         }
         this.§_-Wz§(this.§_-D2y§);
         this.§_-D2y§ = null;
      }
      
      private function §_-Wz§(param1:§_-01J§) : void
      {
         if(param1)
         {
            if(Boolean(this.§_-S16§) && Boolean(this.§_-S16§.particleSystem))
            {
               this.§_-S16§.particleSystem.stop(true);
            }
            param1.buffs.§_-e1z§(§_-92W§.NAME);
            param1.buffs.place(new §_-92W§());
            §_-TZ§.removeListener(param1 as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Jc§);
            param1.removeEventListener(§_-L3Q§.DISPOSED,this.§_-Wo§);
         }
      }
      
      private function §_-E1i§(param1:starling.events.Event = null) : void
      {
         var event:starling.events.Event = param1;
         Starling.current.removeEventListener(starling.events.Event.CONTEXT3D_CREATE,this.§_-E1i§);
         try
         {
            if(this.§_-S16§)
            {
               if(this.§_-D2y§)
               {
                  this.§_-Wz§(this.§_-D2y§);
               }
               this.§_-b1V§(this.§_-S16§);
            }
            this.§_-S16§ = new ParticleAura(Effects.AURA_SOUL,"spirit",this.§_-D2y§ as §_-F3o§,0,null,this.§_-81q§);
         }
         catch(e:Error)
         {
            Starling.current.addEventListener(starling.events.Event.CONTEXT3D_CREATE,§_-E1i§);
         }
      }
      
      private function §_-81q§(param1:ParticleAura) : void
      {
         param1.setPositionOffset(0,-this.bosses[0].height * 0.5);
         param1.particleSystem.alpha = 0.7;
      }
      
      private function §_-b1V§(param1:ParticleAura) : void
      {
         if(param1)
         {
            if(param1.particleSystem)
            {
               param1.particleSystem.stop(true);
            }
            param1.dispose();
            param1 = null;
         }
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         this.§_-b1V§(this.§_-S16§);
         for each(_loc1_ in this.bosses)
         {
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Jc§);
            _loc1_.removeEventListener(§_-L3Q§.DISPOSED,this.§_-Wo§);
            _loc1_.buffs.clearAll();
            _loc1_ = null;
         }
         this.§_-D2y§ = null;
         this.bosses = null;
      }
   }
}


package §_-aM§
{
   import §_-73d§.§_-g1J§;
   import §_-82a§.*;
   import §_-82l§.§_-A2Y§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-k1I§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-P2i§.§_-b7§;
   import §_-TF§.§_-y2n§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-e2r§.§_-636§;
   import §_-f1G§.*;
   import §_-fo§.*;
   import §_-gG§.§_-52P§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-u1P§.ShopResultEvent;
   import §_-u1T§.*;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderCore;
   import dragonBones.animation.WorldClock;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import flash.geom.Point;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.controller.mobile.*;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.particle.ParticleEffectType;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-r1R§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.Drill;
   import ru.pragmatix.wormix.weapons.§_-7o§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.interfaces.§_-P2v§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   
   use namespace gestouch_internal;
   
   public class §_-L3E§ extends §_-P1N§
   {
      
      private static const §_-23I§:§_-TA§ = new §_-TA§(50);
      
      private static const §_-A3K§:§_-TA§ = new §_-TA§(25);
      
      private static const §_-73w§:Number = 0.4;
      
      private static const §_-f1m§:int = 38;
      
      private static const §_-TM§:String = "Obelisk";
      
      private static const §_-i10§:String = "SwordJustice";
      
      private static const §_-K1f§:int = 54;
      
      private var boss:§_-01J§;
      
      private var §_-I1C§:§_-TA§ = new §_-TA§(0);
      
      private var §_-g1m§:§_-F3o§;
      
      private var §_-f3§:§_-di§;
      
      public function §_-L3E§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:§_-k1I§ = new §_-k1I§(13,1.3,0.9,param1);
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PALADIN_NAME),[UserProfile.custom(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PALADIN_NAME),_loc4_.level * 1.2,§_-L1x§.§_-So§,500 + 15 * _loc4_.§_-sL§ + 4 * _loc4_.§_-Z2r§,_loc4_.level * 1.05,_loc4_.level * 1.4,§_-S25§.BOSS_PALADIN,Artifacts.PALADIN_SWORD)])];
         return new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PALADIN_NAME),[UserProfile.custom(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_PALADIN_NAME),_loc4_.level * 1.2,§_-L1x§.§_-So§,500 + 15 * _loc4_.§_-sL§ + 4 * _loc4_.§_-Z2r§,_loc4_.level * 1.05,_loc4_.level * 1.4,§_-S25§.BOSS_PALADIN,Artifacts.PALADIN_SWORD)])];
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         this.boss = §_-01J§(param1[0].getUnits()[0]);
         this.boss.aiMissFactor = 1;
         this.boss.aiShotPower = 5;
         §§push(this.boss);
         §§push(§§findproperty(§_-A1l§));
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-w1k§,0.9),new §_-de§(§_-q24§.§_-9r§,0.1),new §_-de§(§_-q24§.§_-z12§,0.7),new §_-de§(§_-q24§.§_-ZW§,0.5),new §_-de§(§_-q24§.§_-m1P§,0.5)]);
         this.boss.addEventListener(§_-L3Q§.DISPOSED,this.§_-u29§);
         this.§_-I1C§.value = MathUtil.§_-na§(§_-A3K§.value,this.boss.record.stats.§_-g2I§.value);
         §_-OP§.§_-g1j§(this.boss);
         super.initBeforeBattle(param1);
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         if(currentUnit == this.boss)
         {
            this.§_-z2D§();
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var turnNumber:uint = param1;
         var currentUnit:§_-01J§ = param2;
         super.§_-03f§(turnNumber,currentUnit);
         if(currentUnit == this.boss)
         {
            this.§_-82F§();
            if(Boolean(this.§_-g1m§) && Boolean(!this.§_-g1m§.disposed) && !this.boss.disposed)
            {
               this.§_-p1j§();
               §_-Zd§.§_-33o§(§_-f1m§,function():void
               {
                  boss.attributes.hp.restore(§_-I1C§.value,§_-b21§.§_-h1U§,false,false);
               },true);
               this.§_-r1L§();
            }
         }
      }
      
      private function §_-p1j§() : void
      {
         Effects.createParticleEffect(ParticleEffectType.PALADIN_HEAL_TOP,§_-f1m§ / 30,this.boss.x,this.boss.y + Physics.UNIT_HALF_HEIGHT);
         Effects.createParticleEffect(ParticleEffectType.PALADIN_HEAL_BOTTOM,§_-f1m§ / 30,this.boss.x,this.boss.y + Physics.UNIT_HALF_HEIGHT);
      }
      
      private function §_-u29§(param1:Event) : void
      {
         var _loc2_:UserProfile = null;
         var _loc3_:Point = null;
         var _loc4_:§_-V23§ = null;
         this.§_-m27§();
         if(Boolean(this.§_-g1m§) && !this.§_-g1m§.disposed)
         {
            this.boss.§_-n2t§();
            _loc2_ = this.boss.record.§_-F1b§();
            _loc2_.stats.§_-g2I§.value = this.§_-I1C§.value * 2;
            _loc3_ = Pool.getPoint(this.§_-g1m§.x,this.§_-g1m§.y);
            §_-X1j§.§_-12n§.scene.sceneCamera.moveTo(_loc3_.x,_loc3_.y);
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_MEDIUM,_loc3_.x,_loc3_.y,40);
            _loc4_ = this.boss.squad;
            this.boss = §_-L1x§.create(_loc2_,_loc3_.x,_loc3_.y);
            _loc4_.§_-D3t§(this.boss);
            this.initBeforeBattle(new <§_-V23§>[_loc4_]);
            Pool.putPoint(_loc3_);
         }
      }
      
      private function §_-82F§() : void
      {
         var enemies:Vector.<§_-01J§> = null;
         var enemy:§_-01J§ = null;
         var selectedEnemy:§_-01J§ = null;
         enemies = gameMaster.§_-83I§(this.boss);
         for each(enemy in enemies)
         {
            if(!selectedEnemy || selectedEnemy.hp < enemy.hp)
            {
               selectedEnemy = enemy;
            }
         }
         if(selectedEnemy)
         {
            Effects.aura(selectedEnemy,§_-i10§,65,function():void
            {
               swordDamage(selectedEnemy);
               for each(enemy in enemies)
               {
                  if(!enemy.disposed && enemy != selectedEnemy && MathUtil.distance(selectedEnemy.x,selectedEnemy.y,enemy.x,enemy.y) <= 12)
                  {
                     swordDamage(enemy);
                  }
               }
            },true);
         }
      }
      
      private function swordDamage(param1:§_-01J§) : void
      {
         var _loc2_:int = 0;
         if(!param1.disposed)
         {
            _loc2_ = MathUtil.§_-na§(§_-23I§.value,param1.hp);
            §_-G4§.§_-Ee§(this.boss,param1.x,param1.y,param1 as §_-F3o§,_loc2_,0,0,false,true,DamageType.SHOCK);
            if(!param1.disposed)
            {
               param1.setSpeedXY(0,-5);
            }
         }
      }
      
      private function §_-z2D§() : void
      {
         var position:Point = §_-OP§.§_-pa§(80);
         if(position)
         {
            this.§_-g1m§ = new §_-F3o§();
            this.§_-g1m§.physParams.addForce(Force.GRAVITY);
            this.§_-g1m§.physParams.collidesWith = PhysParams.COLLIDES_WITH_GROUND;
            this.§_-g1m§.physParams.collideType = CollideType.OTHER;
            this.§_-g1m§.clip = this.§_-P§(§_-K1t§.§_-XN§);
            this.§_-g1m§.x = position.x;
            this.§_-g1m§.y = position.y;
            Pool.putPoint(position);
            this.§_-g1m§.§_-Nt§ = true;
            this.§_-g1m§.addEventListener(§_-L3Q§.§_-Qw§,this.§_-v2k§);
            §_-TZ§.addListener(this.§_-g1m§,§_-L3Q§.DISPOSED,this.§_-62i§,§_-4V§.§_-DA§);
            §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-L2X§(this.§_-g1m§);
            §_-Zd§.§_-33o§(§_-K1f§,function():void
            {
               WorldClock.clock.remove(§_-f3§);
               §_-g1m§.§_-22o§();
            });
         }
      }
      
      private function §_-62i§(param1:Event) : void
      {
         var obeliskFading:§_-F3o§ = null;
         var e:Event = param1;
         §_-TZ§.removeListener(this.§_-g1m§,§_-L3Q§.DISPOSED,this.§_-62i§);
         if(this.§_-g1m§)
         {
            this.§_-g1m§.clip = null;
         }
         obeliskFading = new §_-F3o§();
         obeliskFading.clip = this.§_-f3§.display;
         this.§_-f3§.playAnimation(§_-K1t§.§_-s1g§);
         WorldClock.clock.add(this.§_-f3§);
         obeliskFading.x = this.§_-g1m§.x;
         obeliskFading.y = this.§_-g1m§.y;
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-L2X§(obeliskFading);
         §_-Zd§.§_-33o§(60,function():void
         {
            obeliskFading.clip = null;
            obeliskFading.disposed = true;
            §_-c2Q§();
         });
      }
      
      private function §_-P§(param1:String) : DisplayObject
      {
         this.§_-c2Q§();
         this.§_-f3§ = §_-K1t§.buildArmature(§_-TM§);
         this.§_-f3§.display.scale = §_-73w§;
         WorldClock.clock.add(this.§_-f3§);
         this.§_-f3§.playAnimation(param1);
         return this.§_-f3§.display;
      }
      
      private function §_-c2Q§() : void
      {
         if(this.§_-f3§)
         {
            WorldClock.clock.remove(this.§_-f3§);
            this.§_-f3§.display.removeFromParent();
            this.§_-f3§.dispose();
            this.§_-f3§ = null;
         }
      }
      
      private function §_-v2k§(param1:Event) : void
      {
         param1.data.victim.disposed = true;
      }
      
      private function §_-r1L§() : void
      {
         if(Boolean(this.§_-g1m§) && !this.§_-g1m§.disposed)
         {
            if(this.§_-g1m§.hasEventListener(§_-L3Q§.§_-Qw§))
            {
               this.§_-g1m§.removeEventListener(§_-L3Q§.§_-Qw§,this.§_-v2k§);
            }
            §_-TZ§.removeListener(this.§_-g1m§,§_-L3Q§.DISPOSED,this.§_-62i§);
            this.§_-g1m§.clip = null;
            this.§_-c2Q§();
            this.§_-g1m§.disposed = true;
            this.§_-g1m§ = null;
         }
      }
      
      private function §_-m27§() : void
      {
         if(this.boss)
         {
            this.boss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-u29§);
         }
      }
      
      override public function clear() : void
      {
         this.§_-c2Q§();
         this.§_-r1L§();
         this.§_-m27§();
         this.boss = null;
      }
   }
}


package §_-aM§
{
   import §_-12W§.§_-221§;
   import §_-12W§.§_-53t§;
   import §_-12W§.§_-61z§;
   import §_-12W§.§_-HK§;
   import §_-12W§.§_-QN§;
   import §_-12W§.§_-XO§;
   import §_-12W§.§_-l23§;
   import §_-12W§.§_-v1b§;
   import §_-12W§.§_-x20§;
   import §_-12a§.*;
   import §_-21A§.*;
   import §_-22z§.§_-f1b§;
   import §_-43V§.§_-A4§;
   import §_-5P§.*;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.§_-63i§;
   import §_-C2t§.*;
   import §_-GQ§.§_-31v§;
   import §_-J31§.§_-R1h§;
   import §_-RE§.§_-52p§;
   import §_-TF§.§_-q1j§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Ia§;
   import §_-zI§.§_-X1q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.crypto.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.util.§_-F2L§;
   import config.§_-vR§;
   import feathers.controls.Label;
   import feathers.core.ToggleGroup;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   
   public class §_-x2d§ extends §_-P1N§
   {
      
      private const §_-63n§:uint = 0;
      
      private const §_-P7§:uint = 1;
      
      private const §_-qz§:uint = 2;
      
      private const §_-9p§:Number = 1.7;
      
      private const §_-33P§:Number = 1.9;
      
      private const §_-nB§:Number = 1.9;
      
      private const §_-bP§:Number = 0.17;
      
      private const §_-UC§:Number = 2.1;
      
      private var bosses:Vector.<§_-01J§>;
      
      private var §_-G1z§:uint;
      
      private var §_-g1Q§:Boolean;
      
      private var §_-93B§:Boolean;
      
      public function §_-x2d§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc8_:Number = NaN;
         this.§_-g1Q§ = false;
         this.§_-93B§ = false;
         this.§_-G1z§ = 0;
         var _loc4_:uint = heroic ? uint(1.9 + 0.4 * param2) : uint(5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4);
         var _loc5_:uint = heroic ? uint(4 * param2 + 12 * param2 * param3) : 0;
         var _loc6_:Number = heroic ? 1 + 0.35 * param3 : 1;
         var _loc7_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         _loc8_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _loc9_:Array = [UserProfile.§_-bR§(_loc8_,§_-s2a§.§_-K3t§("BOT_NAME_YAKUZA_RABBIT"),4 + _loc4_ * 1.8,§_-L1x§.§_-I1h§,190 + _loc4_ * 30 + _loc5_,(4 + _loc4_ * 1.5) * _loc6_,(4 + _loc4_ * 1.6) * _loc6_,§_-S25§.BOSS_YAKUZA_2),UserProfile.§_-bR§(_loc8_,§_-s2a§.§_-K3t§("BOT_NAME_YAKUZA_CAT"),4 + _loc4_ * 1.8,§_-L1x§.§_-r2y§,140 + _loc4_ * 27 + _loc5_,(2 + _loc4_ * 0.7) * _loc6_,(10 + _loc4_ * 2.4) * _loc6_,§_-S25§.BOSS_YAKUZA_1),UserProfile.§_-bR§(_loc8_,§_-s2a§.§_-K3t§("BOT_NAME_YAKUZA_BOXER"),4 + _loc4_ * 1.8,§_-L1x§.§_-AU§,210 + _loc4_ * 33 + _loc5_,(10 + _loc4_ * 2.2) * _loc6_,(2 + _loc4_ * 0.4) * _loc6_,§_-S25§.§_-A1V§)];
         if(heroic)
         {
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("BOSS_YAKUZA_NAME"),[_loc9_[0],_loc9_[1],_loc9_[2]]));
         }
         else
         {
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_YAKUZA_RABBIT"),[_loc9_[0]]));
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_YAKUZA_CAT"),[_loc9_[1]]));
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_YAKUZA_BOXER"),[_loc9_[2]]));
         }
         return _loc7_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(heroic)
         {
            _loc2_ = param1[0].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[0]);
            _loc2_.push(param1[2].getUnits()[0]);
         }
         this.bosses = new Vector.<§_-01J§>(0);
         this.bosses[this.§_-63n§] = §_-01J§(_loc2_[0]);
         this.bosses[this.§_-63n§].aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.MOLOTOV,0.7),new §_-de§(§_-q24§.§_-w1k§,0.8),new §_-de§(§_-q24§.§_-xS§,0.4),new §_-de§(§_-q24§.AK_47,0.5),new §_-de§(§_-q24§.§_-m1P§)]);
         this.bosses[this.§_-P7§] = §_-01J§(_loc2_[1]);
         this.bosses[this.§_-P7§].aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,1),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7),new §_-de§(§_-q24§.§_-w1k§,0.8),new §_-de§(§_-q24§.§_-h2N§)]);
         this.bosses[this.§_-qz§] = §_-01J§(_loc2_[2]);
         this.bosses[this.§_-qz§].aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-Qf§,1),new §_-de§(§_-q24§.§_-w1k§,0.8),new §_-de§(§_-q24§.§_-w1s§,0.6),new §_-de§(§_-q24§.§_-ZW§),new §_-de§(§_-q24§.CANNON,0.3)]);
         for each(_loc3_ in this.bosses)
         {
            _loc3_.buffs.place(new §_-92W§());
            _loc3_.addEventListener(§_-L3Q§.DISPOSED,this.§_-224§);
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:Vector.<§_-V23§> = null;
         var _loc4_:§_-V23§ = null;
         var _loc5_:§_-01J§ = null;
         var _loc6_:§_-01J§ = null;
         var _loc7_:Number = NaN;
         super.§_-03f§(param1,param2);
         if(heroic && param1 == 1)
         {
            _loc3_ = new Vector.<§_-V23§>(0);
            for each(_loc4_ in §_-X1j§.§_-12n§.gameMaster.§_-12G§())
            {
               if(_loc4_.isAi() && _loc4_ != this.bosses[this.§_-63n§].squad)
               {
                  _loc3_.push(_loc4_);
               }
            }
            for each(_loc4_ in _loc3_)
            {
               for each(_loc5_ in _loc4_.getUnits())
               {
                  this.bosses.push(_loc5_);
               }
            }
         }
         if(this.§_-g1Q§)
         {
            for each(_loc6_ in this.bosses)
            {
               if(param2 == _loc6_ && !_loc6_.disposed)
               {
                  new HealBolt(_loc6_,_loc6_.x,_loc6_.y,_loc6_,_loc6_.record.getLevel() * this.§_-nB§);
                  break;
               }
            }
         }
         if(this.§_-93B§ && !this.bosses[this.§_-P7§].disposed && param2 == this.bosses[this.§_-P7§])
         {
            _loc7_ = this.bosses[this.§_-P7§].record.getLevel() * this.§_-bP§;
            this.§_-L2y§(§_-s2a§.§_-K3t§(§_-s2a§.BONUS_ATTACK),_loc7_,this.bosses[this.§_-P7§],Effects.TEXT_COLOR_RED);
            this.bosses[this.§_-P7§].attributes.attack.§_-22b§(this.bosses[this.§_-P7§].attributes.attack.value + _loc7_);
         }
      }
      
      private function §_-224§(param1:Event) : void
      {
         var _loc2_:uint = 0;
         var _loc3_:§_-01J§ = §_-01J§(param1.currentTarget);
         var _loc4_:uint = 0;
         while(_loc4_ <= 2)
         {
            if(_loc3_ == this.bosses[_loc4_])
            {
               _loc2_ = _loc4_;
               break;
            }
            _loc4_++;
         }
         ++this.§_-G1z§;
         if(this.§_-G1z§ == 1)
         {
            this.§_-PI§(_loc2_);
         }
         else if(this.§_-G1z§ >= 2)
         {
            this.§_-PI§(_loc2_);
            this.§_-k1C§();
         }
      }
      
      private function §_-PI§(param1:uint) : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         if(param1 == this.§_-qz§)
         {
            dispatchEvent(new §_-R1h§(§_-s1x§.YAKUZA_KILL_STEEL_LAST));
         }
         dispatchEvent(new §_-R1h§(§_-s1x§.YAKUZA_KILL_TWO_IN_TURN));
         var _loc5_:uint = param1;
         switch(_loc5_)
         {
            case this.§_-63n§:
         }
         this.§_-g1Q§ = true;
      }
      
      private function §_-k1C§() : void
      {
         var liveBoss:uint = 0;
         var unit:§_-01J§ = null;
         var regHP:int = 0;
         var i:int = 0;
         while(i <= 2)
         {
            if(!this.bosses[i].disposed)
            {
               liveBoss = uint(i);
               break;
            }
            i++;
         }
         var _loc2_:uint = liveBoss;
         switch(_loc2_)
         {
            case this.§_-63n§:
         }
         §_-01J§(this.bosses[this.§_-63n§]).buffs.place(new §_-L3H§(§_-01J§(this.bosses[this.§_-63n§]).record.getLevel() * this.§_-UC§));
      }
      
      private function §_-L2y§(param1:String, param2:int, param3:§_-01J§, param4:String) : void
      {
         Effects.floatingText(§_-F1P§.format(param1,{"value":param2}),Effects.ATTACK_BONUS_COLOR,param3.x + param3.width * 0.5,param3.y + param3.height * 0.5,20,BitmapFonts.AD_LIB);
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         for each(_loc1_ in this.bosses)
         {
            _loc1_.removeEventListener(§_-L3Q§.DISPOSED,this.§_-224§);
         }
         this.bosses = null;
      }
   }
}


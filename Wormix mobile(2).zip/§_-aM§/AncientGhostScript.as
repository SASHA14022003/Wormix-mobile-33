package §_-aM§
{
   import §_-02q§.§_-4s§;
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-22z§.*;
   import §_-31Y§.§_-D3B§;
   import §_-62§.*;
   import §_-63U§.§_-21K§;
   import §_-92a§.§_-Y2Y§;
   import §_-A1K§.§_-TA§;
   import §_-C2t§.§_-92W§;
   import §_-DJ§.§_-J2l§;
   import §_-F2Q§.GestureEvent;
   import §_-H2g§.§_-F0§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-TF§.§_-P19§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-d26§.*;
   import §_-eW§.*;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-p24§.*;
   import §_-qH§.§_-S25§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-C32§;
   import com.greensock.TweenLite;
   import com.greensock.loading.*;
   import com.hurlant.math.*;
   import com.hurlant.util.der.§_-p1B§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.data.VectorCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class AncientGhostScript extends §_-P1N§ implements §_-F0§
   {
      
      private static const §_-n1j§:uint = 20;
      
      private const §_-Tj§:uint = 39;
      
      private const DAMAGE_RADIUS:uint = 35;
      
      private const EXPLOSION_RADIUS:uint = 15;
      
      private var boss:§_-01J§;
      
      private var §_-f2t§:Array = [];
      
      private var clouds:Array = [];
      
      private var §_-01v§:Vector.<§_-21K§> = new Vector.<§_-21K§>(0);
      
      private var §_-AY§:§_-C3e§;
      
      private var §_-i1h§:§_-C3e§;
      
      private var §_-w2X§:§_-01J§;
      
      private var §_-k2p§:uint;
      
      public function AncientGhostScript(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc7_:uint = 0;
         var _loc8_:Number = NaN;
         var _loc4_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         var _loc5_:uint = 210 + 36 * param2;
         var _loc6_:Number = heroic ? 1 + 0.15 * (param3 - 1) : 1;
         _loc7_ = 13 + 2 * param2;
         _loc8_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _loc9_:Array = [UserProfile.§_-bR§(_loc8_,§_-s2a§.§_-K3t§("BOT_NAME_GHOST_MAIN"),_loc7_ * 0.75,§_-L1x§.§_-l2G§,_loc5_ + 650,_loc7_ * 0.86 * _loc6_,_loc7_ * 0.7 * _loc6_,§_-S25§.BOSS_GHOST),UserProfile.§_-bR§(_loc8_,§_-s2a§.§_-K3t§("BOT_NAME_GHOST_ACOLYTE"),_loc7_ * 0.7,heroic ? §_-L1x§.§_-AU§ : §_-L1x§.§_-R2b§(),_loc5_ + 450,_loc7_ * 0.64 * _loc6_,_loc7_ * 0.1 * _loc6_,§_-S25§.WIZARD),UserProfile.§_-bR§(_loc8_,§_-s2a§.§_-K3t§("BOT_NAME_GHOST_ACOLYTE"),_loc7_ * 0.7,heroic ? §_-L1x§.§_-r2y§ : §_-L1x§.§_-R2b§(),_loc5_ + 450,_loc7_ * 0.64 * _loc6_,_loc7_ * 0.1 * _loc6_,§_-S25§.WIZARD)];
         if(heroic)
         {
            _loc4_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_GHOST_MAIN"),[_loc9_[0],_loc9_[1],_loc9_[2]]));
         }
         else
         {
            _loc4_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_GHOST_MAIN"),[_loc9_[0]]));
            _loc4_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_GHOST_ACOLYTE"),[_loc9_[1],_loc9_[2]]));
         }
         this.§_-k2p§ = heroic ? uint(param3 * 0.5) : 1;
         return _loc4_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(heroic)
         {
            _loc2_ = param1[0].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[1]);
         }
         this.boss = _loc2_[0];
         this.boss.aiMissFactor = 1;
         this.boss.aiShotPower = 5;
         this.boss.aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-h2N§),new §_-de§(§_-q24§.BLIZZARD,0.8),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.9),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.ANTITOXIN,0.1,1)]);
         this.boss.buffs.place(new §_-92W§());
         this.boss.clip.alpha = 0.65;
         this.boss.addEventListener(§_-L3Q§.§_-Qw§,this.onDamaged);
         var _loc3_:uint = 0;
         while(_loc3_ < _loc2_.length - 1)
         {
            this.§_-f2t§[_loc3_] = _loc2_[_loc3_ + 1];
            this.§_-f2t§[_loc3_].aiMissFactor = 1;
            this.§_-f2t§[_loc3_].aiShotPower = 5;
            this.§_-f2t§[_loc3_].aiArsenal = new §_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-Qf§,1),new §_-de§(§_-q24§.SNIPER_RIFLE,0.9),new §_-de§(§_-q24§.BLIZZARD,0.5),new §_-de§(§_-q24§.§_-w1k§)]);
            this.§_-f2t§[_loc3_].buffs.place(new §_-92W§());
            this.§_-f2t§[_loc3_].addEventListener(§_-L3Q§.§_-Qw§,this.onDamaged);
            _loc3_++;
         }
         this.§_-AY§ = new §_-C3e§();
         this.§_-AY§.damageRadius = new §_-TA§(this.DAMAGE_RADIUS);
         this.§_-AY§.explosionRadius = new §_-TA§(this.EXPLOSION_RADIUS);
         this.§_-AY§.damage = new §_-TA§(this.§_-Tj§);
         this.§_-i1h§ = this.§_-AY§.clone();
         this.§_-i1h§.damage = new §_-TA§(this.§_-Tj§ * 2);
         super.initBeforeBattle(param1);
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:§_-di§ = null;
         var _loc4_:CloudData = null;
         var _loc5_:* = 0;
         var _loc6_:Vector.<§_-01J§> = null;
         var _loc7_:§_-01J§ = null;
         var _loc8_:§_-F3o§ = null;
         var _loc9_:Number = NaN;
         var _loc10_:Number = NaN;
         var _loc11_:uint = 0;
         var _loc12_:Vector.<§_-01J§> = null;
         var _loc13_:§_-01J§ = null;
         super.§_-03f§(param1,param2);
         if(param1 == 1)
         {
            this.§_-w2X§ = this.boss;
         }
         if(param2.squad.isAi())
         {
            this.§_-Km§();
            if(this.clouds.length == 1)
            {
               this.clouds[0].animation.gotoAndPlay("vanishing");
               _loc4_ = this.clouds[0].userData as CloudData;
               if(_loc4_)
               {
                  _loc4_.vanishing = true;
                  _loc6_ = §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss);
                  if((Boolean(_loc6_)) && _loc6_.length > 0)
                  {
                     _loc7_ = _loc6_[0];
                     _loc8_ = _loc4_.gameObject;
                     _loc9_ = Number(Math.atan2(_loc7_.y - _loc8_.y,_loc7_.x - _loc8_.x));
                     _loc10_ = MathUtil.PI_ONE_180;
                     _loc5_ = -5;
                     while(_loc5_ < 5)
                     {
                        LightningBullet.create(this.boss,_loc8_,this.§_-i1h§,_loc9_ + §_-X1j§.randomSeed.§_-Fh§(-20,20) * _loc10_,50,20,30,true);
                        _loc5_++;
                     }
                  }
               }
               if(WorldClock.clock.contains(this))
               {
                  WorldClock.clock.remove(this);
               }
            }
            else
            {
               for each(_loc3_ in this.clouds)
               {
                  _loc3_.playAnimation("vanishing");
                  _loc4_ = _loc3_.userData as CloudData;
                  if(_loc4_)
                  {
                     _loc4_.vanishing = true;
                     _loc5_ = -5;
                     while(_loc5_ < 5)
                     {
                        LightningBullet.create(this.boss,_loc4_.gameObject,this.§_-AY§,MathUtil.PI_HALF + 0.1 * _loc5_,10,10,10);
                        _loc5_++;
                     }
                  }
               }
            }
            §_-Ia§.§_-33o§(20,this.§_-m1i§);
         }
         else if(!param2.squad.isAi() && this.§_-w2X§.squad.isAi())
         {
            this.§_-z11§(param2);
            _loc11_ = 0;
            _loc12_ = §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss);
            _loc5_ = int(_loc12_.length);
            while(_loc5_--)
            {
               _loc13_ = _loc12_[_loc5_];
               if(_loc13_ != param2)
               {
                  this.§_-z11§(_loc13_);
                  if(++_loc11_ >= this.§_-k2p§)
                  {
                     break;
                  }
               }
            }
            this.§_-E2v§();
         }
         if(!this.boss.disposed && param2 == this.boss)
         {
            §_-OP§.§_-y1x§(this.boss,this.§_-f2t§);
         }
         this.§_-w2X§ = param2;
      }
      
      private function §_-z11§(param1:§_-01J§) : void
      {
         var _loc2_:§_-di§ = Effects.createStormCloud();
         var _loc3_:§_-F3o§ = new §_-F3o§();
         _loc3_.clip = _loc2_.display;
         _loc3_.x = param1.x;
         _loc3_.y = param1.y - 50;
         _loc3_.stable = true;
         WorldClock.clock.add(_loc2_);
         var _loc4_:CloudData = new CloudData();
         _loc4_.gameObject = _loc3_;
         _loc4_.appeared = false;
         _loc4_.vanishing = false;
         _loc2_.userData = _loc4_;
         _loc2_.playAnimation("appearance",0,-1,1);
         §_-X1j§.§_-12n§.scene.addGameObject(_loc3_);
         this.clouds.push(_loc2_);
         if(!WorldClock.clock.contains(this))
         {
            WorldClock.clock.add(this);
         }
      }
      
      public function advanceTime(param1:Number) : void
      {
         var _loc2_:§_-di§ = null;
         var _loc3_:CloudData = null;
         for each(_loc2_ in this.clouds)
         {
            _loc3_ = _loc2_.userData as CloudData;
            if(_loc3_)
            {
               if(!_loc3_.appeared && _loc2_.animation.isCompleted)
               {
                  _loc2_.playAnimation("dormancy",0,-1,0);
                  _loc3_.appeared = true;
               }
            }
         }
      }
      
      private function §_-m1i§() : void
      {
         var _loc1_:§_-di§ = null;
         for each(_loc1_ in this.clouds)
         {
            if(_loc1_.userData is CloudData)
            {
               (_loc1_.userData as CloudData).gameObject.disposed = true;
            }
            if(WorldClock.clock.contains(_loc1_))
            {
               WorldClock.clock.remove(_loc1_);
            }
            _loc1_.dispose();
         }
         this.clouds = [];
         if(WorldClock.clock.contains(this))
         {
            WorldClock.clock.remove(this);
         }
      }
      
      private function §_-Km§() : void
      {
         var _loc1_:§_-21K§ = null;
         for each(_loc1_ in this.§_-01v§)
         {
            _loc1_.disposed = true;
         }
         this.§_-01v§.length = 0;
      }
      
      private function §_-E2v§() : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc4_:Point = null;
         var _loc1_:Vector.<§_-01J§> = §_-X1j§.§_-12n§.gameMaster.§_-83I§(this.boss);
         var _loc2_:Number = §_-X1j§.§_-12n§.scene.sceneH;
         for each(_loc3_ in _loc1_)
         {
            if(!_loc3_.stable)
            {
               _loc3_.setSpeedXY(0,0);
               _loc4_ = HitTest.castRay(_loc3_.x,_loc3_.y,0,_loc2_);
               if(_loc4_)
               {
                  _loc3_.y = _loc4_.y - Physics.UNIT_HALF_HEIGHT;
                  Pool.putPoint(_loc4_);
               }
            }
            this.§_-01v§.push(new §_-21K§(_loc3_.x,_loc3_.y,§_-n1j§,_loc3_ as §_-F3o§,this.§_-t13§,false));
         }
      }
      
      private function onDamaged(param1:starling.events.Event, param2:§_-v2Q§) : void
      {
         dispatchEventWith(param1.type,false,param2);
      }
      
      private function §_-t13§(param1:§_-21K§) : void
      {
         this.§_-01v§.splice(this.§_-01v§.indexOf(param1),1);
         dispatchEvent(new §_-R1h§(§_-s1x§.ANCIENT_GHOST_DONT_MOVE));
      }
      
      override public function clear() : void
      {
         super.clear();
         this.§_-m1i§();
         this.§_-Km§();
         this.boss.removeEventListener(§_-L3Q§.§_-Qw§,this.onDamaged);
         this.boss = null;
         var _loc1_:* = int(this.§_-f2t§.length);
         while(_loc1_--)
         {
            this.§_-f2t§[_loc1_].removeEventListener(§_-L3Q§.§_-Qw§,this.onDamaged);
         }
         this.§_-f2t§.length = 0;
      }
   }
}

import ru.pragmatix.wormix.objects.§_-F3o§;

class CloudData
{
   
   public var gameObject:§_-F3o§;
   
   public var appeared:Boolean;
   
   public var vanishing:Boolean;
   
   public function CloudData()
   {
      super();
   }
}

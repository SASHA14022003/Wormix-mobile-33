package §_-aM§
{
   import §_-134§.*;
   import §_-31W§.*;
   import §_-62§.*;
   import §_-73I§.§_-Y1l§;
   import §_-82l§.§_-A2Y§;
   import §_-91A§.§_-N2O§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.*;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-Z1Y§;
   import §_-CR§.§_-72p§;
   import §_-D3A§.§_-TZ§;
   import §_-G16§.*;
   import §_-H16§.*;
   import §_-J31§.§_-R1h§;
   import §_-L2F§.§_-D2p§;
   import §_-S§.*;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-Z1w§.§_-s1x§;
   import §_-ZP§.§_-H1H§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.§_-L1x§;
   import §_-j1w§.§_-lD§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-m2s§.§_-R11§;
   import §_-nZ§.§_-6z§;
   import §_-o14§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-zI§.§_-8D§;
   import feathers.controls.Button;
   import feathers.controls.GroupedList;
   import feathers.controls.Scroller;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import feathers.utils.textures.TextureCache;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.social.model.Gender;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.server.AddToGroupResult;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.messages.structures.UnitStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.structures.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.KeyboardEvent;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class IllusionistScript extends §_-P1N§
   {
      
      private static const §_-Rw§:uint = 3;
      
      private static const §_-D2k§:uint = 15;
      
      private static const §_-J1T§:uint = 30;
      
      private var mainBoss:§_-01J§;
      
      private var clonePacks:Array = [];
      
      private var bosses:Vector.<§_-01J§>;
      
      public function IllusionistScript(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:§_-k1I§ = new §_-k1I§(13,1.2,0.9,param1);
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_ILLUSIONIST1"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_ILLUSIONIST1"),_loc4_.level,§_-L1x§.§_-l2G§,15 * _loc4_.§_-sL§ + 4 * _loc4_.§_-Z2r§ + 600,_loc4_.level * 0.9,_loc4_.level * 1.1,§_-S25§.§_-I36§)])];
         return new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_ILLUSIONIST1"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_ILLUSIONIST1"),_loc4_.level,§_-L1x§.§_-l2G§,15 * _loc4_.§_-sL§ + 4 * _loc4_.§_-Z2r§ + 600,_loc4_.level * 0.9,_loc4_.level * 1.1,§_-S25§.§_-I36§)])];
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         this.mainBoss = §_-01J§(param1[0].getUnits()[0]);
         §§push(this.mainBoss);
         §§push(§§findproperty(§_-A1l§));
         var _temp_5:* = new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.WATERMELON,0.5),new §_-de§(§_-q24§.CANNON,0.3),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.§_-F2c§,0.5)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.WATERMELON,0.5),new §_-de§(§_-q24§.CANNON,0.3),new §_-de§(§_-q24§.MOLOTOV,0.3),new §_-de§(§_-q24§.§_-F2c§,0.5)]);
         this.mainBoss.buffs.place(new §_-92W§());
         this.mainBoss.addEventListener(§_-L3Q§.§_-kl§,this.§_-AL§);
         this.mainBoss.addEventListener(§_-L3Q§.DISPOSED,this.§_-u29§);
         this.mainBoss.aiMissFactor = 1;
         this.mainBoss.aiShotPower = 5;
         this.mainBoss.§_-92S§ = false;
         super.initBeforeBattle(param1);
      }
      
      private function §_-u29§(param1:starling.events.Event) : void
      {
         this.§_-bL§();
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         this.§_-bL§();
         if(!§_-X1j§.§_-12n§.gameMaster.§_-y2v§() && !this.mainBoss.disposed)
         {
            §_-X1j§.§_-12n§.scene.sceneCamera.moveToObject(this.mainBoss as §_-F3o§,true);
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var boss:§_-8K§ = null;
         var clonePack:ClonePack = null;
         var allies:Vector.<§_-01J§> = null;
         var index:uint = 0;
         var unstableObject:§_-F3o§ = null;
         var clonesCount:uint = 0;
         var i:uint = 0;
         var clone:§_-N2O§ = null;
         var turnNumber:uint = param1;
         var currentUnit:§_-01J§ = param2;
         super.§_-03f§(turnNumber,currentUnit);
         if(turnNumber == 1 || heroic)
         {
            this.bosses = new <§_-01J§>[this.mainBoss];
            allies = gameMaster.§_-b2W§(this.mainBoss);
            for each(boss in allies)
            {
               this.bosses.push(boss);
            }
         }
         if(!gameMaster.§_-y2v§() && turnNumber != 1)
         {
            index = 0;
            for each(boss in this.bosses)
            {
               if(!boss.disposed)
               {
                  boss.graphics.§_-C2W§();
                  boss.graphics.lock();
                  boss.buffs.§_-e1z§(§_-8u§.NAME);
                  boss.buffs.§_-e1z§(§_-Z2z§.NAME);
                  boss.buffs.§_-e1z§(§_-M2S§.NAME);
                  Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_SMALL,boss.x,boss.y,30);
                  §_-h2B§.play(§_-d27§.§_-h1O§);
                  clonesCount = 1;
                  if(boss.hp < 400)
                  {
                     clonesCount++;
                  }
                  if(boss.hp < 150)
                  {
                     clonesCount++;
                  }
                  clonePack = new ClonePack();
                  clonePack.clones = new Vector.<§_-01J§>(0);
                  clonePack.boss = boss;
                  i = 0;
                  while(i < clonesCount)
                  {
                     clonePack.clones.push(this.§_-F1b§(boss));
                     i++;
                  }
                  this.clonePacks[index] = clonePack;
                  §_-X1j§.§_-12n§.scene.bringToBottom(boss);
                  index++;
                  if(clonesCount >= §_-Rw§)
                  {
                     dispatchEvent(new §_-R1h§(§_-s1x§.§_-930§));
                  }
               }
            }
            unstableObject = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
            for each(clonePack in this.clonePacks)
            {
               if(!clonePack.boss.disposed)
               {
                  for each(clone in clonePack.clones)
                  {
                     clone.§_-b2T§();
                  }
                  if(clonePack.boss is §_-N2O§)
                  {
                     (clonePack.boss as §_-N2O§).§_-b2T§();
                  }
               }
            }
            §_-Ia§.§_-33o§(2,function():void
            {
               var _loc1_:§_-01J§ = null;
               for each(clonePack in clonePacks)
               {
                  if(clonePack.boss.disposed)
                  {
                     return;
                  }
                  for each(_loc1_ in clonePack.clones)
                  {
                     teleportClone(_loc1_,clonePack.boss);
                     §_-X1j§.§_-12n§.scene.bringToBottom(_loc1_ as §_-F3o§);
                  }
                  teleportBoss(clonePack.boss);
               }
            });
            §_-Ia§.§_-33o§(4,function():void
            {
               unstableObject.disposed = true;
            });
         }
         else
         {
            this.§_-bL§();
         }
      }
      
      private function teleportBoss(param1:§_-01J§) : void
      {
         var _loc2_:Point = §_-OP§.§_-pa§();
         var _loc3_:PhaseAmmo = new PhaseAmmo(param1,param1.x,param1.y,true,param1 as §_-F3o§,11289911,80);
         _loc3_.§_-C2P§ = false;
         §_-4v§(param1);
         Physics.teleportUnit(param1 as §_-F3o§,_loc2_.x,_loc2_.y);
         Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_SMALL,_loc2_.x,_loc2_.y,30);
         param1.setSpeedXY(0,1);
         param1.graphics.unlock();
         param1.§_-l2A§(true);
         Pool.putPoint(_loc2_);
      }
      
      private function teleportClone(param1:§_-01J§, param2:§_-01J§) : void
      {
         if(!param1 || param1.disposed)
         {
            return;
         }
         var _loc3_:Point = §_-OP§.§_-pa§();
         var _loc4_:PhaseAmmo = new PhaseAmmo(param1,param1.x,param1.y,true,param1 as §_-F3o§,11289911,80);
         _loc4_.§_-C2P§ = false;
         §_-4v§(param2);
         Physics.teleportUnit(param1 as §_-F3o§,_loc3_.x,_loc3_.y);
         Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_SMALL,_loc3_.x,_loc3_.y,30);
         §_-X1j§.§_-12n§.scene.bringToBottom(param1 as §_-F3o§);
         param1.§_-l2A§(true);
         Pool.putPoint(_loc3_);
      }
      
      private function §_-F1b§(param1:§_-01J§) : §_-01J§
      {
         var raceArmor:int;
         var raceAttack:int;
         var clone:§_-01J§ = null;
         var unit:§_-01J§ = param1;
         clone = §_-L1x§.create(unit.record.§_-F1b§(),unit.x,unit.y);
         clone.§_-o1z§(false);
         raceArmor = clone.record.§_-P2e§().§_-V1v§().§_-F1e§(§_-x2M§.ARMOR);
         raceAttack = clone.record.§_-P2e§().§_-V1v§().§_-F1e§(§_-x2M§.ATTACK);
         clone.attributes.hp.change(-(clone.attributes.hp.value - unit.hp));
         clone.§_-92S§ = false;
         if(unit.direction == §_-8K§.RIGHT)
         {
            clone.turnRight();
         }
         clone.§_-f15§();
         §_-TZ§.addListener(clone as EventDispatcher,§_-L3Q§.§_-Qw§,function(param1:starling.events.Event):void
         {
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_DEMONIC,clone.x,clone.y,§_-J1T§ * 2);
            §_-G4§.§_-Ee§(clone,clone.x,clone.y,null,§_-D2k§,§_-J1T§ + 10,§_-J1T§,false);
            clone.disposed = true;
         });
         clone.setSpeedXY(0,1);
         clone.graphics.§_-C2W§();
         clone.graphics.§_-x29§();
         unit.buffs.§_-K1S§(clone);
         unit.squad.§_-D3t§(clone);
         return clone;
      }
      
      private function §_-AL§(param1:starling.events.Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-s1x§.ILLUSIONIST_DROWN_FIVE_TIMES));
      }
      
      private function §_-bL§(param1:starling.events.Event = null) : void
      {
         var _loc2_:ClonePack = null;
         var _loc3_:§_-01J§ = null;
         for each(_loc2_ in this.clonePacks)
         {
            for each(_loc3_ in _loc2_.clones)
            {
               this.§_-ec§(_loc3_);
            }
            _loc2_.boss = null;
         }
         this.clonePacks.splice(0,this.clonePacks.length);
      }
      
      private function §_-ec§(param1:§_-01J§) : void
      {
         if(Boolean(param1) && !param1.disposed)
         {
            dispatchEvent(new §_-R1h§(§_-s1x§.§_-5w§));
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_DEMONIC,param1.x,param1.y,§_-J1T§ * 2,§_-d27§.§_-J1x§);
            param1.disposed = true;
         }
      }
      
      override public function clear() : void
      {
         super.clear();
         this.mainBoss.removeEventListener(§_-L3Q§.§_-kl§,this.§_-AL§);
         this.mainBoss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-u29§);
         this.mainBoss = null;
         this.clonePacks = [];
         this.bosses = null;
      }
   }
}

import ru.pragmatix.wormix.objects.§_-01J§;

class ClonePack
{
   
   public var clones:Vector.<§_-01J§>;
   
   public var boss:§_-01J§;
   
   public function ClonePack()
   {
      super();
   }
}

package §_-aM§
{
   import §_-12W§.*;
   import §_-31N§.§_-42G§;
   import §_-31W§.§_-g16§;
   import §_-31Y§.§_-D3B§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-O2H§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-C2t§.§_-L3H§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.*;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.*;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-U1i§.§_-81M§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-a19§.§_-g1S§;
   import §_-dS§.§_-D3a§;
   import §_-gG§.§_-8u§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.*;
   import §_-z1g§.§_-M2v§;
   import §_-z1g§.§_-lp§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderStatus;
   import com.hurlant.util.der.*;
   import feathers.controls.List;
   import feathers.core.ITextRenderer;
   import flash.events.Event;
   import flash.events.ProgressEvent;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.ZombieGrave;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.type.RopeHook;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-W1U§ extends §_-P1N§
   {
      
      public static const §_-Q2R§:uint = 1;
      
      private const §_-O2R§:§_-TA§ = new §_-TA§(1300);
      
      private const §_-HF§:§_-TA§ = new §_-TA§(70);
      
      private const §_-p2i§:§_-TA§ = new §_-TA§(32);
      
      private var §_-5S§:Vector.<§_-7u§> = new Vector.<§_-7u§>();
      
      private var §_-xt§:Vector.<RopeHook> = new Vector.<RopeHook>();
      
      private var §_-E3f§:§_-C3e§;
      
      private var §_-I2l§:§_-TA§;
      
      private var bosses:Vector.<§_-01J§> = new Vector.<§_-01J§>();
      
      public function §_-W1U§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc7_:Number = NaN;
         var _loc4_:uint = uint(Application.userProfile.getLevel());
         var _loc5_:uint = Application.userProfile.§_-hz§();
         var _loc6_:uint = heroic ? uint(uint(5 + 1.5 * param2)) : uint(5 + 1.1 * param2 + 0.9 * _loc4_);
         _loc7_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         this.§_-E3f§ = new §_-C3e§();
         this.§_-E3f§.ammoClassName = "MainElectricHarpoonTip";
         this.§_-E3f§.damage = new §_-TA§(0);
         this.§_-E3f§.damageRadius = new §_-TA§(Physics.UNIT_HALF_HEIGHT * 2);
         this.§_-E3f§.explosionRadius = new §_-TA§(Physics.UNIT_HALF_HEIGHT + 4);
         this.§_-E3f§.pushForce = new §_-TA§(0);
         this.§_-I2l§ = new §_-TA§(_loc6_ * 2);
         var _loc8_:UserProfile = UserProfile.§_-bR§(_loc7_,§_-s2a§.§_-K3t§("BOT_NAME_MANIAC_1"),_loc6_ * 0.75,§_-L1x§.§_-p21§,heroic ? uint(110 + 6 * param2 + 7 * param2 * param3) : uint(170 + 7 * _loc5_ + 4 * _loc4_),_loc6_ * 0.85,_loc6_ * 0.7,§_-S25§.§_-g1I§);
         var _loc9_:UserProfile = UserProfile.§_-bR§(_loc7_,§_-s2a§.§_-K3t§("BOT_NAME_MANIAC_2"),_loc6_ * 0.75,§_-L1x§.§_-p21§,heroic ? uint(80 + 5 * param2 + 8 * param2 * param3) : uint(135 + 7 * _loc5_ + 4 * _loc4_),_loc6_ * 0.75,_loc6_ * 0.8,§_-S25§.§_-g1I§);
         var _loc10_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         if(heroic)
         {
            _loc10_.push(new §_-81l§(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_MANIACS_NAME),[_loc8_,_loc9_]));
         }
         else
         {
            _loc10_.push(new §_-81l§(§_-s2a§.§_-K3t§("BOT_NAME_MANIAC_1"),[_loc8_]));
            _loc10_.push(new §_-81l§(§_-s2a§.§_-K3t§("BOT_NAME_MANIAC_2"),[_loc9_]));
         }
         return _loc10_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc4_:§_-01J§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(heroic)
         {
            _loc2_ = param1[0].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[0]);
         }
         var _loc3_:uint = 0;
         while(_loc3_ < 2)
         {
            _loc4_ = _loc2_[_loc3_];
            §§push(_loc4_);
            §§push(§§findproperty(§_-A1l§));
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.SNIPER_RIFLE,0.9),new §_-de§(§_-q24§.§_-w1k§,0.6),new §_-de§(§_-q24§.§_-K3z§,0.6),new §_-de§(§_-q24§.RIFLE,0.5),new §_-de§(§_-q24§.SHOTGUN,0.5),new §_-de§(§_-q24§.AK_47,0.4)]);
            if(!heroic)
            {
               _loc4_.buffs.place(new §_-Ap§());
            }
            this.bosses[_loc3_] = _loc4_;
            this.§_-5S§.push(new §_-7u§());
            _loc3_++;
         }
         super.initBeforeBattle(param1);
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:Number = NaN;
         var _loc4_:Number = NaN;
         var _loc5_:§_-01J§ = null;
         var _loc6_:§_-01J§ = null;
         var _loc7_:§_-01J§ = null;
         var _loc8_:§_-01J§ = null;
         var _loc9_:Number = NaN;
         var _loc10_:Point = null;
         var _loc11_:RopeHook = null;
         super.§_-03f§(param1,param2);
         if(this.§_-S1k§(param2))
         {
            _loc3_ = Number(Number.MAX_VALUE);
            for each(_loc7_ in param2.squad.getUnits())
            {
               if(this.§_-S1k§(_loc7_))
               {
                  for each(_loc8_ in gameMaster.§_-83I§(_loc7_))
                  {
                     if(_loc8_ != _loc6_)
                     {
                        _loc9_ = MathUtil.distance(_loc7_.x,_loc7_.y,_loc8_.x,_loc8_.y);
                        if(_loc9_ > this.§_-HF§.value && _loc9_ < this.§_-O2R§.value && _loc9_ < _loc3_)
                        {
                           _loc4_ = MathUtil.§_-02X§(_loc7_.x,_loc7_.y,_loc8_.x,_loc8_.y);
                           _loc10_ = MathUtil.§_-UW§(32,_loc4_);
                           if(!§_-X1j§.§_-12n§.scene.hitTestPoint(_loc7_.x + _loc10_.x,_loc7_.y + _loc10_.y))
                           {
                              _loc3_ = _loc9_;
                              _loc5_ = _loc8_;
                           }
                           Pool.putPoint(_loc10_);
                        }
                     }
                  }
                  if(_loc5_)
                  {
                     _loc4_ = MathUtil.§_-02X§(_loc7_.x,_loc7_.y,_loc5_.x,_loc5_.y);
                     if(_loc7_.x > _loc5_.x)
                     {
                        param2.turnLeft();
                     }
                     else
                     {
                        param2.turnRight();
                     }
                     _loc11_ = new RopeHook(_loc7_,this.§_-E3f§,_loc4_,30,this.§_-O2R§.value);
                     _loc11_.addEventListener(§_-L3Q§.DISPOSED,this.§_-Ie§);
                     _loc11_.addEventListener(§_-R1h§.NAME,this.§_-d1Y§);
                     param2.stable = false;
                     this.§_-xt§.push(_loc11_);
                     _loc6_ = _loc5_;
                     _loc5_ = null;
                     _loc3_ = Number(Number.MAX_VALUE);
                  }
               }
            }
         }
      }
      
      private function §_-S1k§(param1:§_-01J§) : §_-01J§
      {
         return (param1 == this.bosses[0] || param1 == this.bosses[1]) && !param1.disposed ? param1 : null;
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         var _loc2_:uint = 0;
         if(gameMaster.§_-y2v§())
         {
            this.§_-g2Y§();
            _loc2_ = 0;
            while(_loc2_ < this.bosses.length)
            {
               this.§_-5S§[_loc2_].value = false;
               _loc2_++;
            }
         }
      }
      
      public function §_-Ie§(param1:starling.events.Event) : void
      {
         var _loc2_:RopeHook = RopeHook(param1.currentTarget);
         _loc2_.removeEventListener(§_-L3Q§.DISPOSED,this.§_-Ie§);
         _loc2_.removeEventListener(§_-R1h§.NAME,this.§_-d1Y§);
         this.§_-xt§.splice(this.§_-xt§.indexOf(_loc2_),1);
         this.§_-g2Y§();
      }
      
      private function §_-g2Y§() : void
      {
         var _loc1_:uint = 0;
         var _loc2_:§_-7u§ = null;
         var _loc3_:§_-01J§ = null;
         var _loc4_:§_-01J§ = null;
         if(this.§_-S1k§(currentUnit))
         {
            _loc1_ = 0;
            while(_loc1_ < this.bosses.length)
            {
               _loc2_ = this.§_-5S§[_loc1_];
               _loc3_ = this.bosses[_loc1_];
               if(!_loc3_.disposed && !_loc2_.value)
               {
                  for each(_loc4_ in Physics.getUnitsInCircle(_loc3_.x,_loc3_.y,this.§_-HF§.value))
                  {
                     if(_loc4_ != _loc3_ && _loc4_.squad.getTeamId() != _loc3_.squad.getTeamId())
                     {
                        §_-OP§.§_-fF§(_loc3_.x,_loc3_.y,_loc4_,this.§_-I2l§.value,this.§_-p2i§.value);
                        _loc2_.value = true;
                     }
                  }
                  if(_loc2_.value)
                  {
                     Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_SMALL,currentUnit.x,currentUnit.y,this.§_-HF§.value);
                  }
               }
               _loc1_++;
            }
         }
      }
      
      private function §_-d1Y§(param1:§_-R1h§) : void
      {
         dispatchEvent(new §_-R1h§(§_-Q2R§));
      }
      
      public function getManiacs() : Vector.<§_-01J§>
      {
         return this.bosses;
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         var _loc2_:RopeHook = null;
         var _loc3_:* = 0;
         for each(_loc1_ in this.bosses)
         {
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         }
         this.bosses.length = 0;
         this.§_-5S§ = null;
         if(this.§_-xt§)
         {
            _loc3_ = int(this.§_-xt§.length);
            while(_loc3_--)
            {
               _loc2_ = this.§_-xt§[_loc3_];
               if(_loc2_.hasEventListener(§_-L3Q§.DISPOSED))
               {
                  _loc2_.removeEventListener(§_-L3Q§.DISPOSED,this.§_-Ie§);
               }
               if(_loc2_.hasEventListener(§_-R1h§.NAME))
               {
                  _loc2_.removeEventListener(§_-R1h§.NAME,this.§_-d1Y§);
               }
               this.§_-xt§[_loc3_] = null;
            }
            this.§_-xt§ = null;
         }
      }
   }
}


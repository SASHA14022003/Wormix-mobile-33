package §_-aM§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-63M§.§_-F3f§;
   import §_-9e§.§_-73e§;
   import §_-A2U§.§_-A23§;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-1Y§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-T2h§.§_-43C§;
   import §_-T2h§.§_-C1R§;
   import §_-Tm§.§_-RF§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.§_-N3§;
   import §_-Z1K§.§_-q24§;
   import §_-d26§.§_-d1H§;
   import §_-hO§.§_-03k§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-nZ§.§_-6z§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sQ§.§_-V1n§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-M2v§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-A1s§;
   import config.§_-B1K§;
   import dragonBones.animation.WorldClock;
   import feathers.core.PopUpManager;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.response.treasury.DonateClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.RepeatBossBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-P1N§ extends EventDispatcher
   {
      
      protected var resources:§_-F3f§;
      
      protected var currentUnit:§_-01J§;
      
      protected var heroic:Boolean;
      
      public function §_-P1N§(param1:Boolean = false)
      {
         super();
         this.heroic = param1;
      }
      
      public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         return null;
      }
      
      public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc2_:§_-V23§ = null;
         var _loc3_:§_-01J§ = null;
         for each(_loc2_ in param1)
         {
            for each(_loc3_ in _loc2_.getUnits())
            {
               _loc3_.aiMissFactor = 1;
               _loc3_.aiShotPower = 5;
               _loc3_.§_-vt§ = false;
               if(this.heroic)
               {
                  if(!_loc3_.aiArsenal)
                  {
                     _loc3_.aiArsenal = new §_-A1l§();
                  }
                  _loc3_.aiArsenal.§_-t1j§(new §_-de§(§_-q24§.ANTITOXIN,0.3,10));
                  if(_loc3_.buffs.hasBuff(§_-Ap§.NAME))
                  {
                     _loc3_.buffs.§_-e1z§(§_-Ap§.NAME);
                  }
                  if(!_loc3_.buffs.hasBuff(§_-92W§.NAME))
                  {
                     _loc3_.buffs.place(new §_-92W§());
                  }
               }
            }
         }
      }
      
      public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         this.currentUnit = param2;
      }
      
      public function §_-K2o§(param1:uint) : void
      {
      }
      
      public function §_-fE§(param1:uint, param2:§_-01J§) : void
      {
      }
      
      public function clear() : void
      {
      }
      
      protected function get gameMaster() : §_-eX§
      {
         return §_-X1j§.§_-12n§.gameMaster;
      }
      
      protected function get randomSeed() : §_-V1n§
      {
         return §_-X1j§.randomSeed;
      }
      
      public function §_-739§() : §_-F3f§
      {
         return this.resources;
      }
      
      public function §_-H1J§() : §_-73e§
      {
         return §_-73e§.§_-1y§();
      }
      
      protected function §_-4v§(param1:§_-01J§) : void
      {
         param1.§_-92S§ = false;
         param1.addEventListener(§_-L3Q§.§_-a1V§,this.§_-I2t§);
      }
      
      private function §_-I2t§(param1:Event) : void
      {
         param1.currentTarget.removeEventListener(§_-L3Q§.§_-a1V§,this.§_-I2t§);
         var _loc2_:§_-01J§ = param1.currentTarget as §_-01J§;
         if(Boolean(_loc2_) && !_loc2_.disposed)
         {
            _loc2_.§_-92S§ = true;
         }
      }
   }
}


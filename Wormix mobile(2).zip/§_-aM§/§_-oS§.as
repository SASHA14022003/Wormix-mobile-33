package §_-aM§
{
   import §_-31W§.*;
   import §_-62§.*;
   import §_-63U§.§_-NV§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B1y§.§_-ts§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-C2t§.§_-G2m§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H3§.*;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-N8§.§_-2C§;
   import §_-P1B§.§_-b21§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-w1D§;
   import §_-f1G§.*;
   import §_-g2r§.§_-03A§;
   import §_-hO§.§_-v24§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j1w§.§_-lD§;
   import §_-j2R§.§_-73G§;
   import §_-jF§.*;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-m1g§.§_-K2W§;
   import §_-n1w§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-t1R§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-82X§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.util.§_-a2P§;
   import feathers.controls.ImageLoader;
   import feathers.controls.Label;
   import feathers.controls.ScrollContainer;
   import feathers.controls.ScrollPolicy;
   import feathers.core.ToggleGroup;
   import feathers.data.VectorCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.RelativePosition;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.net.LocalConnection;
   import flash.system.Capabilities;
   import flash.utils.*;
   import org.gestouch.core.*;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.extensions.ParticleAura;
   import starling.text.TextField;
   import starling.text.TextFormat;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   
   public class §_-oS§ extends §_-P1N§
   {
      
      public static const §_-631§:uint = 1;
      
      private const §_-l1x§:§_-TA§ = new §_-TA§(4);
      
      private var boss:§_-01J§;
      
      private var §_-IJ§:Vector.<§_-NV§> = new Vector.<§_-NV§>();
      
      private var bonusAttack:§_-TA§;
      
      private var §_-o2T§:Boolean = true;
      
      private var §_-c2e§:uint;
      
      public function §_-oS§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc4_:uint = uint(uint(5 + 1.2 * param2));
         this.bonusAttack = new §_-TA§(_loc4_ * 0.6);
         var _loc5_:int = 130 + 4 * _loc4_ + 7 * _loc4_ * param3;
         var _temp_1:* = new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("BOT_NAME_FARMER"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_FARMER"),_loc4_,§_-L1x§.§_-AU§,_loc5_,_loc4_ * 4,_loc4_ * 1.2,§_-S25§.FARMER)])];
         return new <§_-81l§>[new §_-81l§(§_-s2a§.§_-K3t§("BOT_NAME_FARMER"),[UserProfile.§_-bR§(§_-N1V§.§_-I39§.§_-X1P§().§_-z1N§(),§_-s2a§.§_-K3t§("BOT_NAME_FARMER"),_loc4_,§_-L1x§.§_-AU§,_loc5_,_loc4_ * 4,_loc4_ * 1.2,§_-S25§.FARMER)])];
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         super.initBeforeBattle(param1);
         this.boss = §_-01J§(param1[0].getUnits()[0]);
         this.boss.aiMissFactor = 1;
         this.boss.aiShotPower = 5;
         §§push(this.boss);
         §§push(§§findproperty(§_-A1l§));
         var _temp_3:* = new <§_-de§>[new §_-de§(§_-q24§.§_-82U§),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE),new §_-de§(§_-q24§.§_-K3z§),new §_-de§(§_-q24§.MORTAR,0.7),new §_-de§(§_-q24§.SHOTGUN),new §_-de§(§_-q24§.MINIGUN,0.7),new §_-de§(§_-q24§.§_-w1k§,0.5)];
         §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-82U§),new §_-de§(§_-q24§.BAZOOKA),new §_-de§(§_-q24§.RIFLE),new §_-de§(§_-q24§.§_-K3z§),new §_-de§(§_-q24§.MORTAR,0.7),new §_-de§(§_-q24§.SHOTGUN),new §_-de§(§_-q24§.MINIGUN,0.7),new §_-de§(§_-q24§.§_-w1k§,0.5)]);
         §_-TZ§.addListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         this.boss.addEventListener(§_-L3Q§.DISPOSED,this.§_-u29§);
      }
      
      override public function §_-K2o§(param1:uint) : void
      {
         if(currentUnit == this.boss)
         {
            this.§_-o2T§ = true;
            this.§_-N2b§();
         }
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:§_-01J§ = null;
         super.§_-03f§(param1,param2);
         if(heroic && param1 == 1)
         {
            this.§_-c2e§ = int(0.5 * this.boss.attributes.armor.value);
            this.§_-39§(this.§_-c2e§);
         }
         if(Boolean(!§_-X1j§.§_-12n§.gameMaster.§_-y2v§() && param2 && !param2.disposed && this.boss) && Boolean(!this.boss.disposed) && this.§_-o2T§)
         {
            for each(_loc3_ in gameMaster.§_-83I§(this.boss))
            {
               _loc3_.buffs.§_-e1z§(§_-G2m§.NAME);
            }
         }
      }
      
      override public function §_-fE§(param1:uint, param2:§_-01J§) : void
      {
         var _loc3_:§_-F3o§ = null;
         super.§_-fE§(param1,param2);
         if(Boolean(!§_-X1j§.§_-12n§.gameMaster.§_-y2v§() && param2 && !param2.disposed && this.boss) && Boolean(!this.boss.disposed) && this.§_-o2T§)
         {
            this.§_-o2T§ = false;
            _loc3_ = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
            §_-OP§.§_-cn§(this.§_-IJ§,110,50,false,§_-bs§.§_-d1Z§(this.§_-u2a§,this,[this.§_-l1x§.value - 1,_loc3_],true));
         }
      }
      
      private function §_-u2a§(param1:Point, param2:int, param3:§_-F3o§) : void
      {
         var _loc4_:§_-NV§ = new §_-NV§(param1);
         _loc4_.addEventListener(§_-v24§.NAME,this.§_-x2G§);
         this.§_-IJ§[this.§_-IJ§.length] = _loc4_;
         Pool.putPoint(param1);
         dispatchEvent(new §_-R1h§(§_-631§));
         if(param2 == 0)
         {
            param3.disposed = true;
         }
         else
         {
            §_-OP§.§_-cn§(this.§_-IJ§,110,50,false,§_-bs§.§_-d1Z§(this.§_-u2a§,this,[--param2,param3],true));
         }
      }
      
      private function §_-x2G§(param1:§_-v24§) : void
      {
         var _loc3_:§_-73G§ = null;
         var _loc4_:uint = 0;
         var _loc2_:§_-01J§ = param1.§_-VC§;
         if(!_loc2_.disposed)
         {
            if(!_loc2_.squad.isAi())
            {
               new ParticleAura(Effects.AURA_RAGE,"ParticleTexture",_loc2_ as §_-F3o§,80);
               Effects.floatingText(§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.BONUS_ATTACK),{"value":this.bonusAttack.value}),Effects.ATTACK_BONUS_COLOR,_loc2_.x + _loc2_.width * 0.5,_loc2_.y + _loc2_.height * 0.5,20,BitmapFonts.AD_LIB);
               _loc3_ = _loc2_.buffs.getBuff(§_-G2m§.NAME);
               _loc4_ = uint(this.bonusAttack.value);
               if(_loc3_ != null)
               {
                  _loc4_ += _loc3_.getValue();
                  _loc2_.buffs.§_-e1z§(§_-G2m§.NAME);
               }
               _loc2_.buffs.place(new §_-G2m§(_loc4_));
            }
            else
            {
               _loc2_.attributes.hp.restore(uint.MAX_VALUE,§_-b21§.§_-uy§);
            }
         }
         dispatchEvent(param1);
         this.§_-mJ§(§_-NV§(param1.target));
      }
      
      private function §_-N2b§() : void
      {
         var _loc1_:§_-NV§ = null;
         for each(_loc1_ in this.§_-IJ§)
         {
            if(!_loc1_.disposed)
            {
               _loc1_.disposed = true;
               this.§_-mJ§(_loc1_);
            }
         }
         this.§_-IJ§.length = 0;
      }
      
      private function §_-mJ§(param1:§_-NV§) : void
      {
         param1.removeEventListener(§_-v24§.NAME,this.§_-x2G§);
      }
      
      private function §_-u29§(param1:Event) : void
      {
         this.§_-39§(-this.§_-c2e§);
      }
      
      private function §_-39§(param1:int) : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:int = 0;
         if(!gameMaster)
         {
            return;
         }
         for each(_loc2_ in gameMaster.§_-b2W§(this.boss))
         {
            _loc3_ = param1 < 0 ? int(Math.max(param1,-_loc2_.attributes.armor.value)) : param1;
            _loc2_.attributes.armor.§_-Y2z§(_loc3_);
         }
      }
      
      override public function clear() : void
      {
         this.§_-N2b§();
         §_-TZ§.removeListener(this.boss as EventDispatcher,§_-L3Q§.§_-Qw§,§_-OP§.§_-ST§);
         this.boss.removeEventListener(§_-L3Q§.DISPOSED,this.§_-u29§);
         this.boss = null;
      }
   }
}


package §_-aM§
{
   import §_-21p§.§_-4w§;
   import §_-2k§.§_-51r§;
   import §_-62§.*;
   import §_-91B§.§_-z2l§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.*;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-b2K§;
   import §_-P1z§.*;
   import §_-X14§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-Zi§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-gG§.§_-Z2z§;
   import §_-hv§.*;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-h1b§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Ia§;
   import §_-z20§.§_-Tn§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.LoaderMax;
   import com.greensock.plugins.*;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.TabBar;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Rectangle;
   import flash.utils.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.client.BuyUnlockMission;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.CatPhysicModel;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.MolotovProjectile;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-3B§ extends §_-P1N§
   {
      
      private var §_-11u§:int = 0;
      
      private var bosses:Array = [];
      
      public function §_-3B§(param1:Boolean = false)
      {
         super(param1);
      }
      
      override public function §_-q2I§(param1:Vector.<§_-V23§>, param2:uint, param3:uint) : Vector.<§_-81l§>
      {
         var _loc6_:Number = NaN;
         var _loc4_:uint = heroic ? uint(2.2 + 1.2 * param2) : uint(5 + (Application.userProfile.§_-hz§() + Application.userProfile.getLevel()) / 4);
         var _loc5_:uint = heroic ? uint(60 + 7 * param2 + 9 * param2 * param3) : uint(_loc4_ * 39);
         _loc6_ = §_-N1V§.§_-I39§.§_-X1P§().§_-z1N§();
         var _loc7_:Vector.<§_-81l§> = new Vector.<§_-81l§>();
         var _loc8_:Array = [UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_VIKING1"),_loc4_ * 2,§_-L1x§.§_-l2G§,125 + _loc5_,_loc4_ * 1.2,10 + _loc4_ * 2.7,§_-S25§.BOSS_VIKING),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_VIKING2"),_loc4_ * 2,§_-L1x§.§_-I1h§,74 + _loc5_,5 + _loc4_ * 1.9,5 + _loc4_ * 1.9,§_-S25§.BOSS_VIKING),UserProfile.§_-bR§(_loc6_,§_-s2a§.§_-K3t§("BOT_NAME_VIKING3"),_loc4_ * 2,§_-L1x§.§_-AU§,230 + _loc5_,10 + _loc4_ * 2.4,_loc4_ * 1.4,§_-S25§.BOSS_VIKING)];
         if(heroic)
         {
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_VIKING1"),[_loc8_[0],_loc8_[1],_loc8_[2]]));
         }
         else
         {
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_VIKING1"),[_loc8_[0]]));
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_VIKING2"),[_loc8_[1]]));
            _loc7_.push(new §_-81l§(§_-s2a§.§_-K3t§("TEAM_NAME_VIKING3"),[_loc8_[2]]));
         }
         return _loc7_;
      }
      
      override public function initBeforeBattle(param1:Vector.<§_-V23§>) : void
      {
         var _loc4_:§_-01J§ = null;
         var _loc2_:Vector.<§_-01J§> = new Vector.<§_-01J§>();
         if(heroic)
         {
            _loc2_ = param1[0].getUnits();
         }
         else
         {
            _loc2_.push(param1[0].getUnits()[0]);
            _loc2_.push(param1[1].getUnits()[0]);
            _loc2_.push(param1[2].getUnits()[0]);
         }
         this.bosses = [];
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_.length)
         {
            _loc4_ = _loc2_[_loc3_];
            _loc4_.aiMissFactor = 1;
            _loc4_.aiShotPower = 5;
            this.bosses.push(_loc4_);
            §§push(_loc4_);
            §§push(§§findproperty(§_-A1l§));
            var _temp_3:* = new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.MOLOTOV,0.7),new §_-de§(§_-q24§.§_-xS§,0.7),new §_-de§(§_-q24§.RIFLE_UPG_1),new §_-de§(§_-q24§.SNIPER_RIFLE),new §_-de§(§_-q24§.§_-Qf§)];
            §§pop().aiArsenal = new §§pop().§_-A1l§(new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§),new §_-de§(§_-q24§.§_-w1k§),new §_-de§(§_-q24§.CROSSBOW),new §_-de§(§_-q24§.§_-z12§),new §_-de§(§_-q24§.MOLOTOV,0.7),new §_-de§(§_-q24§.§_-xS§,0.7),new §_-de§(§_-q24§.RIFLE_UPG_1),new §_-de§(§_-q24§.SNIPER_RIFLE),new §_-de§(§_-q24§.§_-Qf§)]);
            _loc4_.addEventListener(§_-L3Q§.§_-kl§,this.§_-AL§);
            §_-TZ§.addListener(_loc4_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Jc§);
            §_-TZ§.addListener(_loc4_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-v19§,§_-4V§.§_-CO§);
            _loc3_++;
         }
         super.initBeforeBattle(param1);
      }
      
      override public function §_-03f§(param1:uint, param2:§_-01J§) : void
      {
         if(this.§_-11u§ > -100)
         {
            this.§_-11u§ -= 2;
         }
      }
      
      override public function §_-H1J§() : §_-73e§
      {
         var _loc1_:§_-73e§ = super.§_-H1J§();
         _loc1_.backpackEnabled = true;
         _loc1_.timer = new §_-8O§(40,4,4,5,5,30);
         return _loc1_;
      }
      
      private function §_-AL§(param1:Event) : void
      {
         dispatchEvent(new §_-R1h§(§_-s1x§.VIKINGS_DROWN_ALL));
      }
      
      private function §_-Jc§(param1:Event) : void
      {
         §_-OP§.§_-ST§(param1,param1.data as §_-v2Q§);
      }
      
      private function §_-v19§(param1:Event) : void
      {
         dispatchEvent(param1);
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-01J§ = null;
         super.clear();
         for each(_loc1_ in this.bosses)
         {
            _loc1_.removeEventListener(§_-L3Q§.§_-kl§,this.§_-AL§);
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Jc§);
            §_-TZ§.removeListener(_loc1_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-v19§);
         }
         this.bosses = [];
      }
   }
}


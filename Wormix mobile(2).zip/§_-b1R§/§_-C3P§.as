package §_-b1R§
{
   import §_-31N§.§_-42G§;
   import §_-92a§.§_-Y2Y§;
   import §_-937§.§_-BO§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Tm§.§_-RF§;
   import §_-Y1b§.§_-22N§;
   import §_-k1u§.§_-2m§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.*;
   import §_-z1g§.§_-lp§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import flash.events.Event;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-C3P§
   {
      
      private static var §_-jh§:§_-D2p§;
      
      private static var §_-h1s§:UserProfile;
      
      public function §_-C3P§()
      {
         super();
      }
      
      public static function §_-a1r§() : void
      {
         §_-jh§ = null;
      }
      
      public static function §_-D3y§() : Boolean
      {
         return §_-jh§ != null;
      }
      
      public static function §_-1l§() : void
      {
         §_-o2h§(§_-jh§,§_-h1s§);
      }
      
      public static function §_-o2h§(param1:§_-D2p§, param2:UserProfile = null) : void
      {
         §_-C3P§.§_-jh§ = param1;
         §_-C3P§.§_-h1s§ = param2;
         var _loc3_:Class = param1.getClass();
         var _loc4_:§_-22N§ = new _loc3_();
         §_-Bx§.§_-O2o§(_loc4_,§_-Jh§);
      }
      
      private static function §_-Jh§() : void
      {
         if(§_-N1V§.§_-I39§.§_-X1P§().contains(§_-jh§.getId()))
         {
            §_-X1j§.§_-12n§.§_-IT§(§_-jh§);
         }
         else if(§_-C3P§.§_-h1s§ == null)
         {
            §_-K3j§(§_-jh§.getId());
         }
         else
         {
            §_-7g§(§_-C3P§.§_-h1s§);
         }
         §_-J2l§.§_-m1I§();
      }
      
      private static function §_-7g§(param1:UserProfile) : void
      {
         §_-X1j§.§_-12n§.§_-22K§(param1,§_-jh§.getId());
      }
      
      private static function §_-K3j§(param1:int) : void
      {
         §_-X1j§.§_-12n§.§_-f27§(param1);
      }
   }
}


package §_-b1R§
{
   import §_-21p§.§_-4w§;
   import §_-63M§.§_-F3f§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Y1b§.§_-22N§;
   import §_-Z1K§.§_-A2n§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import dragonBones.animation.WorldClock;
   import dragonBones.starling.StarlingFactory;
   import dragonBones.starling.StarlingTextureAtlasData;
   import dragonBones.textures.TextureAtlasData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalLayout;
   import flash.geom.Point;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   
   public class §_-Bx§
   {
      
      public function §_-Bx§()
      {
         super();
      }
      
      public static function §_-z2M§(param1:§_-22N§) : void
      {
         var _loc3_:§_-F3f§ = null;
         var _loc2_:Vector.<§_-F3f§> = param1.§_-322§();
         if(_loc2_.length > 0)
         {
            for each(_loc3_ in _loc2_)
            {
               removeResource(_loc3_);
            }
         }
      }
      
      private static function removeResource(param1:§_-F3f§) : void
      {
         Application.assetManager.removeObject(param1.textureAtlas);
         Application.factory.removeTextureAtlasData(param1.name,true);
         Application.factory.removeDragonBonesData(param1.name,true);
      }
      
      public static function §_-O2o§(param1:§_-22N§, param2:Function) : void
      {
         var _loc3_:Vector.<§_-F3f§> = param1.§_-322§();
         if(_loc3_.length > 0)
         {
            §_-J2l§.§_-e1L§(§_-s2a§.BOSS_RESOURCES_LOAD);
            §_-q2m§(_loc3_,param2);
         }
         else
         {
            param2();
         }
      }
      
      private static function §_-q2m§(param1:Vector.<§_-F3f§>, param2:Function) : void
      {
         var loader:AssetManager = null;
         var res:§_-F3f§ = null;
         var resources:Vector.<§_-F3f§> = param1;
         var onComplete:Function = param2;
         loader = Application.assetManager;
         var path:String = §_-vd§.§_-S11§() + "bosses/";
         for each(res in resources)
         {
            loader.enqueue(path + res.§_-BC§);
            loader.enqueue(path + res.§_-F1n§);
            loader.enqueue(path + res.§_-9o§);
         }
         loader.loadQueue(function(param1:Number):void
         {
            var _loc2_:StarlingFactory = null;
            var _loc3_:§_-F3f§ = null;
            var _loc4_:TextureAtlas = null;
            var _loc5_:TextureAtlasData = null;
            if(param1 == 1)
            {
               _loc2_ = Application.factory;
               for each(_loc3_ in resources)
               {
                  if(_loc2_.getDragonBonesData(_loc3_.name))
                  {
                     removeResource(_loc3_);
                  }
                  _loc2_.parseDragonBonesData(loader.getObject(_loc3_.§_-A3W§),_loc3_.name);
                  loader.removeObject(_loc3_.§_-A3W§);
                  _loc4_ = loader.getTextureAtlas(_loc3_.textureAtlas) as TextureAtlas;
                  _loc5_ = StarlingTextureAtlasData.fromTextureAtlas(_loc4_);
                  _loc2_.addTextureAtlasData(_loc5_,_loc3_.name);
               }
               onComplete();
            }
         });
      }
   }
}


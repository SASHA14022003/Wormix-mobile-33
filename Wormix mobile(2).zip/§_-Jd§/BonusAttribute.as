package §_-Jd§
{
   import §_-21p§.§_-4w§;
   import §_-Vg§.*;
   import §_-lh§.§_-z2A§;
   import feathers.controls.TabBar;
   import ru.pragmatix.wormix.model.items.craft.§_-13q§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import starling.events.Event;
   
   public class BonusAttribute extends §_-11K§
   {
      
      public static const NAME:String = "BonusAttribute";
      
      public function BonusAttribute()
      {
         super(NAME);
      }
      
      override public function add(param1:§_-4w§) : void
      {
         super.add(param1);
         activate(param1);
      }
      
      override public function remove(param1:§_-4w§) : void
      {
         super.remove(param1);
         deactivate(param1);
      }
   }
}


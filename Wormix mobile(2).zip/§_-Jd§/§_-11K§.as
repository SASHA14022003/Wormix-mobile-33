package §_-Jd§
{
   import §_-21p§.§_-4w§;
   import §_-A1K§.§_-TA§;
   import §_-Y1O§.§_-y1o§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   
   public class §_-11K§
   {
      
      protected var count:§_-TA§ = new §_-TA§(0);
      
      protected var owner:§_-01J§;
      
      private var type:§_-x2M§;
      
      private var name:String;
      
      public function §_-11K§(param1:String)
      {
         super();
         this.name = param1;
      }
      
      public function init(param1:§_-01J§, param2:§_-4w§) : void
      {
         this.owner = param1;
         this.type = param2.getType();
         this.add(param2);
      }
      
      public function getType() : §_-x2M§
      {
         return this.type;
      }
      
      public function add(param1:§_-4w§) : void
      {
         ++this.count.value;
      }
      
      public function remove(param1:§_-4w§) : void
      {
         --this.count.value;
      }
      
      protected function activate(param1:§_-4w§) : void
      {
      }
      
      protected function deactivate(param1:§_-4w§) : void
      {
      }
      
      public function getCount() : int
      {
         return this.count.value;
      }
      
      public function getName() : String
      {
         return this.name;
      }
   }
}


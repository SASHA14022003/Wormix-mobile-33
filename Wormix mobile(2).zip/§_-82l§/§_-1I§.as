package §_-82l§
{
   public class §_-1I§
   {
      
      public static const TEXT:int = 0;
      
      public static const §_-r2s§:int = 1;
      
      public function §_-1I§()
      {
         super();
      }
   }
}


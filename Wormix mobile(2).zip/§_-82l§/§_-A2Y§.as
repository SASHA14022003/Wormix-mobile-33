package §_-82l§
{
   import §_-G2H§.*;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-A2Y§
   {
      
      private static const §_-W1y§:Dictionary = new Dictionary();
      
      public static const §_-vu§:§_-A2Y§ = new §_-A2Y§(0);
      
      public static const §_-92j§:§_-A2Y§ = new §_-A2Y§(1);
      
      public static const §_-B1I§:§_-A2Y§ = new §_-A2Y§(2);
      
      public static const §_-82y§:§_-A2Y§ = new §_-A2Y§(3);
      
      public static const §_-v2j§:§_-A2Y§ = new §_-A2Y§(4);
      
      public static const §_-y2c§:§_-A2Y§ = new §_-A2Y§(5);
      
      public static const UNDEFINED:§_-A2Y§ = new §_-A2Y§(-1);
      
      private var _type:int;
      
      public function §_-A2Y§(param1:int)
      {
         super();
         this._type = param1;
         §_-W1y§[this._type] = this;
      }
      
      public static function §_-Y1M§(param1:int) : §_-A2Y§
      {
         var _loc2_:§_-A2Y§ = §_-W1y§[param1];
         return _loc2_ ? _loc2_ : UNDEFINED;
      }
      
      public function get type() : int
      {
         return this._type;
      }
      
      public function equals(param1:§_-A2Y§) : Boolean
      {
         return param1._type == this._type;
      }
   }
}


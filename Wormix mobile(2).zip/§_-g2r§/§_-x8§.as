package §_-g2r§
{
   import §_-12a§.§_-6p§;
   import §_-B1y§.§_-bs§;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   
   public class §_-x8§
   {
      
      public static const SUCCESS:String = "SUCCES";
      
      public static const ERROR:String = "ERROR";
      
      public function §_-x8§()
      {
         super();
      }
   }
}


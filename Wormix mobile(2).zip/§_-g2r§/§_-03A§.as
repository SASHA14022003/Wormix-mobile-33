package §_-g2r§
{
   import §_-dS§.§_-D3a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-03A§
   {
      
      public var noMapGround:Boolean;
      
      public var indestructibleGround:Boolean;
      
      public var mapRecord:§_-D3a§;
      
      public var profiles:Vector.<UserProfile>;
      
      public var success:Boolean = false;
      
      public function §_-03A§()
      {
         super();
      }
      
      public function §_-JV§() : Object
      {
         return {
            "noMapGround":this.noMapGround,
            "indestructibleGround":this.indestructibleGround
         };
      }
   }
}


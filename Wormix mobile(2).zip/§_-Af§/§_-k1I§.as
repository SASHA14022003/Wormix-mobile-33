package §_-Af§
{
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-B1y§.*;
   import §_-B2z§.*;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y23§.*;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-lp§;
   import com.greensock.loading.LoaderMax;
   import feathers.controls.Panel;
   import feathers.core.FeathersControl;
   import feathers.data.IListCollection;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.§_-kQ§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-k1I§
   {
      
      private var §_-21B§:uint;
      
      private var §_-u2F§:uint;
      
      private var §_-K2n§:uint;
      
      private var _level:uint;
      
      private var §_-l4§:uint;
      
      public function §_-k1I§(param1:uint, param2:Number, param3:Number, param4:Vector.<§_-V23§>)
      {
         super();
         this.§_-21B§ = §_-Gk§(param4);
         this.§_-u2F§ = §_-nf§(param4);
         this.§_-l4§ = count(param4);
         this.§_-K2n§ = §_-s1J§(param4);
         this._level = param1 + param2 * this.§_-K2n§ + param3 * this.§_-21B§;
      }
      
      private static function §_-Gk§(param1:Vector.<§_-V23§>) : uint
      {
         var _loc3_:§_-V23§ = null;
         var _loc2_:uint = 0;
         for each(_loc3_ in param1)
         {
            _loc2_ += _loc3_.getUnits().length;
         }
         return uint(§_-nf§(param1) / _loc2_);
      }
      
      private static function §_-nf§(param1:Vector.<§_-V23§>) : uint
      {
         var _loc4_:§_-V23§ = null;
         var _loc5_:§_-01J§ = null;
         var _loc6_:int = 0;
         var _loc2_:uint = §_-lp§.getMaxLevel();
         var _loc3_:uint = 0;
         for each(_loc4_ in param1)
         {
            for each(_loc5_ in _loc4_.getUnits())
            {
               _loc6_ = _loc5_.record.getLevel();
               _loc3_ += Math.min(_loc2_,Math.max(1,_loc6_));
            }
         }
         return _loc3_;
      }
      
      public static function §_-s1J§(param1:Vector.<§_-V23§>) : uint
      {
         var _loc3_:§_-V23§ = null;
         var _loc4_:§_-01J§ = null;
         var _loc2_:uint = 0;
         for each(_loc3_ in param1)
         {
            for each(_loc4_ in _loc3_.getUnits())
            {
               if(_loc4_.record.getLevel() > _loc2_)
               {
                  _loc2_ = uint(_loc4_.record.getLevel());
               }
            }
         }
         return Math.min(§_-lp§.getMaxLevel(),Math.max(1,_loc2_));
      }
      
      public static function count(param1:Vector.<§_-V23§>) : uint
      {
         var _loc3_:§_-V23§ = null;
         var _loc2_:uint = 0;
         for each(_loc3_ in param1)
         {
            _loc2_ += _loc3_.§_-Z2G§();
         }
         return _loc2_;
      }
      
      public function get §_-Z2r§() : uint
      {
         return this.§_-21B§;
      }
      
      public function get §_-sL§() : uint
      {
         return this.§_-u2F§;
      }
      
      public function get maxLevel() : uint
      {
         return this.§_-K2n§;
      }
      
      public function get level() : uint
      {
         return this._level;
      }
      
      public function get unitCount() : uint
      {
         return this.§_-l4§;
      }
   }
}


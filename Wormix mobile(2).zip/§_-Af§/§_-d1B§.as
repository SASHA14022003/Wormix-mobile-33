package §_-Af§
{
   import §_-12W§.*;
   import §_-12a§.§_-6p§;
   import §_-21p§.§_-4w§;
   import §_-23P§.§_-u1z§;
   import §_-43V§.*;
   import §_-5Y§.*;
   import §_-62§.*;
   import §_-73I§.§_-q15§;
   import §_-73d§.§_-pT§;
   import §_-82a§.*;
   import §_-82l§.§_-1I§;
   import §_-9§.§_-52A§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-yG§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G16§.*;
   import §_-G2H§.*;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-L2F§.§_-D2p§;
   import §_-N8§.§_-o2w§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1b§.§_-22N§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.*;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1w§.§_-w1D§;
   import §_-aM§.§_-P1N§;
   import §_-d26§.*;
   import §_-fo§.§_-21L§;
   import §_-fo§.§_-r5§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-q26§.*;
   import §_-qH§.§_-AC§;
   import §_-r1C§.*;
   import §_-s20§.§_-J2g§;
   import §_-sQ§.*;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import §_-zI§.§_-X1q§;
   import com.greensock.events.TweenEvent;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.util.der.§_-p1B§;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalLayout;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import flash.utils.clearInterval;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.EndTurn;
   import ru.pragmatix.wormix.messages.server.EndTurnResponse;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.BossWormStructure;
   import ru.pragmatix.wormix.messages.structures.ReconnectToSimpleBattleResultStructure;
   import ru.pragmatix.wormix.messages.structures.TurnStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-d1B§ extends §_-22N§
   {
      
      private var achieves:Vector.<§_-e2J§> = new Vector.<§_-e2J§>();
      
      private var §_-RZ§:Boolean = false;
      
      private var totalDamageToPlayer:int = 0;
      
      private var totalDamageToBoss:int = 0;
      
      private var §_-42b§:int = 0;
      
      private var §_-M1I§:Array = [];
      
      private var §_-M2j§:Vector.<EndTurn> = new Vector.<EndTurn>(0);
      
      public function §_-d1B§(param1:uint, param2:Boolean = false)
      {
         super(param1,param2);
      }
      
      private static function §_-Mk§(param1:Boolean) : int
      {
         var _loc3_:Object = null;
         var _loc4_:§_-8K§ = null;
         var _loc2_:int = 0;
         for each(_loc3_ in §_-X1j§.§_-12n§.gameMaster.damageAggregator.§_-b2k§)
         {
            _loc4_ = _loc3_.unit;
            if((Boolean(_loc4_)) && Boolean(_loc4_.squad) && _loc4_.squad.isAi() == param1)
            {
               _loc2_ += _loc3_.damage;
            }
         }
         return _loc2_;
      }
      
      override public function §_-e2d§() : void
      {
         this.script.initBeforeBattle(§_-336§);
         this.script.addEventListener(§_-R1h§.NAME,this.§_-d1Y§);
         §_-J2g§.§_-o1R§(EndTurnResponse,this.§_-I3§);
      }
      
      public function activateAchievs(param1:int, param2:Boolean) : void
      {
         var _loc3_:§_-o2w§ = null;
         var _loc4_:§_-e2J§ = null;
         for each(_loc3_ in §_-w1D§.§_-YZ§(param1))
         {
            this.achieves.push(new §_-e2J§(_loc3_));
         }
         this.§_-p13§();
         this.§_-RZ§ = param2;
         if(param2 || !§_-X1j§.§_-A24§.§_-X2A§())
         {
            for each(_loc4_ in this.achieves)
            {
               _loc4_.§_-j2F§();
            }
         }
      }
      
      override protected function §_-03f§(param1:uint) : void
      {
         if(param1 == 1 && this.achieves.length != 0)
         {
            if(!this.§_-RZ§ && §_-X1j§.§_-A24§.§_-X2A§())
            {
               this.§_-s0§();
            }
         }
         super.§_-03f§(param1);
      }
      
      protected function §_-H35§() : Boolean
      {
         return Boolean(§_-6D§) && Boolean(§_-6D§.length);
      }
      
      protected function get script() : §_-P1N§
      {
         return §_-6D§[0];
      }
      
      override public function clear() : void
      {
         var _loc1_:§_-e2J§ = null;
         if(this.§_-42b§ != §_-X1j§.§_-12n§.gameMaster.§_-82g§())
         {
            this.§_-41R§();
         }
         this.script.removeEventListener(§_-R1h§.NAME,this.§_-d1Y§);
         super.clear();
         if(§_-X1j§.§_-12n§.§_-vP§() == §_-J1§.WINNER)
         {
            this.§_-e1m§();
            this.§_-92o§();
         }
         else
         {
            for each(_loc1_ in this.achieves)
            {
               if(!_loc1_.closed)
               {
                  _loc1_.§_-j2F§();
                  this.§_-wJ§(_loc1_);
               }
            }
         }
         this.§_-M2j§.length = 0;
         §_-J2g§.§_-fy§(EndTurnResponse,this.§_-I3§);
      }
      
      protected function §_-o2x§() : void
      {
         var _loc1_:§_-V23§ = null;
         var _loc2_:§_-01J§ = null;
         for each(_loc1_ in playerSquads)
         {
            for each(_loc2_ in _loc1_.getUnits())
            {
               §_-TZ§.addListener(_loc2_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Te§);
            }
         }
      }
      
      protected function §_-43n§() : void
      {
         var _loc1_:§_-V23§ = null;
         var _loc2_:§_-01J§ = null;
         for each(_loc1_ in playerSquads)
         {
            for each(_loc2_ in _loc1_.getUnits())
            {
               §_-TZ§.removeListener(_loc2_ as EventDispatcher,§_-L3Q§.§_-Qw§,this.§_-Te§);
            }
         }
      }
      
      protected function §_-Te§(param1:starling.events.Event) : void
      {
      }
      
      public function §_-x1j§() : Vector.<§_-e2J§>
      {
         return this.achieves;
      }
      
      protected function §_-p13§() : void
      {
      }
      
      protected function §_-e1m§() : void
      {
      }
      
      protected function §_-d1Y§(param1:§_-R1h§) : void
      {
      }
      
      protected function §_-A6§(param1:uint) : §_-e2J§
      {
         var _loc2_:§_-e2J§ = null;
         for each(_loc2_ in this.achieves)
         {
            if(param1 == _loc2_.id)
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      protected function §_-T27§(param1:§_-e2J§, param2:uint) : void
      {
         ++param1.count;
         if(param1.count == param2)
         {
            param1.§_-h2j§ = true;
            this.§_-o2e§(param1);
         }
         else
         {
            this.§_-g28§(param1,String(param1.count + "/" + param2));
         }
      }
      
      protected function §_-o2e§(param1:§_-e2J§) : void
      {
         this.§_-53m§(param1,"COMPLETED","#66CC00");
      }
      
      protected function §_-wJ§(param1:§_-e2J§) : void
      {
         this.§_-53m§(param1,"FAILED","#CC6666");
      }
      
      private function §_-53m§(param1:§_-e2J§, param2:String, param3:String) : void
      {
         §_-h2B§.play(§_-d27§.§_-p1C§);
         var _loc4_:String = §_-s2a§.§_-K3t§("ACHIEVE") + " \"" + §_-s2a§.§_-K3t§(param1.record.levels[0].name) + "\" " + §_-s2a§.§_-K3t§(param2);
         §_-X1j§.§_-12n§.§_-q2B§(_loc4_,§_-1I§.TEXT,null,false,param3);
      }
      
      private function §_-g28§(param1:§_-e2J§, param2:String) : void
      {
         §_-h2B§.play(§_-d27§.§_-p1C§);
         var _loc3_:String = §_-s2a§.§_-K3t§(param1.record.levels[0].name) + ": " + §_-s2a§.§_-K3t§("PROGRESS") + " " + param2;
         §_-X1j§.§_-12n§.§_-q2B§(_loc3_,§_-1I§.TEXT);
      }
      
      private function §_-s0§() : void
      {
         var _loc2_:§_-e2J§ = null;
         var _loc3_:Boolean = false;
         var _loc4_:String = null;
         var _loc5_:Scene = null;
         var _loc1_:Boolean = false;
         for each(_loc2_ in this.achieves)
         {
            _loc3_ = §_-X1j§.§_-k2F§.§_-Sy§().§_-Lb§(_loc2_.id);
            if(!_loc3_)
            {
               if(!_loc1_)
               {
                  _loc1_ = true;
                  _loc5_ = §_-X1j§.§_-12n§.scene;
                  if((Boolean(_loc5_)) && Boolean(_loc5_.gameInterface))
                  {
                     §_-X1j§.§_-12n§.§_-q2B§(§_-s2a§.§_-K3t§("BOSS_ACHIEVE") + ":",§_-1I§.TEXT);
                  }
               }
               _loc4_ = §_-s2a§.§_-K3t§(_loc2_.record.levels[0].name) + ": " + _loc2_.record.§_-p1§(0);
               §_-X1j§.§_-12n§.§_-q2B§(_loc4_,§_-1I§.TEXT);
            }
            else
            {
               _loc2_.closed = true;
               _loc2_.§_-h2j§ = true;
            }
         }
      }
      
      private function §_-92o§() : void
      {
         var _loc1_:§_-e2J§ = null;
         for each(_loc1_ in this.achieves)
         {
            if(!_loc1_.closed)
            {
               _loc1_.closed = true;
               if(_loc1_.§_-h2j§)
               {
                  this.§_-53m§(_loc1_,"CREDITED","#66CC00");
               }
               else
               {
                  this.§_-wJ§(_loc1_);
               }
            }
         }
      }
      
      private function §_-I3§(param1:§_-63i§) : void
      {
         var _loc3_:EndTurn = null;
         var _loc2_:EndTurnResponse = EndTurnResponse(param1.message);
         for each(_loc3_ in this.§_-M2j§)
         {
            if(_loc3_.turn.turnNum == _loc2_.turnNum)
            {
               this.§_-M2j§.splice(this.§_-M2j§.indexOf(_loc3_),1);
               break;
            }
         }
      }
      
      public function resendTurnsFrom(param1:ReconnectToSimpleBattleResultStructure) : void
      {
         var _loc2_:Vector.<EndTurn> = null;
         var _loc3_:EndTurn = null;
         if(param1.lastTurnNum < this.§_-42b§)
         {
            _loc2_ = new Vector.<EndTurn>(0);
            for each(_loc3_ in this.§_-M2j§)
            {
               if(_loc3_.turn.turnNum > param1.lastTurnNum && _loc3_.turn.turnNum <= this.§_-42b§)
               {
                  _loc3_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
                  _loc2_.push(_loc3_);
               }
            }
            for each(_loc3_ in _loc2_)
            {
               if(!§_-J2g§.§_-i1N§.§_-928§())
               {
                  break;
               }
               §_-J2g§.§_-h18§(_loc3_);
            }
         }
      }
      
      public function §_-41R§(param1:starling.events.Event = null) : void
      {
         var _loc2_:EndTurn = new EndTurn();
         var _loc3_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         _loc2_.missionId = §_-X1j§.§_-12n§.§_-WN§().missionIds[0];
         _loc2_.battleId = §_-X1j§.§_-12n§.§_-WN§().battleId;
         _loc2_.banType = Boolean(_loc3_) && Boolean(_loc3_.§_-4n§()) && _loc3_.§_-4n§() != 0 ? int(§_-A2V§.§_-A2e§) : 0;
         _loc2_.turn = this.§_-I1j§();
         _loc2_.sessionKey = §_-J2g§.§_-i1N§.§_-yt§();
         this.§_-M2j§.push(_loc2_);
         §_-J2g§.§_-h18§(_loc2_);
      }
      
      private function §_-I1j§() : TurnStructure
      {
         var _loc3_:Vector.<§_-V23§> = null;
         var _loc4_:§_-V23§ = null;
         var _loc5_:Vector.<§_-01J§> = null;
         var _loc6_:§_-01J§ = null;
         var _loc1_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         var _loc2_:TurnStructure = new TurnStructure();
         _loc2_.endTime = 0;
         this.§_-42b§ = _loc2_.turnNum = Boolean(_loc1_) && Boolean(_loc1_.§_-82g§()) ? int(_loc1_.§_-82g§()) : 0;
         _loc2_.isPlayerTurn = Boolean(_loc1_) && Boolean(currentUnit) ? !currentUnit.squad.isAi() : false;
         this.totalDamageToBoss += _loc2_.damageToBoss = _loc1_ ? §_-OP§.§_-Mk§(true) : 0;
         this.totalDamageToPlayer += _loc2_.damageToPlayer = _loc1_ ? §_-OP§.§_-Mk§(false) : 0;
         _loc2_.items = Boolean(_loc1_) && Boolean(_loc1_.damageAggregator.§_-j1i§) ? _loc1_.damageAggregator.§_-j1i§ : [];
         _loc2_.deaths = Boolean(_loc1_) && Boolean(_loc1_.damageAggregator.§_-Y2c§) ? _loc1_.damageAggregator.§_-Y2c§ : [];
         _loc2_.births = Boolean(_loc1_) && Boolean(_loc1_.damageAggregator.§_-y2§) ? _loc1_.damageAggregator.§_-y2§ : [];
         if(_loc2_.isPlayerTurn)
         {
            this.§_-O19§(_loc2_.items);
         }
         if(_loc2_.turnNum == 0)
         {
            _loc3_ = playerSquads.concat(§_-336§);
            for each(_loc4_ in _loc3_)
            {
               _loc5_ = _loc4_.getUnits();
               for each(_loc6_ in _loc5_)
               {
                  _loc2_.births.push(new BossWormStructure(!_loc6_.squad.isAi(),_loc6_.hp));
               }
            }
         }
         return _loc2_;
      }
      
      private function §_-O19§(param1:Array) : void
      {
         var _loc2_:WeaponStructure = null;
         var _loc3_:Boolean = false;
         var _loc4_:WeaponStructure = null;
         for each(_loc2_ in param1)
         {
            _loc3_ = false;
            for each(_loc4_ in this.§_-M1I§)
            {
               if(_loc2_.getId() == _loc4_.getId())
               {
                  _loc4_.addCount(_loc2_.getCount());
                  _loc3_ = true;
               }
            }
            if(!_loc3_)
            {
               this.§_-M1I§.push(new WeaponStructure(_loc2_.getId(),_loc2_.getCount()));
            }
         }
      }
      
      public function get §_-63Z§() : int
      {
         return this.totalDamageToPlayer;
      }
      
      public function get §_-ve§() : int
      {
         return this.totalDamageToBoss;
      }
      
      public function get §_-j1i§() : Array
      {
         return this.§_-M1I§;
      }
      
      private function §_-u2Z§() : int
      {
         var _loc2_:§_-V23§ = null;
         var _loc1_:int = 0;
         for each(_loc2_ in §_-336§)
         {
            if(_loc2_.isAi())
            {
               _loc1_ += _loc2_.§_-r2g§();
            }
         }
         return _loc1_;
      }
   }
}


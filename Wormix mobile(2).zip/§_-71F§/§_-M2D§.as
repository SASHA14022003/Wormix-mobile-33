package §_-71F§
{
   import §_-02q§.§_-4s§;
   import §_-52L§.§_-u2x§;
   import §_-52V§.§_-I2i§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-ou§;
   import §_-62§.§_-zF§;
   import §_-931§.§_-sz§;
   import §_-hv§.§_-32W§;
   import §_-j22§.§_-5g§;
   import §_-p18§.§_-h1b§;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-T1K§;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import flash.display.DisplayObjectContainer;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.SteamTransactionInitRequest;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-M2D§
   {
      
      protected var §_-Ar§:EventDispatcher;
      
      protected var §_-u8§:§_-I2i§;
      
      public function §_-M2D§()
      {
         super();
      }
      
      public function get eventDispatcher() : EventDispatcher
      {
         return this.§_-Ar§;
      }
      
      [Inject]
      public function set eventDispatcher(param1:EventDispatcher) : void
      {
         this.§_-Ar§ = param1;
      }
      
      protected function get §_-S22§() : §_-I2i§
      {
         return this.§_-u8§ || (this.§_-u8§ = new §_-32W§(this.eventDispatcher));
      }
      
      protected function dispatch(param1:Event) : void
      {
         this.eventDispatcher.dispatchEvent(param1);
      }
      
      protected function dispatchWith(param1:String, param2:Boolean = false, param3:Object = null) : void
      {
         this.eventDispatcher.dispatchEventWith(param1,param2,param3);
      }
   }
}


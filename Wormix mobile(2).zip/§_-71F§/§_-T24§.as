package §_-71F§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-31W§.§_-r26§;
   import §_-52V§.§_-031§;
   import §_-52V§.§_-23C§;
   import §_-52V§.§_-71f§;
   import §_-52V§.§_-I2i§;
   import §_-52V§.§_-Xq§;
   import §_-52V§.§_-b2z§;
   import §_-52V§.§_-iC§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.*;
   import §_-72j§.§_-Z6§;
   import §_-72j§.§_-i2G§;
   import §_-73d§.§_-g1J§;
   import §_-82a§.*;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.*;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-G2H§.*;
   import §_-J31§.§_-e2J§;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-Vx§.§_-V2t§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-dS§.§_-D3a§;
   import §_-hv§.MediatorMap;
   import §_-hv§.§_-32W§;
   import §_-hv§.§_-81v§;
   import §_-hv§.§_-E3a§;
   import §_-hv§.§_-J3y§;
   import §_-hv§.§_-d1x§;
   import §_-hv§.§_-m1z§;
   import §_-j1w§.§_-L1x§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-d2j§;
   import §_-o14§.§_-Dd§;
   import §_-q26§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-sQ§.§_-H3D§;
   import §_-zq§.§_-h1I§;
   import §_-zq§.§_-uw§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.hurlant.math.BigInteger;
   import config.*;
   import feathers.core.ITextRenderer;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.getQualifiedClassName;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-I3A§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.*;
   import ru.pragmatix.wormix.messages.structures.*;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.AtomBomb;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.text.TextFieldAutoSize;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-T24§ extends §_-d1x§ implements §_-23C§
   {
      
      protected var §_-93p§:§_-031§;
      
      protected var §_-01n§:§_-b2z§;
      
      protected var §_-i2b§:Boolean;
      
      protected var §_-93x§:DisplayObjectContainer;
      
      protected var §_-I34§:§_-71f§;
      
      protected var §_-BD§:§_-iC§;
      
      protected var §_-k2I§:§_-Xq§;
      
      public function §_-T24§(param1:DisplayObjectContainer = null, param2:Boolean = true)
      {
         super();
         this.§_-93x§ = param1;
         this.§_-i2b§ = param2;
         if(this.§_-93x§)
         {
            this.§_-Aw§();
            this.§_-nL§();
         }
      }
      
      public function startup() : void
      {
         dispatchEventWith(§_-81v§.§_-Kh§);
      }
      
      public function shutdown() : void
      {
         dispatchEventWith(§_-81v§.§_-o2A§);
      }
      
      public function get §_-v2Z§() : DisplayObjectContainer
      {
         return this.§_-93x§;
      }
      
      public function set §_-v2Z§(param1:DisplayObjectContainer) : void
      {
         if(param1 == this.§_-93x§)
         {
            return;
         }
         if(this.§_-93x§)
         {
            throw new §_-E3a§(§_-E3a§.§_-D3L§);
         }
         this.§_-93x§ = param1;
         this.§_-Aw§();
         this.§_-nL§();
      }
      
      protected function get injector() : §_-031§
      {
         if(!this.§_-93p§)
         {
            this.§_-93p§ = this.§_-qR§();
         }
         return this.§_-93p§;
      }
      
      protected function set injector(param1:§_-031§) : void
      {
         this.§_-93p§ = param1;
      }
      
      protected function get §_-o1i§() : §_-b2z§
      {
         if(!this.§_-01n§)
         {
            this.§_-01n§ = new §_-uw§();
         }
         return this.§_-01n§;
      }
      
      protected function set §_-o1i§(param1:§_-b2z§) : void
      {
         this.§_-01n§ = param1;
      }
      
      protected function get §_-q2w§() : §_-71f§
      {
         if(!this.§_-I34§)
         {
            this.§_-I34§ = new §_-m1z§(eventDispatcher,this.§_-JR§(),this.§_-o1i§);
         }
         return this.§_-I34§;
      }
      
      protected function set §_-q2w§(param1:§_-71f§) : void
      {
         this.§_-I34§ = param1;
      }
      
      protected function get §_-dk§() : §_-iC§
      {
         if(!this.§_-BD§)
         {
            this.§_-BD§ = new MediatorMap(this.§_-v2Z§,this.§_-JR§(),this.§_-o1i§);
         }
         return this.§_-BD§;
      }
      
      protected function set §_-dk§(param1:§_-iC§) : void
      {
         this.§_-BD§ = param1;
      }
      
      protected function get §_-k1g§() : §_-Xq§
      {
         if(!this.§_-k2I§)
         {
            this.§_-k2I§ = new §_-J3y§(this.§_-v2Z§,this.injector);
         }
         return this.§_-k2I§;
      }
      
      protected function set §_-k1g§(param1:§_-Xq§) : void
      {
         this.§_-k2I§ = param1;
      }
      
      protected function §_-Aw§() : void
      {
         this.injector.§_-r2M§(§_-b2z§,this.§_-o1i§);
         this.injector.§_-r2M§(§_-031§,this.injector);
         this.injector.§_-r2M§(EventDispatcher,eventDispatcher);
         this.injector.§_-r2M§(DisplayObjectContainer,this.§_-v2Z§);
         this.injector.§_-r2M§(§_-71f§,this.§_-q2w§);
         this.injector.§_-r2M§(§_-iC§,this.§_-dk§);
         this.injector.§_-r2M§(§_-Xq§,this.§_-k1g§);
         this.injector.§_-PF§(§_-I2i§,§_-32W§);
      }
      
      protected function §_-nL§() : void
      {
         if(this.§_-i2b§ && Boolean(this.§_-v2Z§))
         {
            if(this.§_-v2Z§.stage)
            {
               this.startup();
            }
            else
            {
               this.§_-v2Z§.addEventListener(Event.ADDED_TO_STAGE,this.onAddedToStage);
            }
         }
      }
      
      protected function onAddedToStage(param1:Event) : void
      {
         this.§_-v2Z§.removeEventListener(Event.ADDED_TO_STAGE,this.onAddedToStage);
         this.startup();
      }
      
      protected function §_-qR§() : §_-031§
      {
         var _loc1_:§_-031§ = new §_-h1I§();
         _loc1_.applicationDomain = this.§_-j2j§();
         return _loc1_;
      }
      
      protected function §_-JR§() : §_-031§
      {
         return this.injector.§_-Z1f§(this.§_-j2j§());
      }
      
      protected function §_-j2j§() : ApplicationDomain
      {
         return ApplicationDomain.currentDomain;
      }
   }
}


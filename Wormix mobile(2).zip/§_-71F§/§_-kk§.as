package §_-71F§
{
   import §_-21p§.§_-4w§;
   import §_-52V§.§_-I2i§;
   import §_-52V§.§_-iC§;
   import §_-82a§.*;
   import §_-82l§.§_-1I§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-J2l§;
   import §_-E1I§.§_-b2n§;
   import §_-H3§.*;
   import §_-L1H§.§_-C3e§;
   import §_-RE§.§_-r2q§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-81l§;
   import §_-aM§.*;
   import §_-d2p§.*;
   import §_-hv§.*;
   import §_-j1w§.§_-L1x§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-n1w§.*;
   import §_-p24§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.math.*;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.ILayout;
   import feathers.themes.FontSize;
   import flash.display.BitmapData;
   import flash.geom.Point;
   import flash.text.TextFormatAlign;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.utils.id.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.common.post.*;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   use namespace bi_internal;
   
   public class §_-kk§ extends §_-gC§
   {
      
      [Inject]
      public var §_-v2Z§:DisplayObjectContainer;
      
      [Inject]
      public var §_-dk§:§_-iC§;
      
      protected var §_-Ar§:EventDispatcher;
      
      protected var §_-u8§:§_-I2i§;
      
      public function §_-kk§()
      {
         super();
      }
      
      override public function §_-YM§() : void
      {
         if(this.§_-u8§)
         {
            this.§_-u8§.§_-E1Y§();
         }
         super.§_-YM§();
      }
      
      public function get eventDispatcher() : EventDispatcher
      {
         return this.§_-Ar§;
      }
      
      [Inject]
      public function set eventDispatcher(param1:EventDispatcher) : void
      {
         this.§_-Ar§ = param1;
      }
      
      protected function get §_-S22§() : §_-I2i§
      {
         return this.§_-u8§ || (this.§_-u8§ = new §_-32W§(this.eventDispatcher));
      }
      
      protected function dispatch(param1:Event) : void
      {
         this.eventDispatcher.dispatchEvent(param1);
      }
      
      protected function dispatchWith(param1:String, param2:Boolean = false, param3:Object = null) : void
      {
         this.eventDispatcher.dispatchEventWith(param1,param2,param3);
      }
      
      protected function §_-32S§(param1:String, param2:Function, param3:Class = null) : void
      {
         this.§_-S22§.§_-IF§(EventDispatcher(§_-71k§),param1,param2,param3);
      }
      
      protected function §_-R2p§(param1:String, param2:Function, param3:Class = null) : void
      {
         this.§_-S22§.§_-Hy§(EventDispatcher(§_-71k§),param1,param2,param3);
      }
      
      protected function §_-g2k§(param1:String, param2:Function, param3:Class = null) : void
      {
         this.§_-S22§.§_-IF§(this.eventDispatcher,param1,param2,param3);
      }
      
      protected function §_-hn§(param1:String, param2:Function, param3:Class = null) : void
      {
         this.§_-S22§.§_-Hy§(this.eventDispatcher,param1,param2,param3);
      }
   }
}


package §_-71F§
{
   import §_-52V§.§_-031§;
   import §_-52V§.§_-71f§;
   import §_-52V§.§_-iC§;
   import §_-73d§.§_-g1J§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-DJ§.§_-J1d§;
   import §_-I1l§.*;
   import §_-L1H§.§_-b2K§;
   import §_-T2h§.*;
   import §_-U1i§.§_-hK§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-e1k§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import com.distriqt.extension.pushnotifications.events.PushNotificationGroupEvent;
   import com.greensock.plugins.*;
   import config.§_-V2w§;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class Command
   {
      
      [Inject]
      public var §_-v2Z§:starling.display.DisplayObjectContainer;
      
      [Inject]
      public var §_-q2w§:§_-71f§;
      
      [Inject]
      public var eventDispatcher:EventDispatcher;
      
      [Inject]
      public var injector:§_-031§;
      
      [Inject]
      public var §_-dk§:§_-iC§;
      
      public function Command()
      {
         super();
      }
      
      public function execute() : void
      {
      }
      
      protected function dispatch(param1:Event) : void
      {
         this.eventDispatcher.dispatchEvent(param1);
      }
      
      protected function dispatchWith(param1:String, param2:Boolean = false, param3:Object = null) : void
      {
         this.eventDispatcher.dispatchEventWith(param1,param2,param3);
      }
   }
}


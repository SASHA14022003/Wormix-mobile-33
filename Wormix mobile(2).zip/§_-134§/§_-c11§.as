package §_-134§
{
   import §_-5Y§.§_-33Y§;
   import §_-62§.§_-G1p§;
   import §_-91A§.*;
   import §_-CR§.§_-72p§;
   import §_-D3A§.§_-TZ§;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-99§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-TF§.§_-q1j§;
   import §_-Ty§.§_-K3a§;
   import §_-U1Y§.*;
   import §_-Vg§.*;
   import §_-Vu§.*;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-v2Q§;
   import §_-hO§.§_-BY§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.*;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.crypto.tls.§_-A3§;
   import com.hurlant.crypto.tls.§_-NB§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.data.ArrayCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import feathers.utils.textures.TextureCache;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.clearTimeout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.events.TouchEvent;
   import starling.utils.Pool;
   
   public class §_-c11§ extends §_-33Y§
   {
      
      private static const TEXT_MSG_RENDERER:String = "msg-text";
      
      private static const STICKER_MSG_RENDERER:String = "msg-sticker";
      
      private static const CRAFTED_LEGENDARY_MSG_RENDERER:String = "msg-legendary";
      
      private static const NEWS_MSG_RENDERER:String = "msg-news";
      
      private var renderers:Vector.<FeathersControl>;
      
      public function §_-c11§(param1:Array, param2:String, param3:TextureCache = null)
      {
         super(param1,param2,param3);
      }
      
      override protected function §_-o1t§() : void
      {
         §_-C20§ = new List();
         §_-C20§.backgroundSkin = new Quad(16,16,2041646);
         addChild(§_-C20§);
      }
      
      override protected function §_-C3§() : void
      {
         var layout:VerticalLayout;
         var messageItemFactory:Function;
         var stickerItemFactory:Function;
         var newsItemFactory:Function;
         var craftedLegendaryItemFactory:Function;
         var textureCache:TextureCache = null;
         §_-C20§.addEventListener(FeathersEventType.RESIZE,this.§_-u1Q§);
         Application.§_-ow§.addEventListener(starling.events.Event.CLOSE,this.§_-42q§);
         §_-C20§.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         this.layout = new AnchorLayout();
         §_-C20§.layoutData = new AnchorLayoutData(0,0,0,0);
         layout = §_-y2P§() as VerticalLayout;
         layout.gap = §_-Z2f§;
         §_-C20§.layout = layout;
         this.initList(§_-C20§);
         messageItemFactory = function():IListItemRenderer
         {
            return new §_-h2p§();
         };
         textureCache = §_-g20§.§_-W2i§();
         stickerItemFactory = function():IListItemRenderer
         {
            var _loc1_:§_-G2G§ = new §_-G2G§();
            _loc1_.textureCache = textureCache;
            return _loc1_;
         };
         newsItemFactory = function():IListItemRenderer
         {
            return new §_-82x§();
         };
         craftedLegendaryItemFactory = function():IListItemRenderer
         {
            return new §_-J1W§();
         };
         §_-C20§.setItemRendererFactoryWithID(TEXT_MSG_RENDERER,messageItemFactory);
         §_-C20§.setItemRendererFactoryWithID(STICKER_MSG_RENDERER,stickerItemFactory);
         §_-C20§.setItemRendererFactoryWithID(NEWS_MSG_RENDERER,newsItemFactory);
         §_-C20§.setItemRendererFactoryWithID(CRAFTED_LEGENDARY_MSG_RENDERER,craftedLegendaryItemFactory);
         §_-C20§.factoryIDFunction = function(param1:Object, param2:int):String
         {
            var _loc3_:ClanChatMessageTO = null;
            if(param1 is ClanChatMessageTO)
            {
               _loc3_ = param1 as ClanChatMessageTO;
               if(_loc3_.actionCode == ClanMessages.POST_TO_CHAT_REQUEST && _loc3_.params.indexOf("*sticker*") == 0)
               {
                  return STICKER_MSG_RENDERER;
               }
               if(_loc3_.actionCode == ClanMessages.CRAFT_LEGENDARY_EVENT)
               {
                  return CRAFTED_LEGENDARY_MSG_RENDERER;
               }
               return TEXT_MSG_RENDERER;
            }
            if(param1 is ClanNewsTO)
            {
               return NEWS_MSG_RENDERER;
            }
            return TEXT_MSG_RENDERER;
         };
         §_-OU§ = new §_-72p§(§_-C20§,this.§_-V25§,[RelativePosition.LEFT,RelativePosition.RIGHT],true,feathers.layout.Direction.VERTICAL);
         this.renderers = new Vector.<FeathersControl>(0);
      }
      
      private function §_-u1Q§(param1:starling.events.Event) : void
      {
         var _loc2_:DefaultListItemRenderer = null;
         for each(_loc2_ in this.renderers)
         {
            _loc2_.invalidate(INVALIDATION_FLAG_SIZE);
         }
      }
      
      override protected function initList(param1:List) : void
      {
         super.initList(param1);
         param1.clipContent = false;
      }
      
      private function §_-42q§(param1:starling.events.Event) : void
      {
         §_-OU§.§_-d1e§();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         Application.§_-ow§.removeEventListener(starling.events.Event.CLOSE,this.§_-42q§);
         §_-C20§.removeEventListener(FeathersEventType.RESIZE,this.§_-u1Q§);
         this.renderers = null;
      }
      
      private function §_-V25§(param1:Object) : int
      {
         var _loc2_:ClanChatMessageTO = param1 as ClanChatMessageTO;
         if(_loc2_)
         {
            if(_loc2_.memberProfileId != 0)
            {
               return _loc2_.memberProfileId;
            }
            if(_loc2_.publisherProfileId != 0)
            {
               return _loc2_.publisherProfileId;
            }
         }
         return 0;
      }
      
      private function §_-83b§(param1:Object) : int
      {
         var _loc2_:ClanChatMessageTO = param1 as ClanChatMessageTO;
         if(_loc2_)
         {
            if(_loc2_.memberSocialId != 0)
            {
               return _loc2_.memberSocialId;
            }
            if(_loc2_.publisherSocialId != 0)
            {
               return _loc2_.publisherSocialId;
            }
         }
         return 0;
      }
      
      override public function set height(param1:Number) : void
      {
         super.height = param1;
         if(§_-C20§)
         {
            §_-C20§.scrollToPosition(§_-C20§.horizontalScrollPosition,§_-C20§.verticalScrollPosition);
         }
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(§_-dU§.§_-h26§))
         {
            §_-C20§.dataProvider.updateAll();
         }
      }
   }
}


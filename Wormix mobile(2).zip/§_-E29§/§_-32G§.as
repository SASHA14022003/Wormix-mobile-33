package §_-E29§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.§_-E1E§;
   import §_-5Y§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-a3§;
   import §_-63U§.§_-21K§;
   import §_-82l§.§_-1I§;
   import §_-91A§.*;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.§_-63i§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.*;
   import §_-TF§.§_-F1O§;
   import §_-U1Y§.*;
   import §_-Vg§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Z1K§.§_-A2n§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-Z2z§;
   import §_-j22§.§_-5g§;
   import §_-k13§.§_-j23§;
   import §_-k2s§.§_-b0§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-C32§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-F3q§;
   import config.§_-vR§;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.ToggleButton;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.InviteFriendToClan;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanJoinRatingRequest;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.CheatDetected;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionDailyProgressStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   import starlingbuilder.engine.UIBuilder;
   
   public class §_-32G§ extends §_-D3v§
   {
      
      public static const §_-B2T§:uint = 5;
      
      private var §_-G1A§:Number = 1;
      
      private var records:Vector.<§_-y1S§>;
      
      public function §_-32G§()
      {
         var _loc2_:§_-y1S§ = null;
         var _loc3_:§_-D2p§ = null;
         var _loc4_:Vector.<§_-b0§> = null;
         var _loc5_:§_-b0§ = null;
         super();
         this.records = this.§_-E2T§();
         var _loc1_:Vector.<int> = §_-A2n§.§_-83§();
         for each(_loc2_ in this.records)
         {
            if(_loc2_ is §_-D2p§)
            {
               _loc3_ = _loc2_ as §_-D2p§;
               _loc4_ = _loc3_.§_-814§().§_-S1n§().concat(_loc3_.§_-K1z§().§_-S1n§()) as Vector.<§_-b0§>;
               for each(_loc5_ in _loc4_)
               {
                  if(_loc1_.indexOf(_loc5_.getId()) > -1)
                  {
                  }
               }
            }
         }
      }
      
      protected function §_-E2T§() : Vector.<§_-y1S§>
      {
         return new Vector.<§_-y1S§>(0);
      }
      
      public function get §_-q29§() : Vector.<§_-y1S§>
      {
         return this.records.slice(0,§_-B2T§);
      }
      
      override public function §_-X2L§() : uint
      {
         return Math.ceil((this.records.length - §_-B2T§) / §_-D3v§.§_-IS§);
      }
      
      override public function §_-A2A§(param1:int) : Vector.<§_-y1S§>
      {
         var _loc2_:int = param1 > 0 ? int(§_-B2T§ + §_-D3v§.§_-IS§ * param1) : int(§_-B2T§);
         return this.records.slice(_loc2_,_loc2_ + §_-D3v§.§_-IS§);
      }
      
      override protected function get minId() : int
      {
         return -5;
      }
      
      override protected function get maxId() : int
      {
         return 99;
      }
      
      override public function getOffset() : uint
      {
         return 0;
      }
      
      override public function §_-o§() : Vector.<§_-y1S§>
      {
         return this.records;
      }
      
      public function §_-7k§(param1:int) : §_-D2p§
      {
         return this.getRecord(param1) as §_-D2p§;
      }
      
      public function getRecord(param1:int) : §_-y1S§
      {
         var _loc2_:§_-y1S§ = null;
         for each(_loc2_ in this.records)
         {
            if(_loc2_.getId() == param1)
            {
               return _loc2_;
            }
         }
         return null;
      }
      
      public function §_-z1N§() : Number
      {
         return this.§_-G1A§;
      }
      
      public function §_-G6§(param1:Number) : void
      {
         this.§_-G1A§ = param1;
         if(param1 < 0.75)
         {
            this.§_-G1A§ = 1.1 + 1.1 * Math.random();
         }
      }
   }
}


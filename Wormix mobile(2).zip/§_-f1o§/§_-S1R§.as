package §_-f1o§
{
   import §_-12a§.§_-41b§;
   import §_-71F§.§_-M2D§;
   import §_-73I§.§_-q15§;
   import §_-931§.§_-02O§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-H2g§.§_-s1d§;
   import §_-L1H§.§_-b2K§;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1b§.*;
   import §_-YF§.§_-N3§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-Z2z§;
   import §_-j22§.§_-5g§;
   import §_-o14§.*;
   import §_-q26§.*;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-sQ§.§_-V1n§;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.Label;
   import feathers.controls.ToggleButton;
   import feathers.layout.VerticalAlign;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.GetJoinClansMainResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanAuditActionTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   public class §_-S1R§ extends §_-M2D§ implements §_-k2c§
   {
      
      public function §_-S1R§()
      {
         super();
      }
      
      public function §_-u2B§(param1:int) : void
      {
         §_-X1j§.§_-hl§.common.§_-G3b§(param1,ClanTO.SCOPE_ALL,this.§_-RA§);
      }
      
      private function §_-RA§(param1:ClanTO) : void
      {
         dispatchWith(§_-aG§.§_-D2Y§,false,param1);
      }
      
      public function §_-o1s§() : void
      {
         §_-X1j§.§_-hl§.common.§_-o1s§(this.§_-1q§);
      }
      
      private function §_-1q§(param1:Vector.<ClanAuditActionTO>) : void
      {
         var _loc3_:ClanAuditActionTO = null;
         var _loc2_:Array = [];
         for each(_loc3_ in param1)
         {
            this.§_-CY§(_loc3_.publisherId,_loc2_);
            this.§_-CY§(_loc3_.memberId,_loc2_);
         }
         if(_loc2_.length > 0)
         {
            §_-N3§.§_-Oc§(_loc2_,§_-bs§.§_-d1Z§(this.§_-m2T§,this,[param1]));
         }
         else
         {
            this.§_-m2T§(param1);
         }
      }
      
      private function §_-CY§(param1:int, param2:Array) : void
      {
         if(param1 != 0 && !§_-N3§.§_-g1D§(param1) && param2.indexOf(param1) == -1)
         {
            param2.push(param1);
         }
      }
      
      private function §_-m2T§(param1:Vector.<ClanAuditActionTO>) : void
      {
         dispatchWith(§_-aG§.§_-C1N§,false,param1);
      }
      
      public function §_-WX§() : void
      {
         §_-X1j§.§_-hl§.common.§_-WX§(this.§_-A2t§);
      }
      
      public function §_-S1W§(param1:String) : void
      {
         if(param1)
         {
            §_-X1j§.§_-hl§.common.§_-S1W§(param1,this.§_-A2t§);
         }
         else
         {
            §_-X1j§.§_-hl§.common.§_-WX§(this.§_-A2t§);
         }
      }
      
      private function §_-A2t§(param1:Vector.<ClanTO>) : void
      {
         dispatchWith(§_-aG§.§_-2E§,false,param1);
      }
   }
}


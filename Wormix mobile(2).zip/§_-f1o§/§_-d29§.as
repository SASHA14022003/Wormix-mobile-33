package §_-f1o§
{
   import §_-m2s§.§_-R11§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   
   public interface §_-d29§
   {
      
      function §_-P1s§() : ClanNewsTO;
      
      function §_-111§() : Vector.<ClanChatMessageTO>;
      
      function §_-h18§(param1:String) : void;
      
      function §_-3o§(param1:§_-R11§) : void;
   }
}


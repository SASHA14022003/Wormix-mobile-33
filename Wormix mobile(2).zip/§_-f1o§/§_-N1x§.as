package §_-f1o§
{
   import §_-2k§.*;
   import §_-71F§.§_-M2D§;
   import §_-82a§.*;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A2U§.§_-A23§;
   import §_-W§.*;
   import §_-m2s§.§_-R11§;
   import §_-q26§.§_-Z25§;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-43O§;
   import feathers.controls.Button;
   import feathers.core.IFeathersControl;
   import feathers.layout.ILayoutDisplayObject;
   import feathers.layout.LayoutBoundsResult;
   import feathers.layout.ViewPortBounds;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-N1x§ extends §_-M2D§ implements §_-d29§
   {
      
      [Inject]
      public var §_-hl§:§_-Z25§;
      
      public function §_-N1x§()
      {
         super();
      }
      
      public function §_-P1s§() : ClanNewsTO
      {
         var _loc1_:ClanNewsTO = §_-A23§.§_-P1s§();
         if(Boolean(_loc1_) && Boolean(_loc1_.text))
         {
            return _loc1_;
         }
         return null;
      }
      
      public function §_-111§() : Vector.<ClanChatMessageTO>
      {
         return §_-A23§.§_-82c§();
      }
      
      public function §_-h18§(param1:String) : void
      {
         param1 = StringUtil.§_-32B§(param1);
         if(Boolean(param1) && param1 != " ")
         {
            this.§_-hl§.common.§_-v1F§(StringUtil.§_-32B§(param1));
         }
      }
      
      public function §_-3o§(param1:§_-R11§) : void
      {
         this.§_-hl§.common.§_-HU§(param1);
      }
   }
}


package §_-f1o§
{
   public interface §_-H2I§
   {
      
      function §_-xq§(param1:String) : void;
      
      function §_-l1C§(param1:String) : void;
      
      function §_-l2d§(param1:Vector.<uint>) : void;
      
      function §_-G1k§(param1:int) : void;
      
      function §_-G3T§(param1:Boolean) : void;
      
      function §_-H1R§() : void;
      
      function §_-73X§(param1:int) : void;
   }
}


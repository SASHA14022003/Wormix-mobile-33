package §_-f1o§
{
   import §_-21p§.§_-4w§;
   import §_-23P§.§_-u1z§;
   import §_-71F§.§_-M2D§;
   import §_-A2S§.§_-52j§;
   import §_-A2S§.§_-L1N§;
   import §_-A2S§.§_-SU§;
   import §_-A2S§.§_-d2z§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.*;
   import §_-CF§.§_-E19§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1w§.§_-J2w§;
   import §_-P1B§.§_-b21§;
   import §_-R2I§.§_-H7§;
   import §_-R2I§.§_-u2V§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-U1i§.§_-XA§;
   import §_-UF§.ClanChangeMedalCostDialog;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-yA§;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-v2Q§;
   import §_-kP§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-sQ§.*;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-92Q§;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.mesmotronic.ane.AndroidFullScreen;
   import feathers.controls.Callout;
   import feathers.controls.ScrollPolicy;
   import feathers.core.PopUpManager;
   import feathers.data.VectorCollection;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-41c§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.GetDividendResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginErrorType;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-K3G§ extends §_-M2D§ implements §_-H2I§
   {
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      public function §_-K3G§()
      {
         super();
      }
      
      public function §_-xq§(param1:String) : void
      {
         var _loc2_:Function = null;
         var _loc3_:Boolean = false;
         var _loc4_:§_-SU§ = null;
         if(§_-6A§.§_-D21§(param1))
         {
            _loc2_ = §_-bs§.§_-d1Z§(this.§_-6C§,this);
            _loc3_ = §_-6A§.§_-a1w§(this.§_-2f§.userProfile,§_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§));
            _loc4_ = new §_-SU§(§_-8D§.§_-k2N§.price,_loc2_,§_-s2a§.CLAN_OP_TITLE_RENAME,_loc3_);
            _loc4_.§_-P1i§(param1);
            _loc4_.show();
         }
         else
         {
            §_-fH§.§_-q1a§(§_-s2a§.TITLE_ERROR,§_-s2a§.CHANGE_CLAN_NAME_FAILED,§_-fH§.§_-1B§);
         }
      }
      
      private function §_-6C§() : void
      {
         dispatchWith(§_-aG§.§_-w1v§);
      }
      
      public function §_-l1C§(param1:String) : void
      {
         var _loc3_:Function = null;
         var _loc4_:Boolean = false;
         var _loc5_:§_-L1N§ = null;
         var _loc2_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         if(param1 == _loc2_.clanDescription)
         {
            §_-fH§.§_-q1a§(§_-s2a§.TITLE_ERROR,§_-s2a§.CHANGE_CLAN_DESCRIPTION_FAILED,§_-fH§.§_-1B§);
         }
         else
         {
            _loc3_ = §_-bs§.§_-d1Z§(this.§_-oQ§,this);
            _loc4_ = §_-6A§.§_-a1w§(this.§_-2f§.userProfile,_loc2_);
            _loc5_ = new §_-L1N§(§_-8D§.§_-hP§.price,_loc3_,§_-s2a§.CLAN_OP_TITLE_CHANGE_DESCRIPTION,_loc4_);
            _loc5_.§_-c1g§(param1);
            _loc5_.show();
         }
      }
      
      private function §_-oQ§() : void
      {
         dispatchWith(§_-aG§.§_-U§);
      }
      
      public function §_-l2d§(param1:Vector.<uint>) : void
      {
         var _loc3_:Function = null;
         var _loc4_:Boolean = false;
         var _loc5_:§_-d2z§ = null;
         var _loc2_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         if(param1 == _loc2_.emblem)
         {
            §_-fH§.§_-q1a§(§_-s2a§.TITLE_ERROR,§_-s2a§.CHANGE_CLAN_EMBLEM_FAILED,§_-fH§.§_-1B§);
         }
         else
         {
            _loc3_ = §_-bs§.§_-d1Z§(this.§_-To§,this);
            _loc4_ = §_-6A§.§_-a1w§(this.§_-2f§.userProfile,_loc2_);
            _loc5_ = new §_-d2z§(§_-8D§.§_-K2G§.price,_loc3_,§_-s2a§.CLAN_OP_TITLE_CHANGE_EMBLEM,_loc4_);
            _loc5_.§_-932§(param1);
            _loc5_.show();
         }
      }
      
      private function §_-To§() : void
      {
         this.§_-2f§.§_-93C§();
         dispatchWith(§_-aG§.§_-02p§);
      }
      
      public function §_-G1k§(param1:int) : void
      {
         var _loc3_:Function = null;
         var _loc2_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         if(param1 == _loc2_.joinRating)
         {
            §_-fH§.§_-q1a§(§_-s2a§.TITLE_ERROR,§_-s2a§.CHANGE_CLAN_DESCRIPTION_FAILED,§_-fH§.§_-1B§);
         }
         else
         {
            _loc3_ = §_-bs§.§_-d1Z§(this.§_-G3§,this);
            §_-X1j§.§_-hl§.edit.§_-G1k§(param1,_loc3_);
         }
      }
      
      private function §_-G3§() : void
      {
         dispatchWith(§_-aG§.§_-S2i§);
      }
      
      public function §_-G3T§(param1:Boolean) : void
      {
         var _loc3_:Function = null;
         var _loc2_:ClanTO = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         if(param1 == _loc2_.isExitClosed)
         {
            §_-fH§.§_-q1a§(§_-s2a§.TITLE_ERROR,§_-s2a§.CHANGE_CLAN_DESCRIPTION_FAILED,§_-fH§.§_-1B§);
         }
         else
         {
            _loc3_ = §_-bs§.§_-d1Z§(this.§_-H2k§,this);
            §_-X1j§.§_-hl§.edit.§_-N2a§(param1,_loc3_);
         }
      }
      
      private function §_-H2k§() : void
      {
         dispatchWith(§_-aG§.§_-f2U§);
      }
      
      public function §_-H1R§() : void
      {
         var _loc1_:ClanTO = null;
         var _loc2_:int = 0;
         var _loc4_:Function = null;
         var _loc5_:Boolean = false;
         var _loc6_:§_-52j§ = null;
         _loc1_ = §_-A23§.§_-Y1d§(this.§_-2f§.§_-C2Y§);
         _loc2_ = _loc1_.level + 1;
         var _loc3_:§_-92Q§ = §_-92Q§.§_-KT§(_loc2_);
         if(!_loc3_)
         {
            §_-fH§.§_-q1a§(§_-s2a§.TITLE_ERROR,§_-s2a§.CHANGE_CLAN_EMBLEM_FAILED,§_-fH§.§_-1B§);
         }
         else
         {
            _loc4_ = §_-bs§.§_-d1Z§(this.§_-A3q§,this);
            _loc5_ = §_-6A§.§_-a1w§(this.§_-2f§.userProfile,_loc1_);
            _loc6_ = new §_-52j§(_loc3_.priceInfo.price,_loc4_,§_-s2a§.CLAN_OP_TITLE_EXPAND_CAPACITY,_loc5_);
            _loc6_.show();
         }
      }
      
      private function §_-A3q§(param1:Boolean = true) : void
      {
         dispatchWith(§_-aG§.§_-55§);
      }
      
      public function §_-73X§(param1:int) : void
      {
         var dialog:ClanChangeMedalCostDialog = null;
         var price:int = param1;
         if(price >= §_-8D§.§_-R14§)
         {
            dialog = new ClanChangeMedalCostDialog(price,function():void
            {
               §_-X1j§.§_-hl§.treasury.§_-73X§(price,§_-Kw§);
            });
            dialog.show();
         }
      }
      
      private function §_-Kw§(param1:Boolean) : void
      {
         this.§_-2f§.§_-93C§();
      }
   }
}


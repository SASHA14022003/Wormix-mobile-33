package §_-f1o§
{
   public interface §_-k2c§
   {
      
      function §_-u2B§(param1:int) : void;
      
      function §_-o1s§() : void;
      
      function §_-WX§() : void;
      
      function §_-S1W§(param1:String) : void;
   }
}


package §_-f1o§
{
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   
   public interface §_-p2X§
   {
      
      function §_-s2z§(param1:String, param2:String, param3:Vector.<uint>, param4:int) : void;
      
      function §_-a2r§(param1:ClanTO, param2:ClanInviteStructure) : void;
      
      function §_-Vj§() : void;
      
      function §_-61P§(param1:int) : void;
   }
}


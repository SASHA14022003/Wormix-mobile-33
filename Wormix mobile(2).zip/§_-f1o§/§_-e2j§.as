package §_-f1o§
{
   import §_-31W§.AchievLevelUpMessage;
   import §_-31W§.§_-8§;
   import §_-31W§.§_-c2J§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-L1r§;
   import §_-71F§.§_-M2D§;
   import §_-73d§.§_-pT§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-p2U§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-T2G§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.*;
   import §_-H16§.*;
   import §_-K3q§.§_-L3A§;
   import §_-L1w§.§_-J2w§;
   import §_-N8§.§_-o2w§;
   import §_-P1z§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-Zi§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.§_-Z25§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-A1s§;
   import com.worlize.websocket.§_-03n§;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import flash.events.TimerEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.core.Starling;
   import starling.display.Stage;
   import starling.events.Event;
   
   public class §_-e2j§ extends §_-M2D§ implements §_-p2X§
   {
      
      [Inject]
      public var §_-2f§:§_-J2w§;
      
      public function §_-e2j§()
      {
         super();
      }
      
      public function §_-s2z§(param1:String, param2:String, param3:Vector.<uint>, param4:int) : void
      {
         var cc:§_-Z25§ = null;
         var name:String = param1;
         var description:String = param2;
         var emblem:Vector.<uint> = param3;
         var minRating:int = param4;
         cc = §_-X1j§.§_-hl§;
         cc.login.§_-s2z§(name,emblem,description,function():void
         {
            var completeCallback:Function = function():void
            {
               dispatchWith(§_-aG§.§_-A1i§);
            };
            if(minRating > -1)
            {
               cc.edit.§_-G1k§(minRating,completeCallback);
            }
            else
            {
               completeCallback();
            }
         });
      }
      
      public function §_-a2r§(param1:ClanTO, param2:ClanInviteStructure) : void
      {
         var _loc5_:String = null;
         var _loc3_:String = param2 ? §_-s2a§.§_-K3t§(§_-s2a§.INVITE_CONFIRMATION_TITLE) : §_-s2a§.§_-K3t§(§_-s2a§.JOIN_CLAN_CONFIRMATION_TITLE);
         var _loc4_:String = param2 ? §_-s2a§.INVITE_CONFIRMATION_TEXT : §_-s2a§.JOIN_CLAN_CONFIRMATION_TEXT;
         _loc4_ = StringUtil.format(_loc4_,{"clanName":param1.name});
         if(param1.isExitClosed)
         {
            _loc4_ = StringUtil.format(§_-s2a§.JOIN_TO_EXIT_CLOSED_CLAN,{"count":§_-8D§.§_-2l§}) + " " + _loc4_;
         }
         if(Application.userProfile.getLevel() < §_-8D§.§_-v3§)
         {
            _loc5_ = StringUtil.format(§_-s2a§.CLAN_JOIN_DISABLE_BY_LEVEL,{"value":§_-8D§.§_-v3§});
            §_-fH§.§_-h2r§(_loc3_,_loc5_);
         }
         else
         {
            §_-fH§.§_-F3p§(_loc3_,_loc4_,§_-fH§.§_-X2g§,§_-bs§.§_-d1Z§(this.§_-n22§,this,[param1,param2])).show();
         }
      }
      
      private function §_-n22§(param1:ClanTO, param2:ClanInviteStructure) : void
      {
         var clan:ClanTO = param1;
         var invite:ClanInviteStructure = param2;
         var id:uint = invite ? invite.profileId : 0;
         §_-X1j§.§_-hl§.login.§_-41i§(clan.id,id,function():void
         {
            dispatchWith(§_-aG§.§_-91N§);
         });
      }
      
      public function §_-Vj§() : void
      {
         §_-X1j§.§_-hl§.common.§_-41A§(this.§_-UN§);
      }
      
      private function §_-UN§() : void
      {
         dispatchWith(§_-aG§.§_-jf§);
         this.§_-2f§.clear();
      }
      
      public function §_-61P§(param1:int) : void
      {
         §_-X1j§.§_-hl§.treasury.§_-61U§(param1,this.§_-Zs§);
      }
      
      private function §_-Zs§() : void
      {
      }
   }
}


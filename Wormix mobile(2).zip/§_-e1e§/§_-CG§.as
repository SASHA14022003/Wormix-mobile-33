package §_-e1e§
{
   import §_-12W§.§_-221§;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-J2l§;
   import §_-N8§.§_-o2w§;
   import §_-O2L§.§_-13p§;
   import §_-Z1w§.§_-w1D§;
   import §_-l1g§.§_-F1X§;
   import §_-r1C§.§_-h2B§;
   import §_-wD§.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import flash.errors.IllegalOperationError;
   import flash.events.FullScreenEvent;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.messages.server.IncreaseAchievementResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-CG§
   {
      
      private static var §_-i1N§:§_-CG§;
      
      public function §_-CG§()
      {
         super();
      }
      
      public static function init() : void
      {
         if(!§_-i1N§)
         {
            §_-i1N§ = new §_-CG§();
         }
      }
      
      private function §_-f4§(param1:FullScreenEvent) : void
      {
         §_-13p§.§_-f4§();
      }
   }
}


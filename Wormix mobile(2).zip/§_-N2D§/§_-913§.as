package §_-N2D§
{
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-D3A§.§_-DI§;
   import §_-DJ§.§_-fH§;
   import §_-fo§.§_-r5§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-z1g§.§_-lp§;
   import com.distriqt.extension.inappbilling.Purchase;
   import feathers.controls.LayoutGroup;
   import flash.display.MovieClip;
   import flash.events.TimerEvent;
   import flash.system.Capabilities;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.email.EmptyEmailSender;
   import ru.pragmatix.flox.social.email.IEmailSender;
   import ru.pragmatix.flox.social.email.MobileEmailSender;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.pvp.messages.client.BattleReconnect;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.display.Sprite;
   import starling.events.EventDispatcher;
   
   public class §_-913§
   {
      
      public function §_-913§()
      {
         super();
      }
      
      public static function create(param1:String, param2:int) : §_-o2y§
      {
         return new §_-e2b§(param1,param2);
      }
   }
}


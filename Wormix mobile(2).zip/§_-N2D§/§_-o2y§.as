package §_-N2D§
{
   public interface §_-o2y§
   {
      
      function §_-C22§() : Boolean;
      
      function §_-F1Z§(param1:Function) : void;
      
      function §_-R1v§(param1:Function) : void;
      
      function dispose() : void;
   }
}


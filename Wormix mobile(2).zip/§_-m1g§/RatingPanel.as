package §_-m1g§
{
   import §_-12a§.§_-41b§;
   import §_-533§.§_-c2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-73I§.§_-q15§;
   import §_-A2U§.*;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-V1Y§;
   import §_-G3w§.*;
   import §_-H16§.*;
   import §_-Ly§.§_-81L§;
   import §_-Z1K§.§_-q24§;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import com.hurlant.crypto.tls.§_-21v§;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.TabBar;
   import feathers.core.FeathersControl;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import flash.display.StageOrientation;
   import flash.events.StageOrientationEvent;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.WidenSearch;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.ammo.DynamiteStick;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   
   public class RatingPanel extends §_-V1Y§
   {
      
      private var binder:Binder;
      
      private var §_-E1k§:ScreenNavigator;
      
      public function RatingPanel()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("ratings-window",this.binder);
         addChild(this.binder._container);
         this.§_-A28§(this.binder._tabBar);
         this.§_-E1k§ = new ScreenNavigator();
         this.§_-E1k§.layoutData = new AnchorLayoutData(0,0,0,0);
         this.binder._screen.addChild(this.§_-E1k§);
         var _loc1_:ScreenNavigatorItem = new ScreenNavigatorItem(YesterdayRatingScreen);
         var _loc2_:ScreenNavigatorItem = new ScreenNavigatorItem(TodayRatingScreen);
         var _loc3_:ScreenNavigatorItem = new ScreenNavigatorItem(GlobalRatingScreen);
         var _loc4_:ScreenNavigatorItem = new ScreenNavigatorItem(TopClanRatingScreen);
         this.§_-E1k§.addScreen(§_-N1y§.§_-D37§.toString(),_loc1_);
         this.§_-E1k§.addScreen(§_-N1y§.§_-gA§.toString(),_loc2_);
         this.§_-E1k§.addScreen(§_-N1y§.§_-83T§.toString(),_loc3_);
         this.§_-E1k§.addScreen(§_-N1y§.§_-23L§.toString(),_loc4_);
         §_-Sc§ = §_-d27§.§_-S2s§;
         this.setData();
         §_-J2N§(this.binder._closeButton,Event.TRIGGERED,§_-R1t§);
         §_-J2N§(this.binder._tabBar,Event.CHANGE,this.§_-d11§);
         §_-J2N§(this.binder._tabBar,Event.TRIGGERED,this.§_-Zw§);
         this.§_-d11§(null);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._closeButton,Event.TRIGGERED);
         §_-jg§(this.binder._tabBar,Event.CHANGE);
         §_-jg§(this.binder._tabBar,Event.TRIGGERED);
      }
      
      private function §_-A28§(param1:TabBar) : void
      {
         param1.paddingTop = 10;
         param1.gap = 5;
         param1.distributeTabSizes = false;
         param1.direction = Direction.HORIZONTAL;
         param1.horizontalAlign = HorizontalAlign.LEFT;
         param1.tabProperties.width = 150;
      }
      
      private function setData() : void
      {
         var _loc1_:ArrayCollection = new ArrayCollection([{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.RATING_YESTERDAY),
            "type":§_-N1y§.§_-D37§,
            "color_1":14217847,
            "color_2":13692012
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.RATING_TO_DAY),
            "type":§_-N1y§.§_-gA§,
            "color_1":11525631,
            "color_2":7981055
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.RATING_ALL_TIME),
            "type":§_-N1y§.§_-83T§,
            "color_1":16759931,
            "color_2":16758133
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.RATING_CLANS),
            "type":§_-N1y§.§_-23L§,
            "color_1":16759931,
            "color_2":16758133
         }]);
         this.binder._tabBar.dataProvider = _loc1_;
         this.binder._tabBar.selectedIndex = 1;
      }
      
      private function §_-d11§(param1:Event) : void
      {
         var _loc2_:Object = this.binder._tabBar.selectedItem;
         if(_loc2_)
         {
            this.§_-E1k§.showScreen(_loc2_.type.toString());
         }
      }
      
      private function §_-Zw§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-D1q§);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;
import feathers.controls.TabBar;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _screen:LayoutGroup;
   
   public var _panel:Panel;
   
   public var _tabBar:TabBar;
   
   public var _closeButton:Button;
   
   public function Binder()
   {
      super();
   }
}

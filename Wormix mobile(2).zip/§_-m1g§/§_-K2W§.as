package §_-m1g§
{
   import §_-62§.§_-W1r§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-b1k§;
   import §_-j1w§.§_-B2i§;
   import §_-l1K§.§_-cZ§;
   import §_-z1g§.*;
   import config.§_-V2w§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   
   public class §_-K2W§
   {
      
      public static const §_-8b§:int = 0;
      
      public static const DUEL_15:int = 1;
      
      public static const DUEL_50:int = 2;
      
      public static const DUEL_300:int = 3;
      
      public static const §_-Ss§:int = 4;
      
      public static const §_-31U§:int = 5;
      
      public static const §_-at§:int = 6;
      
      public static const §_-I0§:int = 7;
      
      public static const §_-U2§:int = 8;
      
      public static const §_-p1S§:int = 10;
      
      public static const §_-c1§:int = 11;
      
      public static const PVE_FRIEND:int = 12;
      
      public static const PVE_PARTNER:int = 14;
      
      public static const §_-i2I§:int = 15;
      
      public static const §_-h2I§:int = 16;
      
      public static const §_-C3Y§:int = 17;
      
      public function §_-K2W§()
      {
         super();
      }
   }
}


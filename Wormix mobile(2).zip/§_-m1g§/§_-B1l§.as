package §_-m1g§
{
   import §_-A1K§.§_-TA§;
   import §_-CR§.§_-72p§;
   import §_-P1z§.*;
   import §_-bI§.§_-E8§;
   import §_-bI§.§_-n2F§;
   import §_-jF§.MinimalRatingLineItemRenderer;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-F4§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.layout.Direction;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import starling.events.Event;
   import starling.events.TouchEvent;
   import starling.textures.Texture;
   
   public class §_-B1l§
   {
      
      private var §_-GT§:§_-72p§;
      
      public function §_-B1l§(param1:List, param2:int)
      {
         var layout:VerticalLayout;
         var regularRendererClass:Class;
         var regularItemFactory:Function;
         var minRatingLinItemFactory:Function;
         var list:List = param1;
         var ratingType:int = param2;
         super();
         layout = new VerticalLayout();
         list.layout = layout;
         list.verticalScrollPolicy = ScrollPolicy.AUTO;
         list.horizontalScrollPolicy = ScrollPolicy.OFF;
         list.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         regularRendererClass = ratingType == §_-N1y§.§_-83T§ ? §_-E8§ : §_-n2F§;
         regularItemFactory = function():IListItemRenderer
         {
            return new regularRendererClass();
         };
         minRatingLinItemFactory = function():IListItemRenderer
         {
            return new MinimalRatingLineItemRenderer();
         };
         list.setItemRendererFactoryWithID("regular-item",regularItemFactory);
         list.setItemRendererFactoryWithID("min-rating-line",minRatingLinItemFactory);
         list.factoryIDFunction = function(param1:Object, param2:int):String
         {
            if(Boolean(param1) && param1.rps != null)
            {
               return "regular-item";
            }
            return "min-rating-line";
         };
         this.§_-GT§ = new §_-72p§(list,§_-9t§,[RelativePosition.BOTTOM,RelativePosition.TOP],true,Direction.VERTICAL);
      }
      
      private static function §_-9t§(param1:Object) : int
      {
         var _loc2_:RatingProfileStructure = null;
         if(Boolean(param1) && Boolean(param1.rps))
         {
            _loc2_ = param1.rps as RatingProfileStructure;
            if(_loc2_)
            {
               return _loc2_.id;
            }
         }
         return 0;
      }
      
      private static function §_-H2L§(param1:Object) : int
      {
         var _loc2_:RatingProfileStructure = null;
         if(Boolean(param1) && Boolean(param1.rps))
         {
            _loc2_ = param1.rps as RatingProfileStructure;
            if(!_loc2_)
            {
            }
         }
         return 0;
      }
      
      public function dispose() : void
      {
         this.§_-GT§.dispose();
      }
   }
}


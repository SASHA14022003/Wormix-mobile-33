package §_-m1g§
{
   import §_-21p§.§_-4w§;
   import §_-51p§.§_-W2e§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-bI§.ClanRatingItemRenderer;
   import §_-hO§.SupplyPickedUpEvent;
   import §_-jF§.MinimalRatingLineItemRenderer;
   import §_-l1g§.§_-L3Q§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.utils.Pool;
   
   public class §_-I30§
   {
      
      public function §_-I30§(param1:List)
      {
         var layout:VerticalLayout;
         var regularItemFactory:Function;
         var minRatingLinItemFactory:Function;
         var list:List = param1;
         super();
         layout = new VerticalLayout();
         layout.hasVariableItemDimensions = true;
         list.layout = layout;
         list.verticalScrollPolicy = ScrollPolicy.AUTO;
         list.horizontalScrollPolicy = ScrollPolicy.OFF;
         list.itemRendererType = ClanRatingItemRenderer;
         list.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         regularItemFactory = function():IListItemRenderer
         {
            return new ClanRatingItemRenderer();
         };
         minRatingLinItemFactory = function():IListItemRenderer
         {
            return new MinimalRatingLineItemRenderer();
         };
         list.setItemRendererFactoryWithID("regular-item",regularItemFactory);
         list.setItemRendererFactoryWithID("min-rating-line",minRatingLinItemFactory);
         list.factoryIDFunction = function(param1:Object, param2:int):String
         {
            if(Boolean(param1) && param1.clan != null)
            {
               return "regular-item";
            }
            return "min-rating-line";
         };
      }
   }
}


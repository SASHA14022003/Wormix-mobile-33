package §_-F2M§
{
   import §_-11L§.Archdemon;
   import §_-11L§.Hacker;
   import §_-11L§.Paladin;
   import §_-11L§.Phantoms;
   import §_-11L§.Thieves;
   import §_-11L§.§_-P25§;
   import §_-12a§.KamikazeBuff;
   import §_-21p§.§_-N1H§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-91A§.*;
   import §_-91B§.§_-QK§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-H16§.*;
   import §_-L2F§.§_-D2p§;
   import §_-RE§.*;
   import §_-Ta§.*;
   import §_-U1Y§.*;
   import §_-Y1O§.§_-42h§;
   import §_-Yk§.*;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-s1s§.TeamRoomTeammateItemRenderer;
   import §_-s1s§.§_-62d§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-y1S§;
   import com.greensock.loading.core.*;
   import com.hurlant.math.BigInteger;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ArrayCollection;
   import flash.net.URLRequest;
   import flash.net.URLVariables;
   import flash.utils.ByteArray;
   import flash.utils.getDefinitionByName;
   import org.swiftsuspenders.Injector;
   import org.swiftsuspenders.§_-71M§;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   
   public class §_-pR§
   {
      
      private var §_-W11§:ArrayCollection;
      
      public function §_-pR§(param1:Sprite)
      {
         var _loc3_:TeamRoomTeammateItemRenderer = null;
         var _loc4_:Sprite = null;
         super();
         this.§_-W11§ = new ArrayCollection();
         var _loc2_:int = param1.numChildren;
         var _loc5_:int = 0;
         while(_loc5_ < _loc2_)
         {
            _loc4_ = param1.getChildAt(_loc5_) as Sprite;
            _loc3_ = new TeamRoomTeammateItemRenderer();
            _loc4_.addChild(_loc3_);
            this.§_-W11§.addItemAt(_loc3_,_loc5_);
            _loc5_++;
         }
      }
      
      private static function §_-82G§(param1:Array, param2:int, param3:§_-x2M§) : int
      {
         var _loc6_:§_-N1H§ = null;
         var _loc7_:UserProfile = null;
         var _loc8_:Boolean = false;
         var _loc4_:int = 0;
         var _loc5_:* = int(param1.length);
         while(_loc5_--)
         {
            _loc7_ = param1[_loc5_] as UserProfile;
            _loc8_ = §_-71v§.§_-Q19§(_loc7_.§_-t2I§());
            if(!(_loc7_.getId() == param2 || !_loc7_.§_-H38§()))
            {
               if(_loc7_.getHat())
               {
                  _loc6_ = _loc7_.getHat().§_-V1v§(_loc8_);
                  if(_loc6_.§_-yQ§(param3))
                  {
                     _loc4_ += _loc6_.§_-k2Q§(param3).getValue();
                  }
               }
               if(_loc7_.§_-32q§())
               {
                  _loc6_ = _loc7_.§_-32q§().§_-V1v§(_loc8_);
                  if(_loc6_.§_-yQ§(param3))
                  {
                     _loc4_ += _loc6_.§_-k2Q§(param3).getValue();
                  }
               }
            }
         }
         return _loc4_;
      }
      
      public function dispose() : void
      {
         this.§_-W11§ = null;
      }
      
      public function §_-82v§(param1:UserProfile, param2:Boolean) : void
      {
         var _loc6_:DefaultListItemRenderer = null;
         var _loc7_:UserProfile = null;
         var _loc8_:int = 0;
         var _loc9_:int = 0;
         var _loc10_:§_-62d§ = null;
         var _loc3_:Array = param1.§_-A1U§();
         var _loc4_:int = int(_loc3_.length);
         var _loc5_:int = 0;
         while(_loc5_ < this.§_-W11§.length)
         {
            _loc6_ = this.§_-W11§.getItemAt(_loc5_) as DefaultListItemRenderer;
            _loc7_ = _loc4_ > _loc5_ ? _loc3_[_loc5_] : null;
            _loc8_ = _loc7_ ? §_-82G§(_loc3_,_loc7_.getId(),§_-x2M§.SQUAD_ATTACK) : 0;
            _loc9_ = _loc7_ ? §_-82G§(_loc3_,_loc7_.getId(),§_-x2M§.SQUAD_ARMOR) : 0;
            _loc10_ = new §_-62d§();
            _loc10_.teamOwner = param1;
            _loc10_.§_-9S§ = param2;
            _loc10_.§_-Q3§ = _loc5_;
            _loc10_.§_-x2P§ = _loc4_;
            _loc10_.teammate = _loc7_;
            _loc10_.bonusAttack = _loc8_;
            _loc10_.§_-v2n§ = _loc9_;
            _loc6_.data = _loc10_;
            _loc5_++;
         }
         this.§_-W11§.updateAll();
      }
      
      public function §_-w1S§() : ArrayCollection
      {
         return this.§_-W11§;
      }
   }
}


package §_-F2M§
{
   import §_-43V§.Random;
   import §_-62§.*;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-Bv§.§_-G3P§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-f1G§.*;
   import §_-j1w§.§_-lD§;
   import §_-l1g§.§_-L3Q§;
   import §_-s1s§.TeamRoomTeammateItemRenderer;
   import §_-s1s§.§_-62d§;
   import §_-s1s§.§_-A1o§;
   import com.hurlant.math.BigInteger;
   import feathers.core.FeathersControl;
   import feathers.data.ArrayCollection;
   import flash.errors.IllegalOperationError;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   use namespace gestouch_internal;
   
   public class §_-Z2m§
   {
      
      private var §_-W11§:ArrayCollection;
      
      public function §_-Z2m§(param1:ArrayCollection)
      {
         var _loc2_:TeamRoomTeammateItemRenderer = null;
         super();
         this.§_-W11§ = param1;
         var _loc3_:int = 0;
         while(_loc3_ < this.§_-W11§.length)
         {
            _loc2_ = this.§_-W11§.getItemAt(_loc3_) as TeamRoomTeammateItemRenderer;
            _loc2_.addEventListener(§_-A1o§.CHANGE,this.§_-O1L§);
            _loc2_.addEventListener(§_-A1o§.ADD,this.§_-O1L§);
            _loc2_.addEventListener(§_-A1o§.TOGGLE_ACTIVITY,this.§_-O1L§);
            _loc2_.addEventListener(§_-A1o§.REORDER,this.§_-O1L§);
            _loc3_++;
         }
      }
      
      public function dispose() : void
      {
         this.§_-W11§ = null;
      }
      
      private function §_-O1L§(param1:Event) : void
      {
         var _loc4_:ChooseTeammateMenu = null;
         var _loc2_:TeamRoomTeammateItemRenderer = param1.target as TeamRoomTeammateItemRenderer;
         if(!_loc2_)
         {
            return;
         }
         var _loc3_:§_-62d§ = _loc2_.data as §_-62d§;
         if(_loc3_)
         {
            switch(param1.type)
            {
               case §_-A1o§.TOGGLE_ACTIVITY:
                  §_-X1j§.§_-D3H§.§_-X17§(_loc3_.teammate,param1.data as Boolean,§_-bs§.§_-d1Z§(this.§_-93n§,this,[_loc2_],true));
                  break;
               case §_-A1o§.CHANGE:
                  _loc4_ = new ChooseTeammateMenu(_loc3_.teammate);
                  break;
               case §_-A1o§.ADD:
                  _loc4_ = new ChooseTeammateMenu();
                  break;
               case §_-A1o§.REORDER:
                  §_-X1j§.§_-D3H§.§_-iF§(_loc3_.teamOwner,param1.data[0],param1.data[1],null);
            }
         }
         if(_loc4_)
         {
            _loc4_.show();
         }
      }
      
      private function §_-93n§(param1:Boolean, param2:TeamRoomTeammateItemRenderer) : void
      {
         var _loc3_:§_-62d§ = null;
         var _loc4_:Boolean = false;
         var _loc5_:int = 0;
         if(param1)
         {
            _loc3_ = param2.data as §_-62d§;
            if(_loc3_)
            {
               _loc4_ = _loc3_.teammate.§_-H38§();
               (_loc3_.teamOwner.§_-A1U§()[_loc3_.§_-Q3§] as UserProfile).§_-Ox§(!_loc4_);
               _loc3_.teammate.§_-Ox§(!_loc4_);
               _loc5_ = this.§_-W11§.getItemIndex(_loc3_);
               this.§_-W11§.updateItemAt(_loc5_);
               param2.invalidate(FeathersControl.INVALIDATION_FLAG_DATA);
            }
         }
         else
         {
            §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_SAVING));
         }
      }
   }
}


package §_-73I§
{
   import §_-12a§.§_-B16§;
   import §_-51p§.§_-W2e§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-73d§.§_-V19§;
   import §_-A1K§.§_-TA§;
   import §_-C2M§.§_-u2T§;
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-RE§.§_-r2q§;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-YF§.§_-N3§;
   import §_-Z1K§.§_-q24§;
   import §_-hO§.§_-729§;
   import §_-hO§.§_-v24§;
   import §_-jF§.VipDescriptionFeatureRenderer;
   import §_-l1K§.§_-N1Z§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-nE§.§_-p16§;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-03r§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-y1S§;
   import com.amanitadesign.steam.SteamConstants;
   import com.amanitadesign.steam.SteamEvent;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import feathers.layout.VerticalAlign;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.social.utils.id.GetAuthKeyEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.NotInClanChatScreen;
   import ru.pragmatix.wormix.gui.menu.clans.chat.§_-D2t§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.Canvas;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starlingbuilder.extensions.uicomponents.CustomLabel;
   
   public class §_-K2s§
   {
      
      public static const §_-J1o§:uint = 0;
      
      public static const §_-r2F§:uint = 1;
      
      public static const §_-U2V§:String = "default";
      
      private var container:Sprite;
      
      protected var §_-716§:Sprite;
      
      protected var §_-o2V§:Sprite;
      
      protected var §_-L2A§:Sprite;
      
      protected var §_-k24§:Sprite;
      
      protected var §_-fD§:Sprite;
      
      protected var direction:Direction = Direction.LEFT;
      
      protected var §_-n2h§:String = "";
      
      protected var scale:Number;
      
      protected var armature:§_-di§;
      
      protected var raceName:String;
      
      protected var disposed:Boolean = false;
      
      private var §_-Q1Y§:Vector.<Vector.<§_-Y1l§>> = new <Vector.<§_-Y1l§>>[new Vector.<§_-Y1l§>(0),new Vector.<§_-Y1l§>(0)];
      
      private var §_-b1l§:Vector.<ColorTransform>;
      
      private var §_-LT§:Boolean = false;
      
      protected var oldX:Number;
      
      protected var oldY:Number;
      
      protected var §_-E1§:Direction;
      
      protected var §_-r2S§:Number;
      
      public function §_-K2s§(param1:Sprite, param2:String, param3:Number = 1)
      {
         super();
         this.container = param1;
         this.§_-L2A§ = new Sprite();
         this.§_-716§ = new Sprite();
         this.§_-o2V§ = new Sprite();
         this.§_-k24§ = new Sprite();
         this.§_-k24§.addChild(this.§_-L2A§);
         this.§_-k24§.addChild(this.§_-716§);
         this.§_-fD§ = new Sprite();
         this.§_-fD§.addChild(this.§_-o2V§);
         param1.addChild(this.§_-k24§);
         param1.addChild(this.§_-fD§);
         this.scale = param3;
         this.raceName = param2 == "robot" ? "bot" : param2;
         this.createArmature();
      }
      
      protected function createArmature() : void
      {
         this.armature = §_-K1t§.buildArmature("chars/" + this.§_-LM§(),null,§_-K1t§.§_-IP§);
         this.§_-L2A§.addChild(this.armature.display);
         WorldClock.clock.add(this.armature);
      }
      
      protected function §_-LM§() : String
      {
         return this.raceName.substr(0,1).toUpperCase() + this.raceName.substr(1);
      }
      
      public function getContainer() : Sprite
      {
         return this.container;
      }
      
      public function §_-63t§() : Sprite
      {
         return this.§_-k24§;
      }
      
      public function set x(param1:Number) : void
      {
         this.container.x = param1;
      }
      
      public function set y(param1:Number) : void
      {
         this.container.y = param1;
      }
      
      public function get x() : Number
      {
         return this.container.x;
      }
      
      public function get y() : Number
      {
         return this.container.y;
      }
      
      public function §_-r2n§(param1:Boolean) : void
      {
         if(!this.armature || !this.armature.display)
         {
            return;
         }
         if(param1 && !WorldClock.clock.contains(this.armature))
         {
            WorldClock.clock.add(this.armature);
         }
         if(!param1 && WorldClock.clock.contains(this.armature))
         {
            WorldClock.clock.remove(this.armature);
         }
         if(!this.armature.display.visible)
         {
            this.armature.display.visible = true;
         }
      }
      
      public function turnLeft() : void
      {
         this.§_-n1s§(Direction.LEFT);
      }
      
      public function turnRight() : void
      {
         this.§_-n1s§(Direction.RIGHT);
      }
      
      private function §_-n1s§(param1:Direction) : void
      {
         if(param1 != this.direction)
         {
            §_-c1S§.§_-CC§(this.§_-L2A§);
         }
         this.direction = param1;
      }
      
      protected function play(param1:String, param2:Boolean = false, param3:Boolean = true) : int
      {
         if(this.§_-n2h§ == param1)
         {
            if(param2)
            {
               this.playAnimation(param1.substr(this.raceName.length),param3);
            }
            return this.armature.animation.lastAnimationState.totalTime * 30;
         }
         this.§_-n2h§ = param1;
         this.playAnimation(param1.substr(this.raceName.length),param3);
         return this.armature.animation.lastAnimationState.totalTime * 30;
      }
      
      public function stop(param1:Boolean = false) : void
      {
         this.armature.stopAnimation();
      }
      
      protected function playAnimation(param1:String, param2:Boolean) : void
      {
         this.armature.playAnimation(param1,0,-1,param2 ? 0 : 1);
      }
      
      public function §_-oK§(param1:uint, param2:DisplayObject, param3:int = 0, param4:int = 0, param5:Boolean = true, param6:Boolean = true) : void
      {
         this.§_-o0§(new §_-Y1l§(param2,param3 + param2.x,param4 + param2.y,param6),param1,param5 && !this.§_-LT§);
      }
      
      public function §_-O1i§(param1:uint, param2:DisplayObject, param3:int = 0, param4:int = 0, param5:Boolean = true, param6:Boolean = true) : void
      {
         var _loc7_:§_-Y1l§ = new §_-Y1l§(param2,param3 + param2.x,param4 + param2.y,param6);
         _loc7_.§_-U1E§ = true;
         this.§_-o0§(_loc7_,param1,param5);
      }
      
      private function §_-o0§(param1:§_-Y1l§, param2:uint, param3:Boolean = true) : void
      {
         if(!this.§_-Q1Y§[param2])
         {
            this.§_-Q1Y§[param2] = new Vector.<§_-Y1l§>(0);
         }
         this.§_-Q1Y§[param2].push(param1);
         if(param3)
         {
            this.§_-q2f§(param1);
         }
      }
      
      public function §_-d2T§(param1:uint, param2:DisplayObject) : void
      {
         var _loc3_:int = 0;
         var _loc4_:Vector.<§_-Y1l§> = null;
         if(Boolean(this.§_-Q1Y§) && Boolean(this.§_-Q1Y§[param1]))
         {
            _loc4_ = this.§_-Q1Y§[param1];
            _loc3_ = 0;
            while(_loc3_ < _loc4_.length)
            {
               if(_loc4_[_loc3_].clip == param2)
               {
                  this.hideClip(_loc4_[_loc3_]);
                  break;
               }
               _loc3_++;
            }
            _loc4_.splice(_loc3_,1);
         }
      }
      
      public function colorTransform(param1:int, param2:int, param3:int, param4:int = 1) : void
      {
         if(!this.§_-b1l§)
         {
            this.§_-b1l§ = new Vector.<ColorTransform>();
         }
         var _loc5_:ColorTransform = new ColorTransform(1,1,1,param4,§_-MN§.§_-j1P§(param1),§_-MN§.§_-j1P§(param2),§_-MN§.§_-j1P§(param3));
         var _loc6_:int = this.§_-12P§(this.§_-b1l§,-_loc5_.redOffset,-_loc5_.greenOffset,-_loc5_.blueOffset);
         if(_loc6_ < 0)
         {
            this.§_-b1l§.push(_loc5_);
         }
         else
         {
            this.§_-b1l§.splice(_loc6_,1);
         }
         §_-MN§.§_-u1S§(this.§_-L2A§,this.§_-b1l§);
         §_-MN§.§_-u1S§(this.§_-716§,this.§_-b1l§);
      }
      
      private function §_-12P§(param1:Vector.<ColorTransform>, param2:int, param3:int, param4:int) : int
      {
         var _loc6_:ColorTransform = null;
         var _loc5_:* = int(param1.length);
         while(_loc5_--)
         {
            _loc6_ = param1[_loc5_];
            if(_loc6_.redOffset == param2 && _loc6_.greenOffset == param3 && _loc6_.blueOffset == param4)
            {
               return _loc5_;
            }
         }
         return _loc5_;
      }
      
      public function §_-3N§() : String
      {
         return this.§_-n2h§;
      }
      
      private function §_-q2f§(param1:§_-Y1l§) : Boolean
      {
         var _loc2_:Number = NaN;
         if(!param1.visible)
         {
            param1.visible = true;
            if(param1.§_-O2D§ && this.direction != param1.direction)
            {
               _loc2_ = param1.clip.rotation;
               param1.clip.rotation = 0;
               param1.clip.scaleY = param1.clip.scaleY * this.direction.value * param1.direction.value;
               param1.clip.rotation = _loc2_;
               param1.direction = this.direction;
            }
            param1.§_-01r§(this.direction,this.container.rotation);
            (param1.§_-U1E§ ? this.§_-o2V§ : this.§_-716§).addChild(param1.clip);
         }
         return false;
      }
      
      private function hideClip(param1:§_-Y1l§) : Boolean
      {
         if(param1.visible)
         {
            param1.visible = false;
            if(param1.clip.parent)
            {
               param1.clip.parent.removeChild(param1.clip);
            }
         }
         return false;
      }
      
      private function §_-F3v§(param1:§_-Y1l§, param2:Direction, param3:Number) : Boolean
      {
         param1.§_-01r§(param2,param3);
         return false;
      }
      
      private function §_-e2§(param1:§_-Y1l§) : Boolean
      {
         param1.dispose();
         return false;
      }
      
      public function §_-x29§(param1:uint = 0) : void
      {
         this.§_-LT§ = false;
         §_-F2L§.§_-11m§(this.§_-Q1Y§[param1],this.§_-q2f§);
      }
      
      public function §_-62C§(param1:uint = 0) : void
      {
         this.§_-LT§ = true;
         §_-F2L§.§_-11m§(this.§_-Q1Y§[param1],this.hideClip);
      }
      
      public function §_-u1s§() : void
      {
         var _loc1_:Number = -this.container.x;
         var _loc2_:Number = -this.container.y;
         var _loc3_:Number = this.container.rotation;
         if(_loc1_ == this.oldX && _loc2_ == this.oldY && this.direction == this.§_-E1§ && this.§_-r2S§ == _loc3_)
         {
            return;
         }
         this.oldX = _loc1_;
         this.oldY = _loc2_;
         this.§_-E1§ = this.direction;
         this.§_-r2S§ = _loc3_;
         §_-F2L§.§_-11m§(this.§_-Q1Y§[§_-J1o§],this.§_-F3v§,this.direction,_loc3_);
         §_-F2L§.§_-11m§(this.§_-Q1Y§[§_-r2F§],this.§_-F3v§,this.direction,_loc3_);
      }
      
      public function dispose() : void
      {
         §_-MN§.§_-PN§(this.getContainer());
         if(this.armature)
         {
            if(Boolean(WorldClock.clock) && WorldClock.clock.contains(this.armature))
            {
               WorldClock.clock.remove(this.armature);
            }
            this.armature.dispose();
            this.armature = null;
         }
         if(this.§_-L2A§)
         {
            this.§_-L2A§.dispose();
            this.§_-L2A§ = null;
         }
         if(this.container)
         {
            this.container.dispose();
            this.container = null;
         }
         §_-F2L§.§_-11m§(this.§_-Q1Y§[§_-J1o§],this.§_-e2§);
         §_-F2L§.§_-11m§(this.§_-Q1Y§[§_-r2F§],this.§_-e2§);
         this.§_-Q1Y§ = null;
         this.disposed = true;
      }
      
      public function getArmature() : §_-di§
      {
         return this.armature;
      }
   }
}


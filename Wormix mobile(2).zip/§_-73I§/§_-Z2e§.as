package §_-73I§
{
   import §_-12a§.§_-41b§;
   import §_-12a§.§_-c8§;
   import §_-31N§.§_-42G§;
   import §_-31W§.§_-42v§;
   import §_-51M§.Cat;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-zF§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.*;
   import §_-B2z§.*;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.§_-4I§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-S2O§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-P1z§.*;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.*;
   import §_-d26§.§_-d1H§;
   import §_-i1D§.*;
   import §_-j1w§.§_-B2i§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-d2j§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-n1w§.*;
   import §_-nZ§.*;
   import §_-p18§.§_-vd§;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.§_-W2D§;
   import §_-sQ§.§_-H3D§;
   import §_-t1J§.FastMissionCard;
   import §_-t1J§.HotSeatCard;
   import §_-t1J§.§_-B2R§;
   import §_-u1T§.LocalizationService;
   import §_-v2t§.§_-73F§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-wD§.*;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.*;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.hurlant.crypto.tls.*;
   import config.§_-B1K§;
   import config.§_-V2w§;
   import dragonBones.Bone;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ScrollPolicy;
   import feathers.core.PopUpManager;
   import feathers.data.VectorCollection;
   import flash.desktop.NativeApplication;
   import flash.errors.IllegalOperationError;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.media.SoundMixer;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import flash.utils.clearInterval;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.AbstractAuraEffect;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.request.edit.RenameClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.RenameClanResponse;
   import ru.pragmatix.wormix.messages.server.BuyResetBonusItemsResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.GenericPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   import starlingbuilder.extensions.uicomponents.ImageButton;
   
   public class §_-Z2e§ extends §_-K2s§
   {
      
      private static const §_-n1F§:String = "Artifact";
      
      private static const §_-q16§:String = "Hand";
      
      private static const §_-l6§:String = "Eyes";
      
      private static const §_-41P§:String = "Mouth";
      
      private static const §_-vT§:String = "LeftHand";
      
      private static const §_-z1d§:String = "RightHand";
      
      private static const §_-V18§:String = "Hat";
      
      private static const §_-xy§:String = "HotShield";
      
      private static const ANTIFROST:String = "AntiFrostShield";
      
      private static const §_-c2H§:String = "AttackShield";
      
      private static const §_-H3k§:String = "ArmoryShield";
      
      private static const §_-X2i§:Texture = Texture.empty(1,1);
      
      private const AMMO_ARMATURE_PREFIX:String = "resurces/_ammo/";
      
      protected var locked:Boolean = false;
      
      private var §_-b26§:§_-B2i§;
      
      private var hat:§_-zF§;
      
      private var artifact:§_-T1y§;
      
      private var §_-02a§:Boolean = true;
      
      private var §_-rz§:Boolean = true;
      
      private var §_-l13§:Boolean = true;
      
      private var §_-fh§:Boolean = true;
      
      private var §_-Z1S§:§_-di§;
      
      private var §_-eZ§:Sprite;
      
      private var §_-v11§:DisplayObject;
      
      private var §_-G1S§:§_-di§;
      
      private var §_-f1M§:§_-di§;
      
      private var §_-fW§:Boolean = true;
      
      private var §_-E2I§:Boolean = false;
      
      public function §_-Z2e§(param1:§_-B2i§ = null, param2:Number = 0.3333333333333333)
      {
         super(new Sprite(),param1.configName,param2);
         if(param1)
         {
            this.§_-Z1x§(param1);
         }
         armature.display.scaleX = armature.display.scaleY = param2;
      }
      
      public static function §_-v2s§(param1:String) : Image
      {
         var _loc2_:String = §_-J1v§(param1);
         var _loc3_:Image = new Image(Application.assetManager.getTexture(_loc2_));
         _loc3_.name = _loc2_;
         _loc3_.pivotX = _loc3_.width * 0.5;
         _loc3_.pivotY = _loc3_.height * 0.5;
         return _loc3_;
      }
      
      private static function §_-J1v§(param1:String) : String
      {
         var _loc2_:String = null;
         var _loc3_:String = param1;
         switch(_loc3_)
         {
            case §_-41b§.REGULAR:
               §§push(0);
               break;
            case §_-41b§.ARMORY:
               §§push(1);
               break;
            default:
               switch(_loc3_)
               {
                  case §_-41b§.ATTACK:
                     §§push(2);
                     break;
                  case §_-c8§.ANTIFROST:
                     §§push(3);
                     break;
                  default:
                     §§push(4);
               }
         }
         switch(§§pop())
         {
            case 0:
               _loc2_ = §_-xy§;
               break;
            case 1:
               _loc2_ = §_-H3k§;
               break;
            case 2:
               _loc2_ = §_-c2H§;
               break;
            case 3:
               _loc2_ = ANTIFROST;
         }
         return _loc2_;
      }
      
      public function §_-52m§() : String
      {
         return this.§_-b26§.configName;
      }
      
      public function §_-L§(param1:§_-zF§) : void
      {
         this.hat = param1;
         this.§_-V2h§();
      }
      
      public function §_-aV§(param1:§_-T1y§) : void
      {
         this.artifact = param1;
         this.§_-V2h§();
      }
      
      public function §_-Z1x§(param1:§_-B2i§) : void
      {
         this.§_-b26§ = param1;
         this.stay();
      }
      
      public function §_-J3Q§() : §_-B2i§
      {
         return this.§_-b26§;
      }
      
      public function stay() : void
      {
         this.§_-e2u§(this.§_-b26§.stayClip);
      }
      
      public function go() : void
      {
         this.§_-e2u§(this.§_-b26§.goClip);
      }
      
      public function damage() : uint
      {
         if(this.hat)
         {
            return this.§_-e2u§(this.§_-b26§.damageInHat);
         }
         return this.§_-e2u§(this.§_-b26§.damage);
      }
      
      public function §_-l1j§() : uint
      {
         return this.§_-e2u§(this.§_-b26§.prepareToJumpClip,true);
      }
      
      public function jump() : void
      {
         this.§_-e2u§(this.§_-b26§.jumpClip,true);
      }
      
      public function §_-pO§() : void
      {
         this.§_-e2u§(this.§_-b26§.endJumpClip,true);
      }
      
      public function §_-iU§() : void
      {
         this.§_-e2u§(this.§_-b26§.jumpBackClip,true);
      }
      
      public function §_-N1h§(param1:Boolean, param2:Boolean = false) : void
      {
         this.§_-E2I§ = param1;
         if(armature.display.visible)
         {
            this.§_-e2u§(param1 ? this.§_-b26§.sadClip : this.§_-b26§.breathClip,param2);
         }
      }
      
      public function §_-w2S§(param1:Boolean = false) : uint
      {
         var _loc3_:int = 0;
         var _loc2_:Array = this.hat ? this.§_-b26§.stateActionsInHat : this.§_-b26§.stateActions;
         if(Boolean(_loc2_) && Boolean(_loc2_.length))
         {
            _loc3_ = int(Math.floor(Math.random() * (_loc2_.length - 1)));
            return this.§_-e2u§(_loc2_[_loc3_],false,param1);
         }
         return 0;
      }
      
      public function §_-i29§() : uint
      {
         return this.§_-e2u§(this.§_-b26§.clapClip);
      }
      
      public function jetpack() : void
      {
         this.§_-e2u§(this.§_-b26§.jetpack);
      }
      
      public function jetpackStay() : void
      {
         this.§_-e2u§(this.§_-b26§.jetpackStay);
      }
      
      public function hammer(param1:Texture) : uint
      {
         return this.§_-ls§(this.§_-b26§.hammer,param1);
      }
      
      public function bat(param1:Texture, param2:int, param3:int) : uint
      {
         return this.§_-ls§(this.§_-b26§.bat,param1,param2,param3,true);
      }
      
      public function rope(param1:Texture) : uint
      {
         return this.§_-ls§(this.§_-b26§.rope,param1);
      }
      
      private function §_-ls§(param1:String, param2:Texture, param3:int = 0, param4:int = 0, param5:Boolean = false) : uint
      {
         var _loc6_:Slot = armature.getBone("Weapon").slot;
         _loc6_.offset.x = param3;
         _loc6_.offset.y = param4;
         var _loc7_:uint = uint(this.§_-e2u§(param1,true,false));
         var _loc8_:Image = _loc6_.display as Image;
         _loc8_.texture = param2;
         if(param5)
         {
            _loc8_.readjustSize();
         }
         return _loc7_;
      }
      
      public function §_-310§() : void
      {
         if(this.§_-Z1S§ != null)
         {
            return;
         }
         this.§_-Z1S§ = §_-K1t§.buildArmature("shocker_unit");
         WorldClock.clock.add(this.§_-Z1S§);
         this.§_-Z1S§.playAnimation(§_-K1t§.§_-Y1c§,0,-1,0);
         getContainer().addChild(this.§_-Z1S§.display);
      }
      
      public function §_-41n§() : void
      {
         if(this.§_-Z1S§ == null)
         {
            return;
         }
         this.§_-Z1S§.display.removeFromParent();
         WorldClock.clock.remove(this.§_-Z1S§);
         this.§_-Z1S§.dispose();
         this.§_-Z1S§ = null;
      }
      
      public function §_-y1G§(param1:String) : void
      {
         if(!this.§_-eZ§)
         {
            this.§_-eZ§ = new Sprite();
            getContainer().addChild(this.§_-eZ§);
         }
         this.removeAura(param1);
         this.§_-eZ§.addChild(§_-v2s§(param1));
      }
      
      public function removeAura(param1:String) : void
      {
         var _loc2_:String = §_-J1v§(param1);
         if(_loc2_ == null)
         {
            return;
         }
         if(this.§_-eZ§ == null)
         {
            return;
         }
         var _loc3_:DisplayObject = this.§_-eZ§.getChildByName(_loc2_);
         if(_loc3_)
         {
            _loc3_.removeFromParent(true);
         }
      }
      
      public function damaged() : void
      {
         this.§_-e2u§(this.§_-b26§.damaged);
      }
      
      public function happy() : void
      {
         if(this.§_-b26§.happy)
         {
            this.§_-e2u§(this.§_-b26§.happy);
         }
      }
      
      public function §_-I3E§(param1:String, param2:Boolean = false, param3:Boolean = true, param4:Number = 1) : int
      {
         if(this.§_-v11§)
         {
            §_-L2A§.removeChild(this.§_-v11§);
            this.§_-v11§.dispose();
         }
         var _loc5_:§_-di§ = §_-K1t§.buildArmature(this.AMMO_ARMATURE_PREFIX + param1,§_-K1t§.§_-G1E§,§_-K1t§.§_-t1V§);
         if(_loc5_)
         {
            if(WorldClock.clock.contains(_loc5_))
            {
               WorldClock.clock.remove(_loc5_);
            }
            this.§_-v11§ = _loc5_.display;
            this.§_-v11§.scaleX = this.§_-v11§.scaleY = param4;
         }
         §_-L2A§.removeChild(armature.display);
         §_-L2A§.addChild(this.§_-v11§);
         return 30;
      }
      
      public function §_-924§() : void
      {
         if(this.locked)
         {
            return;
         }
         if(this.§_-v11§)
         {
            §_-L2A§.removeChild(this.§_-v11§);
            this.§_-v11§.dispose();
            this.§_-v11§ = null;
            §_-L2A§.addChildAt(armature.display,0);
         }
      }
      
      public function §_-e2u§(param1:String, param2:Boolean = false, param3:Boolean = true, param4:Boolean = true, param5:Boolean = true) : int
      {
         this.§_-l13§ = param4;
         this.§_-fh§ = param5;
         return this.play(param1,param2,param3);
      }
      
      public function §_-fr§(param1:String, param2:Boolean = false, param3:Boolean = true, param4:Boolean = true, param5:Boolean = true) : int
      {
         return this.§_-e2u§(param1,param2,param3,param4,param5);
      }
      
      public function §_-D2s§(param1:Boolean, param2:Boolean) : void
      {
         this.§_-rz§ = param1;
         this.§_-02a§ = param2;
         this.§_-W1j§();
      }
      
      public function §_-W1j§() : void
      {
         var leftHand:§_-S2O§ = null;
         var rightHand:§_-S2O§ = null;
         var shouldHoldArtifact:Boolean = false;
         if(!armature || !this.§_-b26§)
         {
            return;
         }
         try
         {
            leftHand = armature.getBone(§_-vT§);
            if(Boolean(this.§_-b26§.leftHand) && Boolean(leftHand) && Boolean(leftHand.slot.display))
            {
               shouldHoldArtifact = this.§_-fW§ && Boolean(this.artifact);
               leftHand.visible = this.§_-02a§;
               if(Boolean(leftHand.slot) && Boolean(leftHand.slot.childArmature))
               {
                  leftHand.slot.childArmature.animation.gotoAndStop(shouldHoldArtifact.toString(),0);
               }
            }
            rightHand = armature.getBone(§_-z1d§);
            if(Boolean(this.§_-b26§.rightHand) && Boolean(rightHand) && Boolean(rightHand.slot.display))
            {
               rightHand.visible = this.§_-rz§;
            }
         }
         catch(e:Error)
         {
         }
         armature.advanceTime(0);
      }
      
      override protected function play(param1:String, param2:Boolean = false, param3:Boolean = true) : int
      {
         if(this.locked)
         {
            return 0;
         }
         if(this.§_-v11§)
         {
            §_-L2A§.removeChild(this.§_-v11§);
            this.§_-v11§.dispose();
            this.§_-v11§ = null;
            §_-L2A§.addChildAt(armature.display,0);
         }
         var _loc4_:int = super.play(param1,param2,param3);
         this.§_-E1T§(this.hat);
         return _loc4_;
      }
      
      override protected function playAnimation(param1:String, param2:Boolean) : void
      {
         var _loc3_:Boolean = param1 != armature.animation.lastAnimationName;
         super.playAnimation(param1,param2);
         if(_loc3_)
         {
            this.§_-W1j§();
         }
         this.§_-t2h§(§_-l6§,param1);
         if(armature.§_-42U§(§_-41P§,param1))
         {
            this.§_-t2h§(§_-41P§,param1);
         }
         else
         {
            this.§_-t2h§(§_-41P§,this.§_-E2I§ ? this.§_-b26§.sadClip : this.§_-b26§.breathClip);
         }
      }
      
      private function §_-t2h§(param1:String, param2:String) : void
      {
         var _loc3_:int = int(param2.indexOf(§_-LM§()));
         if(_loc3_ != -1)
         {
            param2 = param2.substr(§_-LM§().length);
         }
         if(armature.§_-42U§(param1,param2))
         {
            armature.§_-I3v§(param1,param2,-1,-1,0);
         }
         else if(armature.§_-42U§(param1,§_-U2V§))
         {
            armature.§_-I3v§(param1,§_-U2V§,-1,-1,0);
         }
      }
      
      override public function stop(param1:Boolean = false) : void
      {
         super.stop(param1);
         if(param1 && Boolean(armature.getBone(§_-l6§).armature))
         {
            armature.getBone(§_-l6§).armature.animation.stop();
         }
      }
      
      protected function §_-V2h§() : void
      {
         if(disposed)
         {
            return;
         }
         this.§_-Vv§();
         this.§_-A3a§();
         this.§_-W1j§();
      }
      
      private function §_-Vv§() : void
      {
         var _loc2_:DisplayObject = null;
         var _loc3_:Sprite = null;
         var _loc4_:Point = null;
         if(Boolean(this.§_-f1M§) && Boolean(this.hat) && this.hat.§_-G3a§() == this.§_-f1M§.source.name)
         {
            return;
         }
         var _loc1_:Slot = armature.getSlot(§_-V18§);
         this.disposeArmature(this.§_-f1M§);
         this.§_-f1M§ = null;
         if(this.hat)
         {
            if(§_-q15§.§_-Q2T§(this.hat))
            {
               this.§_-f1M§ = §_-q15§.§_-b1m§(this.hat);
               WorldClock.clock.add(this.§_-f1M§);
               this.§_-f1M§.animation.play();
               _loc1_.display = this.§_-f1M§.display;
            }
            else
            {
               _loc2_ = §_-q15§.§_-Fd§(this.hat);
               if(_loc2_)
               {
                  _loc3_ = new Sprite();
                  _loc3_.addChild(_loc2_);
                  _loc4_ = §_-AC§.§_-1Q§(this.hat.§_-G3a§());
                  _loc2_.pivotX = -_loc4_.x * 3;
                  _loc2_.pivotY = -_loc4_.y * 3;
                  _loc1_.display = _loc3_;
                  Pool.putPoint(_loc4_);
               }
            }
         }
         else
         {
            _loc1_.display = new Image(§_-X2i§);
         }
         this.§_-E1T§(this.hat);
         armature.advanceTime(0);
      }
      
      public function §_-E1T§(param1:§_-zF§) : void
      {
         var _loc3_:Slot = null;
         var _loc4_:Array = null;
         var _loc5_:Array = null;
         var _loc6_:String = null;
         var _loc7_:Boolean = false;
         var _loc2_:Slot = armature.getSlot(§_-V18§);
         if(Boolean(_loc2_) && _loc2_.display.alpha > 0)
         {
            _loc4_ = param1 ? param1.§_-h1h§() : [];
            _loc5_ = §_-zF§.§_-a18§();
            for each(_loc6_ in _loc5_)
            {
               _loc7_ = _loc4_.indexOf(_loc6_) == -1 || !this.§_-fh§;
               _loc3_ = armature.getSlot(_loc6_);
               if(Boolean(_loc3_) && Boolean(_loc3_.display))
               {
                  _loc3_.display.visible = _loc7_;
               }
            }
         }
      }
      
      private function §_-A3a§() : void
      {
         var _loc1_:Slot = armature.getSlot(§_-vT§);
         if(!_loc1_ || !_loc1_.childArmature)
         {
            return;
         }
         var _loc2_:Slot = _loc1_.childArmature.getSlot(§_-n1F§);
         var _loc3_:Bone = _loc1_.childArmature.getBone(§_-n1F§);
         var _loc4_:Point = Pool.getPoint();
         this.disposeArmature(this.§_-G1S§);
         this.§_-G1S§ = null;
         var _loc5_:Boolean = this.artifact != null;
         _loc1_.childArmature.animation.gotoAndStop(_loc5_.toString(),0);
         if(_loc5_)
         {
            this.§_-53A§(_loc2_,this.artifact);
            if(!§_-q15§.§_-O1m§(this.artifact))
            {
               _loc4_ = §_-W2D§.§_-lI§(this.artifact.§_-G3a§(),_loc4_);
            }
            _loc3_.offset.x = _loc4_.x * 3;
            _loc3_.offset.y = _loc4_.y * 3;
            this.§_-rV§(armature,§_-vT§);
         }
         Pool.putPoint(_loc4_);
      }
      
      private function §_-53A§(param1:Slot, param2:§_-T1y§) : void
      {
         if(Boolean(param2) && §_-q15§.§_-O1m§(param2))
         {
            this.§_-G1S§ = §_-q15§.§_-pC§(param2);
            WorldClock.clock.add(this.§_-G1S§);
            this.§_-G1S§.animation.play();
            param1.display = this.§_-G1S§.display;
         }
         else
         {
            param1.display = §_-q15§.§_-01K§(param2);
         }
      }
      
      private function disposeArmature(param1:§_-di§) : void
      {
         if(param1)
         {
            WorldClock.clock.remove(param1);
            param1.dispose();
         }
      }
      
      private function §_-rV§(param1:§_-di§, param2:String) : void
      {
         var _loc3_:int = this.artifact.§_-rw§() ? 0 : 1;
         var _loc4_:int = this.artifact.§_-rw§() ? 1 : 0;
         param1.§_-23D§(_loc3_,param2.concat(".",§_-n1F§));
         param1.§_-23D§(_loc4_,param2.concat(".",§_-q16§));
      }
      
      public function hideHands(param1:String) : void
      {
         var _loc2_:Boolean = !(param1 == "right" || param1 == "both") || !this.§_-l13§;
         var _loc3_:Boolean = !(param1 == "left" || param1 == "both") || !this.§_-l13§;
         this.§_-D2s§(_loc2_,_loc3_);
      }
      
      public function §_-i§() : void
      {
         this.§_-D2s§(true,true);
      }
      
      public function lock() : void
      {
         this.locked = true;
      }
      
      public function unlock() : void
      {
         this.locked = false;
      }
      
      override public function dispose() : void
      {
         this.disposeArmature(this.§_-f1M§);
         this.§_-f1M§ = null;
         this.disposeArmature(this.§_-G1S§);
         this.§_-G1S§ = null;
         if(Boolean(WorldClock.clock) && WorldClock.clock.contains(this.§_-Z1S§))
         {
            WorldClock.clock.remove(this.§_-Z1S§);
         }
         if(this.§_-Z1S§)
         {
            this.§_-Z1S§.dispose();
            this.§_-Z1S§ = null;
         }
         if(this.§_-eZ§)
         {
            if(this.§_-eZ§.numChildren)
            {
               this.§_-eZ§.removeChildren(0,-1,true);
            }
            this.§_-eZ§.dispose();
            this.§_-eZ§ = null;
         }
         if(this.§_-v11§)
         {
            this.§_-v11§.dispose();
            this.§_-v11§ = null;
         }
         super.dispose();
      }
      
      public function §_-C2W§() : void
      {
         this.§_-i§();
         armature.playAnimation("Stay",0,-1,0);
         armature.invalidUpdate();
         armature.getSlot(§_-l6§).childArmature.invalidUpdate();
         armature.advanceTime(1);
         this.§_-i§();
         this.stop(false);
      }
      
      public function §_-F2v§(param1:Boolean) : void
      {
         armature.animation.gotoAndStop("Jump",0);
         if(param1)
         {
            armature.§_-I3v§(§_-l6§,§_-K2s§.§_-U2V§,0,-1,0);
         }
         else if(armature.§_-42U§(§_-l6§,"closed"))
         {
            armature.§_-I3v§(§_-l6§,"closed",0);
         }
         else
         {
            armature.§_-I3v§(§_-l6§,"Happy",0);
         }
         armature.advanceTime(0.5);
      }
      
      public function §_-m14§(param1:Boolean) : void
      {
         if(this.§_-fW§ != param1)
         {
            this.§_-fW§ = param1;
            this.§_-W1j§();
         }
      }
      
      public function §_-d1m§() : §_-di§
      {
         return this.§_-f1M§;
      }
      
      public function §_-I2c§() : void
      {
         armature.display.alpha = 0.5;
      }
      
      public function §_-kh§() : Boolean
      {
         return this.locked;
      }
   }
}


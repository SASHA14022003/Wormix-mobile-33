package §_-73I§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.*;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-L1O§;
   import §_-L1H§.§_-C3e§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.§_-M11§;
   import §_-YF§.§_-q2v§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-b1F§.§_-G4§;
   import §_-hO§.§_-03k§;
   import §_-j1w§.§_-B2i§;
   import §_-k1r§.§_-j2G§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import dragonBones.animation.WorldClock;
   import dragonBones.objects.DragonBonesData;
   import feathers.controls.Button;
   import feathers.controls.ButtonGroup;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.core.PopUpManager;
   import feathers.layout.Direction;
   import feathers.layout.VerticalAlign;
   import feathers.skins.ImageSkin;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.*;
   import ru.pragmatix.wormix.messages.clans.request.ClanSummaryRequest;
   import ru.pragmatix.wormix.messages.clans.request.treasury.CashMedalsClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.ClanSummaryResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-TT§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Shard;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.*;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-q15§
   {
      
      public static const §_-62l§:String = "AllHats";
      
      public static const §_-N9§:String = "AllArtifacts";
      
      public static const §_-CU§:String = "characterHats/";
      
      public static const §_-D1N§:String = "Artifacts/";
      
      public function §_-q15§()
      {
         super();
      }
      
      public static function §_-82W§(param1:§_-O2H§) : DisplayObject
      {
         var _loc2_:DisplayObject = §_-TT§.§_-92P§(param1);
         _loc2_.pivotX = _loc2_.width * 0.5;
         _loc2_.pivotY = _loc2_.height * 0.5;
         return _loc2_;
      }
      
      public static function §_-zE§(param1:§_-L1r§) : §_-di§
      {
         var _loc2_:§_-B2i§ = Application.userProfile.§_-P2e§();
         var _loc3_:§_-zF§ = param1 is §_-zF§ ? param1 as §_-zF§ : null;
         var _loc4_:§_-T1y§ = param1 is §_-T1y§ ? param1 as §_-T1y§ : null;
         var _loc5_:§_-di§ = §_-L1O§.§_-Yx§(null,null,_loc2_,_loc3_,_loc4_);
         _loc5_.display.scaleX = _loc5_.display.scaleY = _loc5_.display.scaleY / 1.25;
         return _loc5_;
      }
      
      public static function §_-K2x§(param1:§_-W1r§) : DisplayObject
      {
         var _loc2_:DisplayObject = null;
         var _loc3_:§_-zF§ = null;
         var _loc4_:§_-T1y§ = null;
         var _loc5_:§_-di§ = null;
         if(param1 is §_-O2H§)
         {
            _loc2_ = §_-TT§.§_-92P§(param1);
            _loc2_.x = -_loc2_.width / 2;
            _loc2_.y = -_loc2_.height / 2;
         }
         else if(param1 is §_-L1r§)
         {
            _loc3_ = param1 is §_-zF§ ? param1 as §_-zF§ : null;
            _loc4_ = param1 is §_-T1y§ ? param1 as §_-T1y§ : null;
            if(_loc3_)
            {
               if(§_-Q2T§(_loc3_))
               {
                  _loc5_ = §_-b1m§(_loc3_);
                  _loc2_ = _loc5_.display;
               }
               else
               {
                  _loc2_ = §_-Fd§(_loc3_);
               }
            }
            else if(_loc4_)
            {
               if(§_-O1m§(_loc4_))
               {
                  _loc5_ = §_-pC§(_loc4_);
                  _loc2_ = _loc5_.display;
               }
               else
               {
                  _loc2_ = §_-01K§(_loc4_,0,0);
               }
            }
            if(_loc2_)
            {
               _loc2_.scaleX = _loc2_.scaleY = _loc2_.scaleY * §_-K1t§.§_-Q2C§;
            }
         }
         return _loc2_;
      }
      
      public static function §_-Fd§(param1:§_-zF§) : DisplayObject
      {
         if(param1)
         {
            return §_-L31§(param1.§_-G3a§());
         }
         return null;
      }
      
      public static function §_-L31§(param1:String) : DisplayObject
      {
         var _loc2_:String = §_-CU§ + param1;
         return Application.factory.getTextureDisplay(_loc2_,§_-K1t§.§_-82m§);
      }
      
      public static function §_-O1m§(param1:§_-T1y§) : Boolean
      {
         return §_-KH§(param1.§_-G3a§());
      }
      
      public static function §_-KH§(param1:String) : Boolean
      {
         var _loc2_:DragonBonesData = Application.factory.getDragonBonesData(§_-K1t§.§_-vX§);
         return _loc2_.getArmature(§_-D1N§ + param1) != null;
      }
      
      public static function §_-Q2T§(param1:§_-zF§) : Boolean
      {
         return §_-Wj§(param1.§_-G3a§());
      }
      
      public static function §_-Wj§(param1:String) : Boolean
      {
         var _loc2_:DragonBonesData = Application.factory.getDragonBonesData(§_-K1t§.§_-82m§);
         return _loc2_.getArmature(§_-CU§ + param1) != null;
      }
      
      public static function §_-pC§(param1:§_-T1y§) : §_-di§
      {
         return §_-p1z§(param1.§_-G3a§());
      }
      
      public static function §_-p1z§(param1:String) : §_-di§
      {
         return §_-K1t§.buildArmature(§_-D1N§ + param1,§_-K1t§.§_-G1E§,§_-K1t§.§_-vX§);
      }
      
      public static function §_-R26§(param1:String) : §_-di§
      {
         return §_-K1t§.buildArmature(§_-CU§ + param1,§_-K1t§.§_-Y1c§,§_-K1t§.§_-82m§);
      }
      
      public static function §_-b1m§(param1:§_-zF§) : §_-di§
      {
         return §_-R26§(param1.§_-G3a§());
      }
      
      public static function §_-W22§(param1:String, param2:Number = NaN, param3:Number = NaN) : DisplayObject
      {
         var _loc4_:DisplayObject = null;
         var _loc5_:String = §_-D1N§ + param1;
         _loc4_ = new Image(Application.assetManager.getTexture(_loc5_));
         _loc4_.x = param2;
         _loc4_.y = param3;
         return _loc4_;
      }
      
      public static function §_-01K§(param1:§_-T1y§, param2:Number = NaN, param3:Number = NaN) : DisplayObject
      {
         if(param1)
         {
            return §_-W22§(param1.§_-G3a§(),param2,param3);
         }
         return null;
      }
      
      public static function §_-71V§(param1:§_-W1r§, param2:Number = NaN, param3:Number = NaN) : DisplayObject
      {
         var _loc4_:Texture = Application.assetManager.getTexture(param1.§_-92P§());
         if(!_loc4_)
         {
            return null;
         }
         var _loc5_:Image = new Image(_loc4_);
         if(!isNaN(param2) && !isNaN(param3))
         {
            _loc5_.x = param2;
            _loc5_.y = param3;
         }
         return _loc5_;
      }
   }
}


package §_-534§
{
   import §_-12W§.§_-J3J§;
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-31N§.§_-42G§;
   import §_-31W§.§_-Kb§;
   import §_-43V§.*;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-UK§;
   import §_-DJ§.§_-J2l§;
   import §_-H9§.§_-h1H§;
   import §_-J31§.§_-R1h§;
   import §_-Ly§.§_-81L§;
   import §_-P1z§.*;
   import §_-P2i§.§_-b7§;
   import §_-RE§.§_-r2q§;
   import §_-RE§.§_-w0§;
   import §_-T2h§.§_-43C§;
   import §_-T2h§.§_-C1R§;
   import §_-Ta§.§_-73t§;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-Zi§;
   import §_-Z1w§.§_-s1x§;
   import §_-d26§.§_-d1H§;
   import §_-e2r§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-j2N§.*;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-A0§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.pushnotifications.events.PushNotificationEvent;
   import config.§_-B1K§;
   import config.§_-V2w§;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.skins.ImageSkin;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.ScreenShake;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.SteamTransactionInitRequest;
   import ru.pragmatix.wormix.messages.server.ReorderGroupResult;
   import ru.pragmatix.wormix.messages.server.ToggleTeamMemberResult;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-rC§ extends §_-h1H§
   {
      
      private static const §_-R2d§:String = "wall_post/common/bosses/";
      
      public function §_-rC§()
      {
         super();
      }
      
      override public function §_-g18§(param1:§_-Kb§) : String
      {
         return "achives/" + param1.icon + ".png";
      }
      
      override public function §_-b1i§(param1:§_-zF§) : String
      {
         return "hats/" + param1.§_-G3a§() + ".png";
      }
      
      override public function §_-l1F§(param1:§_-O2H§) : String
      {
         return "weapons/" + param1.§_-92P§() + ".png";
      }
      
      override public function get remindAboutLose() : String
      {
         return "wall_post/common/activity_icon.png";
      }
      
      override public function §_-o2z§(param1:Boolean, param2:Boolean) : String
      {
         return §_-R2d§ + (param1 ? "win" : "loose") + "Superboss" + (param2 ? "WithFriend" : "") + ".png";
      }
      
      override public function §_-RX§(param1:int) : String
      {
         var _loc2_:int = param1;
         switch(_loc2_)
         {
            case §_-w0§.FARMER:
               §§push(0);
               break;
            case §_-w0§.§_-G1I§:
               §§push(1);
               break;
            case §_-w0§.§_-z1U§:
               §§push(2);
               break;
            case §_-w0§.§_-nm§:
               §§push(3);
               break;
            case §_-w0§.SAMURAI:
               §§push(4);
               break;
            case §_-w0§.§_-H1Q§:
               §§push(5);
               break;
            case §_-w0§.BURNING:
               §§push(6);
               break;
            case §_-w0§.§_-C3U§:
               §§push(7);
               break;
            case §_-w0§.§_-11B§:
               §§push(8);
               break;
            case §_-w0§.ILLUSIONIST:
               §§push(9);
               break;
            case §_-w0§.§_-q1v§:
               §§push(10);
               break;
            case §_-w0§.PIRATE:
               §§push(11);
               break;
            case §_-w0§.§_-3c§:
               §§push(12);
               break;
            case §_-w0§.§_-A1V§:
               §§push(13);
               break;
            case §_-w0§.§_-M1T§:
               §§push(14);
               break;
            case §_-w0§.§_-41t§:
               §§push(15);
               break;
            case §_-w0§.§_-23T§:
               §§push(16);
               break;
            case §_-w0§.§_-pK§:
               §§push(17);
               break;
            case §_-w0§.§_-L2k§:
               §§push(18);
               break;
            case §_-w0§.§_-hV§:
               §§push(19);
               break;
            case §_-w0§.§_-i0§:
               §§push(20);
               break;
            case §_-w0§.§_-H2h§:
               §§push(21);
               break;
            case §_-w0§.§_-q9§:
               §§push(22);
               break;
            case §_-w0§.EMPEROR:
               §§push(23);
               break;
            case §_-w0§.SCIENTIST:
               §§push(24);
               break;
            case §_-w0§.SYMBIOTE:
               §§push(25);
               break;
            case §_-w0§.ARCHBOT:
               §§push(26);
               break;
            case §_-w0§.§_-o1n§:
               §§push(27);
               break;
            case §_-w0§.§_-n2R§:
               §§push(28);
               break;
            case §_-w0§.§_-L8§:
               §§push(29);
               break;
            default:
               switch(_loc2_)
               {
                  case §_-w0§.§_-i2j§:
                     §§push(30);
                     break;
                  case §_-w0§.§_-S1a§:
                     §§push(31);
                     break;
                  default:
                     §§push(32);
               }
         }
         switch(§§pop())
         {
            case 0:
               return §_-R2d§ + "Farmer.png";
            case 1:
               return §_-R2d§ + "Hunter.png";
            case 2:
               return §_-R2d§ + "Maniacs.png";
            case 3:
               return §_-R2d§ + "TheMiner.png";
            case 4:
               return §_-R2d§ + "TheSamurai.png";
            case 5:
               return §_-R2d§ + "Sergeant.png";
            case 6:
               return §_-R2d§ + "BurningZombies.png";
            case 7:
               return §_-R2d§ + "WanderingSpirit.png";
            case 8:
               return §_-R2d§ + "VoodooShaman.png";
            case 9:
               return §_-R2d§ + "TheIllusionist.png";
            case 10:
               return §_-R2d§ + "Vikings.png";
            case 11:
               return §_-R2d§ + "PirateGang.png";
            case 12:
               return §_-R2d§ + "WindMaster.png";
            case 13:
               return §_-R2d§ + "Yakuza.png";
            case 14:
               return §_-R2d§ + "VengefulCaptain.png";
            case 15:
               return §_-R2d§ + "RomeoAndJuliet.png";
            case 16:
               return §_-R2d§ + "ZombieKing.png";
            case 17:
               return §_-R2d§ + "AncientGhost.png";
            case 18:
               return §_-R2d§ + "Engineer.png";
            case 19:
               return §_-R2d§ + "GuardianOfDepths.png";
            case 20:
               return §_-R2d§ + "DarkKnight.png";
            case 21:
               return §_-R2d§ + "Assassin.png";
            case 22:
               return §_-R2d§ + "Alchemist.png";
            case 23:
               return §_-R2d§ + "Emperor.png";
            case 24:
               return §_-R2d§ + "Scientist.png";
            case 25:
               return §_-R2d§ + "Symbiote.png";
            case 26:
               return §_-R2d§ + "Archbot.png";
            case 27:
               return §_-R2d§ + "Paladin.png";
            case 28:
               return §_-R2d§ + "Hacker.png";
            case 29:
               return §_-R2d§ + "Thieves.png";
            case 30:
               return §_-R2d§ + "Phantoms.png";
            case 31:
               return §_-R2d§ + "Archdemon.png";
            default:
               return "wall_post/common/activity_icon.png";
         }
      }
      
      public function §_-a2A§(param1:Boolean) : String
      {
         return "wall_post/common/activity_icon.png";
      }
      
      public function get §_-S1J§() : String
      {
         return "wall_post/common/activity_icon.png";
      }
      
      public function §_-J1R§() : String
      {
         return "wall_post/common/activity_icon.png";
      }
      
      override public function get boxerIcon() : String
      {
         return "wall_post/common/races/Boxer.png";
      }
      
      override public function get zombieIcon() : String
      {
         return "wall_post/common/races/Zombie.png";
      }
      
      override public function get demonIcon() : String
      {
         return "wall_post/common/races/Demon.png";
      }
      
      override public function get rabbitIcon() : String
      {
         return "wall_post/common/races/Rabbit.png";
      }
      
      override public function get catIcon() : String
      {
         return "wall_post/common/races/Cat.png";
      }
      
      override public function get dragonIcon() : String
      {
         return "wall_post/common/races/Dragon.png";
      }
      
      override public function get robotIcon() : String
      {
         return "wall_post/common/races/Robot.png";
      }
      
      override public function §_-G1f§(param1:§_-B2i§) : String
      {
         switch(param1.configName)
         {
            case "boxer":
               return this.boxerIcon;
            case "demon":
               return this.demonIcon;
            case "rabbit":
               return this.rabbitIcon;
            case "zombie":
               return this.zombieIcon;
            case "cat":
               return this.catIcon;
            case "dragon":
               return this.dragonIcon;
            default:
               return "wall_post/common/activity_icon.jpg";
         }
      }
   }
}


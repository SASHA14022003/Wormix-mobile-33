package §_-J3L§
{
   public class §_-h1D§
   {
      
      public static const MENU_ITEM_SELECT:String = "MENU_ITEM_SELECT";
      
      public static const MENU_OK_ACTION:String = "MENU_OK_ACTION";
      
      public static const WINDOW_CLOSE:String = "WINDOW_CLOSE";
      
      public static const WINDOW_CANCEL:String = "WINDOW_CANCEL";
      
      public static const WINDOW_SHOW:String = "WINDOW_SHOW";
      
      public static const CHANGE:String = "CHANGE";
      
      public function §_-h1D§()
      {
         super();
      }
   }
}


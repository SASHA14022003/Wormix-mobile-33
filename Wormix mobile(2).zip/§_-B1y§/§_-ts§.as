package §_-B1y§
{
   import §_-DJ§.§_-J2l§;
   import §_-QD§.§_-G2z§;
   import §_-r1C§.§_-h2B§;
   import §_-w2W§.§_-v27§;
   import §_-z1w§.*;
   import §_-zI§.§_-X1q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.*;
   
   public class §_-ts§
   {
      
      public function §_-ts§()
      {
         super();
      }
      
      public static function §_-OX§(param1:Array) : Array
      {
         var _loc4_:Object = null;
         var _loc2_:Object = {};
         var _loc3_:Array = [];
         for each(_loc4_ in param1)
         {
            if(!_loc2_[_loc4_])
            {
               _loc3_.push(_loc4_);
               _loc2_[_loc4_] = true;
            }
         }
         return _loc3_;
      }
      
      public static function contains(param1:Array, param2:Object) : Boolean
      {
         return indexOf(param1,param2) != -1;
      }
      
      public static function §_-72V§(param1:Array, param2:Array) : Object
      {
         var _loc3_:Object = null;
         for each(_loc3_ in param2)
         {
            if(indexOf(param1,_loc3_) != -1)
            {
               return _loc3_;
            }
         }
         return null;
      }
      
      public static function indexOf(param1:Array, param2:Object) : int
      {
         var _loc3_:uint = 0;
         while(_loc3_ < param1.length)
         {
            if(param1[_loc3_] == param2)
            {
               return _loc3_;
            }
            _loc3_++;
         }
         return -1;
      }
      
      public static function remove(param1:Array, param2:Object) : void
      {
         var _loc3_:int = int(param1.indexOf(param2));
         if(_loc3_ != -1)
         {
            param1.splice(_loc3_,1);
         }
      }
      
      public static function §_-z1M§(param1:Object) : Array
      {
         var _loc3_:* = undefined;
         var _loc2_:Array = [];
         for each(_loc3_ in param1)
         {
            _loc2_.push(_loc3_);
         }
         return _loc2_;
      }
      
      public static function copy(param1:Array) : Array
      {
         var _loc3_:Object = null;
         var _loc2_:Array = new Array();
         for each(_loc3_ in param1)
         {
            _loc2_.push(_loc3_);
         }
         return _loc2_;
      }
      
      public static function §_-03w§(param1:Object, param2:Object) : void
      {
         var _loc3_:String = null;
         for(_loc3_ in param1)
         {
            param2[_loc3_] = param1[_loc3_];
         }
      }
      
      public static function §_-i2v§(param1:Object, param2:Object) : void
      {
         var _loc3_:String = null;
         for(_loc3_ in param1)
         {
            if(!param2[_loc3_])
            {
               param2[_loc3_] = param1[_loc3_];
            }
         }
      }
      
      public static function toString(param1:Array, param2:String = ",") : String
      {
         if(param1)
         {
            return "[" + param1.join(param2) + "]";
         }
         return "null";
      }
   }
}


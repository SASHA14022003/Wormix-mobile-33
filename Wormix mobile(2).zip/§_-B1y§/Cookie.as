package §_-B1y§
{
   import §_-62§.§_-G1p§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.§_-42h§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import feathers.events.FeathersEventType;
   import flash.errors.IllegalOperationError;
   import flash.net.SharedObject;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.weapons.ammo.MolotovProjectile;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class Cookie
   {
      
      private static var §_-Ej§:String;
      
      private static var §_-i1N§:Cookie;
      
      private static const log:§_-11S§ = new §_-11S§(Cookie);
      
      private var config:SharedObject;
      
      public function Cookie()
      {
         super();
      }
      
      public static function init(param1:String, param2:String = null) : void
      {
         if(§_-Ej§)
         {
            throw new IllegalOperationError("Cookie.init must be called only once");
         }
         §_-Ej§ = param1 + (param2 ? "/" + param2 : "");
      }
      
      public static function isInitialized() : Boolean
      {
         return §_-Ej§ != null;
      }
      
      public static function §_-H1A§(param1:String, param2:Number = 0) : Number
      {
         return getValue(param1,param2) as Number;
      }
      
      public static function getStringValue(param1:String, param2:String = null) : String
      {
         return getValue(param1,param2) as String;
      }
      
      public static function §_-t2R§(param1:String, param2:Boolean = false) : Boolean
      {
         return getValue(param1,param2) as Boolean;
      }
      
      public static function getValue(param1:String, param2:Object) : Object
      {
         return getInstance().getValue(param1,param2);
      }
      
      public static function setValue(param1:String, param2:Object, param3:Boolean = true, param4:int = 0) : void
      {
         getInstance().setValue(param1,param2,param3,param4);
      }
      
      private static function getInstance() : Cookie
      {
         if(!§_-i1N§)
         {
            §_-i1N§ = new Cookie();
            §_-i1N§.§_-zX§();
         }
         return §_-i1N§;
      }
      
      public function getValue(param1:String, param2:Object) : Object
      {
         if(!this.config)
         {
            this.§_-zX§();
         }
         if(!this.config)
         {
            log.debug("Could not read property " + param1 + ". SharedObject.getLocal() == " + this.config);
         }
         else if(this.config.data[param1] != undefined)
         {
            return this.config.data[param1];
         }
         return param2;
      }
      
      public function setValue(param1:String, param2:Object, param3:Boolean = true, param4:int = 0) : void
      {
         var property:String = param1;
         var value:Object = param2;
         var saveImmediatly:Boolean = param3;
         var minDiskSpace:int = param4;
         if(!this.config)
         {
            this.§_-zX§();
         }
         if(this.config)
         {
            log.debug("save property " + property + " = " + value);
            this.config.data[property] = value;
            if(saveImmediatly)
            {
               try
               {
                  this.config.flush(minDiskSpace);
               }
               catch(error:Error)
               {
                  log.error("Error...Could not write SharedObject to disk: \'" + §_-I2J§() + "." + property + "\' = \'" + value + "\'");
               }
            }
         }
         else
         {
            log.error("Could not save property " + property + ". SharedObject.getLocal() == " + this.config);
         }
      }
      
      public function §_-n1V§() : String
      {
         var _loc1_:String = null;
         var _loc2_:String = null;
         if(Boolean(this.config) && Boolean(this.config.data))
         {
            _loc1_ = "";
            for(_loc2_ in this.config.data)
            {
               if(_loc1_.length)
               {
                  _loc1_ += ", ";
               }
               _loc1_ += _loc2_ + " : " + this.config.data[_loc2_];
            }
            return "{" + _loc1_ + "}";
         }
         if(!this.config)
         {
            return "SharedObject.getLocal() == " + this.config;
         }
         return "SharedObject.data == " + this.config.data;
      }
      
      private function §_-I2J§() : String
      {
         if(§_-Ej§)
         {
            return §_-Ej§;
         }
         throw new IllegalOperationError("Cookie is not initialized. Call method Cookie.init to initialize");
      }
      
      private function §_-zX§() : void
      {
         try
         {
            this.config = SharedObject.getLocal(this.§_-I2J§());
            log.debug("read Cookies: " + §_-i1N§.§_-n1V§());
         }
         catch(error:Error)
         {
            §§push(error);
            var _temp_1:* = error;
            error = §§pop();
            log.error("Error...Could not read SharedObject by name \'" + §_-I2J§() + "\'. Reason: " + error.message);
         }
      }
   }
}


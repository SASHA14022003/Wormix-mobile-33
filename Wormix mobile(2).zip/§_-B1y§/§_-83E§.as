package §_-B1y§
{
   import §_-G2H§.*;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import com.distriqt.extension.inappbilling.Purchase;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.net.SharedObject;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   
   public class §_-83E§
   {
      
      public function §_-83E§()
      {
         super();
      }
      
      public static function single(param1:IEventDispatcher, param2:String, param3:Function, param4:Object = null, param5:Array = null, param6:Boolean = false) : void
      {
         var fn:Function = null;
         var obj:IEventDispatcher = param1;
         var eventType:String = param2;
         var listener:Function = param3;
         var scope:Object = param4;
         var args:Array = param5;
         var appendArgs:Boolean = param6;
         var l:Function = §_-bs§.§_-d1Z§(listener,scope,args,appendArgs);
         fn = function(param1:Event):void
         {
            obj.removeEventListener(eventType,fn);
            l(param1);
         };
         obj.addEventListener(eventType,fn);
      }
      
      public static function §_-43T§(param1:IEventDispatcher, param2:Array, param3:Function) : void
      {
         var _loc5_:String = null;
         var _loc4_:Array = [param1];
         for each(_loc5_ in param2)
         {
            _loc4_.push(_loc5_);
            _loc4_.push(param3);
         }
         §_-C38§.apply(§_-83E§,_loc4_);
      }
      
      public static function §_-C38§(param1:IEventDispatcher, ... rest) : void
      {
         var i:int;
         var listeners:Object = null;
         var fn:Function = null;
         var type:String = null;
         var obj:IEventDispatcher = param1;
         var args:Array = rest;
         if(args.length % 2 != 0)
         {
            throw new IllegalOperationError();
         }
         listeners = {};
         fn = function(param1:Event):void
         {
            var _loc2_:String = null;
            for(_loc2_ in listeners)
            {
               obj.removeEventListener(_loc2_,fn);
            }
            listeners[param1.type](param1);
         };
         i = 0;
         while(i < args.length)
         {
            type = args[i];
            listeners[type] = args[i + 1];
            obj.addEventListener(type,fn);
            i += 2;
         }
      }
      
      public static function §_-xC§(param1:Object) : void
      {
         var fn:Function = null;
         var type:String = null;
         var obj:IEventDispatcher = null;
         var listeners:Object = param1;
         fn = function(param1:Event):void
         {
            var _loc2_:String = null;
            var _loc3_:IEventDispatcher = null;
            for(_loc2_ in listeners)
            {
               _loc3_ = listeners[_loc2_].disp;
               _loc3_.removeEventListener(_loc2_,fn);
            }
            listeners[param1.type].fn(param1);
         };
         for(type in listeners)
         {
            obj = listeners[type].disp;
            obj.addEventListener(type,fn);
         }
      }
      
      public static function §_-qu§(param1:Object, param2:Array, param3:Function) : void
      {
         var _loc4_:String = null;
         for each(_loc4_ in param2)
         {
            param1[_loc4_] = param3;
         }
      }
   }
}


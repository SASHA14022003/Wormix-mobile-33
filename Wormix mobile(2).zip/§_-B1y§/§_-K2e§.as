package §_-B1y§
{
   import flash.display.DisplayObjectContainer;
   
   public interface §_-K2e§
   {
      
      function get stageWidth() : int;
      
      function get stageHeight() : int;
      
      function getInstance() : DisplayObjectContainer;
   }
}


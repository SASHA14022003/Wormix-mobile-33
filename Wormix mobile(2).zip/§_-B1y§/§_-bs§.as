package §_-B1y§
{
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   
   public class §_-bs§
   {
      
      public function §_-bs§()
      {
         super();
      }
      
      public static function §_-d1Z§(param1:Function, param2:Object, param3:Array = null, param4:Boolean = false) : Function
      {
         var fn:Function = param1;
         var scope:Object = param2;
         var args:Array = param3;
         var appendArgs:Boolean = param4;
         return function():*
         {
            var _loc2_:* = undefined;
            if(appendArgs)
            {
               _loc2_ = arguments.concat(args);
            }
            else
            {
               _loc2_ = args || arguments;
            }
            return fn.apply(scope,_loc2_);
         };
      }
      
      public static function delay(param1:Function, param2:Object, param3:uint, param4:Array = null) : void
      {
         var t:Timer = null;
         var l:Function = null;
         var fn:Function = param1;
         var scope:Object = param2;
         var delay:uint = param3;
         var args:Array = param4;
         t = new Timer(delay,1);
         l = function():void
         {
            t.removeEventListener(TimerEvent.TIMER_COMPLETE,l);
            fn.apply(scope,args);
         };
         t.addEventListener(TimerEvent.TIMER_COMPLETE,l);
         t.start();
      }
   }
}


package §_-B1y§
{
   import §_-79§.§_-ps§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-gE§;
   import §_-Ly§.§_-81L§;
   import §_-Y1O§.*;
   import §_-j1w§.§_-B2i§;
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.errors.IllegalOperationError;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.system.SecurityDomain;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.events.Event;
   import starling.events.TouchEvent;
   
   public class §_-o2k§
   {
      
      private var §_-OH§:String = "";
      
      private var §_-h1k§:String = "";
      
      private var flashVars:Object;
      
      private var referrerId:String = "";
      
      private var §_-A11§:Object;
      
      private var §_-D3K§:LoaderContext;
      
      private var appMode:§_-gE§;
      
      public function §_-o2k§()
      {
         super();
      }
      
      public function §_-g2d§() : §_-gE§
      {
         return this.appMode;
      }
      
      public function §_-Y26§(param1:§_-gE§) : void
      {
         this.appMode = param1;
      }
      
      public function §_-K3U§() : String
      {
         return this.§_-OH§;
      }
      
      public function §_-TD§(param1:String) : void
      {
         this.§_-OH§ = param1;
      }
      
      public function §_-C1Y§() : String
      {
         return this.§_-h1k§;
      }
      
      public function §_-Md§(param1:String) : void
      {
         this.§_-h1k§ = param1;
      }
      
      public function §_-S2r§() : String
      {
         return this.referrerId;
      }
      
      public function §_-n1X§(param1:String) : void
      {
         this.referrerId = param1;
      }
      
      public function §_-JF§() : Object
      {
         return this.§_-A11§;
      }
      
      public function §_-T2e§(param1:Object) : void
      {
         this.§_-A11§ = param1;
         this.appMode = §_-gE§.valueOf(param1.appMode);
      }
      
      public function §_-E1e§() : Object
      {
         return this.flashVars;
      }
      
      public function §_-63V§(param1:Object) : void
      {
         this.flashVars = param1;
      }
      
      public function §_-21I§() : LoaderContext
      {
         if(!this.§_-D3K§)
         {
            if(this.§_-OH§.toLowerCase().indexOf("http") >= 0)
            {
               this.§_-D3K§ = new LoaderContext(true,ApplicationDomain.currentDomain,SecurityDomain.currentDomain);
            }
            else
            {
               this.§_-D3K§ = new LoaderContext(true,ApplicationDomain.currentDomain);
            }
         }
         return this.§_-D3K§;
      }
   }
}


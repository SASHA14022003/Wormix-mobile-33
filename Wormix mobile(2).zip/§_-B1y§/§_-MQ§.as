package §_-B1y§
{
   import §_-B2z§.§_-82u§;
   import §_-m1g§.§_-N1y§;
   import §_-x2Q§.§_-dU§;
   import flash.errors.IllegalOperationError;
   import flash.utils.getQualifiedClassName;
   import starling.events.Event;
   
   public class §_-MQ§
   {
      
      public function §_-MQ§()
      {
         super();
      }
      
      public static function single(param1:§_-82u§, param2:Class, param3:Function, param4:Object = null, param5:Array = null, param6:Boolean = false) : void
      {
         §_-83E§.single(param1,getQualifiedClassName(param2),param3,param4,param5,param6);
      }
      
      public static function §_-C38§(param1:§_-82u§, ... rest) : void
      {
         if(rest.length % 2 != 0)
         {
            throw new IllegalOperationError();
         }
         var _loc3_:Array = [param1];
         var _loc4_:int = 0;
         while(_loc4_ < rest.length)
         {
            _loc3_.push(getQualifiedClassName(rest[_loc4_]));
            _loc3_.push(rest[_loc4_ + 1]);
            _loc4_ += 2;
         }
         §_-83E§.§_-C38§.apply(§_-MQ§,_loc3_);
      }
      
      public static function §_-43T§(param1:§_-82u§, param2:Array, param3:Function) : void
      {
         var _loc5_:Class = null;
         var _loc4_:Array = [param1];
         for each(_loc5_ in param2)
         {
            _loc4_.push(_loc5_,param3);
         }
         §_-C38§.apply(§_-MQ§,_loc4_);
      }
   }
}


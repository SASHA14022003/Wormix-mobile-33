package §_-B1y§
{
   import §_-H16§.*;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   
   public class §_-fM§
   {
      
      public function §_-fM§()
      {
         super();
      }
      
      public static function toString(param1:*, param2:String = ",") : String
      {
         if(param1)
         {
            return "[" + param1.join(param2) + "]";
         }
         return "null";
      }
      
      public static function §_-n2u§(param1:*) : Array
      {
         var _loc3_:Object = null;
         var _loc2_:Array = [];
         for each(_loc3_ in param1)
         {
            _loc2_.push(_loc3_);
         }
         return _loc2_;
      }
      
      public static function remove(param1:*, param2:Object) : void
      {
         if(!param1)
         {
            return;
         }
         var _loc3_:int = int(param1.indexOf(param2));
         if(_loc3_ != -1)
         {
            param1.splice(_loc3_,1);
         }
      }
      
      public static function copy(param1:*, param2:*) : void
      {
         var _loc3_:Object = null;
         for each(_loc3_ in param1)
         {
            param2.push(_loc3_);
         }
      }
   }
}


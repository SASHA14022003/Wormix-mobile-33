package §_-b1§
{
   import §_-B1y§.§_-83E§;
   import §_-Y1Q§.§_-61Z§;
   import §_-ZP§.§_-YG§;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.InteractiveObject;
   import flash.display.Stage;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.weapons.Girder;
   
   public class §_-03u§
   {
      
      public function §_-03u§()
      {
         super();
      }
      
      public static function §_-33y§(param1:Stage, param2:Point, param3:Boolean = true, param4:uint = 0) : InteractiveObject
      {
         var _loc7_:* = 0;
         var _loc8_:DisplayObject = null;
         var _loc9_:InteractiveObject = null;
         var _loc10_:DisplayObjectContainer = null;
         var _loc5_:Array = param1.getObjectsUnderPoint(param2);
         if(!_loc5_.length)
         {
            return param1;
         }
         var _loc6_:int = _loc5_.length - 1 - param4;
         if(_loc6_ < 0)
         {
            return param1;
         }
         _loc7_ = _loc6_;
         while(_loc7_ >= 0)
         {
            _loc8_ = _loc5_[_loc7_] as DisplayObject;
            while(_loc8_ != param1)
            {
               if(_loc8_ is InteractiveObject)
               {
                  if((_loc8_ as InteractiveObject).mouseEnabled)
                  {
                     if(param3)
                     {
                        _loc9_ = _loc8_ as InteractiveObject;
                        _loc10_ = _loc8_.parent;
                        while(_loc10_)
                        {
                           if(!_loc9_ && Boolean(_loc10_.mouseEnabled))
                           {
                              _loc9_ = _loc10_;
                           }
                           else if(!_loc10_.mouseChildren)
                           {
                              if(_loc10_.mouseEnabled)
                              {
                                 _loc9_ = _loc10_;
                              }
                              else
                              {
                                 _loc9_ = null;
                              }
                           }
                           _loc10_ = _loc10_.parent;
                        }
                        if(_loc9_)
                        {
                           return _loc9_;
                        }
                        return param1;
                     }
                     return _loc8_ as InteractiveObject;
                  }
                  break;
               }
               _loc8_ = _loc8_.parent;
            }
            _loc7_--;
         }
         return param1;
      }
   }
}


package §_-b1§
{
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.Stage;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import org.gestouch.core.§_-qV§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import starling.events.Event;
   
   public final class §_-cB§ implements §_-qV§
   {
      
      private var §_-ei§:Dictionary;
      
      public function §_-cB§(param1:DisplayObject = null)
      {
         super();
         if(param1)
         {
            this.§_-ei§ = new Dictionary(true);
            this.§_-ei§[param1] = true;
         }
      }
      
      public function get target() : Object
      {
         var _loc1_:Object = null;
         var _loc2_:int = 0;
         var _loc3_:* = this.§_-ei§;
         for(_loc1_ in _loc3_)
         {
            return _loc1_;
         }
         return null;
      }
      
      public function contains(param1:Object) : Boolean
      {
         var _loc2_:DisplayObjectContainer = this.target as DisplayObjectContainer;
         if(_loc2_ is Stage)
         {
            return true;
         }
         var _loc3_:DisplayObject = param1 as DisplayObject;
         if(_loc3_)
         {
            return Boolean(_loc2_) && Boolean(_loc2_.contains(_loc3_));
         }
         return false;
      }
      
      public function §_-H3X§(param1:Object) : Vector.<Object>
      {
         var _loc2_:Vector.<Object> = new Vector.<Object>();
         var _loc3_:uint = 0;
         var _loc4_:DisplayObject = param1 as DisplayObject;
         while(_loc4_)
         {
            _loc2_[_loc3_] = _loc4_;
            _loc4_ = _loc4_.parent;
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function §_-N2d§() : Class
      {
         return §_-cB§;
      }
   }
}


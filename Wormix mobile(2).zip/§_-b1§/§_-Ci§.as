package §_-b1§
{
   import §_-w2i§.§_-Ia§;
   import feathers.controls.ImageLoader;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import flash.display.DisplayObject;
   import flash.display.Stage;
   import flash.geom.Point;
   import org.gestouch.core.§_-H3d§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import starling.utils.ScaleMode;
   
   public class §_-Ci§ implements §_-H3d§
   {
      
      private var stage:Stage;
      
      public function §_-Ci§(param1:Stage)
      {
         super();
         if(!param1)
         {
            throw ArgumentError("Missing stage argument.");
         }
         this.stage = param1;
      }
      
      public function hitTest(param1:Point, param2:Object = null) : Object
      {
         if(Boolean(param2) && param2 is DisplayObject)
         {
            return param2;
         }
         return §_-03u§.§_-33y§(this.stage,param1);
      }
   }
}


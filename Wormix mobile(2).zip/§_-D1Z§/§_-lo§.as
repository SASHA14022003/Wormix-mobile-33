package §_-D1Z§
{
   import §_-K3r§.§_-E3O§;
   import §_-K3r§.§_-U2b§;
   import §_-U1i§.§_-hK§;
   import §_-l1g§.§_-L3Q§;
   import com.distriqt.extension.inappbilling.Product;
   import feathers.controls.ScreenNavigator;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.screenOverlay.§_-O5§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.RenderTexture;
   import starling.textures.Texture;
   
   public class §_-lo§ implements §_-k2n§
   {
      
      public function §_-lo§()
      {
         super();
      }
      
      public function start() : void
      {
         var _loc1_:§_-E3O§ = new §_-U2b§();
         var _loc2_:ScreenNavigator = new §_-O5§(_loc1_);
         Application.§_-E1k§ = _loc1_;
         Application.§_-F23§ = _loc2_;
      }
   }
}


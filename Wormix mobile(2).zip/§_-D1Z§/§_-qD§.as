package §_-D1Z§
{
   import §_-J3L§.§_-h1D§;
   import §_-K3r§.§_-E3O§;
   import §_-K3r§.§_-M2u§;
   import §_-U1i§.§_-hK§;
   import §_-Vg§.MainClanWindow;
   import §_-Vg§.§_-K3K§;
   import feathers.controls.ScreenNavigator;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.gui.screenOverlay.§_-W5§;
   import ru.pragmatix.wormix.messages.clans.request.treasury.DonateClanRequest;
   import starling.events.Event;
   
   public class §_-qD§ implements §_-k2n§
   {
      
      public function §_-qD§()
      {
         super();
      }
      
      public function start() : void
      {
         var _loc1_:§_-E3O§ = new §_-M2u§();
         var _loc2_:ScreenNavigator = new §_-W5§(_loc1_);
         Application.§_-E1k§ = _loc1_;
         Application.§_-F23§ = _loc2_;
      }
   }
}


package §_-D1Z§
{
   import §_-62§.*;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-ZB§.§_-A10§;
   import §_-q26§.§_-Z25§;
   import §_-w2i§.§_-Zd§;
   import §_-z20§.§_-Tn§;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.game.ai.§_-12u§;
   import ru.pragmatix.wormix.game.ai.§_-H3h§;
   import ru.pragmatix.wormix.game.ai.§_-dG§;
   import ru.pragmatix.wormix.game.ai.§_-n2q§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.MolotovProjectile;
   import starling.utils.SystemUtil;
   
   public class §_-925§
   {
      
      public function §_-925§()
      {
         super();
      }
      
      public static function §_-o1h§() : §_-k2n§
      {
         var _loc1_:§_-k2n§ = null;
         var _loc2_:String = SystemUtil.platform;
         switch(_loc2_)
         {
            case §_-WK§.§_-c1l§:
               §§push(0);
               break;
            case §_-WK§.IOS:
               §§push(1);
               break;
            case §_-WK§.WIN:
               §§push(2);
               break;
            default:
               if(§_-WK§.MAC === _loc2_)
               {
                  §§push(3);
                  break;
               }
               §§push(4);
         }
         switch(§§pop())
         {
            case 0:
            case 1:
               _loc1_ = new §_-lo§();
               break;
            case 2:
            case 3:
               _loc1_ = new §_-qD§();
            default:
               _loc1_ = new §_-qD§();
         }
         if(_loc1_ == null)
         {
            _loc1_ = new §_-qD§();
         }
         return _loc1_;
      }
   }
}


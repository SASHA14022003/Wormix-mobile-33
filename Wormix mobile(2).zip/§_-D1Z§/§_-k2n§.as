package §_-D1Z§
{
   public interface §_-k2n§
   {
      
      function start() : void;
   }
}


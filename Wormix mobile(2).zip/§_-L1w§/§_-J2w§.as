package §_-L1w§
{
   import §_-71F§.§_-M2D§;
   import §_-D3A§.§_-TZ§;
   import §_-Y1Q§.§_-tc§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-sI§;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanInviteTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.phase.HarmPhase;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.utils.Pool;
   
   public class §_-J2w§ extends §_-M2D§
   {
      
      public var §_-C2Y§:int;
      
      public var §_-E24§:int;
      
      public var userProfile:UserProfile;
      
      public function §_-J2w§()
      {
         super();
      }
      
      public function clear() : void
      {
         this.§_-C2Y§ = 0;
         dispatchWith(§_-tc§.§_-Q1G§);
      }
      
      public function §_-93C§() : void
      {
         dispatchWith(§_-tc§.§_-33G§);
      }
      
      public function §_-23u§() : void
      {
         this.§_-E24§ = this.§_-C2Y§;
      }
   }
}


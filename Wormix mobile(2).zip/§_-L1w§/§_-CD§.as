package §_-L1w§
{
   import §_-71C§.§_-cl§;
   import §_-71F§.§_-M2D§;
   import §_-Y1O§.*;
   import §_-rM§.§_-61j§;
   import flash.events.TimerEvent;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.rewards.*;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginErrorType;
   import starling.utils.Color;
   
   public class §_-CD§ extends §_-M2D§
   {
      
      public var name:String;
      
      public var description:String;
      
      public var §_-6B§:Vector.<uint>;
      
      public var §_-o9§:Vector.<uint>;
      
      public var joinRating:int;
      
      public var isExitClosed:Boolean;
      
      public var level:int;
      
      public function §_-CD§()
      {
         super();
         this.clear();
      }
      
      public function clear() : void
      {
         this.name = "";
         this.description = "";
         §§push(this);
         var _temp_4:* = new <uint>[1,1,Color.RED,Color.WHITE];
         §§pop().§_-6B§ = new <uint>[1,1,Color.RED,Color.WHITE];
         §§push(this);
         var _temp_7:* = new <uint>[1,1,Color.RED,Color.WHITE];
         §§pop().§_-o9§ = new <uint>[1,1,Color.RED,Color.WHITE];
         this.joinRating = 0;
         this.isExitClosed = false;
         this.level = 0;
      }
      
      public function §_-XF§(param1:ClanTO) : void
      {
         this.name = param1.name;
         this.description = param1.clanDescription;
         this.§_-6B§ = param1.emblem.concat();
         this.§_-o9§ = param1.emblem.concat();
         this.joinRating = param1.joinRating;
         this.isExitClosed = param1.isExitClosed;
         this.level = param1.level;
      }
   }
}


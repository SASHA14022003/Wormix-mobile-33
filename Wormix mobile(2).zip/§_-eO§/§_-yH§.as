package §_-eO§
{
   import §_-12W§.*;
   import §_-Bv§.§_-G3P§;
   import §_-DJ§.§_-fH§;
   import §_-Vg§.§_-M11§;
   import feathers.core.FeathersControl;
   import flash.display.BitmapData;
   import flash.events.StatusEvent;
   import flash.net.LocalConnection;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class §_-yH§
   {
      
      private static var instance:§_-yH§ = new §_-yH§();
      
      private var §_-JX§:LocalConnection;
      
      private var channelName:String;
      
      private var §_-928§:Boolean = true;
      
      public function §_-yH§()
      {
         super();
         this.channelName = "_pragmatix_progress_bar_";
         this.§_-JX§ = new LocalConnection();
         this.§_-JX§.allowDomain("*");
         this.§_-JX§.addEventListener(StatusEvent.STATUS,this.§_-U2e§);
      }
      
      public static function init(param1:Object) : void
      {
         instance.channelName = param1.channelName || "_pragmatix_progress_bar_";
      }
      
      public static function publish(param1:int) : void
      {
         if(§_-yH§.instance.§_-928§)
         {
            §_-yH§.instance.§_-JX§.send(§_-yH§.instance.channelName,"progress",param1);
         }
      }
      
      private function §_-U2e§(param1:StatusEvent) : void
      {
         if(param1.level == "error")
         {
            this.§_-928§ = false;
         }
      }
   }
}


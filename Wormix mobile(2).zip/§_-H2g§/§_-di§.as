package §_-H2g§
{
   import §_-22z§.*;
   import §_-5P§.*;
   import §_-62§.§_-O2H§;
   import §_-937§.§_-81u§;
   import §_-937§.§_-BO§;
   import §_-937§.§_-T15§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-Y2R§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-CR§.§_-72p§;
   import §_-Cl§.*;
   import §_-D3A§.*;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G16§.§_-Y2x§;
   import §_-H3§.*;
   import §_-K35§.§_-99§;
   import §_-SP§.§_-M4§;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.*;
   import §_-Vu§.MD5;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-s2Z§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-eW§.*;
   import §_-fo§.§_-hH§;
   import §_-g2r§.§_-x8§;
   import §_-j1w§.*;
   import §_-j22§.§_-5g§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.§_-K2W§;
   import §_-q11§.§_-C2n§;
   import §_-s20§.§_-J2g§;
   import §_-u13§.MAC;
   import §_-u1P§.ShopResultEvent;
   import §_-w2W§.*;
   import §_-y1s§.§_-P9§;
   import §_-z1g§.§_-82X§;
   import §_-z1g§.§_-lp§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.crypto.*;
   import com.hurlant.math.*;
   import config.§_-vR§;
   import dragonBones.Armature;
   import dragonBones.Bone;
   import dragonBones.Slot;
   import dragonBones.animation.Animation;
   import dragonBones.animation.WorldClock;
   import dragonBones.events.EventObject;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.IListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.ui.Keyboard;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-gT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.client.GetAchievements;
   import ru.pragmatix.wormix.messages.client.MobileLogin;
   import ru.pragmatix.wormix.messages.client.NotifyProfile;
   import ru.pragmatix.wormix.messages.server.SendWipeConfirmCodeResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.Canvas;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.KeyboardEvent;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-di§ extends EventDispatcher implements §_-F0§, §_-Y2x§
   {
      
      private var bones:Vector.<§_-S2O§>;
      
      private var armature:Armature;
      
      private var §_-Q2A§:Vector.<String> = new Vector.<String>();
      
      private var disposed:Boolean = false;
      
      public function §_-di§()
      {
         super();
         this.clear();
      }
      
      private static function §_-J1U§(param1:Armature, param2:String, param3:Number = -1, param4:Number = -1, param5:int = -1) : void
      {
         if(!param1 || !param1.animation)
         {
            return;
         }
         if(param1.animation.hasAnimation(param2))
         {
            param1.animation.gotoAndPlay(param2,param3,param4,param5);
         }
         var _loc6_:Vector.<Slot> = param1.getSlots();
         var _loc7_:* = int(_loc6_.length);
         while(_loc7_--)
         {
            §_-J1U§(_loc6_[_loc7_].childArmature,param2,param3,param4,param5);
         }
      }
      
      public function init(param1:Armature) : void
      {
         this.armature = param1;
         if(param1.display)
         {
            param1.addEventListener(EventObject.COMPLETE,this.§_-X1R§);
            param1.addEventListener(EventObject.LOOP_COMPLETE,this.§_-Y1F§);
            this.display.addEventListener(Event.REMOVED_FROM_STAGE,this.§_-cu§);
            this.display.addEventListener(Event.ADDED_TO_STAGE,this.§_-cu§);
         }
         if(param1.name)
         {
            this.§_-Q2A§.push(param1.name);
         }
         this.disposed = false;
      }
      
      private function §_-cu§(param1:Event) : void
      {
         dispatchEventWith(param1.type);
      }
      
      private function §_-X1R§(param1:Event) : void
      {
         this.§_-T1q§(§_-s1d§.COMPLETE,param1);
      }
      
      private function §_-Y1F§(param1:Event) : void
      {
         this.§_-T1q§(§_-s1d§.LOOP_COMPLETE,param1);
      }
      
      private function §_-T1q§(param1:String, param2:Event) : void
      {
         dispatchEventWith(param1,param2.bubbles,param2.data);
      }
      
      public function invalidUpdate(param1:String = null, param2:Boolean = false) : void
      {
         this.armature.invalidUpdate(param1,param2);
      }
      
      public function advanceTime(param1:Number) : void
      {
         try
         {
            this.armature.advanceTime(param1);
         }
         catch(e:Error)
         {
         }
      }
      
      public function getBone(param1:String) : §_-S2O§
      {
         var _loc3_:§_-S2O§ = null;
         if(!this.bones)
         {
            this.§_-82N§();
         }
         var _loc2_:* = int(this.bones.length);
         while(_loc2_--)
         {
            _loc3_ = this.bones[_loc2_];
            if(_loc3_.source.name == param1)
            {
               return _loc3_;
            }
         }
         return null;
      }
      
      private function §_-82N§() : void
      {
         var _loc1_:Vector.<Bone> = this.armature.getBones();
         var _loc2_:* = int(_loc1_.length);
         this.bones = new Vector.<§_-S2O§>(_loc2_);
         while(_loc2_--)
         {
            this.bones[_loc2_] = new §_-S2O§(_loc1_[_loc2_]);
         }
      }
      
      public function getSlot(param1:String) : Slot
      {
         return this.source != null ? this.source.getSlot(param1) : null;
      }
      
      public function get source() : Armature
      {
         return this.armature;
      }
      
      public function get animation() : Animation
      {
         return this.armature.animation;
      }
      
      public function get userData() : Object
      {
         return this.armature ? this.armature.userData : null;
      }
      
      public function set userData(param1:Object) : void
      {
         this.armature.userData = param1;
      }
      
      public function get display() : DisplayObject
      {
         return this.armature ? this.armature.display as DisplayObject : null;
      }
      
      private function §_-Z29§() : void
      {
         if(!this.bones)
         {
            return;
         }
         var _loc1_:* = int(this.bones.length);
         while(_loc1_--)
         {
            this.bones[_loc1_].dispose();
         }
         this.bones = null;
      }
      
      private function §_-r1X§(param1:String) : Slot
      {
         var _loc2_:Array = param1.split(".");
         var _loc3_:Slot = this.getSlot(_loc2_[0]);
         var _loc4_:int = 1;
         while(_loc4_ < _loc2_.length)
         {
            if(_loc3_)
            {
               _loc3_ = _loc3_.childArmature.getSlot(_loc2_[_loc4_]);
            }
            _loc4_++;
         }
         return _loc3_;
      }
      
      public function §_-42U§(param1:String, param2:String) : Boolean
      {
         var _loc3_:Slot = this.§_-r1X§(param1);
         if(!_loc3_ || !_loc3_.childArmature)
         {
            return false;
         }
         return _loc3_.childArmature.animation.hasAnimation(param2);
      }
      
      public function §_-I3v§(param1:String, param2:String, param3:Number = -1, param4:Number = -1, param5:int = -1) : void
      {
         var _loc6_:Slot = this.§_-r1X§(param1);
         if((Boolean(_loc6_)) && Boolean(_loc6_.childArmature) && _loc6_.childArmature.animation.hasAnimation(param2))
         {
            _loc6_.childArmature.animation.gotoAndPlay(param2,param3,param4,param5);
         }
      }
      
      public function playAnimation(param1:String, param2:Number = -1, param3:Number = -1, param4:int = -1) : void
      {
         §_-J1U§(this.armature,param1,param2,param3,param4);
      }
      
      public function stopAnimation(param1:String = null) : void
      {
         if(this.animation)
         {
            this.animation.stop(param1);
         }
      }
      
      public function §_-23D§(param1:int, param2:String) : void
      {
         var _loc3_:Slot = this.§_-r1X§(param2);
         if(!_loc3_)
         {
            return;
         }
         var _loc4_:DisplayObject = _loc3_.display as DisplayObject;
         _loc4_.parent.setChildIndex(_loc4_,param1);
      }
      
      protected function clear() : void
      {
         if(Boolean(this.armature) && Boolean(this.armature.display))
         {
            this.armature.removeEventListener(EventObject.COMPLETE,this.§_-X1R§);
            this.armature.removeEventListener(EventObject.LOOP_COMPLETE,this.§_-Y1F§);
            this.display.removeEventListener(Event.REMOVED_FROM_STAGE,this.§_-cu§);
            this.display.removeEventListener(Event.ADDED_TO_STAGE,this.§_-cu§);
         }
         removeEventListeners(§_-s1d§.LOOP_COMPLETE);
         removeEventListeners(§_-s1d§.COMPLETE);
         this.§_-Z29§();
         this.armature = null;
      }
      
      public function dispose() : void
      {
         this.clear();
         if(!this.disposed)
         {
            §_-K1t§.returnToPool(this);
            this.disposed = true;
         }
      }
      
      public function removeFromPool() : void
      {
         this.clear();
      }
   }
}


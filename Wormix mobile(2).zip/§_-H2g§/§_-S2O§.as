package §_-H2g§
{
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-T2y§.*;
   import §_-aM§.*;
   import §_-z1g§.§_-lp§;
   import dragonBones.Armature;
   import dragonBones.Bone;
   import dragonBones.Slot;
   import dragonBones.geom.Transform;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.weapons.ammo.type.RopeHook;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-S2O§
   {
      
      private var bone:Bone;
      
      public function §_-S2O§(param1:Bone)
      {
         super();
         this.bone = param1;
      }
      
      public function get source() : Bone
      {
         return this.bone;
      }
      
      public function get slot() : Slot
      {
         return this.bone.getSlots()[0];
      }
      
      public function get global() : Transform
      {
         return this.bone.global;
      }
      
      public function get origin() : Transform
      {
         return this.bone.origin;
      }
      
      public function get armature() : Armature
      {
         return this.bone.armature;
      }
      
      public function get display() : DisplayObject
      {
         return this.bone.armature.display as DisplayObject;
      }
      
      public function set visible(param1:Boolean) : void
      {
         this.bone.visible = param1;
      }
      
      public function dispose() : void
      {
         this.bone = null;
      }
   }
}


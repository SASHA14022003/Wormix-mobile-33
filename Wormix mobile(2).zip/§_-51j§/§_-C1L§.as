package §_-51j§
{
   import §_-22z§.§_-f1b§;
   import §_-Ly§.§_-81L§;
   import §_-jF§.§_-R1a§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-r1C§.§_-h2B§;
   import §_-w§.§_-63m§;
   import §_-x2Q§.§_-dU§;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.MathUtil;
   
   public class §_-C1L§
   {
      
      private var §_-H17§:List;
      
      private var §_-x2a§:DisplayObject;
      
      private var §_-21a§:DisplayObject;
      
      public function §_-C1L§(param1:List, param2:DisplayObject, param3:DisplayObject)
      {
         var _loc5_:List = null;
         super();
         this.§_-H17§ = param1;
         this.§_-x2a§ = param2;
         this.§_-21a§ = param3;
         var _loc4_:TiledRowsLayout = new TiledRowsLayout();
         _loc4_.verticalAlign = VerticalAlign.TOP;
         _loc4_.horizontalAlign = HorizontalAlign.CENTER;
         _loc4_.paging = Direction.HORIZONTAL;
         _loc4_.verticalGap = 6;
         _loc5_ = param1;
         _loc5_.layout = _loc4_;
         _loc5_.horizontalScrollPolicy = ScrollPolicy.OFF;
         _loc5_.verticalScrollPolicy = ScrollPolicy.OFF;
         _loc5_.itemRendererType = §_-R1a§;
         _loc5_.snapToPages = true;
         _loc5_.addEventListener(Event.SCROLL,this.§_-528§);
         _loc5_.addEventListener(FeathersEventType.RENDERER_ADD,this.§_-Fw§);
         _loc5_.addEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-e1F§);
         param3.addEventListener(Event.TRIGGERED,this.§_-d1k§);
         param2.addEventListener(Event.TRIGGERED,this.§_-wd§);
      }
      
      public function dispose() : void
      {
         this.§_-H17§.removeEventListener(Event.SCROLL,this.§_-528§);
         this.§_-H17§.removeEventListener(FeathersEventType.RENDERER_ADD,this.§_-Fw§);
         this.§_-H17§.removeEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-e1F§);
         this.§_-21a§.removeEventListener(Event.TRIGGERED,this.§_-d1k§);
         this.§_-x2a§.removeEventListener(Event.TRIGGERED,this.§_-wd§);
      }
      
      public function §_-Za§(param1:UserProfile) : void
      {
         var _loc6_:§_-Oi§ = null;
         var _loc8_:§_-63m§ = null;
         var _loc9_:§_-Oi§ = null;
         var _loc10_:Boolean = false;
         var _loc11_:int = 0;
         var _loc2_:§_-F3H§ = §_-33r§.§_-5o§(param1);
         var _loc3_:§_-2m§ = param1.§_-pd§();
         var _loc4_:Array = _loc2_.§_-P2l§();
         if(!_loc4_)
         {
            return;
         }
         var _loc5_:ListCollection = this.§_-H17§.dataProvider as ListCollection;
         _loc5_.removeAll();
         var _loc7_:int = 0;
         while(_loc7_ < _loc4_.length)
         {
            _loc6_ = _loc4_[_loc7_] as §_-Oi§;
            if(_loc6_)
            {
               _loc8_ = new §_-63m§();
               _loc8_.§_-13k§ = _loc6_;
               _loc9_ = _loc3_.§_-d0§(_loc6_.getId());
               _loc10_ = (Boolean(_loc9_)) && _loc9_.getLevel() == _loc6_.getLevel();
               _loc8_.§_-9m§ = !_loc10_;
               _loc11_ = Application.§_-SH§.§_-x2k§ ? §_-f1b§.getKey(_loc6_.getId()) : -1;
               if(_loc11_ != -1)
               {
                  _loc8_.§_-i7§ = §_-f1b§.§_-d2Y§(_loc11_);
               }
               _loc5_.addItem(_loc8_);
            }
            _loc7_++;
         }
      }
      
      private function §_-528§(param1:Event) : void
      {
         var _loc2_:List = param1.target as List;
         this.§_-21a§.visible = _loc2_.horizontalPageIndex < _loc2_.horizontalPageCount - 1;
         this.§_-x2a§.visible = _loc2_.horizontalPageIndex > 0;
      }
      
      private function §_-Fw§(param1:Event) : void
      {
         var _loc2_:DefaultListItemRenderer = param1.data as DefaultListItemRenderer;
         _loc2_.addEventListener(TouchEvent.TOUCH,this.§_-W2O§);
      }
      
      private function §_-e1F§(param1:Event) : void
      {
         var _loc2_:DefaultListItemRenderer = param1.data as DefaultListItemRenderer;
         _loc2_.removeEventListener(TouchEvent.TOUCH,this.§_-W2O§);
      }
      
      private function §_-W2O§(param1:TouchEvent) : void
      {
         var _loc5_:Object = null;
         var _loc2_:DefaultListItemRenderer = param1.currentTarget as DefaultListItemRenderer;
         var _loc3_:Touch = param1.getTouch(_loc2_,TouchPhase.HOVER);
         var _loc4_:List = _loc2_.owner;
         if(Boolean(_loc3_) && Boolean(_loc2_))
         {
            _loc5_ = _loc2_.data;
            if((Boolean(_loc5_)) && _loc4_.selectedItem != _loc5_)
            {
               _loc4_.selectedItem = _loc5_;
            }
         }
         else
         {
            _loc4_.selectedIndex = -1;
         }
      }
      
      private function §_-d1k§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         this.§_-O1v§(1);
      }
      
      private function §_-wd§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         this.§_-O1v§(-1);
      }
      
      private function §_-O1v§(param1:int = 0) : void
      {
         var _loc2_:List = this.§_-H17§;
         var _loc3_:int = MathUtil.clamp(_loc2_.horizontalPageIndex + param1,0,_loc2_.horizontalPageCount - 1);
         _loc2_.scrollToPageIndex(_loc3_,0,0);
      }
   }
}


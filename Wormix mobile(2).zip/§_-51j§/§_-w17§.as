package §_-51j§
{
   import §_-Vu§.MD5;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-w17§ extends EventDispatcher
   {
      
      private var §_-eL§:Sprite;
      
      private var §_-A2I§:§_-G1F§;
      
      private var §_-W1O§:§_-C2c§;
      
      public function §_-w17§(param1:Sprite)
      {
         super();
         this.§_-eL§ = param1;
      }
      
      public function dispose() : void
      {
         this.§_-r1c§();
         if(this.§_-A2I§)
         {
            this.§_-A2I§.dispose();
         }
      }
      
      public function init() : void
      {
         Application.§_-SH§.addEventListener(Event.CHANGE,this.§_-C3y§);
         Application.§_-SH§.addEventListener(Event.UPDATE,this.§_-C3y§);
         this.§_-C3y§();
      }
      
      private function §_-C3y§(param1:Event = null) : void
      {
         this.§_-r1c§();
         var _loc2_:UserProfile = Application.§_-SH§.userProfile;
         this.§_-W1O§ = _loc2_.§_-pk§();
         this.§_-W1O§.addEventListener(Event.COMPLETE,this.§_-h29§);
         this.§_-W1O§.addEventListener(Event.TRIGGERED,this.§_-h29§);
         if(!this.§_-A2I§)
         {
            this.§_-A2I§ = new §_-G1F§(this.§_-eL§,this.§_-W1O§);
         }
         else
         {
            this.§_-A2I§.§_-7N§(this.§_-W1O§);
         }
         if(this.§_-eL§)
         {
            this.§_-eL§.visible = _loc2_.§_-33n§();
         }
      }
      
      private function §_-h29§(param1:Event) : void
      {
         if(this.§_-eL§)
         {
            this.§_-eL§.visible = Application.§_-SH§.userProfile.§_-33n§();
         }
         dispatchEventWith(Event.CHANGE);
      }
      
      private function §_-r1c§() : void
      {
         if(this.§_-W1O§)
         {
            this.§_-W1O§.removeEventListener(Event.COMPLETE,this.§_-h29§);
            this.§_-W1O§.removeEventListener(Event.TRIGGERED,this.§_-h29§);
            this.§_-W1O§ = null;
         }
      }
   }
}


package §_-51j§
{
   import §_-22z§.§_-f1b§;
   import §_-k1u§.§_-Oi§;
   import §_-w§.§_-63m§;
   import feathers.controls.List;
   import feathers.data.ListCollection;
   import feathers.events.CollectionEventType;
   import flash.utils.Dictionary;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   
   public class §_-X19§
   {
      
      private var §_-x1H§:Dictionary;
      
      private var §_-6e§:List;
      
      private var §_-R6§:ListCollection;
      
      public function §_-X19§(param1:List)
      {
         super();
         this.§_-6e§ = param1;
         this.§_-x1H§ = new Dictionary();
         this.§_-R6§ = param1.dataProvider as ListCollection;
         if(this.§_-R6§)
         {
            this.§_-R6§.addEventListener(CollectionEventType.ADD_ITEM,this.§_-eD§);
         }
         Starling.current.stage.addEventListener(KeyboardEvent.KEY_DOWN,this.onKeyDown);
      }
      
      public function dispose() : void
      {
         this.§_-6e§ = null;
         this.§_-x1H§ = null;
         if(this.§_-R6§)
         {
            this.§_-R6§.removeEventListener(CollectionEventType.ADD_ITEM,this.§_-eD§);
            this.§_-R6§ = null;
         }
         Starling.current.stage.removeEventListener(KeyboardEvent.KEY_DOWN,this.onKeyDown);
      }
      
      private function §_-eD§(param1:Event) : void
      {
         var _loc4_:int = 0;
         var _loc2_:int = int(param1.data as int);
         var _loc3_:§_-63m§ = this.§_-R6§.getItemAt(_loc2_) as §_-63m§;
         if(_loc3_)
         {
            _loc4_ = §_-f1b§.getKey(_loc3_.§_-13k§.getId());
            if(_loc4_ != -1)
            {
               this.§_-x1H§[_loc4_] = _loc3_;
            }
         }
      }
      
      private function onKeyDown(param1:KeyboardEvent) : void
      {
         var _loc3_:§_-63m§ = null;
         var _loc4_:§_-Oi§ = null;
         var _loc5_:int = 0;
         var _loc6_:uint = 0;
         if(!Application.§_-SH§.§_-x2k§)
         {
            return;
         }
         var _loc2_:List = this.§_-6e§;
         if(_loc2_.selectedIndex != -1)
         {
            _loc3_ = _loc2_.selectedItem as §_-63m§;
            if(_loc3_)
            {
               _loc4_ = _loc3_.§_-13k§;
               _loc5_ = _loc4_.getId();
               _loc6_ = param1.keyCode;
               if(§_-f1b§.getKey(_loc5_) != _loc6_)
               {
                  if(§_-f1b§.§_-81G§(_loc6_,_loc5_))
                  {
                     this.§_-qO§(_loc3_,_loc6_,_loc2_);
                  }
               }
               else
               {
                  §_-f1b§.§_-Ju§(_loc6_);
                  this.§_-qO§(null,_loc6_,_loc2_);
               }
            }
         }
      }
      
      private function §_-qO§(param1:§_-63m§, param2:uint, param3:List) : void
      {
         var _loc4_:§_-63m§ = this.§_-x1H§[param2] as §_-63m§;
         var _loc5_:String = §_-f1b§.§_-d2Y§(param2);
         if(Boolean(_loc4_) && _loc4_.§_-i7§ == _loc5_)
         {
            _loc4_.§_-i7§ = null;
         }
         this.§_-x1H§[param2] = param1;
         if(param1)
         {
            param1.§_-i7§ = _loc5_;
         }
         var _loc6_:ListCollection = param3.dataProvider as ListCollection;
         var _loc7_:int = _loc6_.getItemIndex(param1);
         _loc6_.updateItemAt(_loc7_);
         _loc7_ = _loc6_.getItemIndex(_loc4_);
         _loc6_.updateItemAt(_loc7_);
      }
   }
}


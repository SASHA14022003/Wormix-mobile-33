package §_-91B§
{
   import §_-12W§.*;
   import §_-A1K§.§_-TA§;
   import §_-DJ§.§_-fH§;
   import §_-K3r§.§_-E3O§;
   import §_-K3r§.§_-U2b§;
   import §_-R2S§.*;
   import §_-b1F§.§_-G4§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.util.§_-F2L§;
   import feathers.controls.ScreenNavigator;
   import feathers.themes.FontColor;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.§_-O5§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.pvp.messages.wager.WagerCancelBattle;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import ru.pragmatix.wormix.weapons.DoctorBag;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-z2l§
   {
      
      public static const NORMAL:§_-z2l§ = new §_-z2l§("PREFIX.NORMAL",AlternateTextStyles.ITEM_NAME_NORMAL,FontColor.ITEM_COLOR_NORMAL);
      
      public static const SUPERIOR:§_-z2l§ = new §_-z2l§("PREFIX.SUPERIOR",AlternateTextStyles.ITEM_NAME_SUPERIOR,FontColor.ITEM_COLOR_SUPERIOR);
      
      public static const AGGRESSIVE:§_-z2l§ = new §_-z2l§("PREFIX.AGGRESSIVE",AlternateTextStyles.ITEM_NAME_AGGRESSIVE,FontColor.ITEM_COLOR_AGGRESSIVE);
      
      public static const DEFENSIVE:§_-z2l§ = new §_-z2l§("PREFIX.DEFENSIVE",AlternateTextStyles.ITEM_NAME_DEFENSIVE,FontColor.ITEM_COLOR_DEFENSIVE);
      
      public static const VIOLENT:§_-z2l§ = new §_-z2l§("PREFIX.VIOLENT",AlternateTextStyles.ITEM_NAME_VIOLENT,FontColor.ITEM_COLOR_VIOLENT);
      
      public static const EPIC:§_-z2l§ = new §_-z2l§("PREFIX.EPIC",AlternateTextStyles.ITEM_NAME_EPIC,FontColor.ITEM_COLOR_EPIC);
      
      public static const LEGENDARY:§_-z2l§ = new §_-z2l§("PREFIX.LEGENDARY",AlternateTextStyles.ITEM_NAME_LEGENDARY,FontColor.ITEM_COLOR_LEGENDARY);
      
      private var name:String;
      
      private var §_-73a§:String;
      
      private var color:uint;
      
      public function §_-z2l§(param1:String, param2:String, param3:uint)
      {
         super();
         this.name = param1;
         this.§_-73a§ = param2;
         this.color = param3;
      }
      
      public function getName() : String
      {
         return this.name;
      }
      
      public function §_-Z2F§() : String
      {
         return this.§_-73a§;
      }
      
      public function §_-P2B§() : uint
      {
         return this.color;
      }
   }
}


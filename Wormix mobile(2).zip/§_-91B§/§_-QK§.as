package §_-91B§
{
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-62§.§_-W1r§;
   import §_-G1h§.*;
   import §_-X14§.MainSidePanel;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-q2v§;
   import §_-e2r§.*;
   import §_-l1K§.§_-F3m§;
   import §_-l1K§.§_-I7§;
   import §_-l1K§.§_-m2§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-f2L§;
   import §_-r1C§.§_-h2B§;
   import §_-u1m§.*;
   import feathers.controls.text.BitmapFontTextRenderer;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.text.BitmapFontTextFormat;
   import flash.geom.Point;
   import flash.globalization.DateTimeFormatter;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.Dictionary;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.gui.controls.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-QK§
   {
      
      private var §_-Xt§:int = 0;
      
      private var name:String = "N/A";
      
      private var equipId:int;
      
      private var §_-vc§:§_-z2l§;
      
      private var §_-Us§:Object;
      
      private var §_-b1t§:§_-N1H§;
      
      public function §_-QK§(param1:uint, param2:§_-z2l§, param3:Object = null)
      {
         super();
         this.equipId = param1;
         this.§_-vc§ = param2;
         if(!param3)
         {
            param3 = {};
         }
         this.§_-b1t§ = new §_-N1H§(§_-N1H§.NONE);
         §_-2t§.§_-X1r§(this.§_-b1t§,param3);
         this.§_-Us§ = param3;
      }
      
      public function §_-Sn§(param1:CraftedEquipFamily) : void
      {
         this.§_-Xt§ = param1.getId();
         this.name = param1.getName();
      }
      
      public function §_-62n§() : int
      {
         return this.§_-Xt§ + this.equipId;
      }
      
      public function §_-Gr§() : String
      {
         return this.name;
      }
      
      public function getType() : §_-z2l§
      {
         return this.§_-vc§;
      }
      
      public function §_-x1C§() : Object
      {
         return this.§_-Us§;
      }
      
      public function §_-V1v§() : §_-N1H§
      {
         return this.§_-b1t§;
      }
   }
}


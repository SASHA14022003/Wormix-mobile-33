package §_-Ly§
{
   import §_-62§.§_-G1p§;
   import §_-73d§.§_-V19§;
   import §_-73d§.§_-pT§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-K2e§;
   import §_-L1H§.§_-C3e§;
   import §_-e1e§.§_-CG§;
   import §_-l1K§.§_-W2f§;
   import §_-r1C§.§_-t1R§;
   import flash.display.DisplayObjectContainer;
   import flash.display.StageDisplayState;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.AmmoPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   
   public class §_-81L§
   {
      
      public static var §_-WH§:§_-t1R§;
      
      public static var §_-o1Z§:§_-t1R§;
      
      public static var §_-g0§:§_-t1R§;
      
      public static var §_-jn§:§_-t1R§;
      
      public static var §_-B3D§:§_-t1R§;
      
      public static var §_-D1q§:§_-t1R§;
      
      public static var §_-TH§:§_-t1R§;
      
      public static var §_-q2C§:§_-t1R§;
      
      public static var §_-Cu§:§_-t1R§;
      
      private static var §_-93§:§_-K2e§;
      
      public static var §_-C3b§:String = "Qtip";
      
      public static var §_-I3X§:String = "MsgBox";
      
      public static var §_-YC§:uint = 10066329;
      
      public static var §_-a1e§:Number = 0.5;
      
      public static var §_-N2p§:Boolean = false;
      
      public static var §_-sq§:Boolean = true;
      
      public static var §_-a1Z§:Boolean = false;
      
      public function §_-81L§()
      {
         super();
      }
      
      public static function get stageWidth() : int
      {
         if(§_-93§.getInstance().stage.displayState == StageDisplayState.NORMAL)
         {
            return §_-93§.stageWidth;
         }
         return §_-93§.getInstance().stage.stageWidth;
      }
      
      public static function get stageHeight() : int
      {
         if(§_-93§.getInstance().stage.displayState == StageDisplayState.NORMAL)
         {
            return §_-93§.stageHeight;
         }
         return §_-93§.getInstance().stage.stageHeight;
      }
      
      public static function get scene() : DisplayObjectContainer
      {
         return §_-93§.getInstance();
      }
      
      public static function §_-FZ§(param1:§_-K2e§) : void
      {
         §_-93§ = param1;
      }
      
      public static function §_-8H§(param1:Boolean) : void
      {
         if(param1)
         {
            §_-CG§.init();
         }
      }
   }
}


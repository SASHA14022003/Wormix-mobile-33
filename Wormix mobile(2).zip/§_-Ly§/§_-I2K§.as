package §_-Ly§
{
   import §_-9§.§_-52A§;
   import §_-931§.§_-sz§;
   import §_-B1y§.§_-fM§;
   import §_-d26§.§_-d1H§;
   import §_-i1D§.*;
   import §_-n1w§.X509Certificate;
   import §_-o14§.*;
   import §_-s20§.§_-J2g§;
   import §_-u2J§.§_-T1K§;
   import com.hurlant.crypto.tls.*;
   import com.mesmotronic.ane.AndroidID;
   import feathers.layout.VerticalAlign;
   import flash.utils.ByteArray;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class §_-I2K§
   {
      
      private static var §_-i1N§:§_-I2K§;
      
      public static var §_-335§:§_-11S§ = new §_-11S§(§_-I2K§);
      
      private static var §_-X1§:int = 0;
      
      private static var §_-I3J§:String = "cp_";
      
      private var §_-J10§:Vector.<§_-sz§> = new Vector.<§_-sz§>();
      
      public function §_-I2K§()
      {
         super();
         §_-52A§.§_-Q18§(this.§_-E3V§);
      }
      
      public static function §_-wu§() : String
      {
         return §_-I3J§ + §_-X1§++;
      }
      
      public static function §_-E1V§(param1:Object) : void
      {
         §_-335§.info(param1,"test");
      }
      
      public static function §_-yV§(param1:§_-sz§) : void
      {
         §_-i1N§.§_-yV§(param1);
      }
      
      public static function §_-Il§(param1:§_-sz§) : void
      {
         §_-i1N§.§_-Il§(param1);
      }
      
      public static function init() : void
      {
         if(!§_-i1N§)
         {
            §_-i1N§ = new §_-I2K§();
         }
      }
      
      private function §_-yV§(param1:§_-sz§) : void
      {
         this.§_-J10§.push(param1);
      }
      
      private function §_-Il§(param1:§_-sz§) : void
      {
         §_-fM§.remove(this.§_-J10§,param1);
      }
      
      private function §_-E3V§() : void
      {
         var _loc1_:§_-sz§ = null;
         for each(_loc1_ in this.§_-J10§)
         {
            _loc1_.§_-o1y§();
         }
      }
   }
}


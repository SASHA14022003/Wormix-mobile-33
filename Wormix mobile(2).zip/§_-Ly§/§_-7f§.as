package §_-Ly§
{
   import §_-P1z§.*;
   import §_-Tm§.§_-RF§;
   import §_-Z1K§.§_-q24§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-w2i§.§_-Zd§;
   import dragonBones.animation.WorldClock;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-7f§
   {
      
      public static var LOADING:String = "LOADING";
      
      public static var BUTTON_OK:String = "BUTTON_OK";
      
      public static var BUTTON_YES:String = "BUTTON_YES";
      
      public static var BUTTON_CANCEL:String = "BUTTON_CANCEL";
      
      public function §_-7f§()
      {
         super();
      }
   }
}


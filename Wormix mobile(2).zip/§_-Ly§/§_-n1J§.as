package §_-Ly§
{
   import §_-02q§.§_-4s§;
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.§_-63i§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F2Q§.GestureEvent;
   import §_-H2g§.§_-di§;
   import §_-P2i§.§_-b7§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1O§.*;
   import §_-Z1K§.§_-q24§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.§_-4l§;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFieldAutoSize;
   import flash.text.TextFieldType;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.response.ListClansResponse;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.server.GetDailyBonusResult;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-n1J§
   {
      
      public function §_-n1J§()
      {
         super();
      }
      
      public static function §_-G34§(param1:TextFormat, param2:Array = null) : TextField
      {
         var _loc3_:TextField = new TextField();
         _loc3_.autoSize = TextFieldAutoSize.LEFT;
         if(param1)
         {
            _loc3_.defaultTextFormat = param1;
         }
         if(param2)
         {
            _loc3_.filters = param2;
         }
         _loc3_.selectable = false;
         _loc3_.mouseEnabled = false;
         return _loc3_;
      }
      
      public static function createTextField(param1:String, param2:TextFormat, param3:Array = null) : TextField
      {
         var _loc4_:TextField = §_-G34§(param2,param3);
         _loc4_.text = param1;
         return _loc4_;
      }
      
      public static function §_-K1h§(param1:String, param2:TextFormat, param3:Array = null) : TextField
      {
         var _loc4_:TextField = §_-G34§(param2,param3);
         _loc4_.multiline = true;
         _loc4_.htmlText = param1;
         return _loc4_;
      }
      
      public static function §_-r10§(param1:DisplayObjectContainer, param2:String, param3:Boolean = true) : TextField
      {
         var _loc4_:TextField = TextField(param1.getChildByName(param2));
         var _loc5_:TextField = new TextField();
         if(param3)
         {
            _loc5_.defaultTextFormat = _loc4_.getTextFormat();
         }
         _loc5_.x = _loc4_.x;
         _loc5_.y = _loc4_.y;
         _loc5_.width = _loc4_.width;
         _loc5_.height = _loc4_.height;
         _loc5_.selectable = true;
         _loc5_.mouseEnabled = true;
         _loc5_.type = TextFieldType.INPUT;
         param1.addChild(_loc5_);
         param1.swapChildren(_loc4_,_loc5_);
         param1.removeChild(_loc4_);
         return _loc5_;
      }
      
      public static function §_-23E§(param1:§_-zi§, param2:String, param3:String) : TextField
      {
         var _loc4_:TextField = §_-4s§.§_-2P§(param1.§_-j2l§(),param2);
         §_-PO§(_loc4_,param3);
         return _loc4_;
      }
      
      public static function §_-PO§(param1:TextField, param2:String) : void
      {
         §_-63I§(param1,param2 + ":");
      }
      
      public static function §_-c2v§(param1:§_-zi§, param2:String, param3:String) : TextField
      {
         var _loc4_:TextField = §_-4s§.§_-2P§(param1.§_-j2l§(),param2);
         §_-63I§(_loc4_,param3);
         return _loc4_;
      }
      
      public static function §_-63I§(param1:TextField, param2:String) : void
      {
         param1.htmlText = "<b>" + param2 + "</b>";
      }
      
      public static function §_-21y§(param1:TextField, param2:String, param3:TextFormat = null) : void
      {
         if(param3)
         {
            §_-03U§(param1,param3);
         }
         param1.text = (param2 ? param2 : "") + ":";
      }
      
      public static function §_-n2v§(param1:§_-zi§, param2:String, param3:String, param4:TextFormat = null) : TextField
      {
         var _loc5_:TextField = §_-4s§.§_-2P§(param1.§_-j2l§(),param2);
         §_-21y§(_loc5_,param3,param4);
         return _loc5_;
      }
      
      public static function §_-3v§(param1:flash.display.DisplayObject, param2:String, param3:String, param4:TextFormat = null) : TextField
      {
         var _loc5_:TextField = DisplayObjectContainer(param1).getChildByName(param2) as TextField;
         §_-21y§(_loc5_,param3,param4);
         return _loc5_;
      }
      
      public static function §_-03U§(param1:TextField, param2:TextFormat, param3:String = null) : void
      {
         param1.embedFonts = true;
         if(param2)
         {
            param1.defaultTextFormat = param2;
            param1.setTextFormat(param2);
         }
         if(param3)
         {
            param1.text = param3;
         }
      }
   }
}


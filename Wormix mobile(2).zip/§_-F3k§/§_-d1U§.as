package §_-F3k§
{
   import §_-21p§.§_-4w§;
   import §_-31N§.§_-42G§;
   import §_-DJ§.§_-J2l§;
   import §_-U1i§.§_-J1§;
   import §_-Y1O§.§_-42h§;
   import §_-Z1K§.§_-q24§;
   import §_-a19§.§_-g1S§;
   import §_-b1F§.§_-v2Q§;
   import §_-f1Q§.*;
   import §_-j1w§.§_-L1x§;
   import §_-p24§.*;
   import §_-qH§.§_-S25§;
   import com.hurlant.math.*;
   import flash.events.Event;
   import flash.events.NativeWindowDisplayStateEvent;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   import ru.pragmatix.flox.social.controller.ICustomInviter;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   public class §_-d1U§
   {
      
      private static const §_-kY§:Vector.<§_-L1x§> = new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-l2G§];
      
      §§push(§§findproperty(§_-J1M§));
      var _temp_4:* = new <§_-de§>[new §_-de§(§_-q24§.ANTITOXIN,0.2,1,18),new §_-de§(§_-q24§.BANDAGE,0.3,1,20),new §_-de§(§_-q24§.WATERMELON,0.1,1,15),new §_-de§(§_-q24§.CANNON,0.1,1,15),new §_-de§(§_-q24§.CANNON_UPG_1,0.1,1,15),new §_-de§(§_-q24§.CANNON_UPG_2,0.1,1,15)];
      var _temp_7:* = new <§_-de§>[new §_-de§(§_-q24§.ANTITOXIN,0.2,1,18),new §_-de§(§_-q24§.BANDAGE,0.3,1,20),new §_-de§(§_-q24§.WATERMELON,0.1,1,15),new §_-de§(§_-q24§.CANNON,0.1,1,15),new §_-de§(§_-q24§.CANNON_UPG_1,0.1,1,15),new §_-de§(§_-q24§.CANNON_UPG_2,0.1,1,15)];
      
      private static var §_-J1M§:Vector.<§_-de§> = new <§_-de§>[new §_-de§(§_-q24§.ANTITOXIN,0.2,1,18),new §_-de§(§_-q24§.BANDAGE,0.3,1,20),new §_-de§(§_-q24§.WATERMELON,0.1,1,15),new §_-de§(§_-q24§.CANNON,0.1,1,15),new §_-de§(§_-q24§.CANNON_UPG_1,0.1,1,15),new §_-de§(§_-q24§.CANNON_UPG_2,0.1,1,15)];
      
      private var §_-02y§:Array;
      
      public function §_-d1U§()
      {
         §§push(this);
         §§push({
            "hatId":0,
            "pricePoints":5,
            "minLevelUser":1,
            "maxLevelUser":12,
            "races":§_-kY§,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.5,-1,5)]
         });
         §§push({
            "hatId":§_-S25§.FARMER,
            "pricePoints":6,
            "minLevelUser":5,
            "maxLevelUser":16,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-q1w§],
            "races":§_-kY§,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.5,-1,5),new §_-de§(§_-q24§.§_-K3z§,0.4)]
         });
         §§push({
            "hatId":§_-S25§.WIZARD,
            "pricePoints":6,
            "minLevelUser":5,
            "maxLevelUser":16,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-q1w§],
            "races":§_-kY§,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.4),new §_-de§(§_-q24§.§_-K3z§,0.7),new §_-de§(§_-q24§.SHOTGUN,0.3)]
         });
         §§push({
            "hatId":§_-S25§.§_-w1§,
            "pricePoints":7,
            "minLevelUser":5,
            "maxLevelUser":16,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.7),new §_-de§(§_-q24§.SHOTGUN,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-ck§,
            "pricePoints":7,
            "minLevelUser":5,
            "maxLevelUser":16,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-q1w§],
            "races":§_-kY§,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.5),new §_-de§(§_-q24§.§_-K3z§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-W1A§,
            "pricePoints":9,
            "minLevelUser":6,
            "maxLevelUser":17,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-I1h§,§_-L1x§.§_-l2G§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.7),new §_-de§(§_-q24§.§_-82U§,0.7),new §_-de§(§_-q24§.SHOTGUN,0.4)]
         });
         §§push({
            "hatId":§_-S25§.§_-c2F§,
            "pricePoints":10,
            "minLevelUser":7,
            "maxLevelUser":17,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MINIGUN,0.8),new §_-de§(§_-q24§.SHOTGUN,0.5)]
         });
         §§push({
            "hatId":§_-S25§.SOMBRERO,
            "pricePoints":11,
            "minLevelUser":8,
            "maxLevelUser":18,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-q1w§],
            "races":§_-kY§,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.SHOTGUN,0.7),new §_-de§(§_-q24§.MORTAR,0.7)]
         });
         §§push({
            "hatId":§_-S25§.§_-x2O§,
            "pricePoints":12,
            "minLevelUser":8,
            "maxLevelUser":18,
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MINIGUN,0.5,-1,1),new §_-de§(§_-q24§.§_-LY§,0.5,-1,13),new §_-de§(§_-q24§.§_-82U§,0.7),new §_-de§(§_-q24§.§_-K3z§,0.7)]
         });
         §§push({
            "hatId":§_-S25§.§_-c16§,
            "pricePoints":14,
            "minLevelUser":9,
            "maxLevelUser":20,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-31m§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.7),new §_-de§(§_-q24§.§_-G2Z§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-nn§,
            "pricePoints":14,
            "minLevelUser":9,
            "maxLevelUser":19,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-K3z§,0.7),new §_-de§(§_-q24§.§_-82U§,0.7),new §_-de§(§_-q24§.MORTAR,0.6),new §_-de§(§_-q24§.§_-i2k§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.VIKING,
            "pricePoints":16,
            "minLevelUser":10,
            "maxLevelUser":20,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.MORTAR,0.6),new §_-de§(§_-q24§.§_-82U§,0.6)]
         });
         §§push({
            "hatId":§_-S25§.§_-N2L§,
            "pricePoints":17,
            "minLevelUser":11,
            "maxLevelUser":21,
            "races":new <§_-L1x§>[§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§,0.7),new §_-de§(§_-q24§.SHOTGUN,0.7),new §_-de§(§_-q24§.MINIGUN,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-L1p§,
            "pricePoints":18,
            "minLevelUser":11,
            "maxLevelUser":21,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CAT_BAZOOKA,0.7),new §_-de§(§_-q24§.MINIGUN,0.6),new §_-de§(§_-q24§.MORTAR,0.6),new §_-de§(§_-q24§.§_-K3z§,0.6)]
         });
         §§push({
            "hatId":§_-S25§.§_-g1I§,
            "pricePoints":19,
            "minLevelUser":11,
            "maxLevelUser":22,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CAT_BAZOOKA,0.7,-1,1),new §_-de§(§_-q24§.§_-z12§,0.7,-1,20),new §_-de§(§_-q24§.§_-i2k§,0.7),new §_-de§(§_-q24§.§_-Qf§,0.5),new §_-de§(§_-q24§.MINIGUN,0.6)]
         });
         §§push({
            "hatId":§_-S25§.§_-Q2M§,
            "pricePoints":20,
            "minLevelUser":12,
            "maxLevelUser":22,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§],
            "races":new <§_-L1x§>[§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,0.7),new §_-de§(§_-q24§.MORTAR,0.6,-1,1),new §_-de§(§_-q24§.§_-A1a§,0.6,-1,20)]
         });
         §§push({
            "hatId":§_-S25§.ELVIS,
            "pricePoints":20,
            "minLevelUser":12,
            "maxLevelUser":22,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CAT_BAZOOKA,0.7),new §_-de§(§_-q24§.§_-82U§,0.5),new §_-de§(§_-q24§.§_-xS§,0.6,-1,18),new §_-de§(§_-q24§.MOLOTOV,0.6,-1,21)]
         });
         §§push({
            "hatId":§_-S25§.PIRATE,
            "pricePoints":21,
            "minLevelUser":12,
            "maxLevelUser":23,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§],
            "races":new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-g1q§,0.7),new §_-de§(§_-q24§.§_-Qf§,0.6),new §_-de§(§_-q24§.SNIPER_RIFLE,0.5),new §_-de§(§_-q24§.CANNON,0.6,-1,16)]
         });
         §§push({
            "hatId":§_-S25§.INDIAN,
            "pricePoints":22,
            "minLevelUser":13,
            "maxLevelUser":24,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§],
            "races":new <§_-L1x§>[§_-L1x§.§_-l2G§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,0.7),new §_-de§(§_-q24§.§_-i2k§,0.6),new §_-de§(§_-q24§.§_-82U§,0.7)]
         });
         §§push({
            "hatId":§_-S25§.SAMURAI,
            "pricePoints":23,
            "minLevelUser":13,
            "maxLevelUser":24,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CAT_BAZOOKA,0.7),new §_-de§(§_-q24§.§_-LY§,0.6),new §_-de§(§_-q24§.§_-82U§,0.5),new §_-de§(§_-q24§.SHURIKEN,0.1,-1,1),new §_-de§(§_-q24§.§_-G2Z§,0.1,-1,18)]
         });
         §§push({
            "hatId":§_-S25§.§_-81w§,
            "pricePoints":24,
            "minLevelUser":15,
            "maxLevelUser":26,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-l2G§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.SHOTGUN,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-p2J§,
            "pricePoints":24,
            "minLevelUser":15,
            "maxLevelUser":26,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-r2y§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§,0.7),new §_-de§(§_-q24§.CAT_BAZOOKA,0.7,-1,1),new §_-de§(§_-q24§.§_-z12§,0.7,-1,20),new §_-de§(§_-q24§.§_-G2Z§,0.6)]
         });
         §§push({
            "hatId":§_-S25§.§_-D1B§,
            "pricePoints":25,
            "minLevelUser":16,
            "maxLevelUser":28,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-i2k§,0.7),new §_-de§(§_-q24§.SNIPER_RIFLE,0.6),new §_-de§(§_-q24§.MINIGUN,0.5),new §_-de§(§_-q24§.AK_47,0.5,-1,19)]
         });
         §§push({
            "hatId":§_-S25§.AQUALUNG,
            "pricePoints":26,
            "minLevelUser":17,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-l2G§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-Qf§,0.7),new §_-de§(§_-q24§.CANNON,0.7,-1,1),new §_-de§(§_-q24§.CANNON_UPG_1,0.7,-1,22),new §_-de§(§_-q24§.MORTAR,0.5)]
         });
         §§push({
            "hatId":§_-S25§.NIMBUS,
            "pricePoints":27,
            "minLevelUser":17,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-r2y§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-g1q§,0.7,-1),new §_-de§(§_-q24§.SNIPER_RIFLE,0.6,-1,1),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.6,-1,23),new §_-de§(§_-q24§.CAT_BAZOOKA,0.5)]
         });
         §§push("hatId");
         §§push(§_-S25§.TRIBAL);
         §§push("pricePoints");
         §§push(27);
         §§push("minLevelUser");
         §§push(17);
         §§push("typeParams");
         §§push(new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-q1w§]);
         §§push("races");
         §§push(new <§_-L1x§>[§_-L1x§.§_-I1h§,§_-L1x§.§_-r2y§]);
         §§push("baseArsenal");
         §§push(null);
         §§push({
            "hatId":§_-S25§.§_-v1z§,
            "pricePoints":28,
            "minLevelUser":19,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-r2y§,§_-L1x§.§_-I1h§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-13G§,0.1,-1,19),new §_-de§(§_-q24§.§_-AV§,0.1,-1,25),new §_-de§(§_-q24§.§_-Qf§,0.4),new §_-de§(§_-q24§.§_-z12§,0.7,-1,1),new §_-de§(§_-q24§.§_-w2m§,0.7,-1,24),new §_-de§(§_-q24§.§_-82U§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.CHIEFTAIN,
            "pricePoints":29,
            "minLevelUser":20,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§],
            "races":new <§_-L1x§>[§_-L1x§.§_-l2G§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,0.7),new §_-de§(§_-q24§.§_-h2N§,0.6,-1,24),new §_-de§(§_-q24§.§_-G2Z§,0.6,-1,1),new §_-de§(§_-q24§.SHOTGUN,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-F3z§,
            "pricePoints":31,
            "minLevelUser":20,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-z12§,0.7,-1,1),new §_-de§(§_-q24§.§_-w2m§,0.7,-1,25),new §_-de§(§_-q24§.§_-xS§,0.6),new §_-de§(§_-q24§.§_-i2k§,0.5),new §_-de§(§_-q24§.MINIGUN,0.5)]
         });
         §§push({
            "hatId":§_-S25§.GLADIATOR_HELMET,
            "pricePoints":32,
            "minLevelUser":20,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-r2y§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.CROSSBOW,0.5),new §_-de§(§_-q24§.§_-t§,0.6)]
         });
         §§push({
            "hatId":§_-S25§.§_-g1B§,
            "pricePoints":33,
            "minLevelUser":21,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-I1h§,§_-L1x§.§_-r2y§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§,0.7,-1,1),new §_-de§(§_-q24§.§_-m1P§,0.7,-1,26),new §_-de§(§_-q24§.§_-Qf§,0.6),new §_-de§(§_-q24§.§_-Qb§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.LEGIONER,
            "pricePoints":33,
            "minLevelUser":22,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-l2G§,§_-L1x§.§_-p21§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.7),new §_-de§(§_-q24§.CANNON_UPG_1,0.6,-1,22),new §_-de§(§_-q24§.CANNON_UPG_2,0.6,-1,29),new §_-de§(§_-q24§.§_-z12§,0.6,-1,1),new §_-de§(§_-q24§.§_-Z2L§,0.6,-1,29)]
         });
         §§push({
            "hatId":§_-S25§.PRINCESS,
            "pricePoints":34,
            "minLevelUser":23,
            "races":new <§_-L1x§>[§_-L1x§.§_-I1h§,§_-L1x§.§_-r2y§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-LY§,0.7,-1,1),new §_-de§(§_-q24§.§_-s1b§,0.7,-1,29),new §_-de§(§_-q24§.§_-J2R§,0.6,-1,28),new §_-de§(§_-q24§.§_-G2Z§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.CROWN,
            "pricePoints":34,
            "minLevelUser":23,
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-l2G§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-A1a§,0.7,-1,1),new §_-de§(§_-q24§.§_-42a§,0.7,-1,28),new §_-de§(§_-q24§.MOLOTOV,0.6),new §_-de§(§_-q24§.§_-z12§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.NEO,
            "pricePoints":36,
            "minLevelUser":25,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-r2y§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.7),new §_-de§(§_-q24§.MOLOTOV,0.6),new §_-de§(§_-q24§.§_-J2R§,0.6),new §_-de§(§_-q24§.SNIPER_RIFLE,0.6,-1,1),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.6,-1,28),new §_-de§(§_-q24§.§_-13G§,0.05,-1,1),new §_-de§(§_-q24§.§_-I2I§,0.05,-1,29)]
         });
         §§push({
            "hatId":§_-S25§.NINJA_TURTLES,
            "pricePoints":36,
            "minLevelUser":25,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-q1w§],
            "races":new <§_-L1x§>[§_-L1x§.§_-r2y§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-z12§,0.7,-1,1),new §_-de§(§_-q24§.§_-Z2L§,0.7,-1,28),new §_-de§(§_-q24§.§_-13G§,0.1,-1,1),new §_-de§(§_-q24§.§_-AV§,0.1,-1,29)]
         });
         §§push({
            "hatId":§_-S25§.§_-A1V§,
            "pricePoints":37,
            "minLevelUser":25,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§,§_-g1S§.§_-31m§],
            "races":new <§_-L1x§>[§_-L1x§.§_-l2G§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-xS§,0.6),new §_-de§(§_-q24§.§_-z12§,0.7,-1,1),new §_-de§(§_-q24§.§_-w2m§,0.7,-1),new §_-de§(§_-q24§.SNIPER_RIFLE,0.6,-1,1),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.6,-1,28)]
         });
         §§push({
            "hatId":§_-S25§.RUSSIAN,
            "pricePoints":39,
            "minLevelUser":26,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§],
            "races":new <§_-L1x§>[§_-L1x§.§_-I1h§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.AK_47,0.7),new §_-de§(§_-q24§.§_-Qb§,0.7),new §_-de§(§_-q24§.§_-Qf§,0.6),new §_-de§(§_-q24§.SNIPER_RIFLE,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-D2n§,
            "pricePoints":41,
            "minLevelUser":26,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-s1b§,0.7),new §_-de§(§_-q24§.§_-ZW§,0.6),new §_-de§(§_-q24§.BANDAGE,0.2,2)]
         });
         §§push({
            "hatId":§_-S25§.§_-72g§,
            "pricePoints":41,
            "minLevelUser":26,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-s1b§,0.7),new §_-de§(§_-q24§.MOLOTOV,0.6),new §_-de§(§_-q24§.§_-xS§,0.6),new §_-de§(§_-q24§.§_-Qb§,0.6),new §_-de§(§_-q24§.BANDAGE,0.2,2)]
         });
         §§push({
            "hatId":§_-S25§.OFFICER,
            "pricePoints":43,
            "minLevelUser":26,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-w1s§,0.7),new §_-de§(§_-q24§.§_-ZW§,0.6),new §_-de§(§_-q24§.MOLOTOV,0.6),new §_-de§(§_-q24§.AK_47,0.6)]
         });
         §§push({
            "hatId":§_-S25§.HERO_MASK,
            "pricePoints":44,
            "minLevelUser":26,
            "races":new <§_-L1x§>[§_-L1x§.§_-r2y§,§_-L1x§.§_-I1h§,§_-L1x§.§_-AU§],
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE,§_-g1S§.§_-31m§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-z12§,0.7,-1,1),new §_-de§(§_-q24§.§_-Z2L§,0.7,-1,29),new §_-de§(§_-q24§.§_-13G§,0.05),new §_-de§(§_-q24§.AK_47,0.6),new §_-de§(§_-q24§.§_-Qf§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.MASTER,
            "pricePoints":45,
            "minLevelUser":26,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7,-1,1),new §_-de§(§_-q24§.§_-g1q§,0.6,-1,1),new §_-de§(§_-q24§.§_-ZW§,0.6,-1,29),new §_-de§(§_-q24§.CANNON_UPG_1,0.5,-1,1),new §_-de§(§_-q24§.CANNON_UPG_2,0.5,-1,28),new §_-de§(§_-q24§.MOLOTOV,0.5,-1)]
         });
         §§push({
            "hatId":§_-S25§.§_-b4§,
            "pricePoints":47,
            "minLevelUser":26,
            "races":new <§_-L1x§>[§_-L1x§.§_-l2G§,§_-L1x§.§_-AU§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-xS§,0.7),new §_-de§(§_-q24§.MOLOTOV,0.7),new §_-de§(§_-q24§.§_-Z2L§,0.5)]
         });
         §§push({
            "hatId":§_-S25§.SOVIET,
            "pricePoints":48,
            "minLevelUser":27,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-42a§,0.7),new §_-de§(§_-q24§.§_-t§,0.6),new §_-de§(§_-q24§.MOLOTOV,0.5)]
         });
         §§push({
            "hatId":§_-S25§.§_-Hn§,
            "pricePoints":50,
            "minLevelUser":27,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-t§,0.7),new §_-de§(§_-q24§.AK_47,0.7),new §_-de§(§_-q24§.CROSSBOW,0.6)]
         });
         §§push({
            "hatId":§_-S25§.ACE,
            "pricePoints":51,
            "minLevelUser":27,
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-Z2L§,0.7),new §_-de§(§_-q24§.§_-xS§,0.6),new §_-de§(§_-q24§.§_-A1a§,0.5,-1,1),new §_-de§(§_-q24§.§_-m1P§,0.5,-1,29)]
         });
         §§push({
            "hatId":§_-S25§.§_-cG§,
            "pricePoints":55,
            "minLevelUser":28,
            "typeParams":new <§_-g1S§>[§_-g1S§.DEFENSIVE],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-p21§,§_-L1x§.§_-l2G§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.ANTITOXIN,0.2,1),new §_-de§(§_-q24§.BANDAGE,0.3,1),new §_-de§(§_-q24§.§_-Qf§,0.5),new §_-de§(§_-q24§.§_-m1P§,0.6),new §_-de§(§_-q24§.§_-h2N§,0.6,2),new §_-de§(§_-q24§.SNIPER_RIFLE_UPG_1,0.7)]
         });
         §§push({
            "hatId":§_-S25§.VAMPIRE,
            "pricePoints":55,
            "minLevelUser":28,
            "typeParams":new <§_-g1S§>[§_-g1S§.§_-jl§],
            "races":new <§_-L1x§>[§_-L1x§.§_-AU§,§_-L1x§.§_-r2y§],
            "baseArsenal":new <§_-de§>[new §_-de§(§_-q24§.§_-Z2L§,0.7),new §_-de§(§_-q24§.§_-s1b§,0.7),new §_-de§(§_-q24§.WATERMELON,0.6,2),new §_-de§(§_-q24§.§_-J2R§,0.5),new §_-de§(§_-q24§.§_-h2N§,0.5)]
         });
         §§push("hatId");
         §§push(§_-S25§.§_-H3Q§);
         §§push("pricePoints");
         §§push(55);
         §§push("minLevelUser");
         §§push(28);
         §§push("typeParams");
         §§push(new <§_-g1S§>[§_-g1S§.§_-jl§]);
         §§push("races");
         §§push(new <§_-L1x§>[§_-L1x§.§_-p21§,§_-L1x§.§_-AU§]);
         §§push("baseArsenal");
         var _temp_341:* = new <§_-de§>[new §_-de§(§_-q24§.CANNON_UPG_2,0.7),new §_-de§(§_-q24§.§_-h2N§,0.6),new §_-de§(§_-q24§.CROSSBOW,0.5),new §_-de§(§_-q24§.ANTITOXIN,0.2,1)];
         §§pop().§_-02y§ = null;
         super();
      }
      
      public static function §_-f1s§() : §_-de§
      {
         var _loc1_:uint = MathUtil.random(0,§_-J1M§.length - 1);
         return §_-J1M§[_loc1_];
      }
      
      public function get §_-M1w§() : Array
      {
         return this.§_-02y§;
      }
   }
}


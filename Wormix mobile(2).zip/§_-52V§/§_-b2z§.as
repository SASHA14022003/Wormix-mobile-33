package §_-52V§
{
   import flash.system.ApplicationDomain;
   
   public interface §_-b2z§
   {
      
      function §_-T2j§(param1:Object, param2:Class, param3:ApplicationDomain = null) : Boolean;
      
      function getClass(param1:*, param2:ApplicationDomain = null) : Class;
      
      function §_-518§(param1:*, param2:Boolean = false) : String;
   }
}


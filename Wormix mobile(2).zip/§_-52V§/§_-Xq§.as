package §_-52V§
{
   import starling.display.DisplayObjectContainer;
   
   public interface §_-Xq§
   {
      
      function §_-s2F§(param1:String) : void;
      
      function §_-Q1d§(param1:String) : void;
      
      function §_-q1u§(param1:String) : Boolean;
      
      function §_-K10§(param1:Class) : void;
      
      function §_-61D§(param1:Class) : void;
      
      function §_-34§(param1:Class) : Boolean;
      
      function get §_-v2Z§() : DisplayObjectContainer;
      
      function set §_-v2Z§(param1:DisplayObjectContainer) : void;
      
      function get enabled() : Boolean;
      
      function set enabled(param1:Boolean) : void;
   }
}


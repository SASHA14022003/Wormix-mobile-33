package §_-52V§
{
   import starling.display.DisplayObjectContainer;
   
   public interface §_-iC§
   {
      
      function §_-H2T§(param1:*, param2:Class, param3:* = null, param4:Boolean = true, param5:Boolean = true) : void;
      
      function §_-Cw§(param1:*) : void;
      
      function §_-K1e§(param1:Object) : §_-R9§;
      
      function §_-KM§(param1:Object, param2:§_-R9§) : void;
      
      function §_-SA§(param1:§_-R9§) : §_-R9§;
      
      function §_-119§(param1:Object) : §_-R9§;
      
      function §_-HY§(param1:Object) : §_-R9§;
      
      function §_-t2Q§(param1:*) : Boolean;
      
      function §_-C3G§(param1:§_-R9§) : Boolean;
      
      function §_-BF§(param1:Object) : Boolean;
      
      function get §_-v2Z§() : DisplayObjectContainer;
      
      function set §_-v2Z§(param1:DisplayObjectContainer) : void;
      
      function get enabled() : Boolean;
      
      function set enabled(param1:Boolean) : void;
   }
}


package §_-52V§
{
   import starling.events.EventDispatcher;
   
   public interface §_-I2i§
   {
      
      function §_-IF§(param1:EventDispatcher, param2:String, param3:Function, param4:Class = null) : void;
      
      function §_-Hy§(param1:EventDispatcher, param2:String, param3:Function, param4:Class = null) : void;
      
      function §_-E1Y§() : void;
   }
}


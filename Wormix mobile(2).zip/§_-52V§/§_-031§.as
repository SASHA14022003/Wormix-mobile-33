package §_-52V§
{
   import flash.system.ApplicationDomain;
   
   public interface §_-031§
   {
      
      function §_-r2M§(param1:Class, param2:Object, param3:String = "") : *;
      
      function §_-PF§(param1:Class, param2:Class, param3:String = "") : *;
      
      function §_-A2l§(param1:Class, param2:String = "") : *;
      
      function §_-qE§(param1:Class, param2:Class, param3:String = "") : *;
      
      function §_-w1t§(param1:Class, param2:*, param3:String = "") : *;
      
      function §_-61p§(param1:Object) : void;
      
      function §_-s15§(param1:Class) : *;
      
      function getInstance(param1:Class, param2:String = "") : *;
      
      function §_-Z1f§(param1:ApplicationDomain = null) : §_-031§;
      
      function §_-g2K§(param1:Class, param2:String = "") : void;
      
      function §_-t2Q§(param1:Class, param2:String = "") : Boolean;
      
      function get applicationDomain() : ApplicationDomain;
      
      function set applicationDomain(param1:ApplicationDomain) : void;
   }
}


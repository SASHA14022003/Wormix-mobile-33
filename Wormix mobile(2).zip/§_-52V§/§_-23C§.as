package §_-52V§
{
   import starling.events.EventDispatcher;
   
   public interface §_-23C§
   {
      
      function get eventDispatcher() : EventDispatcher;
   }
}


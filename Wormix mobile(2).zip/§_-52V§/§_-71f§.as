package §_-52V§
{
   public interface §_-71f§
   {
      
      function §_-JL§(param1:Object) : void;
      
      function §_-53x§(param1:Object) : void;
      
      function execute(param1:Class, param2:Object = null, param3:Class = null, param4:String = "") : void;
      
      function §_-f2X§(param1:String, param2:Class, param3:Class = null, param4:Boolean = false) : void;
      
      function §_-9P§(param1:String, param2:Class, param3:Class = null) : void;
      
      function §_-R2M§() : void;
      
      function §_-iE§(param1:String, param2:Class, param3:Class = null) : Boolean;
   }
}


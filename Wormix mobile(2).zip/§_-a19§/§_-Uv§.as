package §_-a19§
{
   import §_-82a§.*;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-fo§.*;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.inappbilling.InAppBillingAvailability;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import flash.display.BitmapData;
   import flash.geom.Rectangle;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.SelectStuffResultStructure;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileData;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.core.Starling;
   import starling.events.Event;
   
   public class §_-Uv§
   {
      
      private var §_-lw§:Vector.<uint> = new Vector.<uint>();
      
      private var §_-F1o§:uint;
      
      public function §_-Uv§(param1:uint, param2:Vector.<uint>)
      {
         super();
         this.§_-F1o§ = param1;
         this.§_-lw§ = param2;
      }
      
      public function §_-I2F§() : Vector.<uint>
      {
         return this.§_-lw§;
      }
      
      public function §_-e1t§() : uint
      {
         return this.§_-F1o§;
      }
   }
}


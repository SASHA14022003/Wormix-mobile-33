package §_-a19§
{
   import §_-03T§.§_-2p§;
   import §_-82a§.*;
   import §_-91A§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-4I§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-U1Y§.*;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-G4§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.*;
   import §_-r1C§.§_-h2B§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalAlign;
   import flash.events.TimerEvent;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.tile.TileData;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   use namespace gestouch_internal;
   
   public class §_-Y15§
   {
      
      public static var all:Vector.<§_-Y15§> = new Vector.<§_-Y15§>();
      
      public static const EASY:§_-Y15§ = new §_-Y15§(0,80,1,-1,0.85,{
         1:new <uint>[1,1],
         5:new <uint>[1,1],
         9:new <uint>[1,1],
         13:new <uint>[1,2],
         17:new <uint>[1,2],
         21:new <uint>[1,2],
         24:new <uint>[1,2],
         27:new <uint>[1,2]
      });
      
      public static const §_-g23§:§_-Y15§ = new §_-Y15§(1,80,0.9,-1,0.9,{
         1:new <uint>[1,1],
         5:new <uint>[1,1],
         9:new <uint>[1,1],
         13:new <uint>[1,2],
         17:new <uint>[1,2],
         21:new <uint>[1,2],
         24:new <uint>[1,2],
         27:new <uint>[2,2]
      });
      
      §§push(§§findproperty(MEDIUM));
      §§push(§_-Y15§);
      §§push(2);
      §§push(105);
      §§push(0.6);
      §§push(0);
      §§push(0.95);
      §§push(String(1));
      §§push(new <uint>[1,1]);
      §§push(String(5));
      §§push(new <uint>[1,1]);
      §§push(String(9));
      §§push(new <uint>[1,2]);
      §§push(String(13));
      §§push(new <uint>[1,2]);
      §§push(String(17));
      §§push(new <uint>[2,2]);
      §§push(String(21));
      §§push(new <uint>[2,2]);
      §§push(String(24));
      §§push(new <uint>[2,3]);
      §§push(String(27));
      var _temp_47:* = new <uint>[2,4];
      
      public static const MEDIUM:§_-Y15§ = new §§pop()(§§pop(),§§pop(),§§pop(),§§pop(),§§pop(),null);
      
      public static const §_-g10§:§_-Y15§ = new §_-Y15§(3,110,0.7,0,1,{
         1:new <uint>[1,1],
         5:new <uint>[1,1],
         9:new <uint>[1,2],
         13:new <uint>[2,2],
         17:new <uint>[2,3],
         21:new <uint>[2,3],
         24:new <uint>[2,3],
         27:new <uint>[3,4]
      });
      
      public static const HARD:§_-Y15§ = new §_-Y15§(4,120,0.2,1,1.1,{
         1:new <uint>[1,1],
         5:new <uint>[1,2],
         9:new <uint>[2,2],
         13:new <uint>[2,3],
         17:new <uint>[3,3],
         21:new <uint>[3,4],
         24:new <uint>[3,4],
         27:new <uint>[3,4]
      });
      
      §§push(§§findproperty(§_-12d§));
      §§push(§_-Y15§);
      §§push(5);
      §§push(130);
      §§push(0.15);
      §§push(1);
      §§push(1.15);
      §§push(String(1));
      §§push(new <uint>[1,1]);
      §§push(String(5));
      §§push(new <uint>[1,2]);
      §§push(String(9));
      §§push(new <uint>[2,2]);
      §§push(String(13));
      §§push(new <uint>[2,3]);
      §§push(String(17));
      §§push(new <uint>[3,3]);
      §§push(String(21));
      §§push(new <uint>[3,4]);
      §§push(String(24));
      
      public static const §_-12d§:§_-Y15§ = new §§pop()(§§pop(),§§pop(),§§pop(),§§pop(),§§pop(),null);
      
      private var power:uint;
      
      private var §_-F1o§:uint;
      
      private var §_-92m§:Number;
      
      private var §_-v1O§:int;
      
      private var §_-P1T§:Number;
      
      private var map:Object;
      
      public function §_-Y15§(param1:uint, param2:uint, param3:Number, param4:int, param5:Number, param6:Object)
      {
         super();
         this.power = param1;
         this.§_-F1o§ = param2;
         this.§_-92m§ = param3;
         this.§_-v1O§ = param4;
         this.§_-P1T§ = param5;
         this.map = param6;
         all[all.length] = this;
      }
      
      public function §_-12q§() : uint
      {
         return this.power;
      }
      
      public function §_-S1c§() : uint
      {
         return this.§_-F1o§;
      }
      
      public function §_-b1K§() : Number
      {
         return this.§_-92m§;
      }
      
      public function §_-e1Z§() : int
      {
         return this.§_-v1O§;
      }
      
      public function §_-V2S§() : Number
      {
         return this.§_-P1T§;
      }
      
      public function §_-82j§(param1:uint) : Vector.<uint>
      {
         var _loc3_:String = null;
         var _loc4_:int = 0;
         var _loc2_:uint = uint(uint.MIN_VALUE);
         for(_loc3_ in this.map)
         {
            _loc4_ = int(uint(_loc3_));
            if(param1 >= _loc4_ && param1 - _loc4_ <= param1 - _loc2_)
            {
               _loc2_ = uint(_loc4_);
            }
         }
         return this.map[_loc2_];
      }
      
      public function §_-72R§(param1:uint) : uint
      {
         var _loc2_:Vector.<uint> = this.§_-82j§(param1);
         return _loc2_[MathUtil.random(0,_loc2_.length - 1)];
      }
   }
}


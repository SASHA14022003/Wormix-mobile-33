package §_-D3A§
{
   import §_-62§.§_-zF§;
   import §_-A1K§.§_-TA§;
   import §_-H2g§.§_-di§;
   import §_-J3L§.§_-h1D§;
   import §_-K3r§.§_-E3O§;
   import §_-K3r§.§_-U2b§;
   import §_-Ly§.§_-81L§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-61Z§;
   import §_-j1w§.*;
   import §_-k1u§.§_-2m§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-lp§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.math.BigInteger;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import flash.events.*;
   import ru.pragmatix.flox.social.controller.mobile.*;
   import ru.pragmatix.flox.social.response.LoadUserProfilesResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.gui.screenOverlay.§_-O5§;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.Canvas;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-TZ§
   {
      
      private static var §_-ES§:Vector.<§_-DI§> = new Vector.<§_-DI§>();
      
      public function §_-TZ§()
      {
         super();
      }
      
      public static function addListener(param1:EventDispatcher, param2:String, param3:Function, param4:int = 0) : void
      {
         var _loc5_:§_-DI§ = §_-C3i§(param1,param2);
         if(_loc5_)
         {
            _loc5_.§_-g1W§(param3,param4);
            return;
         }
         §_-h2k§(param1,param2,param3,param4);
      }
      
      public static function removeListener(param1:EventDispatcher, param2:String, param3:Function) : void
      {
         var _loc5_:§_-DI§ = null;
         var _temp_1:* = §_-Z2V§(param1,param2);
         var _loc4_:int = §_-Z2V§(param1,param2);
         if(_loc4_ >= 0)
         {
            _loc5_ = §_-ES§[_loc4_];
            _loc5_.§_-K2S§(param3);
            if(_loc5_.isCleared)
            {
               §_-ES§.splice(_loc4_,1);
            }
         }
      }
      
      public static function clear() : void
      {
         var _loc1_:* = int(§_-ES§.length);
         while(_loc1_--)
         {
            §_-ES§[_loc1_].clear();
         }
         §_-ES§.splice(0,§_-ES§.length);
      }
      
      private static function §_-h2k§(param1:EventDispatcher, param2:String, param3:Function, param4:int) : void
      {
         var _loc5_:§_-DI§ = new §_-DI§(param1,param2);
         _loc5_.§_-g1W§(param3,param4);
         §_-ES§.push(_loc5_);
      }
      
      private static function §_-Z2V§(param1:EventDispatcher, param2:String) : int
      {
         var _loc4_:§_-DI§ = null;
         var _loc3_:* = int(§_-ES§.length);
         while(_loc3_--)
         {
            _loc4_ = §_-ES§[_loc3_];
            if(_loc4_.dispatcher == param1 && _loc4_.eventType == param2)
            {
               return _loc3_;
            }
         }
         return -1;
      }
      
      private static function §_-C3i§(param1:EventDispatcher, param2:String) : §_-DI§
      {
         var _loc4_:§_-DI§ = null;
         var _loc3_:* = int(§_-ES§.length);
         while(_loc3_--)
         {
            _loc4_ = §_-ES§[_loc3_];
            if(_loc4_.dispatcher == param1 && _loc4_.eventType == param2)
            {
               return _loc4_;
            }
         }
         return null;
      }
   }
}


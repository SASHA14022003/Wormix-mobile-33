package §_-D3A§
{
   import §_-31N§.§_-42G§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.*;
   import §_-73I§.§_-q15§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-CF§.§_-p2U§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G2H§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-P1z§.*;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Ta§.*;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1b§.*;
   import §_-YF§.§_-Zi§;
   import §_-Z1K§.§_-q24§;
   import §_-f1G§.§_-kf§;
   import §_-fo§.§_-21L§;
   import §_-fo§.§_-r5§;
   import §_-j1w§.§_-L1x§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m0§.§_-X1F§;
   import §_-o14§.§_-Dd§;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.§_-W2D§;
   import §_-s20§.§_-J2g§;
   import §_-w2i§.§_-Zd§;
   import §_-x2Q§.§_-dU§;
   import §_-zI§.§_-X1q§;
   import com.hurlant.math.BigInteger;
   import dragonBones.Bone;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.themes.FontColor;
   import flash.display.DisplayObject;
   import flash.events.MouseEvent;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.ammo.feats.IFrameFeat;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Color;
   import starling.utils.Pool;
   
   use namespace gestouch_internal;
   
   public class §_-DI§
   {
      
      private var _dispatcher:EventDispatcher;
      
      private var _eventType:String;
      
      private var handlers:Vector.<§_-UK§>;
      
      public function §_-DI§(param1:EventDispatcher, param2:String)
      {
         super();
         this._dispatcher = param1;
         this._eventType = param2;
         this.handlers = new Vector.<§_-UK§>();
      }
      
      private static function §_-h1M§(param1:§_-UK§, param2:§_-UK§) : int
      {
         if(param1.priority > param2.priority)
         {
            return 1;
         }
         if(param1.priority < param2.priority)
         {
            return -1;
         }
         return 0;
      }
      
      public function §_-g1W§(param1:Function, param2:int = 1) : void
      {
         var _loc3_:§_-UK§ = null;
         if(!this.§_-L3N§(param1,param2))
         {
            _loc3_ = new §_-UK§(param1,param2);
            this.handlers.push(_loc3_);
            this._dispatcher.addEventListener(this._eventType,this.§_-E1X§);
         }
      }
      
      public function §_-L3N§(param1:Function, param2:int = 1) : Boolean
      {
         var _loc3_:§_-UK§ = this.§_-K1c§(param1);
         if(_loc3_)
         {
            _loc3_.priority = param2;
            return true;
         }
         return false;
      }
      
      public function §_-K2S§(param1:Function) : void
      {
         var _loc2_:int = this.§_-I3x§(param1);
         if(_loc2_ >= 0)
         {
            this.handlers.splice(_loc2_,1);
         }
      }
      
      private function §_-K1c§(param1:Function) : §_-UK§
      {
         var _loc2_:* = int(this.handlers.length);
         while(_loc2_--)
         {
            if(this.handlers[_loc2_].handler == param1)
            {
               return this.handlers[_loc2_];
            }
         }
         return null;
      }
      
      private function §_-I3x§(param1:Function) : int
      {
         var _loc2_:* = int(this.handlers.length);
         while(_loc2_--)
         {
            if(this.handlers[_loc2_].handler == param1)
            {
               return _loc2_;
            }
         }
         return -1;
      }
      
      private function §_-E1X§(param1:Event, param2:Object = null) : void
      {
         this.handlers = this.handlers.sort(§_-h1M§);
         var _loc3_:* = int(this.handlers.length);
         while(_loc3_--)
         {
            this.run.call(this,this.handlers[_loc3_],param1,param2);
         }
      }
      
      private function run(param1:§_-UK§, param2:Event, param3:Object = null) : void
      {
         if(param1.handler.length == 0)
         {
            param1.handler.call();
         }
         if(param1.handler.length > 1)
         {
            if(param3)
            {
               param1.handler.call(null,param2,param3);
            }
            else
            {
               param1.handler.call(null,param2,param2.data);
            }
            return;
         }
         param1.handler.call(null,param2);
      }
      
      public function get dispatcher() : EventDispatcher
      {
         return this._dispatcher;
      }
      
      public function get eventType() : String
      {
         return this._eventType;
      }
      
      public function get isCleared() : Boolean
      {
         return this.handlers.length == 0;
      }
      
      public function clear() : void
      {
         var _loc1_:* = int(this.handlers.length);
         while(_loc1_--)
         {
            this._dispatcher.removeEventListener(this._eventType,this.§_-E1X§);
         }
         this.handlers.splice(0,this.handlers.length);
      }
   }
}


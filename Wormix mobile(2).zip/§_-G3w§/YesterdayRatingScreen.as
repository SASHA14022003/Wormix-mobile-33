package §_-G3w§
{
   import §_-Ly§.§_-81L§;
   import §_-bI§.OwnerRatingItemRenderer;
   import §_-m1g§.*;
   import §_-r1C§.§_-h2B§;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.TabBar;
   import feathers.controls.ToggleButton;
   import feathers.data.ArrayCollection;
   import feathers.data.IListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.events.Event;
   
   public class YesterdayRatingScreen extends §_-Cj§
   {
      
      private var binder:Binder;
      
      public function YesterdayRatingScreen()
      {
         super(§_-N1y§.§_-D37§);
      }
      
      override protected function initialize() : void
      {
         var data:Object;
         var tabBar:TabBar;
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         data = Application.assetManager.getObject("rating_screen_yesterday");
         Application.uiBuilder.create(data,true,this.binder);
         addChild(this.binder._container);
         tabBar = this.binder._tabBar;
         tabBar.tabProperties.width = 150;
         tabBar.distributeTabSizes = false;
         tabBar.direction = Direction.HORIZONTAL;
         tabBar.horizontalAlign = HorizontalAlign.LEFT;
         tabBar.tabInitializer = function(param1:ToggleButton, param2:Object):void
         {
            param1.label = §_-s2a§.§_-K3t§(param2.stringId);
         };
         tabBar.addEventListener(Event.CHANGE,this.§_-n24§);
         tabBar.addEventListener(Event.TRIGGERED,this.§_-cR§);
         §_-fC§(this.binder._ratingList,§_-62e§);
         this.binder._userList.itemRendererType = OwnerRatingItemRenderer;
         this.binder._userList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._userList.verticalScrollPolicy = ScrollPolicy.OFF;
         this.binder._tabBar.dataProvider = new ArrayCollection([{
            "wager":§_-K2W§.§_-8b§,
            "stringId":§_-s2a§.RATING_BATTLES_ALL
         },{
            "wager":§_-K2W§.DUEL_15,
            "stringId":§_-s2a§.RATING_BATTLES_BET_SMALL
         },{
            "wager":§_-K2W§.DUEL_50,
            "stringId":§_-s2a§.RATING_BATTLES_BET_MED
         },{
            "wager":§_-K2W§.§_-I0§,
            "stringId":§_-s2a§.RATING_BTN_2х2
         }]);
      }
      
      private function §_-n24§(param1:Event) : void
      {
         this.§_-B0§();
      }
      
      private function §_-cR§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-D1q§);
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_STATE))
         {
            this.§_-B0§();
         }
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            this.binder._ratingList.dataProvider = new ArrayCollection(§_-K3x§);
            this.binder._userList.dataProvider = _owner ? new ArrayCollection([{
               "owner":§_-sE§,
               "result":_result
            }]) : new ArrayCollection([]);
         }
      }
      
      private function §_-B0§() : void
      {
         if(Boolean(this.binder._tabBar) && Boolean(this.binder._tabBar.selectedItem))
         {
            dispatchEventWith(Event.CHANGE,false,{
               "type":§_-62e§,
               "wager":this.binder._tabBar.selectedItem.wager
            });
         }
      }
   }
}

import feathers.controls.List;
import feathers.controls.Panel;
import feathers.controls.TabBar;

class Binder
{
   
   public var _container:Panel;
   
   public var _tabBar:TabBar;
   
   public var _ratingList:List;
   
   public var _userList:List;
   
   public function Binder()
   {
      super();
   }
}

package §_-G3w§
{
   import §_-bI§.§_-d2V§;
   import §_-m1g§.§_-K2W§;
   import §_-m1g§.§_-N1y§;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-Uc§;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.data.IListCollection;
   import feathers.layout.AnchorLayout;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class GlobalRatingScreen extends §_-Cj§
   {
      
      private var binder:Binder;
      
      public function GlobalRatingScreen()
      {
         super(§_-N1y§.§_-83T§);
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("rating_screen_global");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         this.binder._ratingIcon.visible = false;
         this.binder._leagueIcon.maintainAspectRatio = true;
         this.binder._leagueIcon.scaleMode = ScaleMode.SHOW_ALL;
         this.binder._userList.itemRendererType = §_-d2V§;
         this.binder._userList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._userList.verticalScrollPolicy = ScrollPolicy.OFF;
         §_-fC§(this.binder._ratingList,§_-62e§);
         this.binder._noLeaguePanel.removeFromParent();
      }
      
      override protected function draw() : void
      {
         var _loc1_:§_-5c§ = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_STATE))
         {
            dispatchEventWith(Event.CHANGE,false,{
               "type":§_-62e§,
               "wager":§_-K2W§.§_-8b§
            });
         }
         if(isInvalid(INVALIDATION_FLAG_DATA) && Boolean(§_-sE§))
         {
            _loc1_ = §_-sE§ ? §_-Uc§.§_-Fp§(§_-sE§) : null;
            this.binder._ratingList.dataProvider = new ArrayCollection(§_-K3x§);
            this.binder._userList.dataProvider = _owner ? new ArrayCollection([{
               "owner":§_-sE§,
               "result":_result
            }]) : new ArrayCollection([]);
            if(_loc1_)
            {
               this.binder._noLeaguePanel.removeFromParent();
               this.binder._content.addChildAt(this.binder._ratingListPanel,0);
               this.binder._content.addChildAt(this.binder._leagueDescriptionContent,0);
               this.binder._leagueName.text = _loc1_ ? §_-s2a§.§_-K3t§(_loc1_.title) : "";
               this.binder._leagueDescription.text = _loc1_ ? §_-s2a§.§_-K3t§(_loc1_.descr) : "";
               this.binder._leagueRatingRange.text = _loc1_ ? §_-Uc§.§_-P1§(_loc1_) : "";
               this.binder._leagueIcon.source = _loc1_ ? Application.assetManager.getTexture(_loc1_.icon) : "";
               this.binder._ratingIcon.visible = true;
            }
            else
            {
               this.binder._ratingListPanel.removeFromParent();
               this.binder._leagueDescriptionContent.removeFromParent();
               this.binder._content.addChildAt(this.binder._noLeaguePanel,0);
               this.binder._noEnoughRatingTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.NOT_ENOUGH_RATING_TITLE);
               this.binder._noEnoughRatingDescription.text = §_-s2a§.§_-K3t§(§_-s2a§.NOT_ENOUGH_RATING_DESCR);
               this.binder._ratingIcon.visible = false;
            }
         }
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;
import starling.display.Image;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _content:LayoutGroup;
   
   public var _noLeaguePanel:Panel;
   
   public var _ratingListPanel:Panel;
   
   public var _leagueDescriptionContent:Panel;
   
   public var _ratingList:List;
   
   public var _userList:List;
   
   public var _leagueIcon:ImageLoader;
   
   public var _leagueName:Label;
   
   public var _ratingIcon:Image;
   
   public var _leagueRatingRange:Label;
   
   public var _leagueDescription:Label;
   
   public var _noEnoughRatingTitle:Label;
   
   public var _noEnoughRatingDescription:Label;
   
   public function Binder()
   {
      super();
   }
}

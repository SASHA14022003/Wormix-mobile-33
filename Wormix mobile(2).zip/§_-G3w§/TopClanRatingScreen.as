package §_-G3w§
{
   import §_-B1y§.§_-F1P§;
   import §_-Ly§.§_-81L§;
   import §_-bI§.OwnerClanRatingItemRenderer;
   import §_-m1g§.§_-I30§;
   import §_-m1g§.§_-N1y§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-F3q§;
   import config.§_-vR§;
   import feathers.controls.Screen;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import starling.events.Event;
   
   public class TopClanRatingScreen extends Screen
   {
      
      private var binder:Binder;
      
      private var _response:TopClansResponse;
      
      private var §_-8X§:ClanTO;
      
      private var §_-P2W§:§_-I30§;
      
      public function TopClanRatingScreen()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject("rating_screen_top_clan");
         Application.uiBuilder.create(_loc1_,true,this.binder);
         addChild(this.binder._container);
         this.§_-P2W§ = new §_-I30§(this.binder._ratingList);
         this.binder._userList.itemRendererType = OwnerClanRatingItemRenderer;
         this.binder._userList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._userList.verticalScrollPolicy = ScrollPolicy.OFF;
         this.binder._ratingList.addEventListener(Event.TRIGGERED,this.§_-J1g§);
         this.binder._ratingList.addEventListener(Event.CHANGE,this.§_-p9§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.binder._ratingList.removeEventListener(Event.TRIGGERED,this.§_-J1g§);
         this.binder._ratingList.removeEventListener(Event.CHANGE,this.§_-p9§);
         this.§_-P2W§ = null;
      }
      
      override protected function draw() : void
      {
         var _loc1_:Array = null;
         var _loc2_:Array = null;
         var _loc3_:Date = null;
         var _loc4_:String = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:ClanTO = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_STATE))
         {
            dispatchEventWith(Event.CHANGE,false,{
               "type":§_-N1y§.§_-23L§,
               "wager":0
            });
         }
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc1_ = [];
            _loc2_ = [];
            if(this._response)
            {
               _loc3_ = §_-72u§.§_-p2H§(this._response.startSeasonDate);
               _loc4_ = StringUtil.format(§_-s2a§.CLAN_SEASON_DATES,{
                  "numberSeason":this._response.seasonId,
                  "month":§_-72u§.§_-9i§(_loc3_.month),
                  "year":_loc3_.fullYear.toString()
               });
               _loc5_ = §_-F3q§.getInstance().minimalRatingForTop;
               _loc6_ = §_-F3q§.getInstance().topPlaces;
               this.binder._seasonInfo.text = _loc4_;
               this.binder._seasonDescription.text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.CLAN_SEASON_AWARD),{
                  "topPlaces":_loc6_,
                  "ratingPoints":_loc5_
               });
               _loc7_ = 0;
               while(_loc7_ < this._response.topClans.length)
               {
                  _loc1_.push({
                     "clan":this._response.topClans[_loc7_],
                     "oldPlace":this._response.oldPlaces[_loc7_]
                  });
                  _loc7_++;
               }
               _loc7_ = 0;
               while(_loc7_ < _loc1_.length)
               {
                  _loc8_ = _loc1_[_loc7_].clan;
                  if(_loc8_.seasonRating < _loc5_)
                  {
                     _loc1_.insertAt(_loc7_,{"rating":_loc5_});
                     break;
                  }
                  _loc7_++;
               }
               _loc2_.push({
                  "clan":this.§_-8X§,
                  "oldPlace":this._response.oldPlace
               });
            }
            this.binder._ratingList.dataProvider = new ArrayCollection(_loc1_);
            this.binder._userList.dataProvider = new ArrayCollection(_loc2_);
         }
      }
      
      public function setData(param1:TopClansResponse, param2:ClanTO) : void
      {
         this._response = param1;
         this.§_-8X§ = param2;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      public function set userClan(param1:ClanTO) : void
      {
         this.§_-8X§ = param1;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-p9§(param1:Event) : void
      {
         if(this.binder._ratingList.selectedItem)
         {
            dispatchEventWith(Event.SELECT,false,this.binder._ratingList.selectedItem);
         }
         this.binder._ratingList.selectedIndex = -1;
      }
      
      private function §_-J1g§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-D1q§);
      }
   }
}

import feathers.controls.Label;
import feathers.controls.List;
import feathers.controls.Panel;

class Binder
{
   
   public var _container:Panel;
   
   public var _ratingList:List;
   
   public var _userList:List;
   
   public var _seasonInfo:Label;
   
   public var _seasonDescription:Label;
   
   public function Binder()
   {
      super();
   }
}

package §_-G3w§
{
   import §_-m1g§.§_-B1l§;
   import feathers.controls.List;
   import feathers.controls.Screen;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-Cj§ extends Screen
   {
      
      protected var §_-Z1n§:Array;
      
      protected var §_-sE§:UserProfile;
      
      protected var _result:GetRatingResult;
      
      protected var §_-K3x§:Array;
      
      protected var §_-62e§:int;
      
      private var §_-722§:§_-B1l§;
      
      public function §_-Cj§(param1:int)
      {
         super();
         this.§_-62e§ = param1;
      }
      
      public function setData(param1:UserProfile, param2:Array, param3:GetRatingResult) : void
      {
         var _loc4_:* = 0;
         var _loc5_:Object = null;
         var _loc6_:int = 0;
         this.§_-sE§ = param1;
         this.§_-Z1n§ = param2;
         this._result = param3;
         this.§_-K3x§ = [];
         if(this._result)
         {
            _loc4_ = 1;
            _loc6_ = 0;
            while(_loc6_ < this._result.userProfileStructures.length)
            {
               _loc5_ = this._result.userProfileStructures[_loc6_];
               if(_loc5_ is RatingProfileStructure)
               {
                  this.§_-K3x§.push({
                     "rps":_loc5_,
                     "pos":_loc4_++
                  });
               }
               else
               {
                  this.§_-K3x§.push(_loc5_);
               }
               _loc6_++;
            }
         }
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      protected function §_-fC§(param1:List, param2:int) : void
      {
         this.§_-722§ = new §_-B1l§(param1,param2);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         this.§_-722§.dispose();
      }
      
      public function §_-l2h§() : int
      {
         return this.§_-62e§;
      }
   }
}


package §_-G3w§
{
   import §_-533§.§_-c2b§;
   import §_-Ly§.§_-81L§;
   import §_-bI§.DailyRatingAwardItemRenderer;
   import §_-bI§.OwnerRatingItemRenderer;
   import §_-k1u§.§_-Oi§;
   import §_-kP§.*;
   import §_-lh§.§_-z2A§;
   import §_-m1g§.*;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-Uc§;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.TabBar;
   import feathers.controls.ToggleButton;
   import feathers.data.ArrayCollection;
   import feathers.data.IListCollection;
   import feathers.data.VectorCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import starling.events.Event;
   
   public class TodayRatingScreen extends §_-Cj§
   {
      
      private var binder:Binder;
      
      public function TodayRatingScreen()
      {
         super(§_-N1y§.§_-gA§);
      }
      
      override protected function initialize() : void
      {
         var data:Object;
         var tabBar:TabBar;
         var awardsListLayout:HorizontalLayout;
         super.initialize();
         this.layout = new AnchorLayout();
         this.binder = new Binder();
         data = Application.assetManager.getObject("rating_screen_daily");
         Application.uiBuilder.create(data,true,this.binder);
         addChild(this.binder._container);
         tabBar = this.binder._tabBar;
         tabBar.tabProperties.width = 150;
         tabBar.distributeTabSizes = false;
         tabBar.direction = Direction.HORIZONTAL;
         tabBar.horizontalAlign = HorizontalAlign.LEFT;
         tabBar.tabInitializer = function(param1:ToggleButton, param2:Object):void
         {
            param1.label = §_-s2a§.§_-K3t§(param2.stringId);
         };
         tabBar.addEventListener(Event.CHANGE,this.§_-n24§);
         tabBar.addEventListener(Event.TRIGGERED,this.§_-cR§);
         §_-fC§(this.binder._ratingList,§_-62e§);
         this.binder._userList.itemRendererType = OwnerRatingItemRenderer;
         this.binder._userList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._userList.verticalScrollPolicy = ScrollPolicy.OFF;
         this.binder._awardsList.itemRendererType = DailyRatingAwardItemRenderer;
         awardsListLayout = new HorizontalLayout();
         awardsListLayout.gap = 20;
         this.binder._awardsList.layout = awardsListLayout;
         this.binder._awardsList.verticalScrollPolicy = ScrollPolicy.OFF;
         this.binder._awardsList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._tabBar.dataProvider = new ArrayCollection([{
            "wager":§_-K2W§.§_-8b§,
            "stringId":§_-s2a§.RATING_BATTLES_ALL
         },{
            "wager":§_-K2W§.DUEL_15,
            "stringId":§_-s2a§.RATING_BATTLES_BET_SMALL
         },{
            "wager":§_-K2W§.DUEL_50,
            "stringId":§_-s2a§.RATING_BATTLES_BET_MED
         },{
            "wager":§_-K2W§.§_-I0§,
            "stringId":§_-s2a§.RATING_BTN_2х2
         }]);
      }
      
      private function §_-n24§(param1:Event) : void
      {
         this.§_-B0§();
      }
      
      private function §_-cR§(param1:Event) : void
      {
         §_-h2B§.play(§_-81L§.§_-D1q§);
      }
      
      override protected function draw() : void
      {
         var _loc1_:Vector.<§_-c2b§> = null;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_STATE))
         {
            this.§_-B0§();
         }
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            this.binder._ratingList.dataProvider = new ArrayCollection(§_-K3x§);
            this.binder._userList.dataProvider = _owner ? new ArrayCollection([{
               "owner":§_-sE§,
               "result":_result
            }]) : new ArrayCollection([]);
            this.binder._descTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING_AWARDS_TITLE);
            this.binder._descText.text = StringUtil.format(§_-s2a§.§_-K3t§(§_-s2a§.RATING_AWARDS_TEXT),{"rating":§_-Uc§.§_-l2S§});
            _loc1_ = §_-Uc§.§_-Cp§(this.binder._tabBar.selectedItem.wager);
            this.binder._awardsList.dataProvider = new VectorCollection(_loc1_);
         }
      }
      
      private function §_-B0§() : void
      {
         if(Boolean(this.binder._tabBar) && Boolean(this.binder._tabBar.selectedItem))
         {
            dispatchEventWith(Event.CHANGE,false,{
               "type":§_-62e§,
               "wager":this.binder._tabBar.selectedItem.wager
            });
         }
      }
   }
}

import feathers.controls.Label;
import feathers.controls.List;
import feathers.controls.Panel;
import feathers.controls.TabBar;

class Binder
{
   
   public var _container:Panel;
   
   public var _tabBar:TabBar;
   
   public var _ratingList:List;
   
   public var _userList:List;
   
   public var _awardsList:List;
   
   public var _descTitle:Label;
   
   public var _descText:Label;
   
   public function Binder()
   {
      super();
   }
}

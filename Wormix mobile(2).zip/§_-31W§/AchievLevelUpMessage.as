package §_-31W§
{
   import §_-21p§.§_-N1H§;
   import §_-5Y§.*;
   import §_-62§.§_-O2H§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-T22§;
   import §_-DJ§.§_-T2G§;
   import §_-DJ§.§_-zb§;
   import §_-E1I§.*;
   import §_-YF§.§_-q2v§;
   import §_-l1K§.*;
   import §_-w2W§.§_-21w§;
   import feathers.controls.Button;
   import feathers.core.ITextRenderer;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class AchievLevelUpMessage extends EventDispatcher implements §_-T22§
   {
      
      private static const §_-F2E§:String = "awardLabel";
      
      private static const §_-Bo§:String = "shareAchiev_btn";
      
      private static const §_-H22§:String = "reward";
      
      private static const §_-91E§:String = "icon";
      
      private static const §_-R2v§:String = "nameAchiev";
      
      private static const §_-a2Z§:String = "descrAchiev.text";
      
      private static const §_-71h§:String = "score";
      
      private static const §_-C1I§:String = "close";
      
      protected var _container:Sprite;
      
      private var iconContainer:DisplayObjectContainer;
      
      private var §_-P2M§:§_-t1q§;
      
      protected var §_-u1L§:ITextRenderer;
      
      protected var §_-H34§:ITextRenderer;
      
      private var §_-91Y§:Button;
      
      private var §_-621§:Button;
      
      protected var §_-Mw§:§_-8§;
      
      protected var level:int;
      
      protected var §_-42g§:Boolean;
      
      public function AchievLevelUpMessage(param1:§_-8§, param2:int)
      {
         super();
         this.§_-Mw§ = param1;
         this.level = param2;
         this._container = §_-YQ§.§_-qM§(§_-q2v§.§_-t2a§,§_-q2v§.§_-A2T§);
         var _loc3_:ITextRenderer = this._container.getChildByName(§_-F2E§) as ITextRenderer;
         _loc3_.text = " ";
         this.§_-91Y§ = this._container.getChildByName(§_-Bo§) as Button;
         if(SystemUtil.isDesktop || !§_-N1V§.postController.§_-hh§())
         {
            this.§_-91Y§.removeFromParent(true);
         }
         else
         {
            this.§_-91Y§.label = §_-s2a§.§_-K3t§(§_-s2a§.BTN_SHARE_NAME);
            this.§_-91Y§.addEventListener(Event.TRIGGERED,this.§_-U1u§);
         }
         this.§_-u1L§ = §_-YQ§.getClip(§_-R2v§,this._container) as ITextRenderer;
         this.§_-H34§ = §_-YQ§.getClip(§_-a2Z§,this._container) as ITextRenderer;
         _loc3_.text = §_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_AWARD_BUTTON);
         this.iconContainer = this._container.getChildByName(§_-91E§) as DisplayObjectContainer;
         this.§_-621§ = this._container.getChildByName(§_-C1I§) as Button;
         this.§_-621§.addEventListener(Event.TRIGGERED,this.§_-r2x§);
         this.setIcon(param1);
         this.§_-zZ§(param1);
         this.§_-D3z§(§_-Kb§(param1.levels[param2]));
      }
      
      protected function setIcon(param1:§_-8§) : void
      {
         if(!this.§_-P2M§)
         {
            this.§_-P2M§ = new §_-t1q§(this.iconContainer);
         }
         this.§_-P2M§.§_-f1F§(param1.levels[this.level].icon);
      }
      
      protected function §_-zZ§(param1:§_-8§) : void
      {
         this.§_-u1L§.text = §_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_LEVELUP_TITLE);
         this.§_-H34§.text = §_-s2a§.§_-K3t§(param1.levels[this.level].name);
         this.§_-H34§.width = NaN;
         this.§_-H34§.height = NaN;
      }
      
      protected function §_-U1u§(param1:Event = null) : void
      {
         this.§_-42g§ = true;
         §_-N1V§.postController.§_-91Y§(this.§_-Mw§,this.level);
         this.§_-r2x§();
      }
      
      private function §_-D3z§(param1:§_-Kb§) : void
      {
         var _loc7_:DisplayObject = null;
         var _loc8_:DisplayObject = null;
         this.§_-I2z§(param1);
         var _loc2_:ITextRenderer = this._container.getChildByName(§_-H22§ + "1") as ITextRenderer;
         var _loc3_:ITextRenderer = this._container.getChildByName(§_-H22§ + "2") as ITextRenderer;
         _loc2_.text = param1.reward.count;
         _loc3_.text = String(param1.points);
         var _loc4_:DisplayObjectContainer = this._container.getChildByName(§_-H22§ + "1_" + §_-91E§) as DisplayObjectContainer;
         var _loc5_:DisplayObjectContainer = this._container.getChildByName(§_-H22§ + "2_" + §_-91E§) as DisplayObjectContainer;
         var _loc6_:* = _loc4_.numChildren;
         while(_loc6_--)
         {
            _loc7_ = _loc4_.getChildAt(_loc6_);
            _loc7_.visible = _loc7_.name == param1.reward.type;
            _loc8_ = _loc5_.getChildAt(_loc6_);
            _loc8_.visible = _loc8_.name == §_-71h§;
         }
      }
      
      private function §_-I2z§(param1:§_-Kb§) : void
      {
         if(param1.reward.type == §_-aO§.§_-J2y§.value)
         {
            Application.userProfile.§_-m1O§(param1.reward.count,§_-E19§.§_-i2d§);
         }
         else if(param1.reward.type == §_-aO§.§_-Mu§.value)
         {
            Application.userProfile.§_-m1O§(param1.reward.count,§_-E19§.§_-51D§);
         }
         else if(param1.reward.type == §_-aO§.REACTION.value)
         {
            §_-X1j§.§_-k2F§.§_-f1I§([§_-r26§.§_-S2§],[param1.reward.count]);
            Application.userProfile.§_-P2P§(param1.reward.count);
         }
      }
      
      protected function §_-r2x§(param1:Event = null) : void
      {
         dispatchEventWith(Event.CLOSE);
      }
      
      public function get container() : DisplayObject
      {
         return this._container;
      }
      
      public function §_-X2O§() : void
      {
         this.§_-r2x§();
      }
      
      public function dispose() : void
      {
         if(this.§_-P2M§)
         {
            this.§_-P2M§.dispose();
            this.§_-P2M§ = null;
         }
         if(Boolean(this.§_-91Y§) && this.§_-91Y§.hasEventListener(Event.TRIGGERED))
         {
            this.§_-91Y§.removeEventListener(Event.TRIGGERED,this.§_-U1u§);
         }
         if(Boolean(this.§_-621§) && this.§_-621§.hasEventListener(Event.TRIGGERED))
         {
            this.§_-621§.removeEventListener(Event.TRIGGERED,this.§_-r2x§);
         }
         this.§_-u1L§ = null;
         this.§_-H34§ = null;
         this.iconContainer = null;
         this.§_-91Y§ = null;
         this.§_-621§ = null;
         this._container = §_-c1S§.dispose(this._container) as Sprite;
      }
      
      public function get §_-L2N§() : Boolean
      {
         return this.§_-42g§;
      }
   }
}


package §_-31W§
{
   import §_-21p§.§_-4w§;
   import §_-5Y§.§_-h2c§;
   import §_-82l§.§_-A2Y§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import starling.events.Event;
   
   public class §_-g16§
   {
      
      public static const PVP_PLAYED:uint = 50;
      
      public static const PVP_WON:uint = 51;
      
      public static const PVP_DRAWS:uint = 52;
      
      public static const MISSIONS_PLAYED:uint = 53;
      
      public static const MISSIONS_WON:uint = 54;
      
      public static const WAGERS_EARNED:uint = 55;
      
      public static const MISSIONS_EARNED:uint = 56;
      
      public static const RUBIES_FOUND:uint = 57;
      
      public static const SOLO_DAMAGE:uint = 58;
      
      public static const TEAM_DAMAGE:uint = 59;
      
      public static const SOLO_DAMAGE_TAKEN:uint = 60;
      
      public static const TEAM_DAMAGE_TAKEN:uint = 61;
      
      public static const KILLED_CATS:uint = 62;
      
      public static const SNIPER_SHOTS:uint = 63;
      
      public static const WIND_SHOTS:uint = 64;
      
      public static const KILLED_DRAGONS:uint = 65;
      
      public static const KILLED_BOTS:uint = 78;
      
      public static const KILLED_BOXERS:uint = 66;
      
      public static const KILLED_DEMONS:uint = 67;
      
      public static const KILLED_RABBITS:uint = 68;
      
      public static const KILLED_ZOMBIES:uint = 69;
      
      public static const KILLED_REVIVED:uint = 70;
      
      public static const §_-71X§:uint = 71;
      
      public static const UNITS_LOST:uint = 72;
      
      public static const COLLECTED_MEDKITS:uint = 73;
      
      public static const COLLECTED_CRATES:uint = 74;
      
      public static const COLLECTED_STARS:uint = 75;
      
      public static const DESTROYED_SUPPLIES:uint = 76;
      
      public static const GRAVES_SANK:uint = 77;
      
      public function §_-g16§()
      {
         super();
      }
   }
}


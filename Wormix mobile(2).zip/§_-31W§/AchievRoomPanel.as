package §_-31W§
{
   import §_-51M§.Cat;
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-1Y§;
   import §_-C3f§.§_-yG§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-Vg§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-b1R§.§_-Bx§;
   import §_-g2e§.§_-q2Z§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2W§.§_-21w§;
   import §_-zI§.*;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import config.§_-q2e§;
   import feathers.controls.TabBar;
   import feathers.core.FeathersControl;
   import feathers.core.ToggleGroup;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import flash.display.StageDisplayState;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.clans.main.IncomingClanMessage;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.IPooledAmmo;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class AchievRoomPanel
   {
      
      private var §_-AW§:TabBar;
      
      private var §_-J2J§:§_-H3V§;
      
      private var §_-D1U§:§_-X2s§;
      
      private var §_-dX§:AwardListTab;
      
      private var §_-T2m§:§_-Y1q§;
      
      private var §_-oB§:Boolean = false;
      
      private var §_-E1o§:uint;
      
      private var binder:Binder;
      
      public function AchievRoomPanel(param1:Number = 800)
      {
         super();
         this.§_-oB§ = false;
         this.binder = new Binder();
         §_-YQ§.§_-qM§("AchievRoomPanel",§_-q2v§.§_-A2T§,this.binder);
         this.binder._panel.height = param1;
         this.binder._panel.maxHeight = param1;
         this.binder._panel.validate();
         this.§_-32R§();
         var _loc2_:DisplayObjectContainer = this.binder._battleTab;
         _loc2_.touchable = true;
         this.§_-N1A§(_loc2_);
         this.§_-J1K§(_loc2_);
         this.§_-i2c§(_loc2_);
         this.§_-z2h§(_loc2_);
         this.§_-Za§();
      }
      
      public function get display() : FeathersControl
      {
         return this.binder._panel;
      }
      
      private function §_-32R§() : void
      {
         var _loc1_:TabBar = new §_-xd§(this.binder._panel);
         _loc1_.dataProvider = new ListCollection([{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_BATTLE_BUTTON),
            "example":0,
            "type":§_-t2d§.§_-C39§
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_GAME_BUTTON),
            "example":1,
            "type":§_-t2d§.§_-i1G§
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_BOSSES_BUTTON),
            "example":2,
            "type":§_-t2d§.§_-Fs§
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_AWARD_BUTTON),
            "example":3,
            "type":§_-t2d§.§_-01Z§
         },{
            "label":§_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_STATISTIC_BUTTON),
            "example":4,
            "type":§_-t2d§.§_-f2j§
         }]);
         this.binder._panel.addChild(_loc1_);
         _loc1_.addEventListener(Event.CHANGE,this.§_-w2q§);
         this.§_-AW§ = _loc1_;
      }
      
      private function §_-N1A§(param1:DisplayObjectContainer) : void
      {
         this.§_-J2J§ = new §_-H3V§(param1);
      }
      
      private function §_-J1K§(param1:DisplayObjectContainer) : void
      {
         this.§_-D1U§ = new §_-X2s§(param1);
      }
      
      private function §_-i2c§(param1:DisplayObjectContainer) : void
      {
         this.§_-dX§ = new AwardListTab(§_-42v§.§_-De§,param1);
         this.§_-dX§.addEventListener(Event.CHANGE,this.§_-g2h§);
      }
      
      private function §_-g2h§(param1:Event) : void
      {
         if(Boolean(this.§_-J2J§) && Boolean(this.§_-dX§))
         {
            this.§_-J2J§.§_-J2U§ = this.§_-dX§.§_-J2U§;
         }
      }
      
      private function §_-z2h§(param1:DisplayObjectContainer) : void
      {
         this.§_-T2m§ = new §_-Y1q§(param1);
         this.§_-T2m§.setData(§_-q2e§.§_-7a§);
      }
      
      public function §_-Za§() : void
      {
         this.§_-E1o§ = Starling.juggler.repeatCall(this.§_-uW§,5);
         this.§_-oB§ = false;
         this.§_-H3b§(!this.§_-oB§);
         this.§_-uW§();
      }
      
      private function §_-uW§() : void
      {
         if(this.§_-oB§)
         {
            Starling.juggler.removeByID(this.§_-E1o§);
         }
         else
         {
            this.§_-J2J§.addEventListener(Event.COMPLETE,this.§_-I3F§);
            this.§_-J2J§.§_-z24§(Application.§_-SH§.userProfile);
         }
      }
      
      private function §_-I3F§(param1:Event) : void
      {
         this.§_-oB§ = true;
         this.§_-H3b§(!this.§_-oB§);
         this.§_-J2J§.removeEventListener(Event.COMPLETE,this.§_-I3F§);
         this.§_-D1U§.§_-yL§(param1.data as §_-S2Y§);
         this.§_-T2m§.§_-yL§(param1.data as §_-S2Y§);
         this.binder._pointsCount.text = this.§_-J2J§.§_-g1g§.toString();
         this.§_-w2q§();
      }
      
      private function §_-w2q§(param1:Event = null) : void
      {
         var _loc2_:§_-t2d§ = null;
         if(Boolean(param1) && (param1.currentTarget as TabBar).selectedIndex != -1)
         {
            §_-h2B§.play(§_-81L§.§_-o1Z§);
         }
         this.§_-S1f§();
         if(this.§_-oB§)
         {
            _loc2_ = this.§_-AW§.selectedItem.type as §_-t2d§;
            if(_loc2_ == §_-t2d§.§_-i1G§ || _loc2_ == §_-t2d§.§_-C39§)
            {
               this.§_-83Z§(_loc2_);
            }
            if(_loc2_ == §_-t2d§.§_-Fs§)
            {
               this.§_-E2r§();
            }
            if(_loc2_ == §_-t2d§.§_-01Z§)
            {
               this.§_-o1A§();
            }
            if(_loc2_ == §_-t2d§.§_-f2j§)
            {
               this.§_-6K§();
            }
         }
      }
      
      private function §_-83Z§(param1:§_-t2d§) : void
      {
         this.§_-J2J§.visible = true;
         this.§_-J2J§.§_-83Z§(param1);
      }
      
      private function §_-E2r§() : void
      {
         this.§_-D1U§.visible = true;
      }
      
      private function §_-o1A§() : void
      {
         this.§_-dX§.visible = true;
         this.§_-dX§.setData(this.§_-J2J§.§_-J2U§,this.§_-J2J§.§_-g1g§);
      }
      
      private function §_-6K§() : void
      {
         this.§_-T2m§.visible = true;
      }
      
      private function §_-H3b§(param1:Boolean) : void
      {
         this.§_-S1f§();
         if(param1)
         {
            this.binder._loadingText.text = §_-s2a§.§_-K3t§(§_-s2a§.LOADING);
         }
         this.binder._loading.visible = param1;
      }
      
      private function §_-S1f§() : void
      {
         if(this.§_-J2J§)
         {
            this.§_-J2J§.visible = false;
         }
         if(this.§_-D1U§)
         {
            this.§_-D1U§.visible = false;
         }
         if(this.§_-dX§)
         {
            this.§_-dX§.visible = false;
         }
         if(this.§_-T2m§)
         {
            this.§_-T2m§.visible = false;
         }
      }
      
      public function dispose() : void
      {
         Starling.juggler.removeByID(this.§_-E1o§);
         if(Boolean(this.§_-AW§) && this.§_-AW§.hasEventListener(Event.CHANGE))
         {
            this.§_-AW§.removeEventListener(Event.CHANGE,this.§_-w2q§);
         }
         this.§_-AW§ = §_-c1S§.dispose(this.§_-AW§) as TabBar;
         if(this.§_-J2J§)
         {
            if(this.§_-J2J§.hasEventListener(Event.COMPLETE))
            {
               this.§_-J2J§.removeEventListener(Event.COMPLETE,this.§_-I3F§);
            }
            this.§_-J2J§.dispose();
            this.§_-J2J§ = null;
         }
         if(this.§_-D1U§)
         {
            this.§_-D1U§.dispose();
            this.§_-D1U§ = null;
         }
         if(this.§_-dX§)
         {
            this.§_-dX§.removeEventListener(Event.CHANGE,this.§_-g2h§);
            this.§_-dX§.dispose();
            this.§_-dX§ = null;
         }
         if(this.§_-T2m§)
         {
            this.§_-T2m§.dispose();
            this.§_-T2m§ = null;
         }
         this.binder._panel.removeFromParent(true);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.core.ITextRenderer;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _battleTab:LayoutGroup;
   
   public var _loading:LayoutGroup;
   
   public var _loadingText:ITextRenderer;
   
   public var _pointsCount:ITextRenderer;
   
   public function Binder()
   {
      super();
   }
}

package §_-31W§
{
   import §_-A2U§.§_-A23§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-fH§;
   import §_-R2I§.§_-H7§;
   import §_-R2I§.§_-u2V§;
   import §_-Y1O§.§_-V23§;
   import §_-r1C§.§_-h2B§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-sI§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.events.Event;
   
   public class §_-42v§
   {
      
      public static const §_-De§:Array = [{
         "itemId":62,
         "level":1
      },{
         "itemId":63,
         "level":1
      },{
         "itemId":64,
         "level":2
      },{
         "itemId":68,
         "level":2
      },{
         "itemId":1027,
         "level":3
      },{
         "itemId":67,
         "level":3
      },{
         "itemId":2022,
         "level":4
      },{
         "itemId":1034,
         "level":4
      },{
         "itemId":77,
         "level":4
      }];
      
      public function §_-42v§()
      {
         super();
      }
      
      public static function §_-e26§(param1:int) : int
      {
         var _loc2_:int = int(§_-De§.length);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_)
         {
            if(param1 == §_-De§[_loc3_].itemId)
            {
               return §_-De§[_loc3_].position;
            }
            _loc3_++;
         }
         return -1;
      }
      
      public static function §_-y1w§(param1:int) : int
      {
         var _loc2_:int = int(§_-De§.length);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_)
         {
            if(param1 == §_-De§[_loc3_].itemId)
            {
               return §_-De§[_loc3_].level;
            }
            _loc3_++;
         }
         return -1;
      }
   }
}


package §_-31W§
{
   import §_-j22§.§_-5g§;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import starling.display.DisplayObject;
   
   public class §_-aO§
   {
      
      public static const §_-J2y§:§_-aO§ = new §_-aO§("fuzy");
      
      public static const §_-Mu§:§_-aO§ = new §_-aO§("ruby");
      
      public static const §_-2O§:§_-aO§ = new §_-aO§("points");
      
      public static const REACTION:§_-aO§ = new §_-aO§("reaction");
      
      public static const WEAPON:§_-aO§ = new §_-aO§("weapon");
      
      private var _value:String;
      
      public function §_-aO§(param1:String)
      {
         super();
         this._value = param1;
      }
      
      public function get value() : String
      {
         return this._value;
      }
   }
}


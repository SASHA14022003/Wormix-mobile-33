package §_-31W§
{
   public interface §_-8§
   {
      
      function get id() : int;
      
      function get levels() : Vector.<§_-Kb§>;
      
      function §_-p1§(param1:uint) : String;
   }
}


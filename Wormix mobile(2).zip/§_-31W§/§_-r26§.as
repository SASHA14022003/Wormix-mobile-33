package §_-31W§
{
   public class §_-r26§
   {
      
      public static const §_-cV§:int = 0;
      
      public static const §_-M29§:int = 1;
      
      public static const §_-L2w§:int = 2;
      
      public static const §_-GB§:int = 3;
      
      public static const §_-n2M§:int = 4;
      
      public static const §_-2x§:int = 5;
      
      public static const MASSIVE_DAMAGE:int = 6;
      
      public static const GRAVES_SANK:int = 7;
      
      public static const §_-R1y§:int = 8;
      
      public static const §_-RR§:int = 9;
      
      public static const §_-r1W§:int = 10;
      
      public static const §_-AH§:int = 11;
      
      public static const §_-B2b§:int = 12;
      
      public static const §_-21t§:int = 13;
      
      public static const §_-h1B§:int = 14;
      
      public static const KAMIKAZE:int = 15;
      
      public static const §_-K33§:int = 16;
      
      public static const §_-T20§:int = 17;
      
      public static const §_-b22§:int = 18;
      
      public static const §_-S2§:int = 19;
      
      public static const RUBIES_FOUND:int = 20;
      
      public static const §_-HX§:int = 21;
      
      public static const §_-93q§:int = 22;
      
      public static const §_-wy§:int = 23;
      
      public static const §_-R1k§:int = 24;
      
      public static const §_-91c§:int = 25;
      
      public static const §_-l2C§:int = 26;
      
      public static const §_-Uo§:int = 27;
      
      public static const §_-61y§:int = 28;
      
      public static const §_-K1B§:int = 29;
      
      public static const §_-41k§:int = 31;
      
      public static const §_-92j§:int = 32;
      
      public static const §_-U10§:int = 33;
      
      public static const §_-l2m§:int = 37;
      
      public function §_-r26§()
      {
         super();
      }
   }
}


package §_-31W§
{
   import §_-12a§.§_-B16§;
   import §_-931§.§_-sz§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.weapons.*;
   
   public class §_-Y1v§ implements §_-8§
   {
      
      private var _id:§_-TA§;
      
      private var _description:String;
      
      private var §_-q§:Vector.<§_-Kb§>;
      
      public function §_-Y1v§(param1:int, param2:String, param3:Array)
      {
         var _loc4_:§_-Kb§ = null;
         super();
         this._id = new §_-TA§(param1);
         this._description = param2;
         this.§_-q§ = new Vector.<§_-Kb§>(0);
         for each(_loc4_ in param3)
         {
            this.§_-q§.push(_loc4_);
         }
      }
      
      public function get id() : int
      {
         return this._id.value;
      }
      
      public function get levels() : Vector.<§_-Kb§>
      {
         return this.§_-q§;
      }
      
      public function §_-p1§(param1:uint) : String
      {
         var _loc2_:String = this._description;
         var _loc3_:uint = 0;
         if(param1 < this.§_-q§.length)
         {
            _loc3_ = this.§_-q§[param1].maxValue;
            if(this.§_-q§[param1].description)
            {
               _loc2_ = this.§_-q§[param1].description;
            }
         }
         return §_-F1P§.format(_loc2_,{"progress":_loc3_});
      }
   }
}


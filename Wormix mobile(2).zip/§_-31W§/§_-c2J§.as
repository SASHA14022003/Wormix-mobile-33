package §_-31W§
{
   import §_-62§.*;
   import §_-82l§.§_-1I§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-J2l§;
   import §_-F39§.§_-a2W§;
   import §_-H3§.*;
   import §_-N8§.§_-2C§;
   import §_-RE§.*;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.*;
   import §_-Yk§.*;
   import §_-d2p§.*;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-lD§;
   import §_-rM§.§_-61j§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-y1S§;
   import config.§_-p1i§;
   import feathers.core.ITextRenderer;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.server.ChooseBonusItemResult;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.HealBlocker;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-c2J§ extends AchievLevelUpMessage
   {
      
      private var §_-t1S§:BossAchieveIcon;
      
      private const §_-02v§:Number = 13;
      
      public function §_-c2J§(param1:§_-8§)
      {
         super(param1,0);
      }
      
      override protected function setIcon(param1:§_-8§) : void
      {
         this.§_-t1S§ = new BossAchieveIcon(_container.getChildByName("icon") as DisplayObjectContainer);
         if(param1 is §_-2C§)
         {
            this.§_-t1S§.§_-J0§((param1 as §_-2C§).§_-B3d§);
         }
         else
         {
            this.§_-t1S§.§_-O1t§(param1.levels[0].icon);
         }
      }
      
      override protected function §_-zZ§(param1:§_-8§) : void
      {
         §_-u1L§.text = §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.ACHIEV_LEVELUP_TITLE),{"name":param1.levels[0].name});
         §_-H34§.text = param1.§_-p1§(0);
         §_-H34§.width = NaN;
         §_-H34§.height = NaN;
      }
      
      override public function dispose() : void
      {
         if(this.§_-t1S§)
         {
            this.§_-t1S§.dispose();
            this.§_-t1S§ = null;
         }
         super.dispose();
      }
      
      override protected function §_-U1u§(param1:Event = null) : void
      {
         var _loc2_:DisplayObject = null;
         var _loc3_:Rectangle = null;
         var _loc4_:Rectangle = null;
         var _loc5_:Sprite = null;
         if(§_-Mw§ is §_-2C§)
         {
            _loc2_ = this.§_-t1S§.§_-d15§();
            _loc3_ = _loc2_.bounds;
            _loc4_ = Pool.getRectangle(0,0,300,300);
            _loc3_ = RectangleUtil.fit(_loc3_,_loc4_,ScaleMode.NO_BORDER);
            Pool.putRectangle(_loc4_);
            _loc2_.width = _loc3_.width;
            _loc2_.height = _loc3_.height;
            _loc5_ = new Sprite();
            _loc5_.addChild(_loc2_);
            §_-c1S§.§_-Z1T§(Starling.current,_loc5_,this.§_-Iu§);
         }
         else
         {
            super.§_-U1u§(param1);
         }
      }
      
      private function §_-Iu§(param1:BitmapData) : void
      {
         §_-42g§ = true;
         §_-N1V§.postController.§_-91Y§(§_-Mw§,level,param1);
         §_-r2x§();
      }
   }
}


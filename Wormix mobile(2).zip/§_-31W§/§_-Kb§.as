package §_-31W§
{
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.*;
   import dragonBones.animation.WorldClock;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-Kb§
   {
      
      public var name:String;
      
      public var reward:Object;
      
      public var maxValue:uint = 0;
      
      public var icon:String;
      
      public var points:uint = 0;
      
      public var description:String = "";
      
      public function §_-Kb§(param1:String, param2:Object, param3:uint, param4:String, param5:uint, param6:String = "")
      {
         super();
         this.name = param1;
         this.reward = param2;
         this.maxValue = param3;
         this.icon = param4;
         this.points = param5;
         this.description = param6;
      }
   }
}


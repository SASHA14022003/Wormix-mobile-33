package §_-DJ§
{
   import §_-12a§.§_-41b§;
   import §_-73I§.§_-q15§;
   import §_-73d§.§_-pT§;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-p1m§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-U1i§.§_-O2i§;
   import §_-aM§.*;
   import §_-dS§.§_-D3a§;
   import §_-g2r§.§_-03A§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-qH§.§_-AC§;
   import §_-z1g§.§_-Uc§;
   import com.greensock.OverwriteManager;
   import com.greensock.TweenLite;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.AutoAlphaPlugin;
   import com.greensock.plugins.BevelFilterPlugin;
   import com.greensock.plugins.BezierPlugin;
   import com.greensock.plugins.BezierThroughPlugin;
   import com.greensock.plugins.BlurFilterPlugin;
   import com.greensock.plugins.ColorMatrixFilterPlugin;
   import com.greensock.plugins.ColorTransformPlugin;
   import com.greensock.plugins.DropShadowFilterPlugin;
   import com.greensock.plugins.EndArrayPlugin;
   import com.greensock.plugins.FrameLabelPlugin;
   import com.greensock.plugins.FramePlugin;
   import com.greensock.plugins.GlowFilterPlugin;
   import com.greensock.plugins.HexColorsPlugin;
   import com.greensock.plugins.RemoveTintPlugin;
   import com.greensock.plugins.RoundPropsPlugin;
   import com.greensock.plugins.ShortRotationPlugin;
   import com.greensock.plugins.TintPlugin;
   import com.greensock.plugins.TweenPlugin;
   import com.greensock.plugins.VisiblePlugin;
   import com.greensock.plugins.VolumePlugin;
   import dragonBones.Slot;
   import dragonBones.animation.WorldClock;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.TiledRowsLayout;
   import feathers.layout.VerticalAlign;
   import flash.display.BitmapData;
   import flash.display.Shape;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-51d§;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   
   public class §_-zb§ extends §_-51d§
   {
      
      public static var §_-L22§:§_-zb§ = null;
      
      private var panel:DisplayObjectContainer;
      
      private var iconSource:§_-p1m§;
      
      private var §_-MC§:Boolean;
      
      private var §_-X2§:Boolean;
      
      private var profile:UserProfile;
      
      public function §_-zb§(param1:DisplayObjectContainer, param2:UserProfile, param3:Boolean = true, param4:Boolean = true)
      {
         super(param1);
         this.§_-MC§ = param3;
         this.§_-X2§ = param4;
         this.panel = param1;
         this.profile = param2;
         this.iconSource = new §_-p1m§();
      }
      
      public function §_-82v§(param1:UserProfile) : void
      {
         this.profile = param1;
      }
      
      override public function §_-IR§(param1:int, param2:int) : void
      {
         var _loc3_:uint = §_-81L§.stageHeight - 110;
         if(container.height > _loc3_)
         {
            container.scaleX = container.scaleY = _loc3_ / container.height;
         }
         super.§_-IR§(param1,this.§_-MC§ ? int(§_-81L§.stageHeight - container.height - 100) : param2);
         §_-L22§ = this;
         var _loc4_:ITextRenderer = this.panel.getChildByName("userName") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-K3u§() ? this.profile.§_-K3u§() : StringUtil.§_-43t§;
         }
         _loc4_ = this.panel.getChildByName("userName_short") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile ? §_-33r§.§_-KQ§(this.profile) : StringUtil.§_-43t§;
         }
         _loc4_ = this.panel.getChildByName("level") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.getLevel() ? this.profile.getLevel().toString() : StringUtil.§_-43t§;
         }
         _loc4_ = this.panel.getChildByName("hp") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-N23§() ? §_-33r§.§_-jA§(this.profile.§_-N23§(),this.profile.stats.§_-q1G§.value) : StringUtil.§_-43t§;
         }
         _loc4_ = this.panel.getChildByName("hpLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.HP);
         }
         _loc4_ = this.panel.getChildByName("teamHp") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-e2A§() ? this.profile.§_-e2A§().toString() : StringUtil.§_-43t§;
         }
         _loc4_ = this.panel.getChildByName("teamHpLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_HP_LABEL);
         }
         _loc4_ = this.panel.getChildByName("teamSize") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-A1U§() ? this.profile.§_-A1U§().length.toString() : StringUtil.§_-43t§;
         }
         _loc4_ = this.panel.getChildByName("teamLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_LABEL);
         }
         _loc4_ = this.panel.getChildByName("rating") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-Uc§.§_-Zp§(this.profile);
         }
         _loc4_ = this.panel.getChildByName("ratingLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING);
         }
         _loc4_ = this.panel.getChildByName("armor") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-33r§.§_-jA§(this.profile.§_-h2m§(),this.profile.stats.§_-v2n§.value);
         }
         _loc4_ = this.panel.getChildByName("armorLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.ARMOR);
         }
         _loc4_ = this.panel.getChildByName("attack") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-33r§.§_-jA§(this.profile.§_-w1p§(),this.profile.stats.bonusAttack.value);
         }
         _loc4_ = this.panel.getChildByName("attackLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.ATTACK);
         }
         _loc4_ = this.panel.getChildByName("money") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-51e§().toString();
         }
         _loc4_ = this.panel.getChildByName("reactionRate") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-u2l§().toString();
         }
         _loc4_ = this.panel.getChildByName("realMoney") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-o1N§().toString();
         }
         _loc4_ = this.panel.getChildByName("race") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-P2e§().getName();
         }
         _loc4_ = this.panel.getChildByName("raceLabel") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.RACE);
         }
         if(Boolean(this.panel.getChildByName("worm")) && Boolean(this.profile.§_-P2e§()))
         {
            this.iconSource.container = getChildByName("worm") as DisplayObjectContainer;
            this.iconSource.setIcon(this.profile);
         }
         dispatchEvent(new starling.events.Event(starling.events.Event.OPEN));
      }
      
      override public function hide() : void
      {
         §_-L22§ = null;
         if(Boolean(container) && Boolean(container.parent))
         {
            container.parent.removeChild(container);
         }
         if(Boolean(this.panel) && Boolean(this.panel.parent))
         {
            this.panel.parent.removeChild(this.panel);
         }
         super.hide();
      }
      
      override public function §_-x18§() : void
      {
         if(this.§_-X2§)
         {
            super.§_-x18§();
         }
      }
      
      override public function dispose() : void
      {
         if(this.iconSource)
         {
            this.iconSource.dispose();
         }
         this.iconSource = null;
         this.panel = null;
         §_-L22§ = null;
         super.dispose();
      }
   }
}


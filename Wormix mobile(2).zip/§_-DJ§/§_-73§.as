package §_-DJ§
{
   import §_-21p§.§_-4w§;
   import §_-63M§.§_-F3f§;
   import §_-81r§.UserParamsMenu;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-p2U§;
   import §_-CR§.§_-S2o§;
   import §_-F39§.§_-i1i§;
   import §_-SP§.§_-M4§;
   import §_-T1o§.§_-n1S§;
   import §_-TF§.*;
   import §_-YF§.§_-L29§;
   import §_-YF§.§_-q2v§;
   import §_-bI§.*;
   import §_-d26§.§_-d1H§;
   import §_-jF§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-w2i§.§_-52k§;
   import com.greensock.*;
   import com.greensock.core.*;
   import dragonBones.Slot;
   import dragonBones.starling.StarlingFactory;
   import dragonBones.starling.StarlingTextureAtlasData;
   import dragonBones.textures.TextureAtlasData;
   import feathers.controls.Button;
   import feathers.controls.TabBar;
   import flash.errors.IllegalOperationError;
   import org.gestouch.core.§_-H3d§;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.ChangeNameDialog;
   import ru.pragmatix.wormix.gui.menu.InfoAndSupportWindow;
   import ru.pragmatix.wormix.gui.menu.SettingsDialog;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.core.Starling;
   import starling.display.Image;
   import starling.events.EnterFrameEvent;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.TouchEvent;
   import starling.textures.Texture;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   
   public class §_-73§
   {
      
      public function §_-73§()
      {
         super();
      }
      
      public static function §_-D3u§(param1:String, param2:Function = null) : void
      {
         §_-J2l§.§_-u2b§.show(§_-Am§,param1,param2);
      }
      
      private static function §_-Am§(param1:String, param2:Function) : void
      {
         var id:String = param1;
         var onCreated:Function = param2;
         §_-L29§.§_-OV§(id,function():void
         {
            §_-52k§.single(Starling.current.stage,EnterFrameEvent.ENTER_FRAME,§_-mS§,null,[id,onCreated]);
         });
      }
      
      private static function §_-mS§(param1:String, param2:Function) : void
      {
         var id:String = param1;
         var onCreated:Function = param2;
         var window:§_-K3O§ = §_-73§.§_-g1k§(id);
         var dispatcher:EventDispatcher = window as EventDispatcher;
         if(dispatcher)
         {
            §_-52k§.single(dispatcher,§_-M4§.WINDOW_CLOSE,function():void
            {
               §_-L29§.§_-gs§(id);
            });
            §_-52k§.single(dispatcher,§_-M4§.WINDOW_SHOW,function():void
            {
               §_-J2l§.§_-u2b§.hide();
            });
         }
         if(onCreated != null)
         {
            onCreated(window);
         }
         window.show();
      }
      
      public static function §_-g1k§(param1:String) : §_-K3O§
      {
         var _loc2_:§_-K3O§ = §_-Lw§(param1);
         if(_loc2_ is §_-73y§)
         {
            §_-73y§(_loc2_).destroyOnRemove = true;
         }
         return _loc2_;
      }
      
      private static function §_-Lw§(param1:String) : §_-K3O§
      {
         switch(param1)
         {
            case §_-q2v§.§_-X2y§:
               return new SettingsDialog();
            case §_-q2v§.§_-24§:
               return new §_-Q1j§();
            case §_-q2v§.§_-D3C§:
               return new ChangeNameDialog();
            case §_-q2v§.§_-e5§:
               return new ChooseSocialNetworkWindow();
            case §_-q2v§.SELECT_FRIEND_TO_INVITE:
               return new SelectFriendToInviteWindow();
            case §_-q2v§.§_-S1m§:
               return new ControlsHelpWindow();
            case §_-q2v§.§_-023§:
               return new UserParamsMenu();
            case §_-q2v§.§_-o10§:
               return new InfoAndSupportWindow();
            default:
               throw new Error("NO SUCH WINDOW");
         }
      }
   }
}


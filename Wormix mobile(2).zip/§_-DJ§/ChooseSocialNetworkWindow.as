package §_-DJ§
{
   import §_-12W§.*;
   import §_-21p§.§_-N1H§;
   import §_-5Y§.§_-h2c§;
   import §_-9§.§_-52A§;
   import §_-91A§.§_-Wy§;
   import §_-B1y§.*;
   import §_-CF§.§_-x2t§;
   import §_-G1h§.DesktopMainOverlayScreen;
   import §_-H16§.*;
   import §_-SP§.§_-M4§;
   import §_-T1t§.§_-A2h§;
   import §_-T1t§.§_-aQ§;
   import §_-Ta§.*;
   import §_-YF§.§_-q2v§;
   import §_-hO§.§_-h2f§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1s§.TeamRoomTeammateItemRenderer;
   import §_-u1T§.§_-33B§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderStatus;
   import com.hurlant.math.BigInteger;
   import feathers.controls.ButtonState;
   import feathers.controls.Screen;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ToggleButton;
   import feathers.core.ToggleGroup;
   import feathers.data.ArrayCollection;
   import feathers.events.FeathersEventType;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.§_-Qd§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.render.IRenderer;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.EnterFrameEvent;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class ChooseSocialNetworkWindow extends §_-73y§
   {
      
      private var _toggleGroup:ToggleGroup;
      
      public function ChooseSocialNetworkWindow()
      {
         var _loc1_:DisplayObjectContainer = §_-YQ§.§_-qM§(§_-q2v§.§_-e5§,§_-q2v§.§_-A2T§);
         super(_loc1_.getChildByName("panel") as DisplayObjectContainer);
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-v1w§.stringId = §_-s2a§.SELECT_SOCIAL_NETWORK;
         §_-rP§.name = "buttons.ok";
         §_-rP§.stringId = §_-s2a§.BUTTON_SELECT;
         §_-H1o§.name = "buttons.cancel";
         §_-H1o§.stringId = §_-s2a§.BUTTON_CANCEL;
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         super.§_-Q2j§(param1);
         §_-X1j§.§_-k2F§.§_-ib§().§_-A3t§();
      }
      
      override public function hide() : void
      {
         super.hide();
         §_-X1j§.§_-k2F§.§_-ib§().§_-Nc§();
      }
      
      override protected function §_-b1H§() : void
      {
         var _loc1_:SocialType = §_-X1j§.socialController.getType();
         var _loc2_:ToggleButton = this._toggleGroup.selectedItem as ToggleButton;
         var _loc3_:SocialType = _loc2_ ? SocialType.valueOf(_loc2_.name) : SocialType.NONE;
         if(!_loc1_.equals(_loc3_))
         {
            dispatchEventWith(§_-M4§.CHANGE,false,_loc3_);
         }
         super.§_-b1H§();
      }
      
      override public function set data(param1:Object) : void
      {
         var _loc2_:DisplayObjectContainer = null;
         var _loc4_:SocialType = null;
         var _loc5_:SocialType = null;
         var _loc6_:ToggleButton = null;
         super.data = param1;
         _loc2_ = getChildByName("choosePanel") as DisplayObjectContainer;
         this._toggleGroup = new ToggleGroup();
         var _loc3_:Array = data as Array;
         _loc4_ = §_-X1j§.socialController.getType();
         for each(_loc5_ in _loc3_)
         {
            _loc6_ = this.§_-EN§();
            _loc6_.label = §_-Qd§.§_-72t§(_loc5_);
            _loc6_.name = _loc5_.name;
            _loc6_.setSkinForState(ButtonState.DOWN,_loc6_.getSkinForState(ButtonState.DISABLED));
            this._toggleGroup.addItem(_loc6_);
            _loc2_.addChild(_loc6_);
            _loc6_.isSelected = _loc5_.equals(_loc4_);
         }
      }
      
      private function §_-EN§() : ToggleButton
      {
         var _loc1_:DisplayObjectContainer = §_-YQ§.§_-qM§(§_-q2v§.§_-e2G§,§_-q2v§.§_-A2T§);
         return _loc1_.getChildByName("button") as ToggleButton;
      }
   }
}


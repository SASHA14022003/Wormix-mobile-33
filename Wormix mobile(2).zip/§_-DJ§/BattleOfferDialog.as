package §_-DJ§
{
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-12a§.§_-lc§;
   import §_-52L§.§_-u2x§;
   import §_-5P§.§_-H1u§;
   import §_-62§.*;
   import §_-73I§.*;
   import §_-9§.§_-52A§;
   import §_-A1K§.§_-TA§;
   import §_-Cl§.§_-i28§;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.§_-i1i§;
   import §_-G16§.*;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-p1m§;
   import §_-R2I§.PvpTab;
   import §_-Ta§.*;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-V23§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-v2Q§;
   import §_-g2r§.§_-03A§;
   import §_-gG§.§_-8u§;
   import §_-j1w§.*;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-p24§.MissionTab;
   import §_-u2J§.§_-T1K§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-Uc§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.loading.LoaderStatus;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import config.§_-p1i§;
   import feathers.controls.ToggleButton;
   import feathers.core.IFeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.RelativePosition;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.SelectMapMenu;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.cloud.GasCloud;
   import starling.animation.IAnimatable;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   use namespace gestouch_internal;
   
   public class BattleOfferDialog extends §_-73y§ implements IAnimatable
   {
      
      private static const §_-w1b§:Number = 0.82;
      
      private var profile:UserProfile;
      
      private var iconSource:§_-p1m§;
      
      private var mapId:int;
      
      public function BattleOfferDialog(param1:DisplayObjectContainer = null)
      {
         super(param1 ? param1 : §_-YQ§.§_-qM§(§_-q2v§.§_-UE§,§_-q2v§.§_-A2T§));
         getContainer().visible = false;
         §_-u2m§ = §_-NY§.§_-w1y§;
         outsideClosable = false;
         §_-A1e§(§_-s2a§.BATTLE_OFFER_TITLE);
         this.iconSource = new §_-p1m§();
         var _loc2_:DisplayObject = getChildByName("ground");
         if(_loc2_)
         {
            _loc2_.visible = false;
         }
      }
      
      public function setMap(param1:int) : void
      {
         this.mapId = param1;
      }
      
      public function §_-82v§(param1:UserProfile) : void
      {
         this.profile = param1;
         this.§_-21z§();
      }
      
      override protected function §_-93S§(param1:starling.events.Event = null) : void
      {
         super.§_-93S§(param1);
         this.§_-21z§();
      }
      
      override public function hide() : void
      {
         Starling.juggler.remove(this);
         dispatchEventWith(§_-T1K§.DECLINE_BATTLE_OFFER);
         super.hide();
      }
      
      override protected function §_-b1H§() : void
      {
         Starling.juggler.remove(this);
         dispatchEventWith(§_-T1K§.ACCEPT_BATTLE_OFFER);
         super.hide();
      }
      
      private function §_-21z§() : void
      {
         var _loc16_:ITextRenderer = null;
         var _loc17_:ITextRenderer = null;
         var _loc18_:ITextRenderer = null;
         var _loc19_:ITextRenderer = null;
         var _loc20_:ITextRenderer = null;
         var _loc21_:ITextRenderer = null;
         var _loc22_:ITextRenderer = null;
         var _loc1_:DisplayObjectContainer = getContainer() as DisplayObjectContainer;
         var _loc2_:ITextRenderer = _loc1_.getChildByName("playerName") as ITextRenderer;
         if(_loc2_)
         {
            _loc2_.text = (this.profile.§_-K3u§() ? this.profile.§_-K3u§() : StringUtil.§_-43t§) + " (ID " + this.profile.getId() + ")";
         }
         var _loc3_:ITextRenderer = _loc1_.getChildByName("level") as ITextRenderer;
         if(_loc3_)
         {
            _loc3_.text = this.profile.getLevel() ? this.profile.getLevel().toString() : StringUtil.§_-43t§;
         }
         var _loc4_:ITextRenderer = _loc1_.getChildByName("hp") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = this.profile.§_-N23§() ? §_-33r§.§_-jA§(this.profile.§_-N23§(),this.profile.stats.§_-q1G§.value) : StringUtil.§_-43t§;
            _loc16_ = _loc1_.getChildByName("hpLabel") as ITextRenderer;
            if(_loc16_)
            {
               _loc16_.text = §_-s2a§.§_-K3t§(§_-s2a§.HP);
            }
         }
         var _loc5_:ITextRenderer = _loc1_.getChildByName("teamHp") as ITextRenderer;
         if(_loc5_)
         {
            _loc5_.text = this.profile.§_-e2A§() ? this.profile.§_-e2A§().toString() : StringUtil.§_-43t§;
            _loc17_ = _loc1_.getChildByName("teamHpLabel") as ITextRenderer;
            if(_loc17_)
            {
               _loc17_.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_HP_LABEL);
            }
         }
         var _loc6_:ITextRenderer = _loc1_.getChildByName("teamSize") as ITextRenderer;
         if(_loc6_)
         {
            _loc6_.text = this.profile.§_-A1U§() ? this.profile.§_-A1U§().length.toString() : StringUtil.§_-43t§;
            _loc18_ = _loc1_.getChildByName("teamLabel") as ITextRenderer;
            if(_loc18_)
            {
               _loc18_.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_LABEL);
            }
         }
         var _loc7_:ITextRenderer = _loc1_.getChildByName("rating") as ITextRenderer;
         if(_loc7_)
         {
            _loc7_.text = §_-Uc§.§_-Zp§(this.profile);
            _loc19_ = _loc1_.getChildByName("ratingLabel") as ITextRenderer;
            if(_loc19_)
            {
               _loc19_.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING);
            }
         }
         var _loc8_:ITextRenderer = _loc1_.getChildByName("armor") as ITextRenderer;
         if(_loc8_)
         {
            _loc8_.text = §_-33r§.§_-jA§(this.profile.§_-h2m§(),this.profile.stats.§_-v2n§.value);
            _loc20_ = _loc1_.getChildByName("armorLabel") as ITextRenderer;
            if(_loc20_)
            {
               _loc20_.text = §_-s2a§.§_-K3t§(§_-s2a§.ARMOR);
            }
         }
         var _loc9_:ITextRenderer = _loc1_.getChildByName("attack") as ITextRenderer;
         if(_loc9_)
         {
            _loc9_.text = §_-33r§.§_-jA§(this.profile.§_-w1p§(),this.profile..stats.bonusAttack.value);
            _loc21_ = _loc1_.getChildByName("attackLabel") as ITextRenderer;
            if(_loc21_)
            {
               _loc21_.text = §_-s2a§.§_-K3t§(§_-s2a§.ATTACK);
            }
         }
         var _loc10_:ITextRenderer = _loc1_.getChildByName("money") as ITextRenderer;
         if(_loc10_)
         {
            _loc10_.text = this.profile.§_-51e§().toString();
         }
         var _loc11_:ITextRenderer = _loc1_.getChildByName("realMoney") as ITextRenderer;
         if(_loc11_)
         {
            _loc11_.text = this.profile.§_-o1N§().toString();
         }
         var _loc12_:ITextRenderer = _loc1_.getChildByName("reactionRate") as ITextRenderer;
         if(_loc12_)
         {
            _loc12_.text = this.profile.§_-u2l§().toString();
         }
         var _loc13_:ITextRenderer = _loc1_.getChildByName("race") as ITextRenderer;
         if(_loc13_)
         {
            _loc13_.text = this.profile.§_-P2e§().getName();
            _loc22_ = _loc1_.getChildByName("raceLabel") as ITextRenderer;
            if(_loc22_)
            {
               _loc22_.text = §_-s2a§.§_-K3t§(§_-s2a§.RACE);
            }
         }
         var _loc14_:ITextRenderer = _loc1_.getChildByName("map") as ITextRenderer;
         if(_loc14_)
         {
            if(this.mapId == 0)
            {
               _loc14_.text = "";
            }
            else
            {
               _loc14_.text = §_-s2a§.§_-K3t§(§_-s2a§.MAP_TITLE).concat(" ",§_-s2a§.§_-K3t§(SelectMapMenu.§_-61s§.concat(§_-p1i§.§_-o26§(this.mapId).name.toUpperCase())));
            }
         }
         var _loc15_:DisplayObjectContainer = _loc1_.getChildByName("worm") as DisplayObjectContainer;
         if((Boolean(_loc15_)) && Boolean(this.profile.§_-P2e§()))
         {
            this.iconSource.container = _loc15_;
            this.iconSource.setIcon(this.profile);
            this.iconSource.display.scale = §_-w1b§;
         }
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         super.§_-Q2j§(param1);
         Starling.juggler.add(this);
         this.advanceTime(0);
         §_-12E§(§_-s2a§.BATTLE_OFFER_ACCEPT);
         §_-xQ§(§_-s2a§.BUTTON_CANCEL);
      }
      
      public function advanceTime(param1:Number) : void
      {
         if(!§_-X1j§.§_-12n§.isReady())
         {
            this.§_-pQ§();
            return;
         }
         this.§_-l2B§();
      }
      
      public function §_-l2B§() : void
      {
         if(!getContainer().visible)
         {
            getContainer().visible = true;
         }
         §_-YQ§.§_-l2B§(getContainer(),§_-yp§,§_-3y§());
      }
      
      public function §_-pQ§() : void
      {
         Starling.juggler.remove(this);
         dispatchEventWith(§_-T1K§.DECLINE_BATTLE_OFFER);
         this.hide();
      }
      
      override public function dispose() : void
      {
         if(this.iconSource)
         {
            this.iconSource.dispose();
         }
         this.iconSource = null;
         super.dispose();
      }
   }
}


package §_-DJ§
{
   import §_-r1C§.§_-t1R§;
   
   public interface §_-K3O§
   {
      
      function show(param1:Boolean = true) : void;
      
      function §_-h1C§() : Boolean;
      
      function hide() : void;
      
      function dispose() : void;
      
      function get soundOnShow() : §_-t1R§;
      
      function get soundOnHide() : §_-t1R§;
   }
}


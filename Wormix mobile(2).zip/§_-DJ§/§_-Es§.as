package §_-DJ§
{
   import §_-51W§.§_-G2h§;
   import §_-5Y§.§_-h2c§;
   import §_-92a§.*;
   import §_-931§.§_-sz§;
   import §_-B1y§.§_-fM§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-F39§.§_-Ey§;
   import §_-G2H§.*;
   import §_-K35§.§_-p1m§;
   import §_-O2L§.§_-C3d§;
   import §_-O2L§.§_-X1T§;
   import §_-P2i§.§_-G3J§;
   import §_-P2i§.§_-b7§;
   import §_-Tm§.§_-RF§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-jF§.*;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-sQ§.§_-H3D§;
   import §_-u2J§.§_-T1K§;
   import §_-w2i§.§_-Ia§;
   import §_-wD§.*;
   import §_-z1g§.*;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderStatus;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.hurlant.math.BigInteger;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateTextStyles;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.ProgressEvent;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.client.GetDividend;
   import ru.pragmatix.wormix.messages.server.Pong;
   import ru.pragmatix.wormix.messages.server.RepeatPvpBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.IAnimatable;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-Es§ extends §_-73y§ implements IAnimatable
   {
      
      public static const §_-kR§:uint = 0;
      
      public static const §_-I2v§:uint = 1;
      
      public static const §_-T3§:uint = 5;
      
      private static const §_-w1b§:Number = 0.82;
      
      private var §_-93L§:String;
      
      private var §_-FC§:ITextRenderer;
      
      private var message:ITextRenderer;
      
      private var §_-W7§:uint;
      
      private var _time:Number;
      
      private var §_-Jf§:ITextRenderer;
      
      private var §_-dB§:Boolean;
      
      private var iconSource:§_-p1m§;
      
      public function §_-Es§(param1:uint, param2:uint, param3:Boolean = false)
      {
         var _loc4_:String = null;
         this.§_-W7§ = param2;
         this.§_-dB§ = param3;
         if(param1 == §_-I2v§)
         {
            _loc4_ = §_-q2v§.§_-vn§;
            this.§_-93L§ = §_-s2a§.BATTLE_OP_REQUEST_TITLE;
         }
         else
         {
            _loc4_ = §_-q2v§.§_-J3k§;
            this.§_-93L§ = param3 ? §_-s2a§.SEARCHING_RANDOM_PARTNER_TITLE : §_-s2a§.ENEMY_WAITING_MSG;
         }
         super(§_-YQ§.§_-qM§(_loc4_,§_-q2v§.§_-A2T§));
         this.§_-Jf§ = getChildByName(param1 == §_-I2v§ ? "waitText" : "waitBattleLabel") as ITextRenderer;
         this.§_-FC§ = getChildByName("time") as ITextRenderer;
         this.message = getChildByName("msg") as ITextRenderer;
         §_-51P§ = getChildByName("cancel");
         §_-51P§.addEventListener(starling.events.Event.TRIGGERED,this.§_-03a§);
         outsideClosable = false;
         §_-H1o§.name = "cancel";
         this.iconSource = new §_-p1m§();
         var _loc5_:DisplayObject = getChildByName("ground");
         if(_loc5_)
         {
            _loc5_.visible = false;
         }
      }
      
      private function §_-21z§(param1:UserProfile) : void
      {
         var _loc16_:ITextRenderer = null;
         var _loc17_:ITextRenderer = null;
         var _loc18_:ITextRenderer = null;
         var _loc19_:ITextRenderer = null;
         var _loc20_:ITextRenderer = null;
         var _loc21_:ITextRenderer = null;
         var _loc22_:ITextRenderer = null;
         var _loc2_:DisplayObjectContainer = getContainer() as DisplayObjectContainer;
         var _loc3_:ITextRenderer = _loc2_.getChildByName("playerName") as ITextRenderer;
         if(_loc3_)
         {
            _loc3_.text = (param1.§_-K3u§() ? param1.§_-K3u§() : StringUtil.§_-43t§) + " (ID " + param1.getId() + ")";
         }
         var _loc4_:ITextRenderer = _loc2_.getChildByName("level") as ITextRenderer;
         if(_loc4_)
         {
            _loc4_.text = param1.getLevel() ? param1.getLevel().toString() : StringUtil.§_-43t§;
         }
         var _loc5_:ITextRenderer = _loc2_.getChildByName("hp") as ITextRenderer;
         if(_loc5_)
         {
            _loc5_.text = param1.§_-N23§() ? §_-33r§.§_-jA§(param1.§_-N23§(),param1.stats.§_-q1G§.value) : StringUtil.§_-43t§;
            _loc16_ = _loc2_.getChildByName("hpLabel") as ITextRenderer;
            if(_loc16_)
            {
               _loc16_.text = §_-s2a§.§_-K3t§(§_-s2a§.HP) + ":";
            }
         }
         var _loc6_:ITextRenderer = _loc2_.getChildByName("teamHp") as ITextRenderer;
         if(_loc6_)
         {
            _loc6_.text = param1.§_-e2A§() ? param1.§_-e2A§().toString() : StringUtil.§_-43t§;
            _loc17_ = _loc2_.getChildByName("teamHpLabel") as ITextRenderer;
            if(_loc17_)
            {
               _loc17_.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_HP_LABEL) + ":";
            }
         }
         var _loc7_:ITextRenderer = _loc2_.getChildByName("teamSize") as ITextRenderer;
         if(_loc7_)
         {
            _loc7_.text = param1.§_-A1U§() ? param1.§_-A1U§().length.toString() : StringUtil.§_-43t§;
            _loc18_ = _loc2_.getChildByName("teamLabel") as ITextRenderer;
            if(_loc18_)
            {
               _loc18_.text = §_-s2a§.§_-K3t§(§_-s2a§.TEAM_LABEL) + ":";
            }
         }
         var _loc8_:ITextRenderer = _loc2_.getChildByName("rating") as ITextRenderer;
         if(_loc8_)
         {
            _loc8_.text = §_-Uc§.§_-Zp§(param1);
            _loc19_ = _loc2_.getChildByName("ratingLabel") as ITextRenderer;
            if(_loc19_)
            {
               _loc19_.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING) + ":";
            }
         }
         var _loc9_:ITextRenderer = _loc2_.getChildByName("armor") as ITextRenderer;
         if(_loc9_)
         {
            _loc9_.text = §_-33r§.§_-jA§(param1.§_-h2m§(),param1.stats.§_-v2n§.value);
            _loc20_ = _loc2_.getChildByName("armorLabel") as ITextRenderer;
            if(_loc20_)
            {
               _loc20_.text = §_-s2a§.§_-K3t§(§_-s2a§.ARMOR) + ":";
            }
         }
         var _loc10_:ITextRenderer = _loc2_.getChildByName("attack") as ITextRenderer;
         if(_loc10_)
         {
            _loc10_.text = §_-33r§.§_-jA§(param1.§_-w1p§(),param1.stats.bonusAttack.value);
            _loc21_ = _loc2_.getChildByName("attackLabel") as ITextRenderer;
            if(_loc21_)
            {
               _loc21_.text = §_-s2a§.§_-K3t§(§_-s2a§.ATTACK) + ":";
            }
         }
         var _loc11_:ITextRenderer = _loc2_.getChildByName("money") as ITextRenderer;
         if(_loc11_)
         {
            _loc11_.text = param1.§_-51e§().toString();
         }
         var _loc12_:ITextRenderer = _loc2_.getChildByName("realMoney") as ITextRenderer;
         if(_loc12_)
         {
            _loc12_.text = param1.§_-o1N§().toString();
         }
         var _loc13_:ITextRenderer = _loc2_.getChildByName("reactionRate") as ITextRenderer;
         if(_loc13_)
         {
            _loc13_.text = param1.§_-u2l§().toString();
         }
         var _loc14_:ITextRenderer = _loc2_.getChildByName("race") as ITextRenderer;
         if(_loc14_)
         {
            _loc14_.text = param1.§_-P2e§().getName();
            _loc22_ = _loc2_.getChildByName("raceLabel") as ITextRenderer;
            if(_loc22_)
            {
               _loc22_.text = §_-s2a§.§_-K3t§(§_-s2a§.RACE) + ":";
            }
         }
         var _loc15_:DisplayObjectContainer = _loc2_.getChildByName("worm") as DisplayObjectContainer;
         if((Boolean(_loc15_)) && Boolean(param1.§_-P2e§()))
         {
            this.iconSource.container = _loc15_;
            this.iconSource.setIcon(param1);
            this.iconSource.display.scale = §_-w1b§;
         }
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-u2m§ = §_-NY§.§_-w1y§;
      }
      
      override protected function §_-03a§(param1:starling.events.Event) : void
      {
         if(!Starling.juggler.contains(this))
         {
            Starling.juggler.remove(this);
         }
         dispatchEvent(new starling.events.Event(§_-T1K§.CANCEL_BATTLE_REQUEST));
         super.§_-03a§(param1);
      }
      
      public function §_-82v§(param1:UserProfile) : void
      {
         this.§_-21z§(param1);
      }
      
      public function §_-x23§(param1:String) : void
      {
         this.message.text = param1;
      }
      
      public function §_-w27§(param1:String) : void
      {
         §_-C1H§.text = param1;
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         super.§_-Q2j§(param1);
         §_-A1e§(this.§_-93L§);
         this.§_-Jf§.text = §_-s2a§.§_-K3t§(§_-s2a§.BATTLE_WAITE_LABLE);
         (getChildByName("secLabel") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.SEC_LABEL);
         if(this.message)
         {
            this.§_-x23§(§_-s2a§.§_-K3t§(this.§_-dB§ ? §_-s2a§.SEARCHING_RANDOM_PARTNER : §_-s2a§.BATTLE_REQUEST_MSG));
         }
         (§_-51P§ as Button).label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_CANCEL);
         §_-51P§.visible = false;
         this.§_-Jf§.visible = true;
         getChildByName("secLabel").visible = getChildByName("time").visible = true;
         this.§_-J2Z§(this.§_-W7§);
      }
      
      private function §_-J2Z§(param1:uint) : void
      {
         this._time = param1;
         if(!Starling.juggler.contains(this))
         {
            Starling.juggler.add(this);
         }
      }
      
      private function §_-c9§() : void
      {
         if(!§_-51P§ || !this.§_-Jf§)
         {
            return;
         }
         §_-51P§.visible = true;
         this.§_-Jf§.visible = false;
         getChildByName("secLabel").visible = getChildByName("time").visible = false;
      }
      
      override public function dispose() : void
      {
         if(this.iconSource)
         {
            this.iconSource.dispose();
         }
         this.iconSource = null;
         this.§_-FC§ = §_-c1S§.dispose(this.§_-FC§ as DisplayObject) as ITextRenderer;
         this.§_-Jf§ = §_-c1S§.dispose(this.§_-Jf§ as DisplayObject) as ITextRenderer;
         super.dispose();
      }
      
      override public function §_-X2O§() : void
      {
      }
      
      public function advanceTime(param1:Number) : void
      {
         this._time -= param1;
         if(this._time > 0)
         {
            if(this.§_-FC§)
            {
               this.§_-FC§.text = int(this._time).toString();
            }
         }
         else
         {
            Starling.juggler.remove(this);
            this.§_-c9§();
         }
      }
   }
}


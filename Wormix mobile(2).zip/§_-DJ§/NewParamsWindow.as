package §_-DJ§
{
   import §_-A2U§.§_-A23§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-Tm§.§_-RF§;
   import §_-k2s§.§_-iI§;
   import §_-kP§.CraftTreePanel;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-nE§.§_-p16§;
   import §_-x2Q§.§_-dU§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayout;
   import feathers.layout.VerticalLayout;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import flash.utils.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.*;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class NewParamsWindow extends §_-V1Y§
   {
      
      private var binder:Binder;
      
      public function NewParamsWindow()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("new_params_window",this.binder);
         addChild(this.binder._panel);
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._okButton,Event.TRIGGERED,this.§_-y1l§,§_-81L§.§_-o1Z§);
         §_-J2N§(this.binder._cancelButton,Event.TRIGGERED,this.§_-y1l§,§_-81L§.§_-o1Z§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,Event.CLOSE);
         §_-jg§(this.binder._okButton,Event.TRIGGERED);
         §_-jg§(this.binder._cancelButton,Event.TRIGGERED);
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(§_-dU§.§_-h26§))
         {
            this.binder._panel.title = §_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION);
            this.binder._description.text = §_-s2a§.§_-K3t§(§_-s2a§.NOTE_BALLS_ATTENTION);
            this.binder._okButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_BALLS);
            this.binder._cancelButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_ARENA);
         }
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         switch(param1.currentTarget)
         {
            case this.binder._okButton:
               dispatchEventWith(Event.SELECT);
               break;
            case this.binder._cancelButton:
               dispatchEventWith(Event.CANCEL);
         }
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.Panel;

class Binder
{
   
   public var _panel:Panel;
   
   public var _description:Label;
   
   public var _okButton:Button;
   
   public var _cancelButton:Button;
   
   public function Binder()
   {
      super();
   }
}

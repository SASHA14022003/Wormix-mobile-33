package §_-DJ§
{
   import §_-12a§.§_-41b§;
   import §_-62§.§_-O2H§;
   import §_-B1y§.§_-bs§;
   import §_-Ly§.§_-81L§;
   import §_-Vg§.ClanCreateView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-nE§.§_-p16§;
   import §_-w2W§.AchieveRoomScreenDesktop;
   import §_-w2W§.ArmoryScreenDesktop;
   import §_-w2W§.CraftRoomScreenDesktop;
   import §_-w2W§.DesktopRaceRoomScreen;
   import §_-w2W§.MainMenuScreenDesktop;
   import §_-w2W§.TeamRoomScreenDesktop;
   import §_-w2W§.WardrobeRoomScreen;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-72M§;
   import §_-w2W§.§_-HV§;
   import §_-w2W§.§_-I2R§;
   import §_-w2W§.§_-I3c§;
   import §_-w2W§.§_-h1Z§;
   import §_-y1s§.*;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-F3q§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import config.§_-V2w§;
   import feathers.core.ITextRenderer;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.net.URLRequest;
   import flash.net.URLRequestHeader;
   import flash.net.URLRequestMethod;
   import flash.net.navigateToURL;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.gui.controls.§_-a1t§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-41p§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-G2k§ extends §_-fH§
   {
      
      private static var msg:§_-G2k§;
      
      public function §_-G2k§(param1:String, param2:String, param3:Function = null)
      {
         super(param1,param2,§_-fH§.§_-1B§,param3,§_-81L§.§_-q2C§);
         var _loc4_:starling.display.DisplayObject = getChildByName("msg");
         _loc4_.touchable = true;
         var _loc5_:TapToTrigger = new TapToTrigger(_loc4_);
         _loc4_.addEventListener(starling.events.Event.TRIGGERED,this.§_-x5§);
         outsideClosable = false;
      }
      
      public static function show(param1:String, param2:String, param3:int, param4:Function = null) : void
      {
         if(Boolean(msg) && msg.§_-h1C§())
         {
            msg.hide();
         }
         msg = new §_-G2k§(param1,param2 + " " + param3.toString(),param4);
         msg.show();
      }
      
      private function §_-x5§(param1:starling.events.Event) : void
      {
         navigateToURL(new URLRequest("mailto:" + §_-41p§.§_-y2B§()));
      }
      
      override public function §_-X2O§() : void
      {
      }
   }
}


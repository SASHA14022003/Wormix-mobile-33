package §_-DJ§
{
   import §_-31W§.§_-Kb§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-CF§.§_-E19§;
   import §_-G3w§.GlobalRatingScreen;
   import §_-G3w§.TodayRatingScreen;
   import §_-G3w§.TopClanRatingScreen;
   import §_-G3w§.YesterdayRatingScreen;
   import §_-N8§.*;
   import §_-P2i§.§_-b7§;
   import §_-YF§.§_-q2v§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-m2§;
   import §_-m1g§.§_-N1y§;
   import §_-r1C§.§_-t1R§;
   import §_-s20§.§_-J2g§;
   import §_-y1s§.§_-P9§;
   import §_-z1g§.§_-F4§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.display.ContentDisplay;
   import feathers.controls.Button;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.TiledColumnsLayout;
   import feathers.utils.touch.TapToTrigger;
   import flash.events.Event;
   import flash.media.Sound;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.IncomingPayment;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.AssetManager;
   
   public class ClanFireWindow extends §_-73y§
   {
      
      private var binder:Binder = new Binder();
      
      private var §_-ZO§:UserProfile;
      
      private var §_-71B§:int;
      
      private var §_-sr§:int;
      
      private var §_-a1T§:Function;
      
      public function ClanFireWindow(param1:UserProfile, param2:int, param3:int, param4:Function)
      {
         this.§_-ZO§ = param1;
         this.§_-71B§ = param2;
         this.§_-sr§ = param3;
         this.§_-a1T§ = param4;
         var _loc5_:Object = Application.assetManager.getObject("clan_fire_dialog");
         Application.uiBuilder.create(_loc5_,true,this.binder);
         super(this.binder._container);
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-H1o§.name = "panel.controls.cancel";
         §_-H1o§.stringId = §_-s2a§.BUTTON_CANCEL;
         §_-rP§.name = "panel.controls.ok";
         §_-rP§.text = "";
      }
      
      override protected function §_-q2a§() : void
      {
         super.§_-q2a§();
         this.binder._container.title = §_-s2a§.§_-K3t§(§_-s2a§.CONTEXT_MENU_FIRE_FROM_CLAN);
         this.binder._description.text = this.§_-ZO§.getCharName();
         this.binder._paymentDesc.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_MATE_FIRE_RETURN_PAY);
         this.binder._medalsDesc.text = §_-s2a§.§_-K3t§(§_-s2a§.CLAN_MATE_FIRE_MEDALS_COST);
         this.binder._paymentValue.text = this.§_-71B§.toString();
         this.binder._medalsValue.text = this.§_-sr§.toString();
         §_-e1Q§((this.§_-71B§ + this.§_-sr§).toString());
      }
      
      override protected function §_-b1H§() : void
      {
         super.§_-b1H§();
         this.§_-a1T§();
      }
   }
}

import feathers.controls.Label;
import feathers.controls.Panel;

class Binder
{
   
   public var _container:Panel;
   
   public var _description:Label;
   
   public var _paymentDesc:Label;
   
   public var _paymentValue:Label;
   
   public var _medalsDesc:Label;
   
   public var _medalsValue:Label;
   
   public function Binder()
   {
      super();
   }
}

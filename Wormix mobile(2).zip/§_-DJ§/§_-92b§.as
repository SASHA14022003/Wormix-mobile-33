package §_-DJ§
{
   import §_-21p§.§_-4w§;
   import §_-31Y§.§_-D3B§;
   import §_-5P§.*;
   import §_-62§.§_-L1r§;
   import §_-C2t§.§_-wL§;
   import §_-CF§.§_-E19§;
   import §_-K35§.§_-p1m§;
   import §_-L1H§.§_-b2K§;
   import §_-P1z§.*;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.*;
   import §_-Vu§.MD5;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.§_-q2v§;
   import §_-j1w§.§_-L1x§;
   import §_-k2s§.§_-e1U§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import config.§_-vR§;
   import feathers.controls.NumericStepper;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.IListCollection;
   import flash.geom.Point;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.MobileLogin;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Girder;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   
   public class §_-92b§ extends DefaultListItemRenderer
   {
      
      private const §_-M1P§:String = "count";
      
      private const §_-91E§:String = "moneyIcon";
      
      private const §_-71§:String = "plus";
      
      private const §_-S1y§:String = "equals";
      
      public function §_-92b§()
      {
         super();
      }
      
      override protected function commitData() : void
      {
         var _loc1_:Sprite = null;
         if(!_data)
         {
            return;
         }
         removeChildren(0,-1,true);
         _loc1_ = §_-YQ§.§_-qM§(this.§_-v1y§(_index,_data.moneyType),§_-q2v§.§_-A2T§);
         var _loc2_:ITextRenderer = _loc1_.getChildByName(this.§_-M1P§) as ITextRenderer;
         _loc2_.text = _data.value;
         this.§_-B§(_loc1_);
         addChild(_loc1_);
         width = _loc1_.width;
         height = _loc1_.height;
      }
      
      private function §_-B§(param1:Sprite) : void
      {
         var _loc3_:DisplayObject = null;
         var _loc4_:DisplayObject = null;
         var _loc2_:int = owner.dataProvider.length;
         if(_loc2_ > 1 && _index < _loc2_ - 1)
         {
            _loc3_ = param1.getChildByName(this.§_-71§);
            _loc4_ = param1.getChildByName(this.§_-S1y§);
            _loc3_.visible = _index < _loc2_ - 2;
            _loc4_.visible = _index == _loc2_ - 2;
            §_-YQ§.§_-42Z§(_data.moneyType,param1.getChildByName(this.§_-91E§) as Image);
         }
      }
      
      private function §_-v1y§(param1:int, param2:§_-E19§) : String
      {
         return param1 < owner.dataProvider.length - 1 ? §_-q2v§.§_-Bz§ : (param2 == §_-E19§.§_-51D§ ? §_-q2v§.§_-s23§ : §_-q2v§.§_-wZ§);
      }
   }
}


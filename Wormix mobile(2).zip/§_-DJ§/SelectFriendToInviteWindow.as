package §_-DJ§
{
   import §_-03T§.§_-K3B§;
   import §_-43V§.*;
   import §_-62§.§_-W1r§;
   import §_-A2U§.§_-A23§;
   import §_-B2z§.§_-63i§;
   import §_-TF§.§_-13z§;
   import §_-TF§.§_-b2D§;
   import §_-Y1O§.*;
   import §_-YF§.§_-q2v§;
   import §_-bI§.*;
   import §_-fo§.§_-r5§;
   import §_-j22§.§_-5g§;
   import §_-jF§.§_-O2b§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.util.§_-a2P§;
   import feathers.controls.List;
   import feathers.controls.ScrollBarDisplayMode;
   import feathers.controls.TextInput;
   import feathers.data.ListCollection;
   import feathers.events.CollectionEventType;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalLayout;
   import flash.display.*;
   import flash.events.*;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.*;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.flox.social.controller.ICustomInviter;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.clans.response.ListClansResponse;
   import ru.pragmatix.wormix.messages.clans.response.treasury.DonateClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.messages.client.AssembleStuff;
   import ru.pragmatix.wormix.messages.server.AddToGroupResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.VilePumpkin;
   import starling.core.Starling;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   
   public class SelectFriendToInviteWindow extends §_-73y§
   {
      
      private var §_-F1L§:List;
      
      private var §_-a2V§:TextInput;
      
      public function SelectFriendToInviteWindow()
      {
         var _loc1_:DisplayObjectContainer = §_-YQ§.§_-qM§(§_-q2v§.SELECT_FRIEND_TO_INVITE,§_-q2v§.§_-A2T§);
         super(_loc1_.getChildByName("panel") as DisplayObjectContainer);
         this.§_-F1L§ = new List();
         var _loc2_:VerticalLayout = new VerticalLayout();
         _loc2_.gap = 5;
         this.§_-F1L§.layout = _loc2_;
         this.§_-F1L§.itemRendererType = §_-O2b§;
         var _loc3_:DisplayObjectContainer = getChildByName("friendsPanel") as DisplayObjectContainer;
         this.§_-F1L§.width = _loc3_.width;
         this.§_-F1L§.height = _loc3_.height;
         _loc3_.addChild(this.§_-F1L§);
         this.§_-F1L§.addEventListener(Event.TRIGGERED,this.§_-j2T§);
         this.§_-F1L§.verticalScrollBarFactory = §_-eP§.§_-M1B§;
         this.§_-F1L§.scrollBarDisplayMode = ScrollBarDisplayMode.FIXED_FLOAT;
         this.§_-a2V§ = §_-YQ§.getClip("searchField.text",§_-j2l§()) as TextInput;
         this.§_-a2V§.prompt = §_-s2a§.§_-K3t§(§_-s2a§.INPUT_NAME);
         this.§_-a2V§.addEventListener(Event.CHANGE,this.§_-m1Z§);
         this.§_-a2V§.touchable = true;
         §_-YQ§.getClip("searchField",§_-j2l§()).touchable = true;
      }
      
      private function §_-m1Z§(param1:Event) : void
      {
         var _loc3_:String = null;
         var _loc5_:SocialUserData = null;
         var _loc2_:String = (param1.target as TextInput).text.toLowerCase();
         var _loc4_:ListCollection = new ListCollection();
         for each(_loc5_ in data)
         {
            _loc3_ = _loc5_.getFirstName().toLowerCase() + " " + _loc5_.getLastName().toLowerCase();
            if(_loc3_.search(_loc2_) > -1)
            {
               _loc4_.addItem(_loc5_);
            }
         }
         this.§_-F1L§.dataProvider = _loc4_;
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-v1w§.stringId = §_-s2a§.SELECT_FRIEND_TO_INVITE;
         §_-H1o§.name = "buttons.cancel";
         §_-H1o§.stringId = §_-s2a§.BUTTON_CANCEL;
      }
      
      private function §_-j2T§(param1:Event) : void
      {
         var _loc2_:SocialUserData = param1.data as SocialUserData;
         if(_loc2_)
         {
            §_-h2B§.play(§_-d27§.§_-S29§);
            (§_-X1j§.socialController as ICustomInviter).inviteFriend(_loc2_.getSocialId(),§_-s2a§.§_-K3t§(§_-s2a§.INVITE_FRIENDS_TEXT),null,this.§_-cx§);
         }
      }
      
      private function §_-cx§(param1:Object) : void
      {
         if((param1 as SocialResponse).success == false)
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_SOCIAL));
         }
      }
      
      override public function set data(param1:Object) : void
      {
         var _loc3_:SocialUserData = null;
         super.data = param1;
         data.sort(this.compareFunction);
         var _loc2_:ListCollection = new ListCollection();
         for each(_loc3_ in data)
         {
            _loc2_.addItem(_loc3_);
         }
         this.§_-F1L§.dataProvider = _loc2_;
      }
      
      private function compareFunction(param1:SocialUserData, param2:SocialUserData) : int
      {
         var _loc3_:String = param1.getFirstName() + param1.getLastName();
         var _loc4_:String = param2.getFirstName() + param2.getLastName();
         return _loc3_ > _loc4_ ? 1 : -1;
      }
      
      override public function dispose() : void
      {
         this.§_-F1L§.removeEventListener(Event.TRIGGERED,this.§_-j2T§);
         this.§_-a2V§.removeEventListener(Event.CHANGE,this.§_-m1Z§);
         super.dispose();
      }
   }
}


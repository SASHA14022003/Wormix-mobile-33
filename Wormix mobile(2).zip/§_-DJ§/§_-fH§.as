package §_-DJ§
{
   import §_-21p§.§_-4w§;
   import §_-63U§.SafetyArea;
   import §_-73d§.§_-g1J§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-G16§.*;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-Ly§.§_-7f§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-SP§.§_-M4§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-U16§;
   import §_-Y1O§.§_-V23§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.*;
   import §_-dS§.§_-D3a§;
   import §_-j22§.§_-5g§;
   import §_-jF§.MainMenuTeamMemberRenderer;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-sQ§.§_-V1n§;
   import com.hurlant.math.BigInteger;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import feathers.data.ArrayCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import feathers.utils.textures.TextureCache;
   import flash.events.Event;
   import flash.events.MouseEvent;
   import flash.geom.Rectangle;
   import flash.text.TextFormat;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getTimer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.response.edit.IncreaseLevelClanResponse;
   import ru.pragmatix.wormix.messages.client.EndBattle;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.text.TextField;
   import starling.text.TextFieldAutoSize;
   import starling.textures.Texture;
   
   public class §_-fH§ extends §_-73y§
   {
      
      public static const §_-1B§:int = 0;
      
      public static const §_-X2g§:int = 1;
      
      public static const §_-L2I§:int = 2;
      
      public static const §_-H2d§:int = 3;
      
      private var §_-m2v§:ITextRenderer;
      
      private var callback:Function;
      
      public var §_-t1D§:Boolean = true;
      
      public function §_-fH§(param1:String, param2:String, param3:int, param4:Function = null, param5:§_-t1R§ = null, param6:String = null, param7:Boolean = true)
      {
         var _loc9_:String = null;
         var _loc8_:Sprite = §_-YQ§.§_-qM§(param6 || §_-81L§.§_-I3X§);
         super(_loc8_.getChildAt(0) as FeathersControl);
         this.§_-t1D§ = param7;
         this.§_-v1w§.text = param1;
         if(§_-C1H§)
         {
            §_-C1H§.text = §_-v1w§.text;
         }
         this.§_-m2v§ = getChildByName("msg") as ITextRenderer;
         §_-R2g§.§_-1c§(this.§_-m2v§,TextFormatAlign.CENTER);
         §_-R2g§.§_-k2g§(this.§_-m2v§,true);
         this.§_-m2v§.text = param2;
         this.callback = param4;
         if(okBtn)
         {
            if(param3 != §_-L2I§)
            {
               _loc9_ = §_-s2a§.§_-K3t§(param3 == §_-H2d§ ? §_-7f§.BUTTON_YES : §_-7f§.BUTTON_OK);
               (okBtn as Button).label = _loc9_;
               §_-rP§.text = _loc9_;
            }
            else
            {
               okBtn.removeFromParent(true);
            }
         }
         if(§_-51P§)
         {
            if(param3 == §_-X2g§ || param3 == §_-H2d§)
            {
               _loc9_ = §_-s2a§.§_-K3t§(§_-7f§.BUTTON_CANCEL);
               (§_-51P§ as Button).label = _loc9_;
               §_-H1o§.text = _loc9_;
            }
            else
            {
               §_-51P§.removeFromParent(true);
            }
         }
         this.soundOnShow = param5;
      }
      
      public static function §_-R2V§(param1:String, param2:String, param3:int = 0, param4:Function = null, param5:Function = null) : void
      {
         §_-F3p§(§_-s2a§.§_-K3t§(param1),§_-s2a§.§_-K3t§(param2),param3,param4,param5).show();
      }
      
      public static function §_-q1a§(param1:String, param2:String, param3:int = 0, param4:Function = null, param5:Function = null) : void
      {
         §_-F3p§(param1,param2,param3,param4,param5).show();
      }
      
      public static function §_-N2W§(param1:String, param2:String, param3:String, param4:int = 0, param5:Function = null, param6:Function = null) : void
      {
         §_-f2c§(param1,param2,param3,param4,param5,param6).show();
      }
      
      public static function §_-F3p§(param1:String, param2:String, param3:int = 0, param4:Function = null, param5:Function = null) : §_-fH§
      {
         return §_-f2c§(null,param1,param2,param3,param4,param5);
      }
      
      public static function §_-Zy§(param1:String, param2:String, param3:int = 0, param4:Boolean = true, param5:Function = null, param6:Function = null, param7:Function = null) : void
      {
         var windowCancelListener:Function = null;
         var windowCloseListener:Function = null;
         var title:String = param1;
         var msg:String = param2;
         var buttons:int = param3;
         var outsideClosable:Boolean = param4;
         var onOkClick:Function = param5;
         var onCancelClick:Function = param6;
         var onWindowClose:Function = param7;
         var window:§_-fH§ = new §_-fH§(title,msg,buttons,onOkClick,§_-81L§.§_-q2C§,null,true);
         if(onCancelClick != null)
         {
            windowCancelListener = function(param1:starling.events.Event):void
            {
               onCancelClick();
            };
            window.addEventListener(§_-M4§.WINDOW_CANCEL,windowCancelListener);
         }
         if(onWindowClose != null)
         {
            windowCloseListener = function(param1:starling.events.Event):void
            {
               onWindowClose();
            };
            window.addEventListener(§_-M4§.WINDOW_CLOSE,windowCloseListener);
         }
         window.outsideClosable = outsideClosable;
         window.show();
      }
      
      public static function §_-f2c§(param1:String, param2:String, param3:String, param4:int = 0, param5:Function = null, param6:Function = null) : §_-fH§
      {
         var panelClassName:String = param1;
         var title:String = param2;
         var msg:String = param3;
         var buttons:int = param4;
         var onOkClick:Function = param5;
         var onCancelClick:Function = param6;
         var window:§_-fH§ = new §_-fH§(title,msg,buttons,onOkClick,§_-81L§.§_-q2C§,panelClassName,true);
         if(onCancelClick != null)
         {
            window.addEventListener(§_-M4§.WINDOW_CANCEL,function(param1:starling.events.Event):void
            {
               onCancelClick();
            });
         }
         return window;
      }
      
      public static function §_-42r§(param1:Object) : void
      {
         §_-q1a§("DEBUG",param1.toString());
      }
      
      public static function §_-dn§(param1:String = "") : void
      {
         §_-q1a§("TODO",param1);
      }
      
      public static function §_-k1O§(param1:String, param2:String, param3:int = 0, param4:Function = null) : §_-fH§
      {
         return new §_-fH§(param1,param2,param3,param4,§_-81L§.§_-WH§);
      }
      
      public static function §_-h2r§(param1:String, param2:String, param3:int = 0, param4:Function = null) : void
      {
         var _loc5_:§_-fH§ = §_-k1O§(param1,param2,param3,param4);
         _loc5_.outsideClosable = false;
         _loc5_.show();
      }
      
      public static function §_-V2L§(param1:String, param2:String, param3:int = 0, param4:Function = null, param5:Function = null, param6:Function = null) : void
      {
         var windowCancelListener:Function = null;
         var windowCloseListener:Function = null;
         var title:String = param1;
         var msg:String = param2;
         var buttons:int = param3;
         var onOkClick:Function = param4;
         var onCancelClick:Function = param5;
         var onWindowClose:Function = param6;
         var window:§_-fH§ = new §_-fH§(title,msg,buttons,onOkClick,§_-81L§.§_-WH§,null,true);
         if(onCancelClick != null)
         {
            windowCancelListener = function(param1:starling.events.Event):void
            {
               onCancelClick();
            };
            window.addEventListener(§_-M4§.WINDOW_CANCEL,windowCancelListener);
         }
         if(onWindowClose != null)
         {
            windowCloseListener = function(param1:starling.events.Event):void
            {
               onWindowClose();
            };
            window.addEventListener(§_-M4§.WINDOW_CLOSE,windowCloseListener);
         }
         window.outsideClosable = false;
         window.show();
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         this.§_-rP§.name = "buttonsLayout.ok";
         this.§_-H1o§.name = "buttonsLayout.cancel";
         destroyOnRemove = true;
      }
      
      override protected function §_-b1H§() : void
      {
         if(this.callback != null)
         {
            this.callback();
         }
         super.§_-b1H§();
      }
      
      override public function dispose() : void
      {
         this.§_-m2v§ = null;
         this.callback = null;
         super.dispose();
      }
   }
}


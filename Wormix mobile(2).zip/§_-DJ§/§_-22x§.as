package §_-DJ§
{
   import §_-62§.*;
   import §_-82a§.*;
   import §_-9§.§_-52A§;
   import §_-931§.§_-i2r§;
   import §_-B1y§.*;
   import §_-K35§.§_-p1m§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-SP§.§_-M4§;
   import §_-YF§.§_-q2v§;
   import §_-j1w§.§_-lD§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-z1g§.*;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.PopUpManager;
   import feathers.events.FeathersEventType;
   import feathers.utils.touch.TapToTrigger;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.server.PumpReactionRatesResult;
   import ru.pragmatix.wormix.messages.structures.PumpReactionRateStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.scene.tile.TileData;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.InvisibleGuardingBot;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-22x§
   {
      
      private static var §_-LS§:Number = §_-81L§.§_-a1e§;
      
      private static var §_-030§:Vector.<§_-K3O§> = new Vector.<§_-K3O§>(0);
      
      public function §_-22x§()
      {
         super();
      }
      
      public static function §_-L2X§(param1:§_-K3O§) : void
      {
         var _loc3_:DisplayObject = null;
         var _loc2_:int = int(§_-030§.indexOf(param1));
         if(_loc2_ == -1)
         {
            _loc3_ = param1 as DisplayObject;
            _loc3_.addEventListener(§_-M4§.WINDOW_SHOW,§_-D3u§);
            _loc3_.addEventListener(§_-M4§.WINDOW_CLOSE,§_-R2L§);
            §_-030§.push(param1);
         }
      }
      
      private static function §_-D3u§(param1:starling.events.Event) : void
      {
         var window:§_-K3O§ = null;
         var display:DisplayObject = null;
         var e:starling.events.Event = param1;
         var index:int = int(§_-030§.indexOf(e.currentTarget as §_-K3O§));
         if(index > -1)
         {
            window = §_-030§[index];
            display = window as DisplayObject;
            PopUpManager.addPopUp(display,true,true,function():DisplayObject
            {
               var quad:Quad = new Quad(Application.§_-i1N§.stageWidth,Application.§_-i1N§.stageHeight,§_-81L§.§_-YC§);
               quad.alpha = §_-LS§;
               new TapToTrigger(quad);
               quad.addEventListener(starling.events.Event.TRIGGERED,function(param1:starling.events.Event):void
               {
                  window.hide();
               });
               return quad;
            });
            if(window is §_-T22§)
            {
               §_-T2G§.§_-F1w§(window as §_-T22§);
            }
            if(window.soundOnShow)
            {
               §_-h2B§.play(window.soundOnShow);
            }
         }
      }
      
      private static function §_-R2L§(param1:starling.events.Event) : void
      {
         var _loc3_:§_-K3O§ = null;
         var _loc4_:DisplayObject = null;
         var _loc2_:int = int(§_-030§.indexOf(param1.currentTarget as §_-K3O§));
         if(_loc2_ > -1)
         {
            _loc3_ = §_-030§[_loc2_];
            _loc4_ = _loc3_ as DisplayObject;
            PopUpManager.removePopUp(_loc4_);
            §_-030§.removeAt(_loc2_);
            if(_loc3_ is §_-T22§)
            {
               §_-T2G§.§_-53B§(_loc3_ as §_-T22§);
            }
            if(_loc3_.soundOnHide)
            {
               §_-h2B§.play(_loc3_.soundOnHide);
            }
         }
      }
   }
}


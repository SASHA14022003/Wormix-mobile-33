package §_-DJ§
{
   import flash.display.BitmapData;
   
   public interface §_-j15§
   {
      
      function hide() : void;
      
      function destroy() : void;
      
      function §_-h1C§() : Boolean;
      
      function §_-d2s§(param1:BitmapData) : void;
      
      function show(param1:Boolean = true) : void;
   }
}


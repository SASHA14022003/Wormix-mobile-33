package §_-DJ§
{
   import §_-12a§.§_-6p§;
   import §_-21A§.§_-A2x§;
   import §_-21p§.§_-4w§;
   import §_-43V§.*;
   import §_-62§.§_-O2H§;
   import §_-9§.§_-52A§;
   import §_-A1K§.§_-7u§;
   import §_-B1y§.§_-bs§;
   import §_-Bv§.§_-G3P§;
   import §_-C2t§.§_-92W§;
   import §_-C2t§.§_-Ui§;
   import §_-D3A§.§_-TZ§;
   import §_-H2g§.§_-di§;
   import §_-J31§.§_-R1h§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-r2q§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1w§.§_-s1x§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-k1u§.§_-Vr§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-nE§.SelectCraftWeaponScreen;
   import §_-r1C§.§_-h2B§;
   import §_-u13§.MAC;
   import §_-u13§.MD2;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u13§.§_-F3§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.hurlant.crypto.*;
   import com.hurlant.util.der.Sequence;
   import com.hurlant.util.der.§_-cz§;
   import com.hurlant.util.der.§_-l1b§;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayoutData;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.getQualifiedClassName;
   import org.swiftsuspenders.§_-71M§;
   import org.swiftsuspenders.§_-T1p§;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class BossBattleOfferDialog extends BattleOfferDialog
   {
      
      private static const §_-J1J§:String = "avatar";
      
      private var profile:UserProfile;
      
      private var §_-53Q§:§_-di§;
      
      private var §_-m1D§:§_-di§;
      
      private var binder:Binder = new Binder();
      
      private var battlesCount:int;
      
      public function BossBattleOfferDialog()
      {
         super(§_-YQ§.§_-qM§(§_-q2v§.§_-Hh§,§_-q2v§.§_-A2T§,this.binder).getChildAt(0) as Sprite);
         §_-X1j§.§_-A24§.§_-I3T§(this.§_-m1h§,null,this.§_-m1h§);
         this.battlesCount = -1;
         (this.binder._line.layoutData as AnchorLayoutData).topAnchorDisplayObject = this.binder._bossName as FeathersControl;
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-rP§.name = "buttonsPanel.ok";
         §_-rP§.stringId = §_-s2a§.BOSS_PLAY_BTN;
         §_-H1o§.name = "buttonsPanel.cancel";
      }
      
      override public function §_-82v§(param1:UserProfile) : void
      {
         var _loc3_:SocialUserData = null;
         this.profile = param1;
         var _loc2_:String = "";
         if(param1 != null)
         {
            _loc3_ = param1.getSocialData();
            _loc2_ = _loc3_ ? _loc3_.getFirstName() + (_loc3_.getLastName() ? " " + _loc3_.getLastName() : "") : param1.getCharName();
         }
         this.binder._callerName.text = _loc2_;
      }
      
      public function §_-8A§(param1:int, param2:int = -1) : void
      {
         var _loc4_:§_-D2p§ = null;
         var _loc5_:§_-D2p§ = null;
         var _loc6_:§_-D2p§ = null;
         var _loc3_:Boolean = param2 != -1;
         this.binder._callDescr.text = §_-s2a§.§_-K3t§(_loc3_ ? §_-s2a§.SUPER_BOSS_BATTLE_OFFER_TITLE : §_-s2a§.BOSS_BATTLE_OFFER_TITLE);
         if(_loc3_)
         {
            _loc4_ = §_-N1V§.§_-I39§.§_-X1P§().§_-7k§(param1);
            _loc5_ = §_-N1V§.§_-I39§.§_-X1P§().§_-7k§(param2);
            this.binder._bossName.text = §_-s2a§.§_-K3t§(_loc5_.getName()) + " + " + §_-s2a§.§_-K3t§(_loc4_.getName());
            this.§_-53Q§ = §_-A2x§.§_-5d§(this.binder._superBossPanel.getChildByName(§_-J1J§ + "1") as DisplayObjectContainer,_loc5_,this.§_-53Q§);
            this.§_-m1D§ = §_-A2x§.§_-5d§(this.binder._superBossPanel.getChildByName(§_-J1J§ + "2") as DisplayObjectContainer,_loc4_,this.§_-m1D§);
         }
         else
         {
            _loc6_ = §_-r2q§.§_-Un§(param1) as §_-D2p§;
            this.binder._bossName.text = §_-s2a§.§_-K3t§(_loc6_.getName());
            if(this.§_-m1D§)
            {
               this.§_-m1D§.dispose();
            }
            this.§_-m1D§ = null;
            this.§_-53Q§ = §_-A2x§.§_-5d§(this.binder._coopBossPanel.getChildByName(§_-J1J§) as DisplayObjectContainer,_loc6_,this.§_-53Q§);
         }
         this.§_-O2y§();
         if(_loc3_)
         {
            this.binder._coopBossPanel.removeFromParent();
         }
         else
         {
            this.binder._superBossPanel.removeFromParent();
         }
         this.§_-Vl§(true);
      }
      
      private function §_-m1h§() : void
      {
         this.§_-Vl§();
      }
      
      public function §_-Vl§(param1:Boolean = false) : void
      {
         if(param1 && §_-X1j§.§_-B35§.§_-w1n§() <= 0)
         {
            return;
         }
         this.binder._battlesText.text = §_-s2a§.§_-K3t§(§_-s2a§.BATTLES_AVAILABLE);
         this.battlesCount = §_-X1j§.§_-B35§.§_-w1n§();
         this.binder._battlesValue.text = this.battlesCount.toString();
      }
      
      override public function advanceTime(param1:Number) : void
      {
         if(!§_-X1j§.§_-12n§.isReady() || this.battlesCount == 0)
         {
            §_-pQ§();
            return;
         }
         §_-l2B§();
      }
      
      override public function dispose() : void
      {
         if(this.§_-53Q§)
         {
            this.§_-53Q§.dispose();
         }
         this.§_-53Q§ = null;
         if(this.§_-m1D§)
         {
            this.§_-m1D§.dispose();
         }
         this.§_-m1D§ = null;
         super.dispose();
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.LayoutGroup;
import feathers.core.ITextRenderer;

class Binder
{
   
   public var _coopBossPanel:LayoutGroup;
   
   public var _superBossPanel:LayoutGroup;
   
   public var _callerName:ITextRenderer;
   
   public var _callDescr:ITextRenderer;
   
   public var _bossName:ITextRenderer;
   
   public var _battlesText:ITextRenderer;
   
   public var _battlesValue:ITextRenderer;
   
   public var _line:ImageLoader;
   
   public function Binder()
   {
      super();
   }
}

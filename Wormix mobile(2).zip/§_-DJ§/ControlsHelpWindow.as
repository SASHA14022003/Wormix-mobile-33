package §_-DJ§
{
   import §_-12a§.§_-41b§;
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-62§.§_-F1D§;
   import §_-63U§.§_-NV§;
   import §_-73I§.§_-Z2e§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-Ui§;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-L1O§;
   import §_-T1t§.§_-u19§;
   import §_-V1H§.§_-m1d§;
   import §_-Y23§.*;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-gG§.§_-5R§;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.AttackDodgedEvent;
   import §_-j1w§.§_-L1x§;
   import §_-j2R§.*;
   import §_-l1K§.§_-cZ§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-V1R§;
   import §_-s1Q§.Artifacts;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-z20§.*;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ToggleButton;
   import feathers.events.FeathersEventType;
   import feathers.layout.Direction;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.*;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.particle.ParticleEffect;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.social.§_-L23§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class ControlsHelpWindow extends §_-73y§
   {
      
      private var binder:Binder = new Binder();
      
      private var armatures:Vector.<§_-di§>;
      
      private var §_-m2S§:Vector.<ParticleEffect>;
      
      public function ControlsHelpWindow()
      {
         Application.uiBuilder.create(Application.assetManager.getObject("help_control"),true,this.binder);
         super(this.binder._container);
         this.§_-I8§();
         this.§_-57§();
         this.binder._close.addEventListener(Event.TRIGGERED,§_-03a§);
      }
      
      private function §_-I8§() : void
      {
         var _loc1_:String = "HELP_CONTROL_TITLE";
         var _loc2_:String = "HELP_CONTROL_DESCR";
         this.binder._title.text = §_-s2a§.§_-K3t§(§_-s2a§.CONTROL_TITLE);
         this.binder._moveTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 1);
         this.binder._moveText.text = §_-s2a§.§_-K3t§(_loc2_ + 1);
         this.binder._jumpTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 2);
         this.binder._jumpText.text = §_-s2a§.§_-K3t§(_loc2_ + 2);
         this.binder._bjumpTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 3);
         this.binder._bjumpText.text = §_-s2a§.§_-K3t§(_loc2_ + 3);
         this.binder._bagTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 4);
         this.binder._bagText.text = §_-s2a§.§_-K3t§(_loc2_ + 4);
         this.binder._aimTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 5);
         this.binder._aimText.text = §_-s2a§.§_-K3t§(_loc2_ + 5);
         this.binder._powerTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 6);
         this.binder._powerText.text = §_-s2a§.§_-K3t§(_loc2_ + 6);
         this.binder._shiftTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 7);
         this.binder._shiftText.text = §_-s2a§.§_-K3t§(_loc2_ + 7);
         this.binder._useHatTitle.text = §_-s2a§.§_-K3t§(_loc1_ + 8);
         this.binder._useHatText.text = §_-s2a§.§_-K3t§(_loc2_ + 8);
         this.§_-o1r§(this.binder._stateList);
      }
      
      private function §_-o1r§(param1:LayoutGroup) : void
      {
         var _loc2_:DisplayObjectContainer = null;
         var _loc3_:Label = null;
         var _loc4_:Label = null;
         var _loc5_:DisplayObjectContainer = null;
         var _loc7_:§_-di§ = null;
         this.armatures = new Vector.<§_-di§>();
         this.§_-m2S§ = new Vector.<ParticleEffect>();
         var _loc6_:* = param1.numChildren;
         while(_loc6_--)
         {
            _loc5_ = param1.getChildAt(_loc6_) as DisplayObjectContainer;
            _loc2_ = _loc5_.getChildByName("icon") as DisplayObjectContainer;
            _loc3_ = _loc5_.getChildByName("title") as Label;
            _loc4_ = _loc5_.getChildByName("text") as Label;
            _loc7_ = §_-L1O§.§_-Yx§(UserProfile.custom("",1,§_-L1x§.§_-AU§,1,1,1),_loc2_);
            _loc7_.display.scale = 0.35;
            this.armatures.push(_loc7_);
            _loc3_.text = §_-s2a§.§_-K3t§("HELP_CONTROL_BUFF_TITLE" + _loc6_);
            _loc4_.text = §_-s2a§.§_-K3t§("HELP_CONTROL_BUFF_TEXT" + _loc6_);
            this.§_-Q1u§(_loc7_.display as DisplayObjectContainer,_loc6_);
         }
      }
      
      private function §_-Q1u§(param1:DisplayObjectContainer, param2:int) : void
      {
         var _loc3_:§_-di§ = null;
         var _loc4_:DisplayObject = null;
         var _loc5_:ParticleEffect = null;
         switch(param2)
         {
            case 0:
               §_-MN§.§_-F3D§(param1,§_-8u§.COLOR);
               break;
            case 1:
               §_-MN§.§_-F3D§(param1,§_-Z2z§.COLOR);
               _loc4_ = §_-Z2z§.§_-k1z§();
               _loc4_.scale /= param1.scale;
               _loc4_.rotation = Math.PI;
               param1.addChild(_loc4_);
               break;
            case 2:
               _loc3_ = §_-M2S§.createEffect();
               _loc3_.display.scale /= param1.scale;
               param1.addChild(_loc3_.display);
               this.armatures.push(_loc3_);
               break;
            case 3:
               _loc5_ = §_-5R§.createEffect();
               _loc5_.scale /= param1.scale;
               param1.addChild(_loc5_);
               this.§_-m2S§.push(_loc5_);
               break;
            case 4:
               _loc3_ = Effects.createAndPlayAnimationEffect("AntitoxinEffect");
               _loc3_.display.scale /= param1.scale;
               this.armatures.push(_loc3_);
               param1.addChild(_loc3_.display);
               break;
            case 5:
               _loc4_ = §_-Z2e§.§_-v2s§(§_-41b§.ATTACK);
               _loc4_.scale /= param1.scale;
               param1.addChild(_loc4_);
         }
      }
      
      private function §_-57§() : void
      {
         this.binder._close.defaultSkin = this.§_-43Z§("button_close_up");
         this.binder._close.downSkin = this.§_-43Z§("button_close_down");
      }
      
      private function §_-43Z§(param1:String) : DisplayObject
      {
         var _loc2_:DisplayObject = new Image(Application.assetManager.getTexture(param1));
         _loc2_.width = 56;
         _loc2_.height = 54;
         return _loc2_;
      }
      
      override public function hide() : void
      {
         var _loc1_:* = int(this.armatures.length);
         while(_loc1_--)
         {
            WorldClock.clock.remove(this.armatures[_loc1_]);
            this.armatures[_loc1_].dispose();
         }
         this.armatures = null;
         _loc1_ = int(this.§_-m2S§.length);
         while(_loc1_--)
         {
            Starling.juggler.remove(this.§_-m2S§[_loc1_]);
            this.§_-m2S§[_loc1_].dispose();
         }
         this.§_-m2S§ = null;
         this.binder = null;
         super.hide();
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _title:Label;
   
   public var _moveTitle:Label;
   
   public var _moveText:Label;
   
   public var _jumpTitle:Label;
   
   public var _jumpText:Label;
   
   public var _bjumpTitle:Label;
   
   public var _bjumpText:Label;
   
   public var _bagTitle:Label;
   
   public var _bagText:Label;
   
   public var _aimTitle:Label;
   
   public var _aimText:Label;
   
   public var _powerTitle:Label;
   
   public var _powerText:Label;
   
   public var _shiftTitle:Label;
   
   public var _shiftText:Label;
   
   public var _useHatTitle:Label;
   
   public var _useHatText:Label;
   
   public var _stateList:LayoutGroup;
   
   public var _close:Button;
   
   public function Binder()
   {
      super();
   }
}

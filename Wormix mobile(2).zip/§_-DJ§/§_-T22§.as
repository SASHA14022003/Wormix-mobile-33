package §_-DJ§
{
   public interface §_-T22§
   {
      
      function §_-X2O§() : void;
   }
}


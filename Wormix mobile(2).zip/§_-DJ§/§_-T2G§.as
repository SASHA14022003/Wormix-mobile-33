package §_-DJ§
{
   import §_-3D§.§_-E3x§;
   import §_-3D§.§_-a2b§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-a3§;
   import §_-73d§.§_-a2s§;
   import §_-82a§.§_-pp§;
   import §_-91A§.*;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-fM§;
   import §_-B2z§.§_-63i§;
   import §_-CR§.§_-72p§;
   import §_-D3A§.§_-TZ§;
   import §_-H3§.*;
   import §_-K35§.§_-99§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.*;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.§_-q2v§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-kP§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import com.greensock.*;
   import com.greensock.core.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.display.BitmapData;
   import flash.errors.IllegalOperationError;
   import flash.events.IEventDispatcher;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.CostStructure;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.§_-kQ§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   
   public class §_-T2G§
   {
      
      private static const §_-i1N§:§_-T2G§ = new §_-T2G§();
      
      private var §_-a2L§:Vector.<§_-T22§> = new Vector.<§_-T22§>(0);
      
      public function §_-T2G§()
      {
         super();
      }
      
      public static function §_-F1w§(param1:§_-T22§) : void
      {
         §_-i1N§.§_-a2L§.push(param1);
      }
      
      public static function §_-53B§(param1:§_-T22§) : void
      {
         §_-fM§.remove(§_-i1N§.§_-a2L§,param1);
      }
      
      public static function §_-D1y§() : Boolean
      {
         return §_-i1N§.§_-a2L§.length != 0;
      }
      
      public static function §_-wr§() : void
      {
         if(§_-D1y§())
         {
            §_-i1N§.§_-a2L§[§_-i1N§.§_-a2L§.length - 1].§_-X2O§();
         }
      }
      
      public static function §_-912§() : void
      {
         var _loc2_:* = undefined;
         var _loc1_:Vector.<§_-T22§> = new Vector.<§_-T22§>();
         §_-fM§.copy(§_-i1N§.§_-a2L§,_loc1_);
         for each(_loc2_ in _loc1_)
         {
            if(§_-i1N§.§_-a2L§.indexOf(_loc2_) != -1)
            {
               _loc2_.hide();
            }
         }
         §_-i1N§.§_-a2L§ = new Vector.<§_-T22§>(0);
      }
      
      public static function forEach(param1:Function, param2:Object) : void
      {
         var _loc4_:int = 0;
         var _loc5_:* = undefined;
         var _loc3_:Vector.<§_-T22§> = new Vector.<§_-T22§>();
         §_-fM§.copy(§_-i1N§.§_-a2L§,_loc3_);
         while(_loc4_ < _loc3_.length)
         {
            _loc5_ = _loc3_[_loc4_];
            if(§_-i1N§.§_-a2L§.indexOf(_loc5_) != -1)
            {
               param1.apply(param2,[_loc5_,_loc4_]);
            }
            _loc4_++;
         }
      }
      
      public static function §_-o1S§() : void
      {
         var _loc2_:* = undefined;
         var _loc1_:Vector.<§_-T22§> = new Vector.<§_-T22§>();
         §_-fM§.copy(§_-i1N§.§_-a2L§,_loc1_);
         for each(_loc2_ in _loc1_)
         {
            if(§_-i1N§.§_-a2L§.indexOf(_loc2_) != -1 && Boolean(_loc2_.outsideClosable))
            {
               _loc2_.hide();
            }
         }
      }
   }
}


package §_-DJ§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-73I§.§_-K2s§;
   import §_-91B§.§_-QK§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-H2g§.§_-di§;
   import §_-L2F§.*;
   import §_-P2i§.§_-b7§;
   import §_-RE§.§_-r2q§;
   import §_-SP§.§_-M4§;
   import §_-Tm§.§_-RF§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-aM§.*;
   import §_-e2r§.*;
   import §_-gG§.§_-Z8§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-o23§.§_-z2X§;
   import §_-r1C§.§_-h2B§;
   import §_-w2W§.§_-21w§;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.TiledColumnsLayout;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import ru.pragmatix.flox.gui.controls.*;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-D3E§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.gui.§_-K2Y§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.DailyBonusStructure;
   import ru.pragmatix.wormix.messages.structures.ProfileDoubleKeyStructure;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.messages.structures.UnitStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.structures.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-J2l§
   {
      
      private static var §_-B2a§:Timer;
      
      public static const §_-R25§:§_-K2Y§ = §_-J3x§(true,{
         "text":{"textId":§_-s2a§.SAVING},
         "descr":""
      });
      
      public static const §_-u2b§:§_-K2Y§ = §_-J3x§(true,{
         "text":{"textId":§_-s2a§.LOADING},
         "descr":""
      });
      
      public static const §_-D1H§:§_-K2Y§ = §_-J3x§(true,{
         "text":{"textId":§_-s2a§.LOADING},
         "descr":""
      });
      
      public static const §_-Z1M§:§_-K2Y§ = §_-J3x§(true,{
         "text":{"textId":§_-s2a§.CONNECTING},
         "descr":""
      });
      
      public static const §_-j28§:§_-K2Y§ = §_-J3x§(false,{"text":{"textId":§_-s2a§.WAITING_DATA}},false);
      
      public static const §_-Q2L§:§_-K2Y§ = §_-J3x§(false,{"text":{"textId":§_-s2a§.SWITCHING_TURN}},false);
      
      private static const §_-21J§:int = 10000;
      
      public static const §_-73c§:§_-K2Y§ = §_-J3x§(true,{"text":{
         "textId":§_-s2a§.LOADING,
         "descr":""
      }});
      
      public function §_-J2l§()
      {
         super();
      }
      
      public static function §_-J3x§(param1:Boolean, param2:Object, param3:Boolean = true) : §_-K2Y§
      {
         var _loc4_:Class = param1 ? §_-D3E§ : §_-K2Y§;
         var _loc5_:§_-K2Y§ = new _loc4_(param2);
         §_-B2a§ = new Timer(§_-21J§);
         §_-B2a§.addEventListener(TimerEvent.TIMER,§_-s2y§);
         _loc5_.addEventListener(§_-M4§.WINDOW_SHOW,§_-y2T§);
         _loc5_.addEventListener(§_-M4§.WINDOW_CLOSE,§_-XW§);
         _loc5_.touchable = param3;
         if(!param3)
         {
            _loc5_.alpha = 0.9;
         }
         return _loc5_;
      }
      
      public static function §_-e1L§(param1:String, param2:Function = null, ... rest) : void
      {
         rest.unshift(param2);
         rest.unshift(param1);
         var _loc4_:String = Application.§_-E1k§.activeScreenID;
         if(_loc4_ == §_-21w§.BATTLE_SCENE)
         {
            §_-73c§.§_-B2h§.apply(§_-73c§,rest);
         }
         else
         {
            §_-73c§.§_-91V§.apply(§_-73c§,rest);
         }
      }
      
      public static function §_-m1I§() : void
      {
         §_-73c§.hide();
      }
      
      public static function §_-p1u§() : void
      {
         §_-R25§.update();
         §_-u2b§.update();
         §_-j28§.update();
         §_-Q2L§.update();
         §_-73c§.update();
         §_-Z1M§.update();
      }
      
      public static function §_-C3D§() : void
      {
         §_-R25§.hide();
         §_-u2b§.hide();
         §_-j28§.hide();
         §_-Q2L§.hide();
         §_-73c§.hide();
      }
      
      private static function §_-y2T§(param1:Event) : void
      {
         §_-B2a§.start();
      }
      
      private static function §_-XW§(param1:Event) : void
      {
         §_-B2a§.stop();
         §_-B2a§ = null;
      }
      
      private static function §_-s2y§(param1:TimerEvent) : void
      {
         Application.§_-i1N§.§_-V6§();
      }
   }
}


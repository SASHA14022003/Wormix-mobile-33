package §_-DJ§
{
   import §_-03T§.§_-2p§;
   import §_-22z§.§_-f1b§;
   import §_-31W§.§_-r26§;
   import §_-51M§.Dragon;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-73I§.§_-Y1l§;
   import §_-82l§.§_-1I§;
   import §_-82l§.§_-A2Y§;
   import §_-A1K§.§_-7u§;
   import §_-B2z§.§_-63i§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-F39§.§_-Ey§;
   import §_-H3§.*;
   import §_-J3L§.§_-h1D§;
   import §_-Ly§.§_-81L§;
   import §_-OJ§.§_-sY§;
   import §_-T1t§.§_-u19§;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-hK§;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-s2Z§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-c2E§;
   import §_-d26§.§_-d1H§;
   import §_-d2p§.*;
   import §_-fo§.*;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-kP§.*;
   import §_-l1K§.§_-d2j§;
   import §_-lh§.§_-z2A§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-u13§.MAC;
   import §_-zI§.§_-X1q§;
   import com.hurlant.crypto.*;
   import feathers.controls.Button;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.net.Socket;
   import flash.net.URLRequest;
   import flash.net.navigateToURL;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.flox.social.response.photo.PhotoSaveResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-P4§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.§_-Qd§;
   import ru.pragmatix.wormix.social.utils.SocialUtils;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-Q1j§ extends §_-73y§ implements §_-j15§
   {
      
      private var uploadToAlbum:Button;
      
      private var §_-q1q§:Image;
      
      private var §_-B3a§:BitmapData;
      
      private var §_-K1x§:Rectangle;
      
      public function §_-Q1j§()
      {
         var _loc7_:Number = NaN;
         var _loc8_:Number = NaN;
         var _loc1_:DisplayObjectContainer = §_-YQ§.§_-qM§(§_-q2v§.§_-24§);
         super(_loc1_);
         var _loc2_:DisplayObject = getChildByName("photo");
         var _loc3_:Number = Application.§_-i1N§.stageWidth / Application.§_-i1N§.stageHeight;
         var _loc4_:Number = _loc2_.width / _loc2_.height;
         this.§_-A3N§(_loc3_);
         if(_loc4_ >= _loc3_)
         {
            _loc7_ = _loc2_.width - _loc2_.height * _loc3_;
            this.§_-K1x§ = Pool.getRectangle(_loc2_.x + _loc7_ / 2,_loc2_.y,_loc2_.height * _loc3_,_loc2_.height);
         }
         else
         {
            _loc8_ = _loc2_.height - _loc2_.width / _loc3_;
            this.§_-K1x§ = Pool.getRectangle(_loc2_.x,_loc2_.y + _loc8_ / 2,_loc2_.width,_loc2_.width / _loc3_);
         }
         var _loc5_:ITextRenderer = getChildByName("loading") as ITextRenderer;
         _loc5_.text = §_-s2a§.§_-K3t§(§_-s2a§.UPLOADING);
         this.§_-H3O§();
         var _loc6_:ITextRenderer = getChildByName("title") as ITextRenderer;
         _loc6_.text = §_-s2a§.§_-K3t§(§_-s2a§.PHOTO_MENU_TITLE);
         getChildByName("loading").visible = false;
         destroyOnRemove = true;
      }
      
      private function §_-A3N§(param1:Number) : void
      {
         var _loc2_:DisplayObject = getChildByName("overlay");
         var _loc3_:Number = _loc2_.width;
         _loc2_.width = _loc2_.height * param1;
         _loc2_.x += (_loc3_ - _loc2_.width) * 0.5;
      }
      
      private function §_-H3O§() : void
      {
         this.uploadToAlbum = getChildByName("uploadToAlbum") as Button;
         this.uploadToAlbum.labelFactory = function():ITextRenderer
         {
            return §_-R2g§.createTextRenderer(BitmapFonts.AD_LIB,20);
         };
         this.uploadToAlbum.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_PUBLISH);
         this.uploadToAlbum.addEventListener(starling.events.Event.TRIGGERED,this.§_-p2p§);
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         super.§_-Q2j§(param1);
         §_-h2B§.play(§_-d27§.§_-d2D§);
      }
      
      public function §_-d2s§(param1:BitmapData) : void
      {
         this.§_-q1q§ = new Image(Texture.fromBitmapData(param1,false));
         this.§_-B3a§ = param1;
         this.§_-q1q§.x = this.§_-K1x§.x;
         this.§_-q1q§.y = this.§_-K1x§.y;
         this.§_-q1q§.width = this.§_-K1x§.width;
         this.§_-q1q§.height = this.§_-K1x§.height;
         this.§_-72v§(this.§_-q1q§);
      }
      
      private function §_-p2p§(param1:starling.events.Event) : void
      {
         §_-N1V§.§_-xJ§(this.§_-a1m§);
      }
      
      private function §_-a1m§(param1:Boolean) : void
      {
         if(§_-N1V§.socialController.isLoggedIn() && §_-h1C§())
         {
            if(!§_-X1j§.§_-12n§.inBattle)
            {
               §_-J2l§.§_-R25§.show(this.§_-t1P§);
            }
            else
            {
               this.§_-t1P§();
            }
         }
      }
      
      private function §_-t1P§() : void
      {
         §_-N1V§.photoUploader.savePhoto(this.§_-B3a§.clone(),"",this.§_-L3R§);
         this.hide();
      }
      
      private function §_-L3R§(param1:SocialResponse) : void
      {
         if(!§_-X1j§.§_-12n§.inBattle)
         {
            §_-J2l§.§_-R25§.hide();
         }
         if(param1.success)
         {
            §_-N1V§.postController.§_-A2C§(param1 is PhotoSaveResponse ? PhotoSaveResponse(param1).photoUrl : "");
            if(§_-X1j§.§_-12n§.inBattle)
            {
               §_-X1j§.§_-12n§.battleStats.increment(§_-r26§.§_-HX§);
            }
            else
            {
               §_-X1j§.§_-k2F§.§_-f1I§([§_-r26§.§_-HX§],[1]);
            }
         }
         else
         {
            this.onError(param1);
         }
      }
      
      private function onError(param1:SocialResponse) : void
      {
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),SocialUtils.getSocialErrorDescription(param1));
      }
      
      public function destroy() : void
      {
         super.dispose();
      }
      
      override public function dispose() : void
      {
         if(this.§_-q1q§ != null)
         {
            this.§_-k6§(this.§_-q1q§);
            this.§_-q1q§.texture.dispose();
            this.§_-q1q§.dispose();
         }
         if(this.§_-B3a§)
         {
            this.§_-B3a§.dispose();
         }
         this.§_-B3a§ = null;
         super.dispose();
         Pool.putRectangle(this.§_-K1x§);
         this.§_-K1x§ = null;
      }
   }
}


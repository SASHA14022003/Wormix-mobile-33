package §_-DJ§
{
   import §_-12W§.*;
   import §_-23P§.§_-V2T§;
   import §_-23P§.§_-u1z§;
   import §_-43V§.Random;
   import §_-62§.*;
   import §_-91A§.*;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.*;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.§_-i1i§;
   import §_-H3§.*;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.§_-j2m§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-yA§;
   import §_-e2r§.EquipTopPanel;
   import §_-e2r§.§_-i1O§;
   import §_-j1w§.§_-B2i§;
   import §_-j1y§.§_-i1b§;
   import §_-l1K§.*;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.§_-K2W§;
   import §_-q26§.*;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-z1g§.§_-82X§;
   import §_-z20§.§_-pl§;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.greensock.loading.LoaderStatus;
   import com.hurlant.crypto.tls.*;
   import config.§_-V2w§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.TabBar;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.events.*;
   import flash.utils.*;
   import org.as3commons.zip.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanEnterAccount;
   import ru.pragmatix.wormix.messages.clans.response.LoginClanErrorResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.BuyResetBonusItems;
   import ru.pragmatix.wormix.messages.server.BuyResetBonusItemsResult;
   import ru.pragmatix.wormix.messages.structures.DepositStructure;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.Girder;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.text.TextField;
   import starling.utils.MathUtil;
   import starling.utils.SystemUtil;
   
   public class DepositIncomeWindow extends §_-73y§
   {
      
      private static const §_-k2z§:Number = -61 * 0.8;
      
      private static const §_-M2A§:Number = -13 * 0.8;
      
      private const §_-b11§:int = 5;
      
      private var §_-QW§:Array;
      
      private var §_-K3§:Boolean;
      
      private var binder:Binder;
      
      public function DepositIncomeWindow(param1:Array, param2:Boolean)
      {
         var _loc3_:Button = null;
         this.binder = new Binder();
         Application.uiBuilder.create(Application.assetManager.getObject("deposit_income_window"),true,this.binder);
         _loc3_ = §_-YQ§.§_-L1A§("OkButtonSmallLabel") as Button;
         _loc3_.width = this.binder._okBtnContainer.width;
         _loc3_.height = this.binder._okBtnContainer.height;
         _loc3_.label = param2 ? §_-s2a§.§_-K3t§(§_-s2a§.COLLECT) : §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_OK);
         _loc3_.name = "okBtn";
         this.binder._okBtnContainer.addChild(_loc3_);
         super(this.binder._content);
         this.§_-QW§ = param1;
         this.§_-K3§ = param2;
         this.binder._title.text = §_-s2a§.§_-K3t§(§_-s2a§.DEPOSIT_INCOME_TITLE);
         §_-12E§(param2 ? §_-s2a§.COLLECT : §_-s2a§.BUTTON_OK);
         this.§_-dx§();
         §_-yp§ = true;
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-v1w§.name = "panel.ribbon.title";
         §_-rP§.name = "panel._okBtnContainer.okBtn";
      }
      
      override protected function §_-b1H§() : void
      {
         §_-X1j§.§_-Rr§.§_-T2Q§();
         super.§_-b1H§();
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         this.binder._description.text = §_-s2a§.§_-K3t§(§_-s2a§.DEPOSIT_INCOME_MSG);
         super.§_-Q2j§(param1);
      }
      
      private function §_-dx§() : void
      {
         var _loc1_:LayoutGroup = null;
         var _loc6_:DepositStructure = null;
         var _loc7_:int = 0;
         _loc1_ = this.§_-mZ§(this.binder._info);
         var _loc2_:List = this.§_-41h§(_loc1_);
         var _loc3_:List = this.§_-41h§(_loc1_);
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc8_:* = int(this.§_-QW§.length);
         while(_loc8_--)
         {
            _loc6_ = this.§_-QW§[_loc8_];
            if(!(this.§_-K3§ && _loc6_.todayDividend == 0))
            {
               if(_loc6_.moneyType == §_-E19§.§_-51D§.id)
               {
                  _loc7_ = int(_loc6_.dividendsByDays[_loc6_.progress]);
                  this.§_-h1e§(_loc7_,§_-E19§.§_-51D§,_loc2_);
                  _loc4_ += _loc7_;
               }
               else
               {
                  _loc7_ = int(_loc6_.dividendsByDays[_loc6_.progress]);
                  this.§_-h1e§(_loc7_,§_-E19§.§_-i2d§,_loc3_);
                  _loc5_ += _loc7_;
               }
            }
         }
         if(Boolean(_loc2_.dataProvider) && _loc2_.dataProvider.length > 1)
         {
            this.§_-xV§({
               "value":_loc4_,
               "moneyType":§_-E19§.§_-51D§
            },_loc2_);
         }
         if(Boolean(_loc3_.dataProvider) && _loc3_.dataProvider.length > 1)
         {
            this.§_-xV§({
               "value":_loc5_,
               "moneyType":§_-E19§.§_-i2d§
            },_loc3_);
         }
      }
      
      private function §_-h1e§(param1:int, param2:§_-E19§, param3:List) : void
      {
         if(Boolean(param3.dataProvider) && param3.dataProvider.length == this.§_-b11§)
         {
            param3.dataProvider.getItemAt(this.§_-b11§ - 1).value = "...";
         }
         else
         {
            this.§_-xV§({
               "value":§_-j2m§.§_-M2m§(param1,1000).toString(),
               "moneyType":param2
            },param3);
         }
      }
      
      private function §_-mZ§(param1:DisplayObject) : LayoutGroup
      {
         var _loc2_:LayoutGroup = new LayoutGroup();
         var _loc3_:VerticalLayout = new VerticalLayout();
         _loc3_.horizontalAlign = HorizontalAlign.CENTER;
         _loc3_.verticalAlign = VerticalAlign.MIDDLE;
         _loc3_.gap = §_-M2A§;
         _loc2_.layout = _loc3_;
         _loc2_.x = param1.x;
         _loc2_.y = param1.y;
         _loc2_.width = param1.width;
         _loc2_.height = param1.height;
         param1.parent.addChild(_loc2_);
         return _loc2_;
      }
      
      private function §_-xV§(param1:Object, param2:List) : void
      {
         if(!param2.dataProvider)
         {
            param2.dataProvider = new ListCollection([]);
         }
         param2.dataProvider.addItem(param1);
      }
      
      private function §_-41h§(param1:LayoutGroup) : List
      {
         var _loc2_:List = new List();
         var _loc3_:HorizontalLayout = new HorizontalLayout();
         _loc3_.paddingLeft = _loc3_.paddingRight = -§_-k2z§ * 0.5;
         _loc3_.gap = §_-k2z§;
         _loc2_.layout = _loc3_;
         _loc2_.itemRendererType = §_-92b§;
         param1.addChild(_loc2_);
         return _loc2_;
      }
   }
}

import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _info:LayoutGroup;
   
   public var _okBtnContainer:LayoutGroup;
   
   public var _title:Label;
   
   public var _description:Label;
   
   public function Binder()
   {
      super();
   }
}

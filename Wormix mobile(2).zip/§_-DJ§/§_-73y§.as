package §_-DJ§
{
   import §_-12a§.*;
   import §_-134§.*;
   import §_-21p§.§_-4w§;
   import §_-2U§.*;
   import §_-2k§.§_-51r§;
   import §_-52L§.*;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-o6§;
   import §_-72j§.§_-Z6§;
   import §_-72j§.§_-i2G§;
   import §_-73I§.*;
   import §_-82a§.*;
   import §_-931§.§_-02O§;
   import §_-931§.§_-i2r§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.*;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-CR§.§_-72p§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-J31§.§_-R1h§;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-b2K§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-S1N§.*;
   import §_-SP§.§_-M4§;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1O§.§_-V23§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-Z1w§.§_-s1x§;
   import §_-a19§.*;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-d1H§;
   import §_-f1G§.*;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-52k§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-zI§.§_-U1A§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.easing.Circ;
   import com.greensock.events.LoaderEvent;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import com.worlize.websocket.§_-03n§;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import com.worlize.websocket.§_-x2j§;
   import config.§_-xD§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalLayout;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import feathers.utils.textures.TextureCache;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.ColorTransform;
   import flash.text.TextFormatAlign;
   import flash.utils.*;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.gui.controls.MessageBox;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.gui.controls.§_-yf§;
   import ru.pragmatix.flox.social.controller.IAuthorizeSocialController;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.particle.ParticleEffectType;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-F3i§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import ru.pragmatix.wormix.messages.server.AchieveLoginError;
   import ru.pragmatix.wormix.messages.server.BuyRaceResult;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.messages.structures.CostStructure;
   import ru.pragmatix.wormix.messages.structures.RestrictionItemStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.CatPhysicModel;
   import ru.pragmatix.wormix.physics.model.NotStuckingPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.scene.tile.TileData;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.phase.HarmPhase;
   import ru.pragmatix.wormix.weapons.ammo.phase.HealBolt;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.EnterFrameEvent;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.textures.Texture;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   
   public class §_-73y§ extends §_-F3i§ implements §_-T22§, §_-K3O§
   {
      
      protected var §_-PQ§:String = "close";
      
      protected var closeBtn:DisplayObject;
      
      protected var §_-v1w§:§_-02O§ = new §_-02O§("title");
      
      protected var §_-C1H§:ITextRenderer;
      
      protected var §_-H1o§:§_-02O§ = new §_-02O§("cancel");
      
      protected var §_-51P§:DisplayObject;
      
      protected var §_-yp§:Boolean = true;
      
      private var §_-Z16§:§_-NY§ = §_-NY§.§_-QT§;
      
      private var §_-K3R§:Function;
      
      private var §_-R1L§:Function;
      
      private var §_-Sc§:§_-t1R§;
      
      private var §_-N1Q§:§_-t1R§;
      
      private var §_-B3p§:Boolean = true;
      
      private var §_-211§:Boolean;
      
      private var ready:Boolean;
      
      private var _data:Object;
      
      public function §_-73y§(param1:DisplayObjectContainer)
      {
         super(param1);
         this.closeBtn = getChildByName(this.§_-PQ§);
         this.§_-C1H§ = getChildByName(this.§_-v1w§.name) as ITextRenderer;
         if(Boolean(panel) && panel is DisplayObjectContainer)
         {
            if(!this.closeBtn)
            {
               this.closeBtn = DisplayObjectContainer(panel).getChildByName(this.§_-PQ§);
            }
            if(!this.§_-C1H§)
            {
               this.§_-C1H§ = getChildByName(§_-G9§ + "." + this.§_-v1w§.name) as ITextRenderer;
            }
         }
         §_-YQ§.§_-JO§(this.§_-C1H§,this.§_-v1w§);
         if(this.§_-H1o§.name)
         {
            this.§_-51P§ = getChildByName(this.§_-H1o§.name);
            if(this.§_-51P§)
            {
               §_-YQ§.§_-S1U§(this.§_-51P§,this.§_-H1o§);
            }
         }
      }
      
      override protected function §_-q2a§() : void
      {
         super.§_-q2a§();
         if(this.closeBtn)
         {
            this.§_-z1R§(this.closeBtn,this.§_-03a§,this.§_-86§);
         }
         if(this.§_-51P§)
         {
            this.§_-z1R§(this.§_-51P§,this.§_-03a§,this.§_-86§);
         }
      }
      
      private function §_-G1x§(param1:DisplayObjectContainer) : void
      {
         var _loc3_:DisplayObjectContainer = null;
         var _loc4_:* = 0;
         var _loc2_:DisplayObject = param1.getChildByName("background");
         if(!_loc2_ && param1.numChildren > 0)
         {
            _loc2_ = param1.getChildAt(0);
         }
         if(_loc2_)
         {
            _loc2_.touchable = true;
            _loc3_ = _loc2_ as DisplayObjectContainer;
            if(_loc3_)
            {
               _loc4_ = _loc3_.numChildren;
               while(_loc4_--)
               {
                  _loc3_.getChildAt(_loc4_).touchable = true;
               }
            }
         }
      }
      
      public function §_-A1e§(param1:String) : void
      {
         this.§_-v1w§.stringId = param1;
         §_-YQ§.§_-JO§(this.§_-C1H§,this.§_-v1w§);
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         this.§_-Sc§ = §_-81L§.§_-q2C§;
         this.§_-N1Q§ = §_-81L§.§_-Cu§;
      }
      
      final public function show(param1:Boolean = true) : void
      {
         if(this.§_-211§)
         {
            return;
         }
         SystemUtil.executeWhenApplicationIsActive(this.§_-Q2j§,param1);
      }
      
      protected function §_-Q2j§(param1:Boolean = true) : void
      {
         if(§_-X1j§.§_-82T§)
         {
            §_-X1j§.§_-82T§.addEventListener(Event.CHANGE,this.§_-93S§);
         }
         this.§_-211§ = true;
         this.ready = false;
         this.§_-T1n§();
         PopUpManager.addPopUp(container,param1,this.§_-yp§,this.§_-3y§());
         container.alpha = 0;
         if(param1)
         {
            §_-T2G§.§_-F1w§(this);
         }
         if(§_-81L§.§_-N2p§ || !this.§_-Z16§ || this.§_-Z16§ == §_-NY§.§_-QT§)
         {
            this.§_-D3u§();
         }
         else if(this.§_-Z16§ == §_-NY§.§_-w1y§)
         {
            TweenMax.to(this.getContainer(),0.3,{
               "startAt":{
                  "alpha":0,
                  "y":-getContainer().height / 2
               },
               "alpha":1,
               "y":y,
               "ease":Circ.easeIn,
               "onComplete":this.§_-D3u§
            });
         }
         else if(this.§_-Z16§ == §_-NY§.§_-g1h§ && this.§_-K3R§ != null)
         {
            this.§_-K3R§(this,this.§_-D3u§);
         }
         if(this.§_-Sc§)
         {
            §_-h2B§.play(this.§_-Sc§);
         }
         Starling.current.nativeStage.focus = null;
      }
      
      protected function §_-T1n§() : void
      {
         if(!this.§_-yp§)
         {
            this.§_-a2T§();
         }
      }
      
      override protected function onAddedToStage(param1:Event) : void
      {
         var event:Event = param1;
         super.onAddedToStage(event);
         §_-52k§.single(Starling.current.stage,EnterFrameEvent.ENTER_FRAME,function(param1:Event):void
         {
            if(container)
            {
               container.alpha = 0.99;
            }
         });
      }
      
      public function §_-a2T§() : void
      {
      }
      
      public function §_-X2O§() : void
      {
         this.hide();
      }
      
      public function hide() : void
      {
         if(!this.§_-211§)
         {
            return;
         }
         if(§_-X1j§.§_-82T§)
         {
            §_-X1j§.§_-82T§.removeEventListener(Event.CHANGE,this.§_-93S§);
         }
         this.§_-211§ = false;
         this.ready = false;
         §_-T2G§.§_-53B§(this);
         Starling.juggler.removeTweens(container);
         if(§_-81L§.§_-N2p§ || !this.§_-Z16§ || this.§_-Z16§ == §_-NY§.§_-QT§)
         {
            this.§_-o1K§();
         }
         else if(this.§_-Z16§ == §_-NY§.§_-w1y§)
         {
            TweenMax.to(this.getContainer(),0.3,{
               "alpha":0,
               "y":this.y + 150,
               "onComplete":this.§_-o1K§,
               "ease":Circ.easeIn
            });
         }
         else if(this.§_-Z16§ == §_-NY§.§_-g1h§ && this.§_-R1L§ != null)
         {
            this.§_-R1L§(this,this.§_-o1K§);
         }
         if(this.§_-N1Q§)
         {
            §_-h2B§.play(this.§_-N1Q§);
         }
      }
      
      protected function §_-D3u§() : void
      {
         this.§_-G1x§(§_-j2l§());
         dispatchEventWith(§_-M4§.WINDOW_SHOW);
         this.ready = true;
      }
      
      private function §_-o1K§() : void
      {
         if(PopUpManager.isPopUp(container))
         {
            PopUpManager.removePopUp(container);
         }
         dispatchEventWith(§_-M4§.WINDOW_CLOSE);
      }
      
      override protected function §_-b1H§() : void
      {
         super.§_-b1H§();
         this.hide();
      }
      
      private function §_-86§(param1:TouchEvent) : void
      {
         if(param1 is TouchEvent && !(param1 as TouchEvent).getTouch(param1.currentTarget as DisplayObject,TouchPhase.ENDED))
         {
            return;
         }
         this.§_-03a§(param1);
      }
      
      protected function §_-03a§(param1:Event) : void
      {
         this.hide();
         dispatchEventWith(§_-M4§.WINDOW_CANCEL);
      }
      
      override protected function §_-93S§(param1:Event = null) : void
      {
         super.§_-93S§(param1);
         §_-YQ§.§_-JO§(this.§_-C1H§,this.§_-v1w§);
         §_-YQ§.§_-S1U§(okBtn,§_-rP§);
         §_-YQ§.§_-S1U§(this.§_-51P§,this.§_-H1o§);
      }
      
      public function §_-oO§(param1:String) : void
      {
         this.§_-H1o§.text = param1;
         §_-YQ§.§_-S1U§(this.§_-51P§,this.§_-H1o§);
      }
      
      public function §_-i25§(param1:String) : void
      {
         this.§_-H1o§.name = param1;
      }
      
      public function §_-xQ§(param1:String) : void
      {
         this.§_-H1o§.stringId = param1;
         §_-YQ§.§_-S1U§(this.§_-51P§,this.§_-H1o§);
      }
      
      public function get outsideClosable() : Boolean
      {
         return this.§_-B3p§;
      }
      
      public function set outsideClosable(param1:Boolean) : void
      {
         this.§_-B3p§ = param1;
      }
      
      override public function §_-h1C§() : Boolean
      {
         return Boolean(super.§_-h1C§()) && this.§_-211§;
      }
      
      override public function dispose() : void
      {
         Starling.juggler.removeTweens(container);
         if(this.closeBtn)
         {
            this.§_-z2T§(this.closeBtn,this.§_-03a§,this.§_-86§);
         }
         if(this.§_-51P§)
         {
            this.§_-z2T§(this.§_-51P§,this.§_-03a§,this.§_-86§);
         }
         if(this.closeBtn)
         {
            this.closeBtn.dispose();
            this.closeBtn = null;
         }
         if(this.§_-C1H§)
         {
            this.§_-C1H§.dispose();
            this.§_-C1H§ = null;
         }
         if(this.§_-51P§)
         {
            this.§_-51P§.dispose();
            this.§_-51P§ = null;
         }
         this.§_-K3R§ = null;
         this.§_-R1L§ = null;
         super.dispose();
      }
      
      protected function §_-3y§() : Function
      {
         return this.§_-Eh§;
      }
      
      protected function §_-Eh§() : DisplayObject
      {
         return this.§_-lY§(§_-81L§.§_-a1e§);
      }
      
      protected function §_-lY§(param1:Number) : DisplayObject
      {
         var _loc2_:Quad = new Quad(Application.§_-i1N§.stageWidth,Application.§_-i1N§.stageHeight,§_-81L§.§_-YC§);
         _loc2_.alpha = param1;
         new TapToTrigger(_loc2_);
         _loc2_.addEventListener(Event.TRIGGERED,this.§_-a6§);
         return _loc2_;
      }
      
      protected function §_-a6§(param1:Event) : void
      {
         if(this.outsideClosable && this.ready)
         {
            this.hide();
            dispatchEventWith(§_-M4§.WINDOW_OUTSIDE_TAP);
         }
      }
      
      public function get data() : Object
      {
         return this._data;
      }
      
      public function set data(param1:Object) : void
      {
         this._data = param1;
      }
      
      private function §_-z1R§(param1:DisplayObject, param2:Function, param3:Function) : void
      {
         if(param1 is Button)
         {
            param1.addEventListener(Event.TRIGGERED,param2);
         }
         else
         {
            param1.addEventListener(TouchEvent.TOUCH,param3);
         }
      }
      
      private function §_-z2T§(param1:DisplayObject, param2:Function, param3:Function) : void
      {
         if(param1 is Button)
         {
            param1.removeEventListener(Event.TRIGGERED,param2);
         }
         else
         {
            param1.removeEventListener(TouchEvent.TOUCH,param3);
         }
      }
      
      public function get soundOnShow() : §_-t1R§
      {
         return this.§_-Sc§;
      }
      
      public function get soundOnHide() : §_-t1R§
      {
         return this.§_-N1Q§;
      }
      
      public function set soundOnShow(param1:§_-t1R§) : void
      {
         this.§_-Sc§ = param1;
      }
      
      public function set soundOnHide(param1:§_-t1R§) : void
      {
         this.§_-N1Q§ = param1;
      }
      
      public function get §_-u2m§() : §_-NY§
      {
         return this.§_-Z16§;
      }
      
      public function set §_-u2m§(param1:§_-NY§) : void
      {
         this.§_-Z16§ = param1;
      }
   }
}


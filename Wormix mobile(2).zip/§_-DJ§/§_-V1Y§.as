package §_-DJ§
{
   import §_-12W§.*;
   import §_-22z§.*;
   import §_-23P§.*;
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-31u§.*;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-bs§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-G2H§.*;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-SP§.§_-M4§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-b1F§.§_-v2Q§;
   import §_-f1G§.§_-kf§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-z1g§.§_-M2v§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.events.LoaderEvent;
   import com.hurlant.math.BigInteger;
   import com.hurlant.util.*;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ToggleButton;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.net.SharedObject;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.clearTimeout;
   import org.gestouch.core.GestureState;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.server.ConnectResult;
   import ru.pragmatix.wormix.messages.server.FastBattleResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-i14§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.scene.ObjectType;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   use namespace gestouch_internal;
   
   public class §_-V1Y§ extends LayoutGroup implements §_-K3O§, §_-T22§
   {
      
      protected var §_-Sc§:§_-t1R§ = §_-81L§.§_-q2C§;
      
      protected var §_-N1Q§:§_-t1R§ = §_-81L§.§_-Cu§;
      
      private var controls:Array = new Array();
      
      public function §_-V1Y§()
      {
         super();
         §_-22x§.§_-L2X§(this);
      }
      
      protected function §_-J2N§(param1:EventDispatcher, param2:String, param3:Function = null, param4:§_-t1R§ = null) : void
      {
         this.controls.push({
            "control":param1,
            "eventType":param2,
            "callback":param3,
            "sound":param4
         });
         param1.addEventListener(param2,this.§_-M1U§);
      }
      
      protected function §_-jg§(param1:EventDispatcher, param2:String) : void
      {
         var _loc3_:int = this.§_-g1Z§(param1,param2);
         if(_loc3_ > -1)
         {
            param1.removeEventListener(param2,this.§_-M1U§);
            this.controls.removeAt(_loc3_);
         }
      }
      
      private function §_-g1Z§(param1:EventDispatcher, param2:String) : int
      {
         var _loc3_:Object = null;
         var _loc4_:int = 0;
         while(_loc4_ < this.controls.length)
         {
            _loc3_ = this.controls[_loc4_];
            if(_loc3_.control == param1 && _loc3_.eventType == param2)
            {
               return _loc4_;
            }
            _loc4_++;
         }
         return -1;
      }
      
      private function §_-M1U§(param1:starling.events.Event) : void
      {
         var _loc5_:Object = null;
         var _loc2_:EventDispatcher = param1.currentTarget as EventDispatcher;
         var _loc3_:String = param1.type;
         var _loc4_:int = this.§_-g1Z§(_loc2_,_loc3_);
         if(_loc4_ > -1)
         {
            _loc5_ = this.controls[_loc4_];
            if(_loc5_.sound)
            {
               §_-h2B§.play(_loc5_.sound as §_-t1R§);
            }
            if(_loc5_.callback != null)
            {
               _loc5_.callback(param1);
            }
         }
      }
      
      public function show(param1:Boolean = true) : void
      {
         dispatchEventWith(§_-M4§.WINDOW_SHOW);
      }
      
      public function hide() : void
      {
         dispatchEventWith(§_-M4§.WINDOW_CLOSE);
      }
      
      public function get soundOnShow() : §_-t1R§
      {
         return this.§_-Sc§;
      }
      
      public function get soundOnHide() : §_-t1R§
      {
         return this.§_-N1Q§;
      }
      
      protected function §_-Z1p§(param1:String, param2:Object) : void
      {
         var _loc3_:Object = Application.assetManager.getObject(param1);
         Application.uiBuilder.create(_loc3_,true,param2);
      }
      
      protected function §_-1o§(param1:String, param2:String = "ui", param3:Object = null) : Sprite
      {
         return §_-YQ§.§_-qM§(param1,param2,param3);
      }
      
      protected function §_-R1t§(param1:starling.events.Event) : void
      {
         this.hide();
      }
      
      public function §_-h1C§() : Boolean
      {
         return this.stage != null;
      }
      
      public function §_-X2O§() : void
      {
         this.§_-R1t§(null);
      }
   }
}


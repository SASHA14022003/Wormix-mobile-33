package §_-DJ§
{
   import §_-2H§.§_-91a§;
   import §_-2H§.§_-A1R§;
   import §_-2H§.§_-N15§;
   import §_-2H§.§_-Y1i§;
   import §_-31W§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-73I§.§_-q15§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-o2k§;
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-E19§;
   import §_-H9§.§_-NX§;
   import §_-L2F§.§_-I1q§;
   import §_-L2F§.§_-t2Z§;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-Y1b§.*;
   import §_-e2r§.§_-02G§;
   import §_-e2r§.§_-lR§;
   import §_-e2r§.§_-n1§;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-F4§;
   import com.greensock.loading.core.LoaderCore;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.core.ITextRenderer;
   import feathers.data.*;
   import feathers.layout.*;
   import feathers.themes.styles.AlternateButtonsStyles;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.WipeProfile;
   import ru.pragmatix.wormix.messages.server.BuyUnlockMissionResult;
   import ru.pragmatix.wormix.messages.structures.ProfileDoubleKeyStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-k1h§;
   import ru.pragmatix.wormix.weapons.ammo.JumpingMine;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class MessageBox extends §_-V1Y§
   {
      
      public static const §_-1B§:int = 0;
      
      public static const §_-X2g§:int = 1;
      
      public static const §_-L2I§:int = 2;
      
      public static const §_-H2d§:int = 3;
      
      private var title:String;
      
      private var message:String;
      
      private var buttons:int;
      
      private var §_-UG§:Function;
      
      private var binder:Binder;
      
      public function MessageBox(param1:String, param2:String, param3:int = 0, param4:Function = null)
      {
         super();
         this.title = param1;
         this.message = param2;
         this.buttons = param3;
         this.§_-UG§ = param4;
      }
      
      override protected function initialize() : void
      {
         var buttonGroupData:Array;
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("base-message-box",this.binder);
         addChild(this.binder._panel);
         this.binder._panel.title = this.title;
         this.binder._message.text = this.message;
         this.binder._messageContainer.maxHeight = 300;
         this.binder._messageContainer.customVerticalScrollBarStyleName = AlternateScrollBarStyles.SIMPLE_NORMAL;
         this.binder._messageContainer.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._messageContainer.verticalScrollPolicy = ScrollPolicy.AUTO;
         buttonGroupData = [];
         switch(this.buttons)
         {
            case §_-1B§:
               buttonGroupData.push({
                  "style":AlternateButtonsStyles.BUTTON_GREEN,
                  "stringID":§_-s2a§.BUTTON_OK,
                  "result":true
               });
               break;
            case §_-X2g§:
               buttonGroupData.push({
                  "style":AlternateButtonsStyles.BUTTON_GREEN,
                  "stringID":§_-s2a§.BUTTON_OK,
                  "result":true
               });
               buttonGroupData.push({
                  "style":AlternateButtonsStyles.BUTTON_RED,
                  "stringID":§_-s2a§.BUTTON_CANCEL,
                  "result":false
               });
               break;
            case §_-H2d§:
               buttonGroupData.push({
                  "style":AlternateButtonsStyles.BUTTON_GREEN,
                  "stringID":§_-s2a§.BUTTON_YES,
                  "result":true
               });
               buttonGroupData.push({
                  "style":AlternateButtonsStyles.BUTTON_RED,
                  "stringID":§_-s2a§.BUTTON_CANCEL,
                  "result":false
               });
         }
         this.binder._buttons.buttonInitializer = function(param1:Button, param2:Object):void
         {
            param1.styleName = param2.style;
            param1.width = 200;
            param1.label = §_-s2a§.§_-K3t§(param2.stringID);
         };
         with(this.binder._buttons)
         {
            dataProvider = new ListCollection(buttonGroupData);
            direction = Direction.HORIZONTAL;
            distributeButtonSizes = false;
            gap = 10;
            horizontalAlign = HorizontalAlign.CENTER;
            verticalAlign = VerticalAlign.MIDDLE;
         }
         §_-J2N§(this.binder._panel,Event.CLOSE,this.§_-R1t§);
         §_-J2N§(this.binder._buttons,Event.TRIGGERED,this.§_-y1l§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,Event.CLOSE);
         §_-jg§(this.binder._buttons,Event.TRIGGERED);
      }
      
      override protected function §_-R1t§(param1:Event) : void
      {
         super.§_-R1t§(param1);
         this.executeCallback(false);
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         hide();
         this.executeCallback(param1.data.result);
      }
      
      private function executeCallback(param1:Boolean) : void
      {
         if(this.§_-UG§ != null)
         {
            this.§_-UG§(param1);
         }
      }
   }
}

import feathers.controls.ButtonGroup;
import feathers.controls.Label;
import feathers.controls.Panel;
import feathers.controls.ScrollContainer;

class Binder
{
   
   public var _panel:Panel;
   
   public var _buttons:ButtonGroup;
   
   public var _message:Label;
   
   public var _messageContainer:ScrollContainer;
   
   public function Binder()
   {
      super();
   }
}

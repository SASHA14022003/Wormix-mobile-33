package §_-72j§
{
   import §_-63U§.*;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-Ly§.§_-81L§;
   import §_-T1o§.§_-n1S§;
   import §_-ZB§.§_-32D§;
   import §_-eW§.§_-FR§;
   import §_-eW§.§_-M2H§;
   import §_-eW§.§_-rK§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-r1C§.§_-h2B§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import dragonBones.animation.WorldClock;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-a1S§
   {
      
      public function §_-a1S§()
      {
         super();
      }
      
      public static function create(param1:SocialType) : §_-32D§
      {
         switch(param1)
         {
            case SocialType.STEAM:
               return new §_-M2H§();
            case SocialType.MOBILE_ANDROID:
            case SocialType.MOBILE_IOS:
               return new §_-FR§();
            default:
               return new §_-rK§();
         }
      }
   }
}


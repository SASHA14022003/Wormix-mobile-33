package §_-72j§
{
   import §_-31N§.§_-42G§;
   import §_-CF§.§_-x2t§;
   import §_-G16§.§_-33h§;
   import §_-H2g§.§_-di§;
   import §_-Y1b§.*;
   import §_-ZB§.§_-A10§;
   import §_-eW§.§_-S21§;
   import §_-eW§.§_-V2n§;
   import §_-eW§.§_-g2b§;
   import §_-j22§.§_-5g§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.NativeWindowDisplayStateEvent;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import flash.utils.clearTimeout;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.client.BuyShopItems;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.client.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-p1G§
   {
      
      public function §_-p1G§()
      {
         super();
      }
      
      public static function create(param1:IPlatformAccountController, param2:ISocialController) : §_-A10§
      {
         var _loc3_:§_-A10§ = null;
         var _loc4_:SocialType = param1.getPlatformType();
         switch(_loc4_)
         {
            case SocialType.MOBILE_ANDROID:
         }
         return new §_-g2b§(param2);
      }
   }
}


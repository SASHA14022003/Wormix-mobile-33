package §_-72j§
{
   import §_-12W§.*;
   import §_-A1K§.§_-7u§;
   import §_-G2H§.SteamBankController;
   import §_-G2H§.§_-B2n§;
   import §_-G2H§.§_-IL§;
   import §_-G2H§.§_-m2E§;
   import §_-ZB§.§_-R2Y§;
   import §_-k1u§.§_-Vr§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.server.RepeatBossBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-Q1F§
   {
      
      public function §_-Q1F§()
      {
         super();
      }
      
      public static function create(param1:SocialType) : §_-R2Y§
      {
         var _loc2_:§_-R2Y§ = null;
         var _loc3_:SocialType = param1;
         switch(_loc3_)
         {
            case SocialType.MOBILE_IOS:
               §§push(0);
               break;
            case SocialType.MOBILE_ANDROID:
               §§push(1);
               break;
            default:
               if(SocialType.STEAM === _loc3_)
               {
                  §§push(2);
                  break;
               }
               §§push(3);
         }
         switch(§§pop())
         {
            case 0:
               _loc2_ = new §_-m2E§();
               break;
            case 1:
               _loc2_ = new §_-B2n§();
               break;
            case 2:
               _loc2_ = new SteamBankController();
         }
         if(_loc2_ == null)
         {
            _loc2_ = new §_-IL§();
         }
         return _loc2_;
      }
   }
}


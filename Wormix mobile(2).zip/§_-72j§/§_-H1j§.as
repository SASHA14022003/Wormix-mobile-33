package §_-72j§
{
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-9e§.§_-73e§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-ZB§.§_-GG§;
   import §_-gG§.§_-8u§;
   import §_-m2s§.§_-R11§;
   import §_-nZ§.§_-6z§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-A1s§;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.core.Starling;
   import starling.events.Event;
   
   public class §_-H1j§
   {
      
      public function §_-H1j§()
      {
         super();
      }
      
      public static function create(param1:ISocialController) : §_-GG§
      {
         var _loc2_:SocialType = param1.getType();
         switch(0)
         {
         }
         return null;
      }
   }
}


package §_-72j§
{
   import §_-534§.§_-rC§;
   import §_-B1y§.§_-o2k§;
   import §_-H9§.§_-H1n§;
   import §_-T1t§.§_-u19§;
   import §_-TF§.§_-q1j§;
   import §_-TF§.§_-y2n§;
   import §_-Ta§.*;
   import §_-ZB§.§_-81R§;
   import §_-ZP§.§_-H1H§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-T0§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-q11§.§_-C2n§;
   import §_-rM§.§_-61j§;
   import §_-zI§.§_-X1q§;
   import config.§_-vR§;
   import feathers.data.IListCollection;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-kQ§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.social.common.post.§_-Gx§;
   import ru.pragmatix.wormix.social.common.post.§_-jw§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.utils.SystemUtil;
   
   public class §_-Z6§
   {
      
      public function §_-Z6§()
      {
         super();
      }
      
      public static function create(param1:§_-o2k§, param2:ISocialController) : §_-81R§
      {
         if(SystemUtil.isDesktop)
         {
            return new §_-jw§();
         }
         switch(param2.getType())
         {
            case SocialType.VK:
            case SocialType.FACEBOOK:
               return new §_-Gx§(param1,param2,new §_-rC§(),§_-vR§.§_-w2N§);
            default:
               return new §_-Gx§(param1,param2,new §_-H1n§(),null);
         }
      }
   }
}


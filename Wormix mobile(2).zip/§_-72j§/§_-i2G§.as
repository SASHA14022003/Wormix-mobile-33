package §_-72j§
{
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-YF§.§_-q2v§;
   import §_-ZB§.§_-V2N§;
   import §_-aM§.*;
   import §_-l1g§.§_-L3Q§;
   import feathers.core.ITextRenderer;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObjectContainer;
   import starling.events.EventDispatcher;
   
   public class §_-i2G§
   {
      
      public function §_-i2G§()
      {
         super();
      }
      
      public static function create(param1:ISocialController) : §_-V2N§
      {
         var _loc2_:SocialType = param1.getType();
         switch(0)
         {
         }
         return null;
      }
   }
}


package §_-J3b§
{
   import §_-12a§.§_-520§;
   import §_-31W§.§_-Kb§;
   import §_-73I§.*;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.§_-63i§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-E1I§.§_-b2n§;
   import §_-TF§.§_-q1j§;
   import §_-W§.*;
   import §_-YF§.§_-q2v§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-s20§.§_-d21§;
   import §_-sQ§.§_-H3D§;
   import §_-v2t§.§_-43O§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import feathers.controls.Button;
   import feathers.core.ITextRenderer;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.GetDailyBonus;
   import ru.pragmatix.wormix.messages.server.GetDailyBonusResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import ru.pragmatix.wormix.weapons.ammo.cloud.FreezingCloud;
   import ru.pragmatix.wormix.weapons.ammo.cloud.GasCloud;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.GasGrenade;
   import starling.display.Canvas;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.extensions.ColorArgb;
   
   public class DailyBonusPanel extends §_-73y§
   {
      
      private static var §_-N1z§:Boolean = false;
      
      private const §_-F3L§:uint = 5;
      
      private var §_-J1t§:§_-4l§;
      
      private var §_-s27§:int;
      
      private var shareBtn:Button;
      
      private var doubleForAdsBtn:Button;
      
      public function DailyBonusPanel(param1:§_-4l§)
      {
         super(§_-YQ§.§_-qM§(§_-q2v§.§_-B1t§,§_-q2v§.§_-A2T§));
         §_-A1e§(§_-s2a§.DAILY_BONUS_TITLE);
         this.§_-J1t§ = param1;
         this.§_-hT§();
         this.update();
         getChildByName("close").visible = false;
         this.shareBtn = getChildByName("shareBtn") as Button;
         this.shareBtn.label = §_-s2a§.§_-K3t§(§_-s2a§.COLLECT);
         this.shareBtn.addEventListener(Event.TRIGGERED,this.§_-Q2B§);
         this.§_-s27§ = this.shareBtn.x;
         §_-YQ§.§_-Xv§(this.shareBtn,!§_-N1V§.postController.§_-hh§());
         this.doubleForAdsBtn = getChildByName("doubleForAdsBtn") as Button;
         this.doubleForAdsBtn.parent.removeChild(this.doubleForAdsBtn);
         this.shareBtn.x = (this.shareBtn.parent.width - this.shareBtn.width) * 0.5;
      }
      
      private function §_-Q2B§(param1:Event) : void
      {
         §_-J2l§.§_-u2b§.show(§_-d21§.§_-51l§,new GetDailyBonus(),GetDailyBonusResult,this.§_-E33§,this.§_-32m§);
      }
      
      private function §_-E33§(param1:§_-63i§, ... rest) : void
      {
         var _loc3_:GetDailyBonusResult = GetDailyBonusResult(param1.message);
         var _loc4_:uint = _loc3_.result;
         if(_loc4_ == 0)
         {
            §_-X1j§.§_-p1c§.§_-z2i§();
         }
         §_-J2l§.§_-u2b§.hide();
         this.shareBtn.removeEventListener(Event.TRIGGERED,this.§_-Q2B§);
         if(this.§_-J1t§ == §_-4l§.§_-92V§)
         {
            §_-N1V§.postController.share4DayBonus();
         }
         else if(this.§_-J1t§ == §_-4l§.§_-32N§)
         {
            §_-N1V§.postController.share5DaySequence(this.§_-J1t§);
         }
         this.hide();
      }
      
      private function §_-32m§(param1:* = null, ... rest) : void
      {
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_SERVER),§_-fH§.§_-1B§);
         §_-J2l§.§_-u2b§.hide();
      }
      
      override protected function §_-O2y§() : void
      {
         super.§_-O2y§();
         §_-u2m§ = §_-NY§.§_-QT§;
         soundOnShow = §_-d27§.§_-S2s§;
         destroyOnRemove = true;
         outsideClosable = false;
      }
      
      override protected function §_-Q2j§(param1:Boolean = true) : void
      {
         if(!§_-N1z§)
         {
            §_-N1z§ = true;
            super.§_-Q2j§(param1);
         }
      }
      
      private function §_-hT§() : void
      {
         (getChildByName("congratzDescr") as ITextRenderer).text = §_-s2a§.§_-K3t§(§_-s2a§.DAILY_BONUS_TEXT);
      }
      
      private function update() : void
      {
         var _loc2_:§_-4l§ = null;
         this.§_-X2x§(this.§_-J1t§);
         var _loc1_:int = 0;
         while(_loc1_ < this.§_-F3L§)
         {
            if(_loc1_ + 1 == this.§_-J1t§.§_-I3m§)
            {
               _loc2_ = this.§_-J1t§;
            }
            else
            {
               _loc2_ = §_-4l§.§_-S2y§(_loc1_ + 1);
            }
            this.§_-V1T§(_loc1_,_loc2_);
            this.§_-H3U§(_loc1_);
            _loc1_++;
         }
      }
      
      private function §_-829§(param1:§_-4l§) : void
      {
         var _loc2_:int = 0;
         while(_loc2_ < this.§_-F3L§)
         {
            if(_loc2_ + 1 == param1.§_-I3m§)
            {
               this.§_-V1T§(_loc2_,param1);
               break;
            }
            _loc2_++;
         }
      }
      
      private function §_-H3U§(param1:uint) : void
      {
         var _loc2_:DisplayObjectContainer = getChildByName("seqControl.seqBar" + param1) as DisplayObjectContainer;
         if(param1 <= this.§_-J1t§.§_-I3m§ - 1)
         {
            _loc2_.removeChildAt(1);
         }
         else
         {
            _loc2_.removeChildAt(0);
         }
         var _loc3_:ITextRenderer = getChildByName("seqControl.day" + param1) as ITextRenderer;
         if(param1 == this.§_-J1t§.§_-I3m§ - 1)
         {
            §_-R2g§.§_-g1H§(_loc3_,null,0,10616832);
         }
         else
         {
            §_-R2g§.§_-g1H§(_loc3_,null,0,8806979);
         }
         _loc3_.text = (param1 + 1).toString() + " " + §_-s2a§.§_-K3t§(§_-s2a§.DAILY_BONUS_DAY);
      }
      
      private function §_-X2x§(param1:§_-4l§) : void
      {
         getChildByName("bonusLot." + param1.type.value).visible = true;
         var _loc2_:ITextRenderer = getChildByName("bonusLot.count") as ITextRenderer;
         _loc2_.visible = param1.count > 0;
         if(_loc2_.visible)
         {
            _loc2_.text = "+" + param1.count;
         }
         getChildByName("bonusLot.fuzy").visible = param1.type.equals(§_-522§.§_-J2y§);
         getChildByName("bonusLot.ruby").visible = param1.type.equals(§_-522§.§_-Mu§);
         getChildByName("bonusLot.reaction").visible = param1.type.equals(§_-522§.REACTION);
         getChildByName("bonusLot.fight").visible = param1.type.equals(§_-522§.§_-a1A§);
      }
      
      private function §_-V1T§(param1:uint, param2:§_-4l§) : void
      {
         var _loc4_:ITextRenderer = null;
         this.§_-kv§(param1,param2.type.value);
         var _loc3_:Boolean = param2.count > 0;
         if(_loc3_)
         {
            _loc4_ = this.§_-AD§(param1,"count") as ITextRenderer;
            _loc4_.visible = _loc3_;
            if(_loc4_.visible)
            {
               _loc4_.text = "" + (param2.count > 0 ? param2.count : "");
            }
         }
      }
      
      private function §_-kv§(param1:uint, param2:String) : void
      {
         this.§_-AD§(param1,"question").visible = param2 == "question";
         this.§_-AD§(param1,"fuzy").visible = param2 == "fuzy";
         this.§_-AD§(param1,"ruby").visible = param2 == "ruby";
         this.§_-AD§(param1,"weapon").visible = param2 == "weapon";
         this.§_-AD§(param1,"fight").visible = param2 == "fight";
         this.§_-AD§(param1,"count").visible = param2 == "count";
         this.§_-AD§(param1,"reaction").visible = param2 == "reaction";
      }
      
      private function §_-AD§(param1:uint, param2:String) : DisplayObject
      {
         return getChildByName("seqControl.iconPrize" + param1 + "." + param2);
      }
      
      override public function hide() : void
      {
         super.hide();
         §_-N1z§ = false;
      }
      
      override public function dispose() : void
      {
         this.shareBtn.removeEventListener(Event.TRIGGERED,this.§_-Q2B§);
         this.shareBtn = §_-c1S§.dispose(this.shareBtn) as Button;
         if(this.doubleForAdsBtn)
         {
            this.doubleForAdsBtn = §_-c1S§.dispose(this.doubleForAdsBtn) as Button;
            this.doubleForAdsBtn = null;
         }
         super.dispose();
      }
      
      override public function §_-X2O§() : void
      {
      }
   }
}


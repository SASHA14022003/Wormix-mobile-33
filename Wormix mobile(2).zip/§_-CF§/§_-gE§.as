package §_-CF§
{
   import §_-62§.§_-zF§;
   import §_-G2H§.*;
   import §_-Ly§.§_-81L§;
   import §_-Ta§.*;
   import §_-YF§.*;
   import §_-ZP§.§_-H1H§;
   import §_-ZP§.§_-w1J§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-x2Q§.§_-dU§;
   import com.hurlant.math.*;
   import feathers.data.ListCollection;
   import flash.errors.IllegalOperationError;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.client.AchieveLogin;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   
   use namespace bi_internal;
   
   public class §_-gE§
   {
      
      public static const §_-v2r§:§_-gE§ = new §_-gE§();
      
      public static const §_-81O§:§_-gE§ = new §_-gE§();
      
      public static const §_-j1M§:§_-gE§ = new §_-gE§();
      
      public function §_-gE§()
      {
         super();
      }
      
      public static function valueOf(param1:String) : §_-gE§
      {
         switch(param1)
         {
            case "test":
               return §_-gE§.§_-81O§;
            case "local":
               return §_-gE§.§_-v2r§;
            default:
               return §_-gE§.§_-j1M§;
         }
      }
      
      public function isLocal() : Boolean
      {
         return this == §_-v2r§;
      }
      
      public function §_-z23§() : Boolean
      {
         return this == §_-81O§;
      }
      
      public function §_-m2e§() : Boolean
      {
         return this == §_-j1M§;
      }
   }
}


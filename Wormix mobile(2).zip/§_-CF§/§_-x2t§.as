package §_-CF§
{
   import §_-12a§.§_-6p§;
   import §_-43V§.*;
   import §_-62§.§_-O2H§;
   import §_-9§.§_-52A§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-l1K§.*;
   import §_-l2r§.§_-K1t§;
   import §_-u1T§.§_-33B§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import dragonBones.animation.WorldClock;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-x2t§
   {
      
      private var §_-Jm§:int;
      
      private var §_-h12§:int;
      
      public function §_-x2t§(param1:uint = 0, param2:uint = 0)
      {
         super();
         this.§_-Jm§ = param2;
         this.§_-h12§ = param1;
      }
      
      public function getValue(param1:§_-E19§) : uint
      {
         return param1 == §_-E19§.§_-51D§ ? this.realPrice : this.§_-R1T§;
      }
      
      public function get realPrice() : uint
      {
         return this.§_-Jm§;
      }
      
      public function get §_-R1T§() : uint
      {
         return this.§_-h12§;
      }
      
      public function set realPrice(param1:uint) : void
      {
         this.§_-Jm§ = param1;
      }
      
      public function set §_-R1T§(param1:uint) : void
      {
         this.§_-h12§ = param1;
      }
      
      public function toString() : String
      {
         return "Price{realPrice=" + String(this.realPrice) + ",ingamePrice=" + String(this.§_-R1T§) + "}";
      }
   }
}


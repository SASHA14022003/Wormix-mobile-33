package §_-CF§
{
   import §_-82a§.*;
   import §_-B1y§.§_-F1P§;
   import §_-Bv§.§_-G3P§;
   import §_-Cl§.*;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-P1B§.§_-b21§;
   import §_-Y1b§.§_-OP§;
   import §_-j22§.§_-5g§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-C32§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import config.§_-vR§;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.§_-K2L§;
   import ru.pragmatix.wormix.gui.screenOverlay.view.*;
   import ru.pragmatix.wormix.messages.server.AddToGroupResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-E19§
   {
      
      private static const §_-R1o§:Vector.<§_-E19§> = new Vector.<§_-E19§>(0);
      
      public static const §_-51D§:§_-E19§ = new §_-E19§(0,"REAL_MONEY");
      
      public static const §_-i2d§:§_-E19§ = new §_-E19§(1,"INGAME_MONEY");
      
      public static const §_-qt§:§_-E19§ = new §_-E19§(2,"BATTLE_TOKENS");
      
      public static const REAGENTS:§_-E19§ = new §_-E19§(3,"REAGENTS");
      
      public static const §_-YN§:§_-E19§ = new §_-E19§(4,"ADVERTISING");
      
      private var _id:int;
      
      private var _name:String;
      
      public function §_-E19§(param1:int, param2:String)
      {
         super();
         this._id = param1;
         this._name = param2;
         §_-R1o§.push(this);
      }
      
      public static function §_-H1M§(param1:int) : §_-E19§
      {
         if(param1 > -1 && param1 < §_-R1o§.length)
         {
            return §_-R1o§[param1];
         }
         return null;
      }
      
      public function toString() : String
      {
         return "MoneyType:{" + "id=" + this._id + ",name=" + this._name + "}";
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get value() : int
      {
         return this._id;
      }
      
      public function get name() : String
      {
         return this._name;
      }
   }
}


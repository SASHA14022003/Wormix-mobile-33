package §_-CF§
{
   import §_-31N§.§_-42G§;
   import §_-82a§.*;
   import §_-931§.§_-i2r§;
   import §_-A2U§.§_-A23§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-522§;
   import com.hurlant.math.*;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.GetReagentsForProfile;
   import ru.pragmatix.wormix.messages.structures.BonusDaysStructure;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.pvp.messages.structures.PositionStructure;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   use namespace bi_internal;
   
   public class §_-p2U§
   {
      
      public static const §_-w13§:§_-p2U§ = new §_-p2U§("ru");
      
      public static const §_-S2t§:§_-p2U§ = new §_-p2U§("ua");
      
      public static const §_-71g§:§_-p2U§ = new §_-p2U§("by");
      
      public static const §_-qr§:§_-p2U§ = new §_-p2U§("en");
      
      public static const §_-Fu§:§_-p2U§ = new §_-p2U§("lv");
      
      public static const §_-L2q§:§_-p2U§ = new §_-p2U§("lt");
      
      public static const §_-Qq§:§_-p2U§ = new §_-p2U§("kor");
      
      public static const §_-j2B§:§_-p2U§ = new §_-p2U§("ge");
      
      public static const §_-73i§:§_-p2U§ = new §_-p2U§("hu");
      
      public static const §_-w2w§:§_-p2U§ = new §_-p2U§("pl");
      
      public static const §_-U1W§:§_-p2U§ = new §_-p2U§("zn");
      
      private var _value:String;
      
      public function §_-p2U§(param1:String)
      {
         super();
         this._value = param1;
      }
      
      public function §_-b2§() : String
      {
         return this._value;
      }
      
      public function equals(param1:§_-p2U§) : Boolean
      {
         return this._value == param1._value;
      }
      
      public function toString() : String
      {
         return this._value;
      }
   }
}


package §_-937§
{
   import §_-02q§.§_-11O§;
   import §_-12W§.§_-221§;
   import §_-23P§.§_-V2T§;
   import §_-23P§.§_-u1z§;
   import §_-31W§.*;
   import §_-62§.*;
   import §_-91A§.§_-sH§;
   import §_-931§.§_-02O§;
   import §_-931§.§_-i2r§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-LE§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-CR§.§_-S2o§;
   import §_-F39§.§_-i1i§;
   import §_-G16§.*;
   import §_-G1h§.MobileMainOverlayScreen;
   import §_-Ly§.§_-7f§;
   import §_-N8§.§_-o2w§;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-J1§;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-yA§;
   import §_-YF§.§_-L29§;
   import §_-YF§.§_-q2v§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-C3A§;
   import §_-k2s§.§_-fG§;
   import §_-l1K§.§_-vO§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import com.greensock.OverwriteManager;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Callout;
   import feathers.controls.LayoutGroup;
   import feathers.controls.Screen;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.TabBar;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.utils.textures.TextureCache;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.display.DisplayObjectContainer;
   import flash.display.Loader;
   import flash.display.MovieClip;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.net.URLRequest;
   import flash.text.TextFieldAutoSize;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import ru.pragmatix.flox.gui.controls.*;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.messages.client.BuyResetBonusItems;
   import ru.pragmatix.wormix.messages.server.BuyResetBonusItemsResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.textures.Texture;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-n1b§ extends Sprite
   {
      
      private static const §_-Z2f§:int = 4;
      
      private var §_-t12§:BitmapData;
      
      private var bitmap:Bitmap;
      
      private var §_-E3q§:LayoutGroup;
      
      private var palette:Image;
      
      private var §_-52c§:Callout;
      
      private var _value:uint;
      
      private var hAlign:String;
      
      private var vAlign:String;
      
      private var touches:Vector.<Touch>;
      
      private var §_-917§:Point;
      
      private var §_-124§:DisplayObject;
      
      private var touch:Touch;
      
      private var §_-T2M§:Quad;
      
      private var tapToTrigger:TapToTrigger;
      
      public function §_-n1b§(param1:int, param2:int, param3:uint = 16777215, param4:String = "right", param5:String = "top")
      {
         super();
         this.hAlign = param4;
         this.vAlign = param5;
         this.§_-T2M§ = new Quad(param1,param2,param3);
         this.§_-T2M§.useHandCursor = true;
         this._value = param3;
         this.§_-E3q§ = new LayoutGroup();
         this.§_-E3q§.backgroundSkin = new Quad(16,16,5391158);
         this.tapToTrigger = new TapToTrigger(this.§_-T2M§);
         this.§_-T2M§.addEventListener(Event.TRIGGERED,this.§_-j2T§);
         addEventListener(Event.ADDED_TO_STAGE,this.§_-j1m§);
      }
      
      private function §_-j2T§(param1:Event) : void
      {
         this.§_-sx§();
      }
      
      private function §_-j1m§(param1:Event) : void
      {
         removeEventListener(Event.ADDED_TO_STAGE,this.§_-j1m§);
         this.init();
      }
      
      private function init() : void
      {
         var _loc1_:String = §_-L29§.§_-f1N§("palette.png");
         var _loc2_:Loader = new Loader();
         _loc2_.load(new URLRequest(_loc1_));
         _loc2_.contentLoaderInfo.addEventListener(Event.COMPLETE,this.§_-Di§);
      }
      
      private function §_-Di§(param1:Object) : void
      {
         addChild(this.§_-T2M§);
         this.bitmap = param1.currentTarget.loader.content as Bitmap;
         this.§_-t12§ = this.bitmap.bitmapData;
         this.palette = new Image(Texture.fromBitmapData(this.§_-t12§));
         this.palette.addEventListener(TouchEvent.TOUCH,this.§_-us§);
         this.§_-E3q§.width = this.palette.width + §_-Z2f§;
         this.§_-E3q§.height = this.palette.height + §_-Z2f§;
         this.palette.x = §_-Z2f§ * 0.5;
         this.palette.y = §_-Z2f§ * 0.5;
         this.§_-E3q§.addChild(this.palette);
      }
      
      private function getColor(param1:int, param2:int) : void
      {
         var _loc3_:uint = uint(this.§_-t12§.getPixel(param1,param2));
         this.value = _loc3_;
         dispatchEventWith(Event.CHANGE,false,_loc3_);
      }
      
      public function set value(param1:uint) : void
      {
         this._value = param1;
         this.§_-T2M§.color = param1;
      }
      
      public function get value() : uint
      {
         return this._value;
      }
      
      private function §_-sx§() : void
      {
         this.§_-52c§ = §_-S2o§.§_-02T§(this.§_-E3q§,this,[RelativePosition.RIGHT,RelativePosition.BOTTOM]);
         this.§_-52c§.closeOnTouchBeganOutside = true;
         this.§_-52c§.closeOnTouchEndedOutside = false;
      }
      
      private function §_-us§(param1:TouchEvent) : void
      {
         var _loc2_:Rectangle = null;
         this.touches = param1.getTouches(stage);
         if(this.touches.length == 1)
         {
            this.touch = this.touches[0];
            this.§_-917§ = Pool.getPoint(this.touch.globalX,this.touch.globalY);
            if(this.touch.phase == TouchPhase.BEGAN)
            {
               _loc2_ = this.palette.getBounds(stage);
               if(!_loc2_.containsPoint(this.§_-917§))
               {
                  Pool.putPoint(this.§_-917§);
                  this.§_-917§ = null;
                  Pool.putRectangle(_loc2_);
                  return;
               }
               Pool.putRectangle(_loc2_);
               this.§_-124§ = this.touch.target;
               this.touch.getLocation(this.palette,this.§_-917§);
               this.getColor(int(this.§_-917§.x),int(this.§_-917§.y));
            }
            else if(this.touch.phase == TouchPhase.ENDED)
            {
               if(stage.hitTest(this.§_-917§) == this.§_-124§)
               {
                  dispatchEventWith(Event.COMPLETE,false,this._value);
               }
            }
            else if(this.touch.phase == TouchPhase.MOVED)
            {
               if(stage.hitTest(this.§_-917§) == this.§_-124§)
               {
                  this.touch.getLocation(this.palette,this.§_-917§);
                  this.getColor(int(this.§_-917§.x),int(this.§_-917§.y));
               }
            }
            Pool.putPoint(this.§_-917§);
            this.§_-917§ = null;
         }
      }
   }
}


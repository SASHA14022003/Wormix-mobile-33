package §_-E1N§
{
   import §_-21p§.§_-4w§;
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-L1r§;
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-q15§;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.*;
   import §_-J31§.§_-e2J§;
   import §_-L1H§.§_-C3e§;
   import §_-N8§.§_-o2w§;
   import §_-SP§.§_-M4§;
   import §_-Y1Q§.§_-F1g§;
   import §_-Z1K§.*;
   import §_-Z1w§.§_-w1D§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.§_-W2D§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2i§.§_-Zd§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-92Q§;
   import config.§_-vR§;
   import dragonBones.Bone;
   import dragonBones.Slot;
   import feathers.controls.Button;
   import feathers.controls.Label;
   import flash.display.DisplayObject;
   import flash.events.MouseEvent;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class §_-H1p§
   {
      
      private var §_-I1B§:Label;
      
      private var §_-r1G§:Label;
      
      private var §_-R3§:Label;
      
      private var §_-xP§:Label;
      
      private var _saveButton:Button;
      
      private var §_-R2z§:int;
      
      public function §_-H1p§(param1:Label, param2:Label, param3:Label, param4:Label, param5:Button)
      {
         super();
         this.§_-I1B§ = param1;
         this.§_-r1G§ = param2;
         this.§_-R3§ = param3;
         this.§_-xP§ = param4;
         this._saveButton = param5;
      }
      
      public function §_-N1n§(param1:int) : void
      {
         this.§_-R2z§ = param1;
         this.update();
      }
      
      public function update() : void
      {
         var _loc1_:§_-92Q§ = §_-92Q§.getLevel(this.§_-R2z§);
         var _loc2_:§_-92Q§ = §_-92Q§.§_-KT§(this.§_-R2z§ + 1);
         this.§_-I1B§.text = String(_loc1_.capacity);
         this.§_-R3§.text = String(_loc1_.§_-52X§);
         if(_loc2_)
         {
            this.§_-r1G§.text = "+" + String(_loc2_.capacity - _loc1_.capacity);
            this.§_-xP§.text = "+" + String(_loc2_.§_-52X§ - _loc1_.§_-52X§);
            this._saveButton.visible = true;
         }
         else
         {
            this.§_-r1G§.text = "";
            this.§_-xP§.text = "";
            this._saveButton.visible = false;
         }
      }
   }
}


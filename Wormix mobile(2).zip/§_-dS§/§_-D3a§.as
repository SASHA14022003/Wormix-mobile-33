package §_-dS§
{
   import §_-62§.§_-T1y§;
   import §_-82l§.§_-A2Y§;
   import §_-91A§.*;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-B1y§.§_-F1P§;
   import §_-C3f§.*;
   import §_-CR§.§_-72p§;
   import §_-U1i§.§_-81M§;
   import §_-b1F§.§_-G4§;
   import §_-g2C§.GlobalChatTextMessageItemRenderer;
   import §_-g2C§.§_-62U§;
   import §_-g2C§.§_-I1R§;
   import §_-g2C§.§_-K2A§;
   import §_-g2C§.§_-K2u§;
   import §_-g2C§.§_-p8§;
   import §_-g2C§.§_-w1K§;
   import §_-l2r§.§_-K1t§;
   import §_-m0§.§_-a1O§;
   import §_-q26§.*;
   import §_-r1C§.§_-h2B§;
   import com.greensock.loading.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import dragonBones.objects.DragonBonesData;
   import feathers.controls.ImageLoader;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.Direction;
   import feathers.layout.FlowLayout;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import feathers.utils.textures.TextureCache;
   import flash.display.StageQuality;
   import flash.events.Event;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-Yp§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.UfoTargetPointer;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   
   use namespace bi_internal;
   
   public class §_-D3a§
   {
      
      private static const §_-333§:String = "levels";
      
      public const §_-e1X§:String = "worm_primary";
      
      public const §_-W2F§:String = "worm_secondary";
      
      public const §_-QG§:String = "mine";
      
      public var id:uint;
      
      public var name:String;
      
      public var className:String;
      
      public var path:String;
      
      public var minLevel:uint;
      
      public var maxLevel:uint;
      
      public var quality:String;
      
      private var §_-41B§:Array = [];
      
      public var §_-FV§:Array = [];
      
      public var §_-42I§:Array = [];
      
      public var §_-P1w§:Array = [];
      
      public var §_-Mr§:Array = [];
      
      public var §_-87§:String;
      
      public var clouds:Object;
      
      public var water:Object;
      
      private var §_-5y§:Boolean;
      
      public var attractiveness:Number;
      
      public var indentHeight:int;
      
      public var §_-s1§:int;
      
      public var §_-5E§:Boolean;
      
      public function §_-D3a§(param1:Object)
      {
         super();
         this.id = param1.id;
         this.name = param1.name;
         this.className = param1.className;
         this.path = §_-Yp§.§_-x27§() + §_-333§ + "/" + param1.name;
         this.§_-87§ = this.path + "/" + (param1.preview ? param1.preview : "preview.png");
         this.§_-5E§ = !param1.notFloodable;
         if(param1.clouds)
         {
            this.clouds = param1.clouds;
         }
         if(param1.water)
         {
            this.water = param1.water;
         }
         if(param1.maxLevel)
         {
            this.maxLevel = param1.maxLevel;
         }
         if(param1.minLevel)
         {
            this.minLevel = param1.minLevel;
         }
         this.attractiveness = 0;
         this.quality = StageQuality.HIGH;
         if(param1.pvpWithFriend == null)
         {
            param1.pvpWithFriend = true;
         }
         if(param1.pvpWager == null)
         {
            param1.pvpWager = true;
         }
         if(param1.mission == null)
         {
            param1.mission = true;
         }
         if(param1.hotSeat == null)
         {
            param1.hotSeat = true;
         }
         this.§_-41B§.push(param1.pvpWithFriend,param1.pvpWager,param1.mission,param1.hotSeat);
         §§push(this);
         param1.indentHeight.indentHeight = 0;
         this.§_-s1§ = param1.indentWight ? int(param1.indentWight) : 0;
      }
      
      public function getId() : uint
      {
         return this.id;
      }
      
      public function isLoaded() : Boolean
      {
         return this.§_-5y§ && (this.§_-FV§ && this.§_-FV§.length > 0 && this.§_-42I§ && this.§_-42I§.length > 0 || Boolean(this.§_-P1w§) && this.§_-P1w§.length > 0);
      }
      
      public function §_-ah§(param1:Boolean) : void
      {
         this.§_-5y§ = param1;
      }
      
      public function §_-p1s§(param1:§_-81M§) : Boolean
      {
         return this.§_-41B§[param1.value];
      }
      
      public function toString() : String
      {
         return "MapRecord{" + "id=" + String(this.id) + ",name=" + String(this.name) + ",className=" + String(this.className) + ",path=" + this.path + ",previewPath=" + this.§_-87§ + ",minLevel=" + this.minLevel + ",maxLevel=" + this.maxLevel + ",quality=" + this.quality + ",availableTypes=" + this.§_-41B§ + ",clouds=" + this.clouds + ",water=" + this.water + ",attractiveness=" + this.attractiveness + ",indentHeight=" + this.indentHeight + ",indentWidth=" + this.§_-s1§ + ",floodable=" + this.§_-5E§ + "}";
      }
   }
}


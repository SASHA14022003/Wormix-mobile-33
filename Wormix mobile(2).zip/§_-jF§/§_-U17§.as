package §_-jF§
{
   import §_-62§.§_-G1p§;
   import §_-73I§.§_-K2s§;
   import §_-A2U§.§_-A23§;
   import §_-F39§.*;
   import §_-L1w§.§_-CD§;
   import §_-R2I§.*;
   import com.greensock.TweenMax;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import feathers.themes.FontColor;
   import feathers.themes.FontSize;
   import flash.text.TextFormatAlign;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.Align;
   
   public class §_-U17§ extends DefaultListItemRenderer
   {
      
      private var §_-r2h§:ITextRenderer;
      
      public function §_-U17§()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasIcon = false;
         this.§_-r2h§ = TextInstanceCreator.createTextRenderer(FontSize.SMALL,FontColor.TAB_UNSELECTED,TextFormatAlign.LEFT);
         this.§_-r2h§.wordWrap = true;
         labelFactory = function():ITextRenderer
         {
            return §_-r2h§;
         };
         accessoryLabelFactory = function():ITextRenderer
         {
            var _loc1_:ITextRenderer = TextInstanceCreator.createTextRenderer(FontSize.SMALL,FontColor.WHITE,TextFormatAlign.RIGHT);
            _loc1_.wordWrap = true;
            _loc1_.minWidth = 50;
            return _loc1_;
         };
         gap = 10;
         accessoryPosition = RelativePosition.RIGHT;
      }
      
      override protected function commitData() : void
      {
         super.commitData();
         this.§_-r2h§.width = data.isDigits ? 175 : Number(NaN);
         var _loc1_:uint = FontColor.TAB_UNSELECTED;
         if(Boolean(_data.interactive) && Boolean(_data.accessoryLabel))
         {
            accessoryLabelProperties.text = "";
            useHandCursor = true;
            _loc1_ = FontColor.BLUE;
         }
         else
         {
            useHandCursor = false;
         }
         §_-R2g§.§_-t8§(this.§_-r2h§,_loc1_);
      }
   }
}


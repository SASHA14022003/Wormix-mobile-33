package §_-A1K§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-62§.§_-G1p§;
   import §_-82l§.§_-A2Y§;
   import §_-91B§.§_-QK§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import §_-P2i§.§_-G3J§;
   import §_-Tm§.§_-RF§;
   import §_-Vu§.§_-ml§;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-v2Q§;
   import §_-hv§.*;
   import §_-jF§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.§_-M2v§;
   import com.hurlant.math.*;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.display.Shape;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   
   use namespace bi_internal;
   
   public class §_-U11§
   {
      
      private static var log:§_-11S§ = new §_-11S§(§_-U11§);
      
      public function §_-U11§()
      {
         super();
      }
      
      public static function §_-E2n§(param1:ByteArray, param2:String) : void
      {
         var _loc3_:ByteArray = new ByteArray();
         _loc3_.writeBytes(param1);
         _loc3_.writeUTFBytes(param2);
         var _loc4_:ByteArray = §_-ml§.hash(_loc3_);
         _loc4_.position = 0;
         param1.writeBytes(_loc4_,0,_loc4_.bytesAvailable);
      }
      
      public static function isSecure(param1:ByteArray, param2:String) : Boolean
      {
         param1.position = 0;
         var _loc3_:ByteArray = new ByteArray();
         param1.readBytes(_loc3_,0,param1.bytesAvailable - 16);
         _loc3_.position = _loc3_.length;
         _loc3_.writeUTFBytes(param2);
         var _loc4_:ByteArray = §_-ml§.hash(_loc3_);
         _loc4_.position = 0;
         var _loc5_:int = 0;
         while(_loc5_ < 16)
         {
            if(_loc4_.readByte() != param1.readByte())
            {
               return false;
            }
            _loc5_++;
         }
         return true;
      }
      
      private static function arrayToString(param1:ByteArray) : String
      {
         var _loc2_:String = "";
         param1.position = 0;
         while(param1.bytesAvailable > 0)
         {
            _loc2_ += " " + param1.readUnsignedByte().toString(16);
         }
         return _loc2_.toLocaleUpperCase();
      }
   }
}


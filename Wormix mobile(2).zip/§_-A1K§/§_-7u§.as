package §_-A1K§
{
   import §_-l1K§.§_-d2j§;
   import dragonBones.Bone;
   import flash.events.MouseEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class §_-7u§
   {
      
      private static const §_-D1u§:int = 13864;
      
      private static const §_-Oy§:int = 60698;
      
      private var §_-mf§:int;
      
      private var §_-w1q§:int;
      
      private var §_-D1l§:int;
      
      public function §_-7u§(param1:Boolean = false)
      {
         super();
         this.§_-w1q§ = int(Math.floor(§_-D1u§ + (§_-Oy§ - §_-D1u§) * Math.random()));
         this.§_-D1l§ = this.§_-w1q§ + int(Math.floor(§_-D1u§ + (§_-Oy§ - §_-D1u§) * Math.random()));
         this.§_-mf§ = param1 ? this.§_-D1l§ : this.§_-w1q§;
      }
      
      public function get value() : Boolean
      {
         return this.§_-mf§ == this.§_-D1l§;
      }
      
      public function set value(param1:Boolean) : void
      {
         this.§_-mf§ = param1 ? this.§_-D1l§ : this.§_-w1q§;
      }
   }
}


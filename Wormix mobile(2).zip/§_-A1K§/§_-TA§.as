package §_-A1K§
{
   import §_-21p§.§_-4w§;
   import §_-62§.§_-L1r§;
   import §_-B1y§.§_-F1P§;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-fo§.§_-r5§;
   import §_-k13§.§_-j23§;
   import §_-sQ§.§_-V1n§;
   import §_-t10§.*;
   import §_-zI§.§_-F3q§;
   import feathers.controls.List;
   import feathers.core.FeathersControl;
   import feathers.data.ListCollection;
   import flash.display.MovieClip;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.LinkResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.utils.*;
   import starling.events.Event;
   
   public class §_-TA§
   {
      
      private static const §_-D1u§:int = -59748151;
      
      private static const §_-Oy§:int = 82162342;
      
      private var §_-mf§:int;
      
      private var §_-W2I§:int;
      
      public function §_-TA§(param1:int = 0)
      {
         super();
         this.§_-W2I§ = int(Math.floor(§_-D1u§ + (§_-Oy§ - §_-D1u§) * Math.random()));
         this.§_-mf§ = param1 ^ this.§_-W2I§;
      }
      
      public function get value() : int
      {
         return this.§_-mf§ ^ this.§_-W2I§;
      }
      
      public function set value(param1:int) : void
      {
         this.§_-mf§ = param1 ^ this.§_-W2I§;
      }
   }
}


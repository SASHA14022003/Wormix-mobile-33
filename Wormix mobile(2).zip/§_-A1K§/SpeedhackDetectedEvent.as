package §_-A1K§
{
   import §_-62§.§_-F1D§;
   import §_-63k§.*;
   import §_-S1N§.§_-RO§;
   import §_-T1t§.§_-u19§;
   import §_-ZP§.§_-w1J§;
   import §_-d26§.§_-d1H§;
   import §_-l1g§.§_-L3Q§;
   import §_-qH§.§_-S25§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.§_-J2g§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-z20§.*;
   import com.hurlant.math.*;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.NotifyProfile;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.wager.WagerBattleRequestError;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   public class SpeedhackDetectedEvent extends flash.events.Event
   {
      
      public static const §_-12g§:String = "SpeedhackDetected";
      
      public function SpeedhackDetectedEvent(param1:Boolean = false, param2:Boolean = true)
      {
         super(§_-12g§,param1,param2);
      }
      
      override public function clone() : flash.events.Event
      {
         return new SpeedhackDetectedEvent(bubbles,cancelable);
      }
      
      override public function toString() : String
      {
         return formatToString("SpeedhackDetectedEvent","type","bubbles","cancelable","eventPhase");
      }
   }
}


package §_-A1K§
{
   import §_-52V§.§_-R9§;
   import §_-bI§.*;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-q26§.*;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import flash.events.Event;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   
   public class §_-LE§
   {
      
      private var §_-mf§:Number;
      
      private var §_-h2H§:Number;
      
      private var §_-If§:Number;
      
      public function §_-LE§(param1:Number = 0, param2:int = 0)
      {
         super();
         this.§_-h2H§ = Math.random() * 7.37252 + 0.137329;
         this.§_-If§ = Math.random() * 273.498 + 92.48038;
         this.§_-mf§ = param1 * this.§_-h2H§ + this.§_-If§;
      }
      
      public function get value() : Number
      {
         return (this.§_-mf§ - this.§_-If§) / this.§_-h2H§;
      }
      
      public function set value(param1:Number) : void
      {
         this.§_-mf§ = param1 * this.§_-h2H§ + this.§_-If§;
      }
   }
}


package §_-bI§
{
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   
   public class §_-n2F§ extends PlayerRatingItemRenderer
   {
      
      public function §_-n2F§()
      {
         super();
      }
      
      override protected function §_-Zp§(param1:RatingProfileStructure) : int
      {
         return param1.dailyRating;
      }
   }
}


package §_-bI§
{
   import §_-SP§.§_-M4§;
   import §_-Vg§.*;
   import feathers.controls.List;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   
   public class PlayerRatingItemRenderer extends DefaultListItemRenderer
   {
      
      private static const §_-32o§:String = "player_rating_item_renderer";
      
      private var binder:Binder;
      
      public function PlayerRatingItemRenderer()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         itemHasLabel = false;
         itemHasIcon = false;
         itemHasAccessory = false;
         isQuickHitAreaEnabled = true;
         this.binder = new Binder();
         var _loc1_:Object = Application.assetManager.getObject(§_-32o§);
         Application.uiBuilder.create(_loc1_,true,this.binder);
         defaultAccessory = this.binder._container;
         this.binder._posDeltaIcon.maintainAspectRatio = true;
         this.binder._posDeltaIcon.scaleMode = ScaleMode.SHOW_ALL;
      }
      
      override protected function commitData() : void
      {
         var _loc1_:RatingProfileStructure = _data ? _data.rps as RatingProfileStructure : null;
         var _loc2_:int = _data ? int(_data.pos as int) : 0;
         if(_loc1_)
         {
            this.binder._name.text = _loc1_.name;
            this.binder._ratingValue.text = this.§_-Zp§(_loc1_).toString();
            §_-c1S§.§_-MU§(_loc2_,this.binder._posValue,null);
            §_-c1S§.§_-62q§(_loc2_,_loc1_.oldPlace,this.binder._posDeltaValue,20,this.binder._posDeltaIcon,false);
         }
         else
         {
            this.binder._name.text = "";
            this.binder._ratingValue.text = "";
            this.binder._posValue.text = "";
            this.binder._posDeltaValue.text = "";
            this.binder._posDeltaIcon.source = "";
         }
      }
      
      protected function §_-Zp§(param1:RatingProfileStructure) : int
      {
         return 0;
      }
      
      override protected function draw() : void
      {
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_SIZE) && Boolean(_owner))
         {
            this.binder._container.width = _owner.width;
         }
      }
      
      override public function set owner(param1:List) : void
      {
         super.owner = param1;
         invalidate(INVALIDATION_FLAG_SIZE);
      }
   }
}

import feathers.controls.ImageLoader;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;

class Binder
{
   
   public var _container:LayoutGroup;
   
   public var _posDeltaIcon:ImageLoader;
   
   public var _posValue:Label;
   
   public var _posDeltaValue:Label;
   
   public var _name:Label;
   
   public var _ratingValue:Label;
   
   public function Binder()
   {
      super();
   }
}

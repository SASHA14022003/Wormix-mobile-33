package §_-bI§
{
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   
   public class §_-E8§ extends PlayerRatingItemRenderer
   {
      
      public function §_-E8§()
      {
         super();
      }
      
      override protected function §_-Zp§(param1:RatingProfileStructure) : int
      {
         return param1.rating;
      }
   }
}


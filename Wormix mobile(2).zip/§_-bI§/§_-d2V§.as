package §_-bI§
{
   import §_-z1g§.§_-Uc§;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   
   public class §_-d2V§ extends OwnerRatingItemRenderer
   {
      
      public function §_-d2V§()
      {
         super();
      }
      
      override protected function commitData() : void
      {
         var _loc1_:GetRatingResult = null;
         if(Boolean(_data) && Boolean(_data.owner) && Boolean(§_-Uc§.§_-Fp§(_data.owner as UserProfile)))
         {
            binder._container.visible = true;
            _loc1_ = _data.result as GetRatingResult;
            binder._name.text = _data.owner.getCharName();
            binder._ratingValue.text = _loc1_.rating.toString();
            §_-c1S§.§_-MU§(_loc1_.place,binder._posValue,null);
            §_-c1S§.§_-62q§(_loc1_.place,_loc1_.oldPlace,binder._posDeltaValue,20,binder._posDeltaIcon,false);
         }
         else
         {
            binder._container.visible = false;
            binder._name.text = "";
            binder._ratingValue.text = "";
            binder._posValue.text = "";
            binder._posDeltaValue.text = "";
            binder._posDeltaIcon.source = "";
         }
      }
   }
}


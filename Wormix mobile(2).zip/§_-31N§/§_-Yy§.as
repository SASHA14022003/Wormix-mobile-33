package §_-31N§
{
   import §_-B2z§.§_-63i§;
   import §_-Y1O§.*;
   import §_-Y1b§.*;
   import §_-r1C§.§_-h2B§;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.response.ListClansResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import starling.events.Event;
   
   public class §_-Yy§ extends Event
   {
      
      public var §_-33i§:§_-F3o§ = null;
      
      public var subject:§_-F3o§;
      
      public var §_-K1l§:Boolean = false;
      
      public function §_-Yy§(param1:§_-F3o§, param2:String = "beforeHit", param3:Boolean = false, param4:Boolean = false)
      {
         super(param2,param3,param4);
         this.subject = param1;
      }
      
      public function clone() : §_-Yy§
      {
         var _loc1_:§_-Yy§ = new §_-Yy§(this.subject,type,bubbles,false);
         _loc1_.§_-33i§ = this.§_-33i§;
         _loc1_.§_-K1l§ = this.§_-K1l§;
         return _loc1_;
      }
   }
}


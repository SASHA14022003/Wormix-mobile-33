package §_-31N§
{
   import §_-12a§.§_-41b§;
   import §_-dS§.§_-D3a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   
   public class §_-42G§
   {
      
      public static const §_-K2J§:String = "stable";
      
      public static const §_-o1a§:String = "unstable";
      
      public static const §_-Lz§:String = "falling";
      
      public static const §_-G36§:String = "hit_wall";
      
      public static const §_-X1C§:String = "stop_moving";
      
      public static const §_-XQ§:String = "bounce";
      
      public function §_-42G§()
      {
         super();
      }
   }
}


package §_-fo§
{
   import §_-31N§.§_-42G§;
   import §_-31W§.§_-Kb§;
   import §_-43V§.*;
   import §_-9§.§_-52A§;
   import §_-91A§.§_-Wy§;
   import §_-931§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-Cl§.*;
   import §_-N8§.*;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-hK§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-k1u§.§_-2m§;
   import §_-l1g§.§_-L3Q§;
   import §_-lh§.§_-z2A§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-sQ§.§_-G1Y§;
   import §_-sQ§.§_-i1a§;
   import §_-u2J§.§_-T1K§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-lp§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.inappbilling.Product;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import flash.display.DisplayObject;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.geom.Point;
   import flash.media.Sound;
   import flash.text.Font;
   import flash.utils.ByteArray;
   import flash.utils.setInterval;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.messages.clans.response.PromoteRankInClanResponse;
   import ru.pragmatix.wormix.messages.client.GetFriendsForBoss;
   import ru.pragmatix.wormix.messages.server.GetFriendsForBossResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.GenericPhysicModel;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-21L§
   {
      
      public static const log:§_-11S§ = new §_-11S§(§_-21L§);
      
      protected var className:String;
      
      protected var §_-G1U§:Class;
      
      protected var x:int;
      
      protected var y:int;
      
      protected var width:int;
      
      protected var height:int;
      
      protected var color:int;
      
      protected var scale:Number;
      
      public function §_-21L§()
      {
         super();
      }
      
      public function getClassName() : String
      {
         return this.className;
      }
      
      public function §_-h1p§(param1:String) : void
      {
         this.className = param1;
      }
      
      public function getClass() : Class
      {
         return this.§_-G1U§;
      }
      
      public function §_-11t§(param1:Class) : void
      {
         this.§_-G1U§ = param1;
      }
      
      public function §_-CE§() : int
      {
         return this.x;
      }
      
      public function §_-625§(param1:int) : void
      {
         this.x = param1;
      }
      
      public function §_-G1g§() : int
      {
         return this.y;
      }
      
      public function §_-db§(param1:int) : void
      {
         this.y = param1;
      }
      
      public function §_-Z27§() : int
      {
         return this.width;
      }
      
      public function §_-UD§(param1:int) : void
      {
         this.width = param1;
      }
      
      public function §_-43p§() : int
      {
         return this.height;
      }
      
      public function §_-HP§(param1:int) : void
      {
         this.height = param1;
      }
      
      public function getColor() : int
      {
         return this.color;
      }
      
      public function setColor(param1:int) : void
      {
         this.color = param1;
      }
      
      public function getScale() : Number
      {
         return this.scale;
      }
      
      public function §_-iB§(param1:Number) : void
      {
         this.scale = param1;
      }
      
      public function §_-tF§() : MovieClip
      {
         return this.§_-WB§() as MovieClip;
      }
      
      public function §_-S2z§() : SimpleButton
      {
         return this.§_-WB§() as SimpleButton;
      }
      
      public function §_-nq§() : Font
      {
         Font.registerFont(this.getClass());
         return new (this.getClass())() as Font;
      }
      
      private function §_-WB§() : flash.display.DisplayObject
      {
         var _loc2_:flash.display.DisplayObject = null;
         var _loc1_:Class = this.getClass();
         if(_loc1_)
         {
            _loc2_ = new (this.getClass())() as flash.display.DisplayObject;
            if(this.x)
            {
               _loc2_.x = this.x;
            }
            if(this.y)
            {
               _loc2_.y = this.y;
            }
            if(this.width)
            {
               _loc2_.width = this.width;
            }
            if(this.height)
            {
               _loc2_.height = this.height;
            }
            if(this.color)
            {
               §_-i1a§.setColor(_loc2_,this.color);
            }
            if(this.scale)
            {
               _loc2_.scaleX = this.scale;
               _loc2_.scaleY = this.scale;
            }
            return _loc2_;
         }
         log.§_-M2b§("Resource \'" + this.className + "\'class is null");
         return null;
      }
      
      public function §_-U22§() : Sound
      {
         return new (this.getClass())() as Sound;
      }
      
      public function apply(param1:§_-21L§) : void
      {
         this.§_-G1U§ = param1.§_-G1U§;
         if(!this.x)
         {
            this.x = param1.x;
         }
         if(!this.y)
         {
            this.y = param1.y;
         }
         if(!this.width)
         {
            this.width = param1.width;
         }
         if(!this.height)
         {
            this.height = param1.height;
         }
      }
   }
}


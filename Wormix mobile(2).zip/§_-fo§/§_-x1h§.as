package §_-fo§
{
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-MQ§;
   import §_-B1y§.§_-bs§;
   import §_-B1y§.§_-fM§;
   import §_-CF§.§_-p2U§;
   import §_-H2g§.§_-di§;
   import §_-Z1K§.§_-q24§;
   import §_-hO§.§_-729§;
   import §_-k1u§.§_-2m§;
   import §_-l2r§.§_-K1t§;
   import §_-qH§.*;
   import §_-s20§.§_-J2g§;
   import §_-z1g§.§_-lp§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import dragonBones.animation.WorldClock;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.system.LoaderContext;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.messages.clans.main.server.GetJoinClansMainRequest;
   import ru.pragmatix.wormix.messages.clans.response.GetJoinClansMainResponse;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-x1h§ extends AbstractConfigLoader
   {
      
      private static const _log:§_-11S§ = new §_-11S§(§_-x1h§);
      
      private var language:§_-p2U§;
      
      protected var messages:Object = {};
      
      private var §_-gz§:§_-p2U§;
      
      private var §_-O2B§:Vector.<String> = new Vector.<String>();
      
      private var §_-V2U§:String;
      
      public function §_-x1h§(param1:§_-p2U§, param2:String, param3:String, param4:LoaderContext, param5:Vector.<String>, param6:String = "")
      {
         super(param2,param3,param5,§_-v2P§.XML,param4);
         §_-fM§.copy(param5,this.§_-O2B§);
         if(!param6)
         {
            param6 = "";
         }
         this.§_-V2U§ = param6.indexOf("_") != 0 ? param6 : "_" + param6;
         this.setLanguage(param1);
      }
      
      public function §_-I9§() : §_-p2U§
      {
         return this.language;
      }
      
      public function setLanguage(param1:§_-p2U§) : void
      {
         if(this.§_-G32§(param1))
         {
            this.language = param1;
         }
         else
         {
            this.§_-gz§ = param1;
         }
      }
      
      override public function load() : void
      {
         var _loc1_:Vector.<String> = null;
         var _loc2_:String = null;
         if(this.§_-gz§)
         {
            _loc1_ = new Vector.<String>();
            for each(_loc2_ in this.§_-O2B§)
            {
               _loc1_.push(_loc2_ + "_" + this.§_-gz§.§_-b2§() + this.§_-V2U§ + ".xml");
            }
            this.§_-t1k§ = _loc1_;
            super.load();
         }
         else
         {
            dispatchEvent(new flash.events.Event(flash.events.Event.COMPLETE));
         }
      }
      
      public function §_-G32§(param1:§_-p2U§) : Boolean
      {
         return this.messages[param1.§_-b2§()];
      }
      
      override protected function §_-x2s§() : void
      {
         if(this.§_-gz§)
         {
            this.language = this.§_-gz§;
            this.§_-gz§ = null;
         }
      }
      
      override protected function §_-v1c§(param1:XML, param2:String) : void
      {
         var _loc3_:XML = null;
         var _loc4_:String = null;
         XML.ignoreWhitespace = true;
         if(!this.messages[this.§_-gz§.§_-b2§()])
         {
            this.messages[this.§_-gz§.§_-b2§()] = {};
         }
         for each(_loc3_ in param1..message)
         {
            _loc4_ = _loc3_.@name.toString();
            this.messages[this.§_-gz§.§_-b2§()][_loc4_] = this.§_-Xs§(_loc3_);
         }
      }
      
      protected function §_-Xs§(param1:XML) : String
      {
         var _loc2_:String = null;
         if(param1.@value.toString())
         {
            _loc2_ = param1.@value.toString();
         }
         else
         {
            _loc2_ = param1.toString();
         }
         return §_-F1P§.trim(_loc2_);
      }
      
      override protected function get log() : §_-11S§
      {
         return _log;
      }
   }
}


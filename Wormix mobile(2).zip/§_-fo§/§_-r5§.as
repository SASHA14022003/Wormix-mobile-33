package §_-fo§
{
   import §_-5Y§.§_-t2O§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-P14§;
   import §_-73I§.§_-q15§;
   import §_-82l§.§_-A2Y§;
   import §_-91B§.§_-z2l§;
   import §_-9e§.§_-73e§;
   import §_-CF§.§_-E19§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-G2H§.*;
   import §_-H2g§.§_-di§;
   import §_-HD§.*;
   import §_-Y1Q§.§_-tc§;
   import §_-aM§.§_-P1N§;
   import §_-d26§.§_-d1H§;
   import §_-eO§.§_-yH§;
   import §_-hO§.§_-v24§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.*;
   import §_-p14§.§_-A3Y§;
   import §_-qH§.§_-AC§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.NumericStepper;
   import feathers.layout.RelativePosition;
   import flash.display.MovieClip;
   import flash.display.SimpleButton;
   import flash.errors.IllegalOperationError;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.media.Sound;
   import flash.system.LoaderContext;
   import flash.text.Font;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-b1g§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-s1V§;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.server.AssembleStuffResult;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-g20§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-r5§ extends §_-5V§
   {
      
      public static var instance:§_-r5§;
      
      private static const _log:§_-11S§ = new §_-11S§(§_-r5§);
      
      private var classes:Object = new Object();
      
      public function §_-r5§(param1:String, param2:String, param3:Vector.<String>, param4:LoaderContext)
      {
         super(param1,param2,param3,param4);
         instance = this;
      }
      
      public static function contains(param1:String) : Boolean
      {
         return §_-r5§.instance.contains(param1);
      }
      
      public static function getClass(param1:String) : Class
      {
         var _loc2_:§_-21L§ = §_-739§(param1);
         if(_loc2_)
         {
            return _loc2_.getClass();
         }
         return null;
      }
      
      public static function §_-tF§(param1:String) : MovieClip
      {
         var _loc2_:§_-21L§ = §_-739§(param1);
         if(_loc2_)
         {
            return _loc2_.§_-tF§();
         }
         return null;
      }
      
      public static function §_-S2z§(param1:String) : SimpleButton
      {
         var _loc2_:§_-21L§ = §_-739§(param1);
         if(_loc2_)
         {
            return _loc2_.§_-S2z§();
         }
         return null;
      }
      
      public static function §_-nq§(param1:String) : Font
      {
         var _loc2_:§_-21L§ = §_-739§(param1);
         if(_loc2_)
         {
            return _loc2_.§_-nq§();
         }
         return null;
      }
      
      public static function §_-U22§(param1:String) : Sound
      {
         var _loc2_:§_-21L§ = §_-739§(param1);
         if(_loc2_)
         {
            return _loc2_.§_-U22§();
         }
         return null;
      }
      
      public static function §_-739§(param1:String) : §_-21L§
      {
         return §_-r5§.instance.§_-739§(param1);
      }
      
      public static function §_-f18§(param1:String, param2:§_-21L§) : void
      {
         §_-r5§.instance.classes[param1] = param2;
      }
      
      public static function §_-GH§(param1:Vector.<String>, param2:Function, param3:Function, param4:Boolean = false) : void
      {
         §_-r5§.instance.§_-GH§(param1,param2,param3,param4);
      }
      
      public static function §_-iX§(param1:String, param2:Function, param3:Function, param4:Boolean = false) : void
      {
         §_-r5§.instance.§_-GH§(new <String>[param1],param2,param3,param4);
      }
      
      public static function §_-a4§(param1:Vector.<§_-A29§>, param2:Function, param3:Function, param4:Boolean = false) : void
      {
         §_-r5§.instance.§_-a4§(param1,param2,param3,param4);
      }
      
      public static function §_-F35§(param1:§_-A29§, param2:Function, param3:Function, param4:Boolean = false) : void
      {
         §_-r5§.§_-a4§(new <§_-A29§>[param1],param2,param3,param4);
      }
      
      public function contains(param1:String) : Boolean
      {
         return this.classes[param1] != null;
      }
      
      public function §_-739§(param1:String) : §_-21L§
      {
         var _loc2_:§_-21L§ = §_-21L§(this.classes[param1]);
         if(!_loc2_)
         {
            this.log.§_-M2b§("resource not found: " + param1);
         }
         return _loc2_;
      }
      
      override protected function progressHandler(param1:LoaderEvent) : void
      {
         super.progressHandler(param1);
         var _loc2_:Number = Number(Number(param1.target.bytesLoaded / param1.target.bytesTotal * 70));
         §_-yH§.publish(_loc2_ + 10);
      }
      
      override protected function §_-u1p§(param1:§_-21L§) : void
      {
         this.classes[param1.getClassName()] = param1;
      }
      
      public function §_-GH§(param1:Vector.<String>, param2:Function, param3:Function, param4:Boolean = false) : void
      {
         var _loc6_:String = null;
         var _loc5_:Vector.<§_-A29§> = new Vector.<§_-A29§>(0);
         for each(_loc6_ in param1)
         {
            _loc5_.push(this.§_-wX§(_loc6_));
         }
         §_-a4§(_loc5_,param2,param3,param4);
      }
      
      private function §_-K2v§(param1:String) : §_-A29§
      {
         var _loc2_:§_-A29§ = null;
         var _loc3_:§_-21L§ = null;
         for each(_loc2_ in §_-K1g§)
         {
            for each(_loc3_ in _loc2_.resources)
            {
               if(_loc3_.getClassName() == param1)
               {
                  return _loc2_;
               }
            }
         }
         return null;
      }
      
      private function §_-wX§(param1:String) : §_-A29§
      {
         var _loc2_:§_-A29§ = null;
         for each(_loc2_ in §_-K1g§)
         {
            if(_loc2_.name == param1)
            {
               return _loc2_;
            }
         }
         this.log.§_-M2b§("library not found by name " + param1 + " in config " + §_-X2H§);
         throw new IllegalOperationError("library not found by name " + param1 + " in config " + §_-X2H§);
      }
      
      override protected function get log() : §_-11S§
      {
         return _log;
      }
   }
}


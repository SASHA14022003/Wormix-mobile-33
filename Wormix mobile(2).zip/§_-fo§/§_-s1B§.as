package §_-fo§
{
   import §_-Y1O§.*;
   import feathers.core.ITextRenderer;
   import flash.text.TextFormat;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.events.Event;
   
   public class §_-s1B§ extends §_-A29§
   {
      
      public function §_-s1B§()
      {
         super();
      }
      
      override public function §_-51m§() : Boolean
      {
         return true;
      }
   }
}


package §_-fo§
{
   import §_-A1K§.§_-TA§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import starling.textures.Texture;
   
   public class §_-v2P§
   {
      
      public static var XML:§_-v2P§ = new §_-v2P§("XML");
      
      public static var JSON:§_-v2P§ = new §_-v2P§("JSON");
      
      public var value:String;
      
      public function §_-v2P§(param1:String)
      {
         super();
         this.value = param1;
      }
   }
}


package §_-fo§
{
   import §_-A1K§.§_-7u§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-gG§.§_-M2S§;
   import §_-l1K§.§_-d2j§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import feathers.controls.List;
   import flash.events.Event;
   import flash.text.TextField;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.rules.§_-Q2u§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   
   public class §_-hH§ extends Event
   {
      
      public static var LOAD_ERROR:String = "LOAD_ERROR";
      
      public var msg:String;
      
      public function §_-hH§(param1:String = "Load Error")
      {
         super(LOAD_ERROR);
         this.msg = param1;
      }
      
      override public function clone() : Event
      {
         return new §_-hH§(this.msg);
      }
   }
}


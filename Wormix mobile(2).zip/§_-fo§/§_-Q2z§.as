package §_-fo§
{
   import §_-62§.§_-G1p§;
   import §_-CR§.§_-S2o§;
   import §_-F39§.*;
   import §_-GQ§.§_-31v§;
   import §_-K35§.§_-S18§;
   import §_-Y1O§.*;
   import §_-k1u§.§_-Vr§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-nZ§.*;
   import §_-p24§.*;
   import §_-rM§.§_-61j§;
   import §_-sQ§.§_-H3D§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.§_-lp§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import dragonBones.animation.WorldClock;
   import feathers.controls.List;
   import feathers.core.PopUpManager;
   import flash.geom.Point;
   import flash.system.LoaderContext;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.messages.server.LinkResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.events.Event;
   
   public class §_-Q2z§ extends AbstractConfigLoader
   {
      
      protected static const _log:§_-11S§ = new §_-11S§(§_-Q2z§);
      
      private var libs:Vector.<§_-A29§> = new Vector.<§_-A29§>();
      
      public function §_-Q2z§(param1:String, param2:String, param3:Vector.<String>, param4:LoaderContext)
      {
         super(param1,param2,param3,§_-v2P§.XML,param4);
      }
      
      override protected function §_-v1c§(param1:XML, param2:String) : void
      {
         §_-03l§("parse loaded config file " + param2);
         this.libs = this.libs.concat(this.§_-o8§(param1));
         this.libs = this.libs.concat(this.§_-337§(param1));
         §_-03l§("parse loaded config file \'" + param2 + "\' done");
      }
      
      protected function §_-o8§(param1:XML) : Vector.<§_-A29§>
      {
         var _loc3_:XML = null;
         var _loc4_:§_-21L§ = null;
         var _loc5_:§_-A29§ = null;
         var _loc2_:Vector.<§_-A29§> = new Vector.<§_-A29§>(0);
         for each(_loc3_ in param1.resource)
         {
            _loc4_ = this.§_-W1§(_loc3_);
            _loc5_ = new §_-A29§();
            _loc5_.name = _loc3_.@name.toString() || this.§_-T1D§(_loc3_.@path);
            _loc5_.§_-yC§ = _loc3_.@path.toString();
            _loc5_.§_-o7§ = §_-o7§;
            _loc5_.§_-j24§ = §_-h1k§;
            _loc5_.estimatedBytes = parseInt(_loc3_.@estimatedBytes);
            _loc5_.resources.push(_loc4_);
            _loc5_.§_-jp§ = _loc3_.@lazy.toString() == "true";
            _loc2_.push(_loc5_);
         }
         return _loc2_;
      }
      
      protected function §_-337§(param1:XML) : Vector.<§_-A29§>
      {
         var _loc3_:XML = null;
         var _loc4_:§_-A29§ = null;
         var _loc2_:Vector.<§_-A29§> = new Vector.<§_-A29§>(0);
         for each(_loc3_ in param1.library)
         {
            _loc4_ = this.§_-d2U§(_loc3_,new §_-A29§());
            _loc2_.push(_loc4_);
         }
         for each(_loc3_ in param1.sound)
         {
            _loc4_ = this.§_-d2U§(_loc3_,new §_-s1B§());
            _loc2_.push(_loc4_);
         }
         return _loc2_;
      }
      
      private function §_-d2U§(param1:XML, param2:§_-A29§) : §_-A29§
      {
         var _loc3_:XML = null;
         var _loc4_:§_-21L§ = null;
         param2.name = param1.@name.toString() || this.§_-T1D§(param1.@path);
         param2.§_-yC§ = param1.@path;
         param2.§_-o7§ = §_-o7§;
         param2.§_-j24§ = §_-h1k§;
         param2.ns = param1.@ns.toString() == "null" ? "" : param1.@ns;
         param2.estimatedBytes = parseInt(param1.@estimatedBytes);
         for each(_loc3_ in param1..resource)
         {
            _loc4_ = this.§_-W1§(_loc3_);
            param2.resources.push(_loc4_);
         }
         param2.§_-jp§ = param1.@lazy.toString() == "true";
         return param2;
      }
      
      private function §_-T1D§(param1:String) : String
      {
         var _loc2_:int = int(param1.lastIndexOf("/"));
         if(_loc2_ < 0)
         {
            _loc2_ = 0;
         }
         else
         {
            _loc2_++;
         }
         var _loc3_:int = int(param1.lastIndexOf("."));
         return param1.slice(_loc2_,_loc3_);
      }
      
      protected function §_-W1§(param1:XML) : §_-21L§
      {
         var _loc2_:§_-21L§ = new §_-21L§();
         this.§_-G19§(_loc2_,param1);
         return _loc2_;
      }
      
      protected function §_-G19§(param1:§_-21L§, param2:XML) : void
      {
         param1.§_-h1p§(param2.@className.toString());
         param1.§_-625§(int(param2.@x.toString()));
         param1.§_-db§(int(param2.@y.toString()));
         param1.§_-UD§(int(param2.@width.toString()));
         param1.§_-HP§(int(param2.@height.toString()));
         param1.setColor(int(param2.@color.toString()));
         param1.§_-iB§(parseFloat(param2.@scale.toString()));
      }
      
      public function §_-D2r§() : Vector.<§_-A29§>
      {
         return this.libs;
      }
      
      override protected function get log() : §_-11S§
      {
         return _log;
      }
   }
}


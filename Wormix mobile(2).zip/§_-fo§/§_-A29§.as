package §_-fo§
{
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-ou§;
   import §_-62§.§_-zF§;
   import §_-L2F§.§_-D2p§;
   import §_-Ty§.§_-K3a§;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   
   public class §_-A29§
   {
      
      public var name:String;
      
      public var estimatedBytes:int;
      
      public var resources:Array = [];
      
      public var §_-o7§:String;
      
      public var §_-yC§:String;
      
      public var §_-j24§:String;
      
      public var §_-jp§:Boolean;
      
      public var ns:String = "";
      
      public function §_-A29§()
      {
         super();
      }
      
      public function §_-51m§() : Boolean
      {
         return false;
      }
      
      public function get §_-c2Z§() : String
      {
         return this.§_-yC§;
      }
   }
}


package §_-fo§
{
   import §_-03T§.§_-K3B§;
   import §_-21p§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B2z§.§_-63i§;
   import §_-H2g§.§_-s1d§;
   import §_-J3L§.§_-h1D§;
   import §_-OA§.§_-k2K§;
   import §_-T2h§.*;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-d26§.§_-c2E§;
   import §_-d26§.§_-d1H§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-s20§.§_-6a§;
   import §_-s20§.§_-J2g§;
   import §_-sK§.*;
   import §_-sQ§.§_-H3D§;
   import §_-y1s§.§_-O1z§;
   import §_-z1g§.*;
   import §_-zI§.§_-sI§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.DataLoader;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.XMLLoader;
   import com.hurlant.crypto.tls.*;
   import feathers.data.ArrayCollection;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.system.LoaderContext;
   import flash.system.System;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.profilePage.IProfilePageShower;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.SteamProductsInfoResponse;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.SteamProductInfoStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpActionEx;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.events.Event;
   
   public class AbstractConfigLoader extends §_-K3B§
   {
      
      protected var §_-o7§:String;
      
      protected var §_-h1k§:String;
      
      protected var dataFormat:§_-v2P§;
      
      public var §_-t1k§:Vector.<String>;
      
      private var queue:LoaderMax;
      
      protected var context:LoaderContext;
      
      public function AbstractConfigLoader(param1:String, param2:String, param3:Vector.<String>, param4:§_-v2P§, param5:LoaderContext)
      {
         super();
         this.§_-o7§ = param1;
         this.§_-h1k§ = param2;
         this.§_-t1k§ = param3;
         this.dataFormat = param4 ? param4 : §_-v2P§.XML;
         this.context = param5;
      }
      
      public function load() : void
      {
         var _loc1_:String = null;
         this.queue = new LoaderMax({
            "auditSize":false,
            "maxConnections":1,
            "onComplete":this.§_-03Z§,
            "onError":this.errorHandler,
            "context":this.context
         });
         for each(_loc1_ in this.§_-t1k§)
         {
            this.§_-Z2u§(_loc1_);
         }
         this.queue.load();
      }
      
      protected function §_-Z2u§(param1:String) : void
      {
         this.§_-03l§("start loading configFile:" + param1);
         var _loc2_:String = this.§_-o7§ + param1;
         var _loc3_:String = this.§_-h1k§ + param1;
         if(this.dataFormat == §_-v2P§.XML)
         {
            this.queue.append(new XMLLoader(_loc2_,{
               "name":param1,
               "alternateURL":_loc3_,
               "context":this.context
            }));
         }
         else
         {
            this.queue.append(new DataLoader(_loc2_,{
               "name":param1,
               "alternateURL":_loc3_,
               "context":this.context
            }));
         }
      }
      
      private function §_-03Z§(param1:LoaderEvent) : void
      {
         var _loc2_:String = null;
         var _loc3_:XML = null;
         var _loc4_:Object = null;
         switch(this.dataFormat.value)
         {
            case §_-v2P§.XML.value:
               for each(_loc2_ in this.§_-t1k§)
               {
                  this.§_-03l§("configFile load complete:" + _loc2_);
                  _loc3_ = new XML(LoaderMax.getContent(_loc2_));
                  this.§_-v1c§(_loc3_,_loc2_);
                  System.disposeXML(_loc3_);
               }
               break;
            case §_-v2P§.JSON.value:
               for each(_loc2_ in this.§_-t1k§)
               {
                  this.§_-03l§("configFile load complete:" + _loc2_);
                  _loc4_ = new §_-k2K§(LoaderMax.getContent(_loc2_)).getValue();
                  this.§_-H3t§(_loc4_,_loc2_);
               }
         }
         this.§_-116§();
      }
      
      protected function §_-v1c§(param1:XML, param2:String) : void
      {
         throw new IllegalOperationError();
      }
      
      protected function §_-H3t§(param1:Object, param2:String) : void
      {
         throw new IllegalOperationError();
      }
      
      private function errorHandler(param1:LoaderEvent) : void
      {
         this.log.§_-E2X§("configFile load fail. error message: " + param1.text);
         if(param1.target is XMLLoader)
         {
            if(XMLLoader(param1.target).status == LoaderStatus.FAILED)
            {
               this.onFail(param1.text);
            }
         }
         else if(param1.target is DataLoader)
         {
            if(DataLoader(param1.target).status == LoaderStatus.FAILED)
            {
               this.onFail(param1.text);
            }
         }
      }
      
      protected function onFail(param1:String) : void
      {
         this.log.error("configFile load fail. error message: " + param1);
         dispatchEvent(new §_-hH§(param1));
         this.queue.dispose(true);
      }
      
      private function §_-116§() : void
      {
         this.queue.dispose(true);
         this.§_-x2s§();
         dispatchEvent(new flash.events.Event(flash.events.Event.COMPLETE));
      }
      
      protected function §_-x2s§() : void
      {
      }
      
      protected function §_-03l§(param1:String) : void
      {
         this.log.debug(param1,"RES_LOAD");
      }
      
      override public function destroy() : void
      {
         this.queue = null;
         super.destroy();
      }
      
      [Abstract]
      protected function get log() : §_-11S§
      {
         throw new Error("AbstractConfigLoader.log is abstract method and must be overriden");
      }
   }
}


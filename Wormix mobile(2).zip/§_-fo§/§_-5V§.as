package §_-fo§
{
   import §_-43V§.*;
   import §_-73d§.§_-v1o§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.*;
   import §_-B2z§.§_-82u§;
   import §_-Bv§.§_-G3P§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-F39§.§_-Ey§;
   import §_-L1H§.§_-C3e§;
   import §_-L2F§.§_-I1q§;
   import §_-L2F§.§_-t2Z§;
   import §_-P1z§.*;
   import §_-RE§.§_-V1m§;
   import §_-Y1O§.*;
   import §_-Y1b§.*;
   import §_-aM§.§_-C1e§;
   import §_-aM§.§_-P1N§;
   import §_-aM§.§_-tX§;
   import §_-b1F§.§_-G4§;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-52D§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Vr§;
   import §_-k1u§.§_-by§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.X509CertificateCollection;
   import §_-n1w§.§_-e2U§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-w2i§.§_-Ia§;
   import §_-w2i§.§_-Zd§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-522§;
   import §_-z1g§.§_-y1S§;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.SWFLoader;
   import com.greensock.loading.core.LoaderCore;
   import com.hurlant.crypto.tls.§_-F16§;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.display.MovieClip;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.geom.Rectangle;
   import flash.system.ApplicationDomain;
   import flash.system.LoaderContext;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   import ru.pragmatix.wormix.messages.server.BuyUnlockMissionResult;
   import ru.pragmatix.wormix.messages.server.SteamTransactionCommitResponse;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Meteor;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.SystemUtil;
   
   public class §_-5V§
   {
      
      protected var §_-o7§:String;
      
      public var §_-31G§:String;
      
      protected var §_-X2H§:Vector.<String>;
      
      protected var context:LoaderContext;
      
      private var §_-P2O§:§_-Q2z§;
      
      protected var §_-o1c§:LoaderMax;
      
      private var §_-P2X§:Vector.<LoaderMax> = new Vector.<LoaderMax>(0);
      
      protected var §_-K1g§:Vector.<§_-A29§> = new Vector.<§_-A29§>(0);
      
      public function §_-5V§(param1:String, param2:String, param3:Vector.<String>, param4:LoaderContext)
      {
         super();
         this.§_-o7§ = param1;
         this.§_-31G§ = param2;
         this.§_-X2H§ = param3;
         this.context = param4;
      }
      
      public function load(param1:Function, param2:Function, param3:Object = null, param4:Boolean = false) : void
      {
         var _loc5_:Object = {
            "onError":param2,
            "onComplete":param1
         };
         this.§_-P2O§ = new §_-Q2z§(this.§_-o7§,this.§_-31G§,this.§_-X2H§,this.context);
         this.§_-P2O§.addEventListener(flash.events.Event.COMPLETE,§_-bs§.§_-d1Z§(this.§_-03Z§,this,[_loc5_,param3 || {},param4],true));
         this.§_-P2O§.addEventListener(§_-hH§.LOAD_ERROR,§_-bs§.§_-d1Z§(this.§_-dy§,this,[_loc5_],true));
         this.§_-P2O§.load();
      }
      
      private function §_-03Z§(param1:flash.events.Event, param2:Object, param3:Object, param4:Boolean) : void
      {
         var _loc7_:§_-A29§ = null;
         var _loc5_:Vector.<§_-A29§> = this.§_-P2O§.§_-D2r§();
         var _loc6_:Vector.<§_-A29§> = new Vector.<§_-A29§>(0);
         for each(_loc7_ in _loc5_)
         {
            this.§_-12t§(_loc7_,param3);
            if(!_loc7_.§_-jp§)
            {
               _loc6_.push(_loc7_);
            }
         }
         this.§_-P2O§.destroy();
         this.§_-P2O§ = null;
         this.§_-a4§(_loc6_,param2.onComplete,param2.onError,param4);
      }
      
      protected function §_-dy§(param1:§_-hH§, param2:Object) : void
      {
         param2.onError(param1);
         this.§_-P2O§.destroy();
         this.§_-P2O§ = null;
      }
      
      protected function §_-12t§(param1:§_-A29§, param2:Object) : void
      {
         var _loc3_:Object = param2[param1.name];
         if(_loc3_)
         {
            if(_loc3_.lazy)
            {
               param1.§_-jp§ = _loc3_.lazy;
            }
            if(_loc3_.path)
            {
               param1.§_-yC§ = _loc3_.path;
            }
         }
         if(param2.pathParams)
         {
            param1.§_-yC§ = §_-F1P§.format(param1.§_-yC§,param2.pathParams);
         }
         if(param1.§_-jp§)
         {
            this.§_-03l§("lazy library detected " + param1.name);
            this.§_-K1g§.push(param1);
         }
      }
      
      protected function §_-a4§(param1:Vector.<§_-A29§>, param2:Function, param3:Function, param4:Boolean) : void
      {
         var _loc5_:§_-A29§ = null;
         var _loc7_:Vector.<§_-A29§> = null;
         var _loc8_:LoaderMax = null;
         var _loc9_:Boolean = false;
         var _loc6_:Object = {
            "onComplete":param2,
            "onError":param3
         };
         if(param4)
         {
            for each(_loc5_ in param1)
            {
               if(!this.§_-83A§(_loc5_,ApplicationDomain.currentDomain,_loc6_))
               {
                  return;
               }
            }
            param2();
         }
         else
         {
            if(!this.§_-o1c§)
            {
               this.§_-o1c§ = new LoaderMax({
                  "auditSize":false,
                  "maxConnections":2,
                  "onProgress":this.progressHandler,
                  "context":this.context
               });
            }
            _loc7_ = new Vector.<§_-A29§>(0);
            _loc8_ = new LoaderMax({"context":this.context});
            _loc8_.addEventListener(LoaderEvent.COMPLETE,§_-bs§.§_-d1Z§(this.completeHandler,this,[_loc8_,_loc7_,_loc6_],true));
            _loc8_.addEventListener(LoaderEvent.ERROR,§_-bs§.§_-d1Z§(this.errorHandler,this,[_loc8_,_loc7_,_loc6_],true));
            _loc9_ = true;
            for each(_loc5_ in param1)
            {
               this.§_-6j§(_loc8_,_loc5_);
               _loc7_.push(_loc5_);
               if(!_loc5_.§_-51m§())
               {
                  _loc9_ = false;
               }
            }
            if(_loc9_)
            {
               this.§_-P2X§.push(_loc8_);
            }
            else
            {
               this.§_-ct§();
            }
            this.§_-03l§("start loading " + param1.length + " libraries");
            this.§_-o1c§.append(_loc8_);
            this.§_-o1c§.load();
         }
      }
      
      protected function §_-83A§(param1:§_-A29§, param2:ApplicationDomain, param3:Object) : Boolean
      {
         var _loc4_:§_-21L§ = null;
         var _loc5_:String = null;
         var _loc6_:String = null;
         for each(_loc4_ in param1.resources)
         {
            _loc5_ = (param1.ns == null ? "" : param1.ns) + _loc4_.getClassName();
            if(param2.hasDefinition(_loc5_))
            {
               _loc4_.§_-11t§(param2.getDefinition(_loc5_) as Class);
               this.§_-u1p§(_loc4_);
            }
            else
            {
               if(!param2.hasDefinition("ru.pragmatix.wormix.data." + _loc4_.getClassName()))
               {
                  _loc6_ = "Class " + _loc5_ + " not found in library " + param1.§_-yC§;
                  this.log.error(_loc6_);
                  param3.onError(new §_-hH§(_loc6_));
                  return false;
               }
               _loc4_.§_-11t§(param2.getDefinition("ru.pragmatix.wormix.data." + _loc4_.getClassName()) as Class);
               this.§_-u1p§(_loc4_);
            }
         }
         return true;
      }
      
      protected function §_-6j§(param1:LoaderMax, param2:§_-A29§) : void
      {
         var _loc3_:int = param2.estimatedBytes == 0 ? 20000 : param2.estimatedBytes;
         if(param2.§_-yC§)
         {
            this.§_-03l§("add resource: [" + param2.§_-yC§ + "] to load queue, estimatedBytes:=" + _loc3_);
            param1.append(new SWFLoader(param2.§_-o7§ + param2.§_-yC§,{
               "name":param2.§_-c2Z§,
               "estimatedBytes":_loc3_,
               "autoPlay":false,
               "alternateURL":param2.§_-j24§ + param2.§_-yC§,
               "context":this.context
            }));
         }
         else
         {
            this.log.§_-M2b§("library \'" + param2.name + "\' path is null");
         }
      }
      
      protected function §_-b1D§(param1:LoaderEvent, param2:Vector.<§_-A29§>, param3:Object) : void
      {
         var library:§_-A29§ = null;
         var name:String = null;
         var clip:MovieClip = null;
         var event:LoaderEvent = param1;
         var libs:Vector.<§_-A29§> = param2;
         var loadParams:Object = param3;
         this.§_-03l§("start parsing swf");
         try
         {
            for each(library in libs)
            {
               this.§_-03l§("try to parse library " + library.§_-yC§);
               name = library.§_-c2Z§;
               if(LoaderMax.getLoader(name) == null)
               {
                  this.log.§_-M2b§("can\'t get loader by path: " + library.§_-yC§);
                  return;
               }
               clip = LoaderMax.getLoader(name).rawContent;
               if(clip == null)
               {
                  this.log.§_-M2b§("can\'t get clip by path: " + library.§_-yC§);
                  return;
               }
               this.§_-03l§("parse swf path = " + library.§_-yC§);
               if(!this.§_-83A§(library,clip.loaderInfo.applicationDomain,loadParams))
               {
                  return;
               }
            }
         }
         catch(e:Object)
         {
            §§push(e);
            var _temp_1:* = e;
            e = §§pop();
            log.error("error: " + e.toString());
            loadParams.onError(new §_-hH§());
         }
      }
      
      protected function completeHandler(param1:LoaderEvent, param2:LoaderMax, param3:Vector.<§_-A29§>, param4:Object) : void
      {
         this.§_-03l§("loading " + param3.length + "  libraries complete");
         this.§_-b1D§(param1,param3,param4);
         §_-fM§.remove(this.§_-P2X§,param2);
         this.§_-6o§(param2);
         param4.onComplete();
         this.§_-r1N§();
      }
      
      protected function progressHandler(param1:LoaderEvent) : void
      {
      }
      
      private function errorHandler(param1:LoaderEvent, param2:LoaderMax, param3:Vector.<§_-A29§>, param4:Object) : void
      {
         this.§_-r1N§();
         this.log.§_-E2X§("load error occured url \'" + param1.target.url + "\' : " + param1.toString());
         if(LoaderCore(param1.target).status == LoaderStatus.FAILED)
         {
            this.log.§_-M2b§("load failed url \'" + param1.target.url + "\' : " + param1.toString());
            this.§_-6o§(param2);
            param4.onError(new §_-hH§(param1.text));
         }
      }
      
      protected function §_-6o§(param1:LoaderMax) : void
      {
         this.§_-o1c§.remove(param1);
         param1.dispose(true);
      }
      
      protected function §_-03l§(param1:String) : void
      {
         this.log.debug(param1,"RES_LOAD");
      }
      
      protected function §_-u1p§(param1:§_-21L§) : void
      {
      }
      
      protected function §_-ct§() : void
      {
         var _loc1_:LoaderMax = null;
         for each(_loc1_ in this.§_-P2X§)
         {
            if(_loc1_.status == LoaderStatus.LOADING || _loc1_.status == LoaderStatus.READY)
            {
               _loc1_.pause();
               this.§_-03l§("suspend sound loader \'" + _loc1_.name + "\'");
            }
         }
      }
      
      protected function §_-r1N§() : void
      {
         var _loc1_:LoaderMax = null;
         for each(_loc1_ in this.§_-P2X§)
         {
            if(_loc1_.status == LoaderStatus.PAUSED)
            {
               _loc1_.resume();
               this.§_-03l§("resume sound loader \'" + _loc1_.name + "\'");
            }
         }
      }
      
      protected function get log() : §_-11S§
      {
         return null;
      }
   }
}


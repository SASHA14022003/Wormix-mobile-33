package §_-l1g§
{
   import §_-A1K§.§_-TA§;
   import §_-l1K§.§_-W2f§;
   import §_-m0§.§_-X1F§;
   import §_-r1C§.§_-h2B§;
   import flash.events.Event;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.*;
   import starling.events.Event;
   
   public class §_-F1X§ extends flash.events.Event
   {
      
      public static const NAME:String = "ACHIEVEMENTS_UPDATED";
      
      public var records:§_-S2Y§;
      
      public function §_-F1X§(param1:§_-S2Y§, param2:String = "ACHIEVEMENTS_UPDATED", param3:Boolean = false, param4:Boolean = false)
      {
         super(param2,param3,param4);
         this.records = param1;
      }
      
      override public function clone() : flash.events.Event
      {
         return new §_-F1X§(this.records,type,bubbles,cancelable);
      }
      
      override public function toString() : String
      {
         return formatToString(getQualifiedClassName(this).split("::")[1],"type","bubbles","cancelable","eventPhase","records");
      }
   }
}


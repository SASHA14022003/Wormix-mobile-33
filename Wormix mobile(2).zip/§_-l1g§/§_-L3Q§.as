package §_-l1g§
{
   import §_-H2g§.§_-di§;
   import §_-ZP§.§_-YG§;
   import §_-ZP§.§_-w1J§;
   import §_-l1K§.§_-W2f§;
   import §_-l2r§.§_-K1t§;
   import dragonBones.animation.WorldClock;
   import flash.geom.Point;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.social.utils.FacebookTracking;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-L3Q§ extends Event
   {
      
      public static const §_-o13§:String = "collide";
      
      public static const §_-U2j§:String = "beforeHit";
      
      public static const §_-kl§:String = "sink";
      
      public static const DISPOSED:String = "disposed";
      
      public static const DAMAGE:String = "damage";
      
      public static const §_-a1V§:String = "stable";
      
      public static const §_-S2B§:String = "unstable";
      
      public static const §_-l5§:String = "command";
      
      public static const §_-Qw§:String = "damaged";
      
      public static const §_-Gn§:String = "ground_damaged";
      
      public static const §_-tN§:String = "trigger_crosshair";
      
      public static const EXIT_BATTLE:String = "EXIT_BATTLE";
      
      public static const SCENE_STABLE:String = "SCENE_STABLE";
      
      public static const NEXT_TURN:String = "NEXT_TURN";
      
      public static const NEXT_TURN_ON_STABLE:String = "NEXT_TURN_ON_STABLE";
      
      public static const FRAME:String = "FRAME";
      
      public static const FORCE_CHANGED:String = "FORCE_CHANGED";
      
      public static const MINE_SET_UP:String = "MINE_SET_UP";
      
      public static const MINE_ACTIVATE:String = "MINE_ACTIVATE";
      
      public static const BOOMERANG_CAUGHT:String = "BOOMERANG_CAUGHT";
      
      public static const TELEPORT:String = "TELEPORT";
      
      public static const §_-aJ§:String = "TURM_TIMER";
      
      public static const GAME_OBJECT_HP_CHANGE:String = "GAME_OBJECT_HP_CHANGE";
      
      public static const §_-51N§:String = "WORM_SHOOT";
      
      public static const DAMAGE_TRIGGER:String = "DAMAGE_TRIGGER";
      
      public static const WEAPON_RESTORE:String = "WEAPON_RESTORE";
      
      public static const SOT:String = "SOT";
      
      public static const EOT:String = "EOT";
      
      public static const TURN_PREPARE:String = "TURN_PREPARE";
      
      public static const UNIT_ACTIVATION:String = "UNIT_ACTIVATION";
      
      public static const UNIT_DEACTIVATION:String = "UNIT_DEACTIVATION";
      
      public static const END_TURN_RECEIVED:String = "END_TURN_RECEIVED";
      
      public static const START_TURN_RECEIVED:String = "START_TURN_RECEIVED";
      
      public static const WEAPON_SELECT:String = "WEAPON_SELECT";
      
      public static const BEFORE_OPEN_CLOSE_BAG:String = "BEFORE_OPEN_CLOSE_BAG";
      
      public static const AFTER_OPEN_CLOSE_BAG:String = "AFTER_OPEN_CLOSE_BAG";
      
      public static const §_-G1s§:String = "KILLED_WORM";
      
      public static const NEW_UNIT_ADDED:String = "NEW_UNIT_ADDED";
      
      public static const ATTACK_DODGED:String = "ATTACK_DODGED";
      
      public static const MASSIVE_DAMAGE:String = "MASSIVE_DAMAGE";
      
      public static const SUPPLY_PICKED_UP:String = "SUPPLY_PICKED_UP";
      
      public static const START_TURN_SWITCHING:String = "START_TURN_SWITCHING";
      
      public static const UNIT_UI_ACTIVATED:String = "UNIT_UI_ACTIVATED";
      
      public static const UNIT_CONTROL_CHANGED:String = "UNIT_CONTROL_CHANGED";
      
      public static const COMMAND_CONTROL_CHANGED:String = "COMMAND_CONTROL_CHANGED";
      
      public function §_-L3Q§(param1:String, param2:Boolean = false, param3:Object = null)
      {
         super(param1,param2,param3);
      }
   }
}


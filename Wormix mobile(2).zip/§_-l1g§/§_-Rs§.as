package §_-l1g§
{
   public class §_-Rs§
   {
      
      public static const §_-M1X§:String = "joined";
      
      public static const §_-12m§:String = "availability";
      
      public static const §_-P8§:String = "message";
      
      public static const §_-D3Z§:String = "admin_message";
      
      public static const §_-y2c§:String = "admin_pinned";
      
      public static const §_-v1§:String = "system";
      
      public function §_-Rs§()
      {
         super();
      }
   }
}


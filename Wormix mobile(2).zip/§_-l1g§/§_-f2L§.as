package §_-l1g§
{
   public class §_-f2L§
   {
      
      public static const §_-Rx§:String = "SOCIAL_CHANGED";
      
      public static const USER_SOCIAL_DATA_CHANGED:String = "USER_SOCIAL_DATA_CHANGED";
      
      public static const USER_FRIENDS_LOADED:String = "USER_FRIENDS_LOADED";
      
      public static const ALL_FRIENDS_LOADED:String = "ALL_FRIENDS_LOADED";
      
      public function §_-f2L§()
      {
         super();
      }
   }
}


package §_-l1g§
{
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-E19§;
   import ru.pragmatix.wormix.weapons.ammo.BunkerBusterMissile;
   import starling.events.Event;
   
   public class §_-T2N§ extends Event
   {
      
      public static const BUY_EVENT:String = "BUY_EVENT";
      
      public var item:§_-1Y§;
      
      public var moneyType:§_-E19§;
      
      public var count:int;
      
      public function §_-T2N§(param1:§_-1Y§, param2:§_-E19§, param3:int = 1)
      {
         super(BUY_EVENT);
         this.item = param1;
         this.moneyType = param2;
         this.count = param3;
      }
   }
}


package §_-H9§
{
   import §_-31W§.§_-Kb§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-j1w§.§_-B2i§;
   
   public interface §_-NX§
   {
      
      function get winInPvp() : String;
      
      function get rubyFoundInHouse() : String;
      
      function get kickTeamMate() : String;
      
      function get missionComplete() : String;
      
      function get enter4DaySequence() : String;
      
      function get enter5DaySequence_2mission() : String;
      
      function get enter5DaySequence_reaction() : String;
      
      function get enter5DaySequence_fuzzes() : String;
      
      function get enter5DaySequence_rubies() : String;
      
      function §_-G1f§(param1:§_-B2i§) : String;
      
      function get newItems() : String;
      
      function get newTeamMate() : String;
      
      function get callToPvp() : Array;
      
      function get activityPumpFriendsReaction() : String;
      
      function get requestPumpReaction() : String;
      
      function get postStatus() : String;
      
      function get boxerIcon() : String;
      
      function get zombieIcon() : String;
      
      function get demonIcon() : String;
      
      function get rabbitIcon() : String;
      
      function get catIcon() : String;
      
      function get dragonIcon() : String;
      
      function get robotIcon() : String;
      
      function §_-b1i§(param1:§_-zF§) : String;
      
      function §_-l1F§(param1:§_-O2H§) : String;
      
      function §_-K14§(param1:§_-T1y§) : String;
      
      function §_-5b§(param1:§_-W1r§) : String;
      
      function get remindAboutLose() : String;
      
      function get bossIcon() : String;
      
      function get tutorialIcon() : String;
      
      function §_-o2z§(param1:Boolean, param2:Boolean) : String;
      
      function §_-RX§(param1:int) : String;
      
      function §_-g18§(param1:§_-Kb§) : String;
   }
}


package §_-H9§
{
   import §_-31W§.§_-Kb§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-Y1O§.*;
   import §_-j1w§.§_-B2i§;
   import feathers.controls.ImageLoader;
   import flash.errors.IllegalOperationError;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.display.DisplayObject;
   
   public class §_-h1H§ implements §_-NX§
   {
      
      private static const PNG:String = ".png";
      
      private static const §_-Iw§:String = "artifacts/";
      
      private static const §_-Bm§:String = "achievs/";
      
      private static const §_-Q1p§:String = "awards/";
      
      protected var §_-U1T§:String = "wall_post/common/activity_icon.png";
      
      private const §_-Pe§:Object = {
         1:{"icon":"weapons/IconBazooka.png"},
         2:{"icon":"weapons/IconGrenade.png"},
         16:{"icon":"weapons/IconPneumaticDrill.png"},
         17:{"icon":"weapons/IconAuger.png"},
         19:{"icon":"weapons/IconDynamite.png"},
         39:{"icon":"weapons/IconMine.png"},
         4:{"icon":"weapons/IconRifle.png"},
         49:{"icon":"weapons/IconRope.png"},
         53:{"icon":"weapons/IconGirder.png"},
         45:{"icon":"weapons/IconShuriken.png"},
         5:{"icon":"weapons/IconCIGrenade.png"},
         7:{"icon":"weapons/IconUzi.png"},
         9:{"icon":"weapons/IconMortar.png"},
         29:{"icon":"weapons/IconStickyBomb.png"},
         14:{"icon":"weapons/IconShotgun.png"},
         40:{"icon":"weapons/IconSwine.png"},
         41:{"icon":"weapons/IconSuperSwine.png"},
         10:{"icon":"weapons/IconMinigun.png"},
         54:{"icon":"weapons/IconFreezingBazooka.png"},
         44:{"icon":"weapons/IconCatBazooka.png"},
         12:{"icon":"weapons/IconDrillRocket.png"},
         50:{"icon":"weapons/IconHarpoon.png"},
         33:{"icon":"weapons/IconShocker.png"},
         52:{"icon":"weapons/IconKalash.png"},
         55:{"icon":"weapons/IconCrossbow.png"},
         38:{"icon":"weapons/IconGuidingBazooka.png"},
         46:{"icon":"weapons/IconCannon.png"},
         34:{"icon":"weapons/IconTeleportThrower.png"},
         42:{"icon":"weapons/IconNextTurn.png"},
         48:{"icon":"weapons/IconSpider.png"},
         32:{"icon":"weapons/IconFirework.png"},
         51:{"icon":"weapons/IconBat.png"},
         23:{"icon":"weapons/IconShiperRifle.png"},
         37:{"icon":"weapons/IconMolotov.png"},
         30:{"icon":"weapons/IconFireThrow.png"},
         43:{"icon":"weapons/IconNapalmStrike.png"},
         27:{"icon":"weapons/IconAirStrike.png"},
         28:{"icon":"weapons/IconMeteor.png"},
         36:{"icon":"weapons/IconCatStrike.png"},
         24:{"icon":"weapons/IconWatermelon.png"},
         47:{"icon":"weapons/IconSledgeHammer.png"},
         26:{"icon":"weapons/IconTeleport.png"},
         35:{"icon":"weapons/IconJetpack.png"},
         56:{"icon":"weapons/IconIceMine.png"},
         57:{"icon":"weapons/GroundBreaker.png"},
         58:{"icon":"weapons/IconBunkerBreaker.png"},
         60:{"icon":"weapons/GuardingBot.png"},
         66:{"icon":"weapons/IconAntiFreezer.png"}
      };
      
      private const §_-y3§:Object = {
         1003:{"icon":"hats/IconHatFarmer.png"},
         1025:{"icon":"hats/IconHatWizzard.png"},
         1004:{"icon":"hats/IconHatWizzard.png"},
         1022:{"icon":"hats/IconHatWhitehat.png"},
         1006:{"icon":"hats/IconHatGentleman.png"},
         1018:{"icon":"hats/IconHatNaruto.png"},
         1009:{"icon":"hats/IconHatTankhelm.png"},
         1019:{"icon":"hats/IconHatPinkhat.png"},
         1023:{"icon":"hats/IconHatRedcap.png"},
         1005:{"icon":"hats/IconHatDartVader.png"},
         1007:{"icon":"hats/IconHatViking.png"},
         1010:{"icon":"hats/IconHatJason.png"},
         1016:{"icon":"hats/IconHatArtist.png"},
         1021:{"icon":"hats/IconHatGirlberret.png"},
         1008:{"icon":"hats/IconHatPirate.png"},
         1011:{"icon":"hats/IconHatSubzero.png"},
         1024:{"icon":"hats/IconHatThief.png"},
         1012:{"icon":"hats/IconHatSadomazo.png"},
         1020:{"icon":"hats/IconHatPinkhelm.png"},
         1013:{"icon":"hats/IconHatScorpion.png"},
         1014:{"icon":"hats/IconHatLegioner.png"},
         1026:{"icon":"hats/IconHatPinklegioner.png"},
         1015:{"icon":"hats/IconHatCrown.png"},
         1017:{"icon":"hats/IconHatPrincess.png"},
         1002:{"icon":"hats/IconHatMaster.png"},
         1000:{"icon":"hats/IconHatFirelord.png"},
         1033:{"icon":"hats/IconChieftain.png"},
         1031:{"icon":"hats/IconIndian.png"},
         1030:{"icon":"hats/IconNazy.png"},
         1032:{"icon":"hats/IconSheriff.png"},
         1029:{"icon":"hats/IconSombrero.png"},
         1027:{"icon":"hats/IconHatVoodo.png"},
         1028:{"icon":"hats/IconHatTribal.png"}
      };
      
      public function §_-h1H§()
      {
         super();
      }
      
      public function get rubyFoundInHouse() : String
      {
         return "wall_post/common/ruby_found.png";
      }
      
      public function get kickTeamMate() : String
      {
         return "wall_post/common/kickTeamMateIcon.png";
      }
      
      public function get missionComplete() : String
      {
         return this.§_-U1T§;
      }
      
      public function get enter4DaySequence() : String
      {
         return "wall_post/common/fuzy_bonus.png";
      }
      
      public function get enter5DaySequence_2mission() : String
      {
         return "wall_post/common/battle_bonus.png";
      }
      
      public function get enter5DaySequence_reaction() : String
      {
         return "wall_post/common/reaction.png";
      }
      
      public function get enter5DaySequence_fuzzes() : String
      {
         return "wall_post/common/coin_bonus.png";
      }
      
      public function get enter5DaySequence_rubies() : String
      {
         return "wall_post/common/ruby_found.png";
      }
      
      public function get newItems() : String
      {
         return this.§_-U1T§;
      }
      
      public function get newTeamMate() : String
      {
         return "wall_post/common/newTeamMateIcon.png";
      }
      
      public function get callToPvp() : Array
      {
         return ["wall_post/common/battle.png"];
      }
      
      public function get requestPumpReaction() : String
      {
         return "wall_post/common/reaction_request";
      }
      
      public function get activityPumpFriendsReaction() : String
      {
         return "wall_post/common/reaction.png";
      }
      
      public function get postStatus() : String
      {
         return this.§_-U1T§;
      }
      
      public function §_-b1i§(param1:§_-zF§) : String
      {
         return this.§_-y3§[param1.getId()].icon;
      }
      
      public function §_-l1F§(param1:§_-O2H§) : String
      {
         return this.§_-Pe§[param1.getId()].icon;
      }
      
      public function §_-K14§(param1:§_-T1y§) : String
      {
         return §_-Iw§ + param1.§_-G3a§() + PNG;
      }
      
      public function §_-g18§(param1:§_-Kb§) : String
      {
         return §_-Bm§ + param1.icon + PNG;
      }
      
      public function §_-5b§(param1:§_-W1r§) : String
      {
         return §_-Q1p§ + param1.§_-G3a§() + PNG;
      }
      
      public function get winInPvp() : String
      {
         throw new IllegalOperationError();
      }
      
      public function §_-G1f§(param1:§_-B2i§) : String
      {
         throw new IllegalOperationError();
      }
      
      public function get boxerIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get zombieIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get demonIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get rabbitIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get dragonIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get robotIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get remindAboutLose() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get bossIcon() : String
      {
         return "wall_post/common/battle.png";
      }
      
      public function get catIcon() : String
      {
         throw new IllegalOperationError();
      }
      
      public function get tutorialIcon() : String
      {
         return this.§_-U1T§;
      }
      
      public function §_-o2z§(param1:Boolean, param2:Boolean) : String
      {
         throw new IllegalOperationError();
      }
      
      public function §_-RX§(param1:int) : String
      {
         throw new IllegalOperationError();
      }
   }
}


package §_-H3§
{
   import §_-12a§.§_-41b§;
   import §_-63U§.*;
   import §_-73I§.§_-Y1l§;
   import §_-73d§.§_-w1O§;
   import §_-91B§.§_-z2l§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-MQ§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G3w§.*;
   import §_-L1H§.§_-C3e§;
   import §_-RE§.§_-r2q§;
   import §_-SP§.§_-M4§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-b1k§;
   import §_-Y1b§.§_-s2Z§;
   import §_-YF§.§_-H2F§;
   import §_-dS§.§_-D3a§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-B2i§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Vr§;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.*;
   import §_-rM§.§_-61j§;
   import §_-s1s§.*;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-R1P§;
   import §_-w2W§.§_-21w§;
   import §_-z1g§.*;
   import com.hurlant.util.der.§_-UO§;
   import dragonBones.animation.WorldClock;
   import dragonBones.objects.DragonBonesData;
   import feathers.data.ArrayCollection;
   import feathers.events.FeathersEventType;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.analytics.Analytics;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.SelectMapMenu;
   import ru.pragmatix.wormix.messages.clans.main.server.GetJoinClansMainRequest;
   import ru.pragmatix.wormix.messages.clans.response.GetJoinClansMainResponse;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.server.ArenaLocked;
   import ru.pragmatix.wormix.messages.server.FastBattleResult;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.messages.server.PumpReactionRatesResult;
   import ru.pragmatix.wormix.messages.server.StartBattleResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.messages.structures.PumpReactionRateStructure;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CreateBattleRequest;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.animation.Transitions;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.extensions.PDParticleSystem;
   
   public class §_-E3m§
   {
      
      private static const §_-Tt§:Vector.<uint> = new <uint>[§_-s2Z§.§_-u25§,§_-s2Z§.§_-g1d§];
      
      private var §_-41G§:§_-H2F§ = new §_-H2F§();
      
      private var info:§_-O2i§;
      
      public function §_-E3m§()
      {
         super();
      }
      
      public function dispose() : void
      {
         if(this.§_-41G§)
         {
            this.§_-41G§.dispose();
         }
         this.§_-41G§ = null;
         if(this.info)
         {
            this.info.dispose();
         }
         this.info = null;
      }
      
      public function isReady() : Boolean
      {
         return this.info == null;
      }
      
      public function §_-2n§(param1:UserProfile, param2:§_-b1k§) : void
      {
         this.info = new §_-O2i§(§_-81M§.§_-e1C§);
         §§push(this.info);
         var _temp_1:* = new <UserProfile>[Application.userProfile,param1];
         §§pop().setProfiles(new <UserProfile>[Application.userProfile,param1],§_-Tt§);
         this.info.missionIds.push(0);
         this.info.§_-11J§ = param2;
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_MISSION_LOAD,this.§_-O2o§,null,this.§_-e23§);
      }
      
      private function §_-e23§(param1:§_-03A§) : void
      {
         this.info.mapRecord = param1.mapRecord;
         this.info.§_-u2Y§ = param1.§_-JV§();
         var _loc2_:StartBattle = new StartBattle();
         _loc2_.missionId = this.info.missionIds[0];
         this.§_-h18§(_loc2_);
      }
      
      private function §_-f2z§(param1:Object = null) : void
      {
         this.reset(true);
         §_-J2l§.§_-m1I§();
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.MAIN_SERVER_CONNECTION_CLOSED));
         if(!Application.§_-E1k§.§_-w18§(§_-21w§.§_-G31§))
         {
            Application.§_-i1N§.§_-V6§();
         }
      }
      
      private function §_-h1x§(param1:§_-63i§) : void
      {
         var _loc2_:StartBattleResult = StartBattleResult(param1.message);
         this.info.battleId = _loc2_.battleId;
         this.info.reagentsForBattle = §_-b1L§.§_-n2§(_loc2_.reagentsForBattle);
         if(!§_-X1j§.§_-12n§.gameMaster)
         {
            §_-X1j§.§_-12n§.§_-a1X§(this.info);
         }
         this.reset(false);
      }
      
      public function §_-IT§(param1:§_-y1S§) : void
      {
         this.info = new §_-O2i§(§_-81M§.§_-K23§);
         var _loc2_:Class = param1.getClass();
         var _loc3_:§_-s2Z§ = new _loc2_();
         this.info.scenario = _loc3_;
         this.info.mapId = _loc3_.map.id;
         this.info.noMapGround = _loc3_.noMapGround;
         this.info.indestructibleGround = _loc3_.indestructibleGround;
         this.info.§_-53U§(new <int>[param1.getId()]);
         if(§_-r2q§.isBoss(param1.getId()))
         {
            this.info.§_-D3W§ = §_-X1j§.§_-A24§.§_-X2A§();
         }
         §§push(this.info);
         §§pop().setProfiles(new <UserProfile>[Application.userProfile],new <uint>[0]);
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_MISSION_LOAD,this.§_-O2o§,null,this.§_-Ra§);
      }
      
      private function §_-Ra§(param1:§_-03A§) : void
      {
         if(this.info.missionIds[0] == -1)
         {
            §_-X1j§.§_-j14§.track(Analytics.TUTORIAL_BEGIN,{});
         }
         this.info.mapRecord = param1.mapRecord;
         this.info.§_-u2Y§ = param1.§_-JV§();
         var _loc2_:StartBattle = new StartBattle();
         _loc2_.missionId = this.info.missionIds[0];
         this.§_-h18§(_loc2_);
      }
      
      public function §_-y1D§(param1:UserProfile) : void
      {
         this.info = new §_-O2i§(§_-81M§.§_-p1U§);
         this.§_-22r§(param1);
         this.§_-g17§();
      }
      
      public function §_-c1R§(param1:UserProfile, param2:int) : void
      {
         this.§_-22r§(param1);
         this.§_-U2I§(param2);
      }
      
      public function §_-A1Y§(param1:UserProfile) : void
      {
         this.§_-22r§(param1);
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_LOAD_MAP,this.§_-O2o§,this.info.§_-83I§(),this.§_-u16§);
      }
      
      public function §_-22r§(param1:UserProfile) : void
      {
         var _loc2_:Vector.<UserProfile> = new <UserProfile>[Application.userProfile,param1];
         if(Application.userProfile.equals(param1))
         {
            _loc2_[1] = Application.userProfile.§_-F1b§();
            _loc2_[1].§_-fR§(Application.userProfile.§_-A1U§());
            _loc2_[1].§_-NG§(Application.userProfile.§_-pd§().clone() as §_-2m§);
            _loc2_[1].§_-72S§(Application.userProfile.§_-E39§().clone() as §_-Vr§);
         }
         this.info.setProfiles(_loc2_,§_-Tt§);
      }
      
      private function §_-u16§(param1:§_-03A§) : void
      {
         this.info.mapRecord = param1.mapRecord;
         this.info.§_-u2Y§ = param1.§_-JV§();
         §_-X1j§.§_-12n§.§_-a1X§(this.info);
      }
      
      private function §_-h18§(param1:Object) : void
      {
         §_-83E§.§_-C38§(§_-J2g§.§_-i1N§,getQualifiedClassName(ArenaLocked),this.§_-232§,getQualifiedClassName(StartBattleResult),this.§_-h1x§,§_-R1P§.MESSAGE_SEND_ERROR,this.§_-f2z§,§_-R1P§.SESSION_KEY_CHANGED,this.§_-f2z§);
         §_-J2g§.§_-h18§(param1);
      }
      
      private function §_-232§(param1:§_-63i§) : void
      {
         var _loc2_:ArenaLocked = ArenaLocked(param1.message);
         this.reset(true);
         §_-J2l§.§_-m1I§();
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(_loc2_.getErrorMessageStringId()));
      }
      
      private function §_-O2o§(param1:Vector.<UserProfile>, param2:Function) : void
      {
         this.info.§_-oR§ = this.info.mapId == 0;
         if(this.info.§_-oR§)
         {
            this.info.mapId = §_-X1j§.§_-H15§.§_-43Y§(this.info.battleType);
         }
         this.info.seed = Math.random() * 1000;
         this.§_-41G§.load(this.info.mapId,this.info.noMapGround,this.info.indestructibleGround,param1,param2,this.§_-QA§);
      }
      
      private function §_-QA§() : void
      {
         this.reset(true);
         §_-J2l§.§_-m1I§();
      }
      
      private function reset(param1:Boolean) : void
      {
         this.info = null;
         if(param1)
         {
            Application.§_-a1k§(false);
         }
      }
      
      private function §_-g17§() : void
      {
         var _loc1_:§_-73y§ = new SelectMapMenu();
         _loc1_.addEventListener(§_-M4§.MENU_OK_ACTION,this.§_-q4§);
         _loc1_.addEventListener(§_-M4§.WINDOW_CANCEL,this.§_-w2R§);
         _loc1_.show();
      }
      
      private function §_-w2R§(param1:Event) : void
      {
         Application.§_-a1k§(false);
         this.info = null;
         §_-J2l§.§_-m1I§();
         if(§_-J2l§.§_-u2b§.§_-h1C§())
         {
            §_-J2l§.§_-u2b§.hide();
         }
      }
      
      private function §_-q4§(param1:Event) : void
      {
         if(!this.info)
         {
            return;
         }
         var _loc2_:§_-D3a§ = §_-D3a§(param1.data);
         this.§_-U2I§(_loc2_ ? int(_loc2_.id) : 0);
      }
      
      private function §_-U2I§(param1:int) : void
      {
         this.info.mapId = param1;
         this.info.§_-oR§ = param1 == 0;
         if(§_-X1j§.§_-A24§.§_-73E§())
         {
            §_-X1j§.§_-A24§.§_-73E§().hide();
         }
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_LOAD_MAP,this.§_-O2o§,this.info.§_-83I§(),this.§_-u16§);
      }
   }
}


package §_-H3§
{
   import §_-51p§.§_-W2e§;
   import §_-5P§.§_-H1u§;
   import §_-62§.*;
   import §_-82l§.§_-1I§;
   import §_-91B§.§_-QK§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-b2K§;
   import §_-P2i§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Y1b§.§_-22N§;
   import §_-YF§.§_-H2F§;
   import §_-b1R§.§_-Bx§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-hO§.§_-v24§;
   import §_-j1w§.§_-lD§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-fG§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-6a§;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-sQ§.§_-H3D§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-A1s§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import flash.display.MovieClip;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.StatusEvent;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.net.LocalConnection;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.flox.social.response.*;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.client.SteamProductsInfoRequest;
   import ru.pragmatix.wormix.messages.server.BuyVipResult;
   import ru.pragmatix.wormix.messages.server.SteamProductsInfoResponse;
   import ru.pragmatix.wormix.messages.structures.PvpProfileStructure;
   import ru.pragmatix.wormix.messages.structures.RentedItemsStructure;
   import ru.pragmatix.wormix.messages.structures.UnitStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurn;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.ex.CancelBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.CreateBattleRequest;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpLogin;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.FreezingMissile;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-I1V§
   {
      
      protected static var §_-41G§:§_-H2F§;
      
      private static const §_-2B§:uint = 5000;
      
      private static const §_-33g§:uint = 500;
      
      protected static const §_-lm§:uint = 5;
      
      protected static const §_-Av§:Vector.<uint> = new Vector.<uint>(0);
      
      protected static const §_-52l§:Vector.<UserProfile> = new Vector.<UserProfile>(0);
      
      protected static const READY:uint = 0;
      
      protected static const §_-uv§:uint = 3;
      
      protected static const §_-83l§:uint = 4;
      
      private static const §_-K2j§:int = 0;
      
      private static const §_-028§:int = 1;
      
      protected var state:uint = 0;
      
      protected var §_-c1K§:§_-6a§;
      
      protected var info:§_-O2i§;
      
      protected var §_-j2n§:Boolean = true;
      
      protected var §_-Q1h§:Boolean = true;
      
      public function §_-I1V§()
      {
         super();
      }
      
      public function §_-c2I§() : void
      {
         §_-41G§ = new §_-H2F§();
      }
      
      public function dispose() : void
      {
         if(§_-41G§)
         {
            §_-41G§.dispose();
         }
         §_-41G§ = null;
         if(this.§_-c1K§)
         {
            this.§_-c1K§.destroy();
         }
         this.§_-c1K§ = null;
         if(this.info)
         {
            this.info.dispose();
         }
         this.info = null;
      }
      
      protected function §_-D3b§() : void
      {
         this.info = null;
      }
      
      protected function changeState(param1:uint) : void
      {
         if(param1 == READY)
         {
            §_-X1j§.§_-12n§.friendInPair = null;
         }
         this.§_-5K§(this.state);
         this.state = param1;
         this.§_-Y1S§(this.state);
      }
      
      protected function §_-5K§(param1:uint) : void
      {
         if(param1 != READY)
         {
            if(param1 == §_-uv§)
            {
               this.§_-Gs§();
            }
         }
      }
      
      private function §_-Gs§() : void
      {
         this.§_-c1K§.removeListener(BattleCreated,this.§_-i4§);
         this.§_-c1K§.removeListener(BattleCreationFailure,this.§_-oN§);
         this.§_-c1K§.removeListener(BattleLoginError,this.§_-f2n§);
         this.§_-c1K§.removeListener(PvpSystemMessage,this.§_-N2K§);
      }
      
      protected function §_-Y1S§(param1:uint) : void
      {
         if(param1 == READY)
         {
            this.§_-D3b§();
            if(this.§_-c1K§)
            {
               this.§_-c1K§.removeEventListener(flash.events.Event.CLOSE,this.§_-J2L§);
               if(this.§_-j2n§)
               {
                  §_-bs§.delay(this.§_-c1K§.close,this.§_-c1K§,§_-33g§);
               }
               else
               {
                  this.§_-j2n§ = true;
               }
            }
            if(this.§_-Q1h§)
            {
               Application.§_-a1k§(false);
            }
            else
            {
               this.§_-Q1h§ = true;
            }
         }
      }
      
      public function §_-52i§() : §_-6a§
      {
         return this.§_-c1K§;
      }
      
      public function cancelBattle() : void
      {
         var _loc1_:CancelBattle = null;
         if(this.state != READY)
         {
            if(this.info.scenario is §_-22N§)
            {
               §_-Bx§.§_-z2M§(this.info.scenario as §_-22N§);
            }
            _loc1_ = new CancelBattle();
            _loc1_.battleId = this.info.battleId;
            _loc1_.error = 0;
            this.§_-c1K§.send(_loc1_);
            this.§_-t16§();
         }
      }
      
      protected function connect(param1:Server, param2:Function, param3:Function) : void
      {
         if(!param1)
         {
            return;
         }
         if(Boolean(this.§_-c1K§) && this.§_-c1K§.§_-928§())
         {
            if(this.§_-c1K§.hasEventListener(flash.events.Event.CLOSE))
            {
               this.§_-c1K§.removeEventListener(flash.events.Event.CLOSE,this.§_-J2L§);
            }
            if(this.§_-c1K§.§_-w25§(BattleCreated))
            {
               this.§_-Gs§();
            }
            this.§_-c1K§.close();
         }
         this.§_-c1K§ = new §_-6a§(param1);
         this.§_-c1K§.open(param2,param3);
         this.§_-c1K§.addEventListener(flash.events.Event.CLOSE,this.§_-J2L§,false,0,true);
      }
      
      protected function §_-LG§() : void
      {
         this.changeState(§_-uv§);
         this.§_-c1K§.addListener(BattleCreated,this.§_-i4§,false,0,true);
         this.§_-c1K§.addListener(BattleCreationFailure,this.§_-oN§,false,0,true);
         this.§_-c1K§.addListener(BattleLoginError,this.§_-f2n§,false,0,true);
         this.§_-c1K§.addListener(PvpSystemMessage,this.§_-N2K§,false,0,true);
      }
      
      final protected function §_-J2L§(param1:flash.events.Event = null) : void
      {
         SystemUtil.executeWhenApplicationIsActive(this.§_-nD§);
      }
      
      protected function §_-nD§() : void
      {
         this.§_-t16§();
      }
      
      final protected function §_-i4§(param1:§_-63i§) : void
      {
         SystemUtil.executeWhenApplicationIsActive(this.§_-rn§,param1);
      }
      
      protected function §_-rn§(param1:§_-63i§) : void
      {
         §_-J2l§.§_-73c§.show();
      }
      
      final protected function §_-oN§(param1:§_-63i§) : void
      {
         SystemUtil.executeWhenApplicationIsActive(this.§_-015§,param1);
      }
      
      protected function §_-015§(param1:§_-63i§) : void
      {
         var callback:Function;
         var msgBox:§_-73y§ = null;
         var msg:String = null;
         var e:§_-63i§ = param1;
         var cmd:BattleCreationFailure = BattleCreationFailure(e.message);
         if(cmd.reason == CallToBattleResultType.NO_ENOUGH_MONEY)
         {
            msgBox = new §_-7D§();
         }
         else
         {
            if(cmd.refuserId == Application.userProfile.getId())
            {
               msg = cmd.reason.localFailureReason;
            }
            else
            {
               msg = cmd.reason.remoteFailureReason;
            }
            msgBox = §_-fH§.§_-k1O§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),msg);
         }
         callback = function():void
         {
            if(msgBox)
            {
               msgBox.show();
            }
         };
         this.§_-t16§(callback);
      }
      
      final protected function §_-f2n§(param1:§_-63i§) : void
      {
         SystemUtil.executeWhenApplicationIsActive(this.§_-d1w§,param1);
      }
      
      protected function §_-d1w§(param1:§_-63i§) : void
      {
         var e:§_-63i§ = param1;
         var callback:Function = function():void
         {
            var _loc1_:BattleLoginError = BattleLoginError(e.message);
            §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),_loc1_.error.message);
         };
         this.§_-t16§(callback);
      }
      
      protected function §_-QA§() : void
      {
         this.cancelBattle();
      }
      
      final protected function §_-N2K§(param1:§_-63i§) : void
      {
         SystemUtil.executeWhenApplicationIsActive(this.§_-is§,param1);
      }
      
      protected function §_-is§(param1:§_-63i§) : void
      {
      }
      
      protected function §_-U2s§(param1:Vector.<PvpProfileStructure>) : void
      {
         var _loc4_:UserProfile = null;
         var _loc5_:PvpProfileStructure = null;
         var _loc6_:String = null;
         var _loc7_:SocialUserData = null;
         var _loc2_:Vector.<UserProfile> = new Vector.<UserProfile>(0);
         var _loc3_:Vector.<uint> = new Vector.<uint>(0);
         for each(_loc5_ in param1)
         {
            if(_loc5_.id == Application.userProfile.getId())
            {
               _loc4_ = Application.userProfile.§_-F1b§();
               _loc4_.build.§_-q2o§(_loc5_);
               this.info.§_-yo§ = _loc5_.dailyRating;
               if(_loc5_.activeTeamMembers.length)
               {
                  this.§_-O1D§(_loc4_,_loc5_.activeTeamMembers);
               }
               _loc2_.push(_loc4_);
            }
            else
            {
               _loc4_ = new UserProfile();
               _loc4_.build.§_-pM§(_loc5_);
               if(_loc5_.activeTeamMembers.length)
               {
                  this.§_-O1D§(_loc4_,_loc5_.activeTeamMembers);
               }
               _loc2_.push(_loc4_);
               _loc6_ = _loc5_.socialIds[SocialType.FACEBOOK];
               if(_loc6_)
               {
                  _loc7_ = new SocialUserData();
                  _loc7_.setFirstName(_loc5_.name == "" ? _loc5_.socialName : _loc5_.name);
                  _loc7_.setSocialId(_loc6_);
                  _loc7_.setPhoto("http://graph.facebook.com/" + _loc6_ + "/picture");
                  _loc7_.setPhotoMedium(_loc7_.getPhotoMedium());
                  _loc7_.setPhotoBig(_loc7_.getPhotoBig());
                  _loc7_.setPageUrl("http://facebook.com/" + _loc6_);
               }
            }
            _loc3_.push(_loc5_.teamNum);
         }
         this.info.setProfiles(_loc2_,_loc3_);
      }
      
      protected function §_-63d§(param1:Vector.<int>) : void
      {
         var reagentsForBattle:Vector.<int> = param1;
         this.info.reagentsForBattle = reagentsForBattle.filter(function(param1:int, ... rest):Boolean
         {
            return param1 >= 0;
         });
      }
      
      protected function §_-22§(param1:PvpLogin) : void
      {
         var _loc2_:UserProfile = Application.userProfile;
         var _loc3_:IPlatformAccountController = §_-X1j§.§_-It§;
         param1.profileId = _loc2_.getId();
         var _loc4_:String = UserProfileStructure.getSocialIdsAsString(_loc2_.getSocialIds());
         param1.socialNetworkId = _loc3_.getPlatformType().servercode;
         param1.playerName = _loc2_.getCharName();
         param1.authKey = §_-H1u§.getAuthKey(true);
         param1.mainServerId = 1;
      }
      
      protected function §_-wv§(param1:int, param2:Boolean, param3:§_-82X§, param4:Vector.<int>, param5:Vector.<uint>, param6:Vector.<uint>, param7:uint = 0) : CreateBattleRequest
      {
         var _loc9_:int = 0;
         var _loc8_:CreateBattleRequest = new CreateBattleRequest();
         this.§_-22§(_loc8_);
         _loc8_.missionIds = param4;
         _loc8_.mapId = param1;
         _loc8_.clientParams = {
            "isRandomWeapons":false,
            "isRandomMap":param2
         };
         _loc8_.wager = param3;
         _loc8_.playerIds = param6.concat(param5);
         _loc8_.teamIds = new Vector.<int>(0);
         _loc8_.friendSocialNetId = param7;
         _loc9_ = 0;
         while(_loc9_ < param6.length)
         {
            _loc8_.teamIds.push(§_-K2j§);
            _loc9_++;
         }
         _loc9_ = 0;
         while(_loc9_ < param5.length)
         {
            _loc8_.teamIds.push(§_-028§);
            _loc9_++;
         }
         return _loc8_;
      }
      
      protected function §_-t16§(param1:Function = null) : void
      {
         this.changeState(READY);
         §_-J2l§.§_-m1I§();
         Application.§_-i1N§.§_-V6§(param1);
      }
      
      private function §_-O1D§(param1:UserProfile, param2:Array) : void
      {
         var _loc5_:UnitStructure = null;
         var _loc6_:UserProfile = null;
         var _loc7_:int = 0;
         var _loc3_:Array = param1.§_-A1U§();
         var _loc4_:Array = [];
         for each(_loc5_ in param2)
         {
            for each(_loc6_ in _loc3_)
            {
               _loc7_ = int(int(_loc5_.ownerId));
               if(_loc6_.getId() == _loc7_)
               {
                  _loc4_.push(_loc6_);
                  break;
               }
            }
         }
         param1.§_-fR§(_loc4_);
      }
   }
}


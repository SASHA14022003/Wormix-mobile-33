package §_-H3§
{
   import §_-5Y§.§_-t2O§;
   import §_-91A§.§_-sH§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-l1g§.§_-L3Q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.weapons.ammo.cloud.BasicCloud;
   
   public class §_-b1L§
   {
      
      public function §_-b1L§()
      {
         super();
         throw new Error("RequestHelper can\'t be instantiated!");
      }
      
      public static function §_-n2§(param1:Vector.<int>) : Vector.<int>
      {
         var reagentsForBattle:Vector.<int> = param1;
         if(reagentsForBattle)
         {
            return reagentsForBattle.filter(function(param1:int, ... rest):Boolean
            {
               return param1 >= 0;
            });
         }
         return new Vector.<int>(0);
      }
   }
}


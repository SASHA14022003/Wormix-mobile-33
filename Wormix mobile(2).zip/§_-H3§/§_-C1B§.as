package §_-H3§
{
   import §_-533§.§_-c2b§;
   import §_-5P§.§_-H1u§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-73I§.*;
   import §_-73d§.§_-v1o§;
   import §_-73d§.§_-x2C§;
   import §_-82l§.§_-A2Y§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.*;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-G2H§.*;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-Tm§.§_-W1Y§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-O2i§;
   import §_-U1i§.§_-XA§;
   import §_-W§.§_-ix§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1Q§.§_-61Z§;
   import §_-Z1K§.§_-q24§;
   import §_-bI§.*;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-cZ§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-6a§;
   import §_-s20§.§_-J2g§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.*;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.crypto.tls.§_-73u§;
   import com.mesmotronic.ane.AndroidID;
   import feathers.controls.ScrollPolicy;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.RelativePosition;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.media.SoundMixer;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.AuditActionsRequest;
   import ru.pragmatix.wormix.messages.clans.response.AuditActionsResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.ReadyForBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginErrorType;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.utils.FrameTimer;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.weapons.§_-93W§;
   import ru.pragmatix.wormix.weapons.ammo.DynamiteStick;
   import ru.pragmatix.wormix.weapons.ammo.VilePumpkin;
   import ru.pragmatix.wormix.weapons.ammo.type.blocker.AirBlocker;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.utils.AssetManager;
   import starling.utils.Pool;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   
   public class §_-C1B§
   {
      
      private static const §_-dl§:uint = 0;
      
      private static const §_-H3e§:uint = 1;
      
      private static const §_-mR§:uint = 2;
      
      private static const DISCONNECTED:uint = 3;
      
      private static const CONNECTING:uint = 4;
      
      private static const §_-A1D§:uint = 5;
      
      private static const §_-h2W§:uint = 6;
      
      private static const §_-X2R§:uint = 7;
      
      private static const §_-Tw§:uint = 30 * 1000;
      
      private static const RECONNECT_TIMEOUT:uint = 2 * 1000;
      
      private static const §_-o1F§:uint = 3;
      
      private static const §_-02n§:uint = 10;
      
      private var state:uint;
      
      private var §_-wA§:Server;
      
      private var connection:§_-6a§;
      
      private var §_-c1y§:§_-D3w§;
      
      private var §_-H2V§:uint = 0;
      
      private var playerNum:int;
      
      private var timeout:Timer;
      
      private var §_-B14§:§_-w2C§;
      
      public function §_-C1B§()
      {
         super();
      }
      
      public function §_-oH§() : void
      {
         this.connection.close();
         this.§_-c1y§.stop();
         Starling.juggler.delayCall(this.§_-52b§,2,null);
      }
      
      public function dispose() : void
      {
         §_-J2h§.§_-n1V§(this + ".dispose...");
         this.§_-wA§ = null;
         if(this.connection)
         {
            this.connection.§_-63O§();
            this.connection.close();
         }
         this.connection = null;
         if(this.§_-c1y§)
         {
            this.§_-c1y§.stop();
         }
         this.§_-c1y§ = null;
         this.§_-B14§ = null;
      }
      
      private function reset() : void
      {
         §_-J2h§.§_-n1V§(this + ".reset...");
         this.state = §_-dl§;
         this.playerNum = -1;
         this.§_-H2V§ = 0;
         this.§_-c1y§ = null;
         this.§_-B14§ = null;
      }
      
      public function enter(param1:§_-O2i§, param2:§_-6a§, param3:Function, param4:Function) : void
      {
         §_-J2h§.§_-n1V§(this + ".enter: " + param1);
         this.reset();
         this.§_-B14§ = new §_-w2C§(param1,param3,param4);
         this.§_-wA§ = param1.§_-wA§;
         this.connection = param2;
         param2.addListener(PvpChatMessage,this.§_-C1x§,false,0,true);
         this.§_-d§();
      }
      
      public function §_-A3u§() : void
      {
         §_-J2h§.§_-n1V§(this + ".closeConnection: " + this.connection);
         if(this.connection)
         {
            this.connection.§_-Z2l§();
            this.connection.§_-63O§();
            this.connection.close();
            this.connection = null;
         }
      }
      
      private function §_-d§() : void
      {
         var _loc1_:ReadyForBattle = null;
         §_-J2h§.§_-n1V§(this + ".handShake: " + this.connection + " " + (this.connection ? this.connection.§_-928§() : "-"));
         if(this.connection != null && this.connection.§_-928§())
         {
            this.state = §_-H3e§;
            §_-J2l§.§_-e1L§(§_-s2a§.WAITING_FOR_OTHER_PLAYERS);
            this.connection.addEventListener(flash.events.Event.CLOSE,this.onHandShakeConnectionClosed,false,0,true);
            this.connection.addListener(StartPvpBattle,this.§_-7Z§,false,0,true);
            this.connection.addListener(BattleCreationFailure,this.onStartBattleFailure,false,0,true);
            this.createTimer(§_-Tw§,1,null,this.onHandShakeTimeout);
            _loc1_ = new ReadyForBattle();
            _loc1_.battleId = this.§_-B14§.info.battleId;
            this.connection.send(_loc1_);
         }
         else
         {
            this.§_-B14§.onFail(§_-s2a§.PVP_SERVER_LOGIN_ERROR);
         }
      }
      
      private function §_-v18§() : void
      {
         §_-J2h§.§_-n1V§(this + ".clearHandShakeEvents: " + this.connection);
         if(this.connection)
         {
            this.connection.removeEventListener(flash.events.Event.CLOSE,this.onHandShakeConnectionClosed);
            this.connection.removeListener(BattleCreationFailure,this.onStartBattleFailure);
            this.connection.removeListener(StartPvpBattle,this.§_-7Z§);
         }
         this.destroyTimer();
      }
      
      private function §_-7Z§(param1:§_-63i§) : void
      {
         var e:§_-63i§ = param1;
         var cmd:StartPvpBattle = null;
         try
         {
            cmd = StartPvpBattle(e.message);
         }
         catch(err:Error)
         {
         }
         §_-J2h§.§_-n1V§(this + ".onStartBattle: " + cmd);
         if(cmd != null && cmd.battleId == this.§_-B14§.info.battleId)
         {
            this.§_-B14§.onSuccess();
            this.§_-v18§();
            this.playerNum = cmd.playerNum;
            this.§_-c1y§ = new §_-D3w§(this.connection,this.playerNum);
            this.process();
         }
         else
         {
            this.onHandShakeFailed(§_-s2a§.§_-K3t§(§_-s2a§.PVP_SERVER_INCORRECT_BATTLE_ID));
         }
      }
      
      private function onStartBattleFailure(param1:§_-63i§) : void
      {
         §_-J2h§.§_-n1V§(this + ".onStartBattleFailure...");
         this.onHandShakeFailed(§_-s2a§.§_-K3t§(§_-s2a§.PVP_SERVER_BATTLE_CREATION_ERROR));
      }
      
      private function onHandShakeConnectionClosed(param1:flash.events.Event) : void
      {
         §_-J2h§.§_-n1V§(this + ".onHandShakeConnectionClosed...");
         this.onHandShakeFailed(§_-s2a§.§_-K3t§(§_-s2a§.PVP_SERVER_CONNECTION_CLOSED));
      }
      
      private function onHandShakeTimeout(param1:flash.events.Event) : void
      {
         §_-J2h§.§_-n1V§(this + ".onHandShakeTimeout...");
         this.onHandShakeFailed(§_-s2a§.§_-K3t§(§_-s2a§.BATTLE_REQUEST_TIMEOUT));
      }
      
      private function onHandShakeFailed(param1:String) : void
      {
         §_-J2h§.§_-n1V§(this + ".onHandShakeFailed...");
         §_-J2l§.§_-m1I§();
         this.state = §_-dl§;
         this.§_-v18§();
         this.§_-A3u§();
         this.§_-B14§.onFail(param1);
      }
      
      private function reopenConnection(param1:flash.events.Event) : void
      {
         §_-J2h§.§_-n1V§(this + ".reopenConnection...");
         §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_PVP_CONNECT);
         this.connection = new §_-6a§(this.§_-wA§);
         this.connection.open(this.onReopenSuccess,null);
         this.connection.addListener(PvpChatMessage,this.§_-C1x§,false,0,true);
      }
      
      private function reopenConnectionFinish(param1:flash.events.Event) : void
      {
         §_-J2h§.§_-n1V§(this + ".reopenConnectionFinish...");
         this.destroyTimer();
         this.endBattleOnConnectionClose();
      }
      
      private function onReopenSuccess() : void
      {
         §_-J2h§.§_-n1V§(this + ".onReopenSuccess...");
         this.destroyTimer();
         this.§_-E3M§();
      }
      
      private function §_-E3M§() : void
      {
         §_-J2h§.§_-n1V§(this + ".relogin: from " + this.state + " to " + §_-X2R§ + ", gm=" + §_-X1j§.§_-12n§.gameMaster);
         this.state = §_-X2R§;
         if(!§_-X1j§.§_-12n§.gameMaster)
         {
            this.endBattleOnConnectionClose();
         }
         else
         {
            §_-J2l§.§_-e1L§(§_-s2a§.BATTLE_PVP_LOGIN,this.sendReloginCommand);
         }
      }
      
      private function sendReloginCommand() : void
      {
         var cmd:ReconnectToBattle = null;
         var up:UserProfile = null;
         var pc:IPlatformAccountController = null;
         var getSocialIds:String = null;
         §_-J2h§.§_-n1V§(this + ".sendReloginCommand...");
         try
         {
            cmd = new ReconnectToBattle();
            up = Application.userProfile;
            pc = §_-X1j§.§_-It§;
            cmd.profileId = up.getId();
            getSocialIds = UserProfileStructure.getSocialIdsAsString(up.getSocialIds());
            cmd.socialNetworkId = pc.getPlatformType().servercode;
            cmd.playerName = up.getCharName();
            cmd.authKey = §_-H1u§.getAuthKey(true);
            cmd.mainServerId = 1;
            cmd.battleId = this.§_-B14§.info.battleId;
            cmd.turnNum = §_-X1j§.§_-12n§.gameMaster.§_-82g§();
            cmd.lastCommandNum = this.§_-c1y§.§_-u1I§();
            this.connection.addEventListener(flash.events.Event.CLOSE,this.§_-ut§);
            this.connection.addListener(BattleLoginError,this.§_-ut§);
            this.connection.addListener(StartPvpBattle,this.§_-ko§);
            this.connection.send(cmd);
         }
         catch(e:Error)
         {
         }
         this.createTimer(RECONNECT_TIMEOUT,1,this.onReloginTimer);
      }
      
      private function clearReloginEvents() : void
      {
         §_-J2h§.§_-n1V§(this + ".clearReloginEvents...");
         §_-J2l§.§_-m1I§();
         this.destroyTimer();
         if(this.connection)
         {
            this.connection.removeEventListener(flash.events.Event.CLOSE,this.§_-ut§);
            this.connection.removeListener(BattleLoginError,this.§_-ut§);
            this.connection.removeListener(StartPvpBattle,this.§_-ko§);
         }
      }
      
      private function §_-ko§(param1:§_-63i§) : void
      {
         var _loc2_:StartPvpBattle = §_-63i§(param1).message as StartPvpBattle;
         §_-J2h§.§_-n1V§(this + ".onReloginSuccess: " + _loc2_);
         §_-J2g§.§_-i1N§.§_-zy§(_loc2_.sessionKey);
         this.clearReloginEvents();
         this.process();
      }
      
      private function §_-ut§(param1:flash.events.Event) : void
      {
         var _loc2_:BattleLoginError = null;
         §_-J2h§.§_-n1V§(this + ".onReloginError: " + param1);
         if(param1 is §_-63i§)
         {
            _loc2_ = §_-63i§(param1).message as BattleLoginError;
            if(Boolean(_loc2_) && Boolean(_loc2_.error))
            {
               if(_loc2_.error == BattleLoginErrorType.RECONNECT_TIMEOUT)
               {
                  this.endBattleOnConnectionClose(§_-XA§.§_-z2q§);
               }
            }
         }
      }
      
      private function onReloginTimer(param1:TimerEvent) : void
      {
         §_-J2h§.§_-n1V§(this + ".onReloginTimer...");
         this.clearReloginEvents();
         this.§_-A3u§();
         this.§_-f2o§();
      }
      
      private function process() : void
      {
         §_-J2h§.§_-n1V§(this + ".process...");
         this.state = §_-mR§;
         this.connection.addEventListener(flash.events.Event.CLOSE,this.§_-52b§,false,0,true);
         this.§_-c1y§.§_-J1z§(this.connection,this.playerNum);
         this.§_-c1y§.run();
      }
      
      private function §_-52b§(param1:flash.events.Event) : void
      {
         §_-J2h§.§_-n1V§(this + ".onConnectionClosed: " + §_-X1j§.§_-12n§.inBattle);
         this.connection.removeEventListener(flash.events.Event.CLOSE,this.§_-52b§);
         this.§_-c1y§.stop();
         if(§_-X1j§.§_-12n§.inBattle)
         {
            this.§_-H2V§ = 0;
            this.§_-f2o§();
         }
         else
         {
            this.endBattleOnConnectionClose();
         }
      }
      
      private function §_-f2o§() : void
      {
         §_-J2h§.§_-n1V§(this + ".tryToReopenConnection: " + this.§_-H2V§ + "/" + §_-o1F§);
         var _temp_1:* = this;
         var _loc1_:§_-C1B§ = this;
         var _temp_2:* = _loc1_.§_-H2V§;
         §§push(_temp_2);
         var _loc2_:Number = _temp_2 + 1;
         _loc1_.§_-H2V§ = _loc2_;
         if(§§pop() > §_-o1F§)
         {
            this.endBattleOnConnectionClose();
         }
         else
         {
            this.createTimer(RECONNECT_TIMEOUT,§_-02n§,this.reopenConnection,this.reopenConnectionFinish);
         }
      }
      
      private function endBattleOnConnectionClose(param1:§_-XA§ = null) : void
      {
         §_-J2h§.§_-n1V§(this + ".endBattleOnConnectionClose...");
         this.clearReloginEvents();
         if(param1 == null)
         {
            param1 = §_-XA§.§_-A2K§;
         }
         §_-X1j§.§_-12n§.§_-Q2l§(§_-J1§.§_-23m§,param1);
      }
      
      public function §_-iJ§() : void
      {
         this.§_-c1y§.§_-iJ§();
      }
      
      public function §_-qJ§(param1:Boolean) : void
      {
         this.§_-c1y§.§_-qJ§(param1);
      }
      
      public function §_-L1b§() : void
      {
         this.§_-c1y§.§_-L1b§();
      }
      
      public function §_-R2§() : void
      {
         this.§_-c1y§.§_-R2§();
      }
      
      public function §_-A1C§() : void
      {
         this.§_-c1y§.§_-A1C§();
      }
      
      public function §_-u1X§(param1:Array, param2:Array, param3:Array, param4:Array, param5:Array, param6:int) : void
      {
         this.§_-c1y§.§_-u1X§(param1,param2,param3,param4,param5,param6);
      }
      
      public function §_-oo§(param1:Array, param2:Array, param3:Array, param4:Array, param5:Array, param6:int) : void
      {
         this.§_-c1y§.§_-oo§(param1,param2,param3,param4,param5,param6);
      }
      
      public function §_-sD§(param1:uint) : void
      {
         §_-J2h§.§_-n1V§(this + ".createTimer: " + param1);
         this.§_-c1y§.§_-sD§(param1);
      }
      
      public function §_-Y2O§(param1:§_-Dd§) : void
      {
         var _loc2_:PvpChatMessage = null;
         if(Boolean(this.connection) && this.connection.§_-928§())
         {
            _loc2_ = new PvpChatMessage();
            _loc2_.playerNum = this.playerNum;
            _loc2_.message = param1.message;
            _loc2_.action = param1.action;
            _loc2_.battleId = this.§_-B14§.info.battleId;
            _loc2_.isTeamMsg = param1.isTeamMsg;
            this.connection.send(_loc2_);
         }
      }
      
      private function §_-C1x§(param1:§_-63i§) : void
      {
         var _loc2_:PvpChatMessage = PvpChatMessage(param1.message);
         §_-X1j§.§_-12n§.§_-q2B§(_loc2_.message,_loc2_.action,§_-X1j§.§_-12n§.§_-V2F§(_loc2_.playerNum),_loc2_.isTeamMsg);
      }
      
      private function createTimer(param1:Number, param2:int = 0, param3:Function = null, param4:Function = null) : void
      {
         §_-J2h§.§_-n1V§(this + ".createTimer...");
         this.destroyTimer();
         this.timeout = new Timer(param1,param2);
         if(param3 != null)
         {
            this.timeout.addEventListener(TimerEvent.TIMER,param3,false,0,true);
         }
         if(param4 != null)
         {
            this.timeout.addEventListener(TimerEvent.TIMER_COMPLETE,param4,false,0,true);
         }
         this.timeout.start();
      }
      
      private function destroyTimer() : void
      {
         §_-J2h§.§_-n1V§(this + ".destroyTimer: " + this.timeout);
         if(this.timeout)
         {
            this.timeout.stop();
            this.timeout = null;
         }
      }
   }
}


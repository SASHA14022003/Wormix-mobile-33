package §_-H3§
{
   import §_-12a§.§_-f1J§;
   import §_-62§.*;
   import §_-73I§.§_-Z2e§;
   import §_-91B§.§_-z2l§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.§_-ts§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-63i§;
   import §_-B2z§.§_-c1G§;
   import §_-DJ§.§_-Es§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-QD§.§_-G2z§;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1b§.§_-81l§;
   import §_-aM§.§_-P1N§;
   import §_-b1F§.§_-G4§;
   import §_-d26§.§_-c2E§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-lD§;
   import §_-l1K§.§_-d2j§;
   import §_-n1w§.*;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-u2J§.§_-T1K§;
   import §_-z1g§.§_-82X§;
   import §_-z20§.§_-Tn§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.hurlant.util.Base64;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.controls.text.TextInstanceCreator;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.themes.FontSize;
   import flash.display.StageOrientation;
   import flash.events.StageOrientationEvent;
   import flash.events.TimerEvent;
   import flash.geom.Point;
   import flash.text.TextFormatAlign;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.Timer;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.server.EndTurnResponse;
   import ru.pragmatix.wormix.messages.server.PumpReactionRatesResult;
   import ru.pragmatix.wormix.messages.structures.PumpReactionRateStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.GameObjectUtils;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.ex.CreateBattleRequest;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.pvp.messages.ex.WidenSearch;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.AirMissile;
   import ru.pragmatix.wormix.weapons.ammo.BurningOil;
   import ru.pragmatix.wormix.weapons.ammo.MolotovProjectile;
   import ru.pragmatix.wormix.weapons.ammo.ammoFactory.AmmosFactory;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.Pool;
   
   public class §_-n1t§ extends §_-I1V§
   {
      
      private static const §_-E3D§:int = 5 * 1000;
      
      private static const §_-R1p§:int = 20;
      
      private var battleType:PvpBattleType;
      
      private var §_-rG§:§_-Es§;
      
      private var wager:§_-82X§;
      
      private var §_-SB§:Timer;
      
      public function §_-n1t§()
      {
         super();
         §_-c2I§();
      }
      
      override public function dispose() : void
      {
         if(this.§_-53v§())
         {
            this.§_-H2S§();
         }
         this.battleType = null;
         if(this.§_-rG§)
         {
            if(this.§_-rG§.§_-h1C§())
            {
               this.§_-rG§.hide();
            }
            if(this.§_-rG§.hasEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST))
            {
               this.§_-rG§.removeEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,this.§_-z13§);
            }
            this.§_-rG§.dispose();
            this.§_-rG§ = null;
         }
         this.wager = null;
         super.dispose();
      }
      
      public function §_-D1n§(param1:§_-82X§) : Boolean
      {
         if(state == READY && !Application.§_-dv§() && Boolean(param1))
         {
            Application.§_-a1k§(true);
            info = new §_-O2i§(§_-81M§.§_-Y1C§);
            info.online = true;
            info.§_-wA§ = Server.§_-O2A§(§_-c1G§.PVP);
            this.wager = param1;
            this.battleType = param1.battleType;
            info.§_-oR§ = true;
            info.mapId = §_-X1j§.§_-H15§.§_-43Y§(§_-81M§.§_-A1W§);
            connect(info.§_-wA§,this.§_-J16§,this.§_-nD§);
            return true;
         }
         §_-fH§.§_-h2r§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ERROR),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_REQUEST_FRIEND_TO_BATTLE),§_-fH§.§_-1B§,§_-t16§);
         return false;
      }
      
      override protected function §_-Y1S§(param1:uint) : void
      {
         super.§_-Y1S§(param1);
         if(param1 == §_-83l§)
         {
            if(Boolean(this.§_-rG§) && this.§_-rG§.§_-h1C§())
            {
               this.§_-rG§.hide();
            }
            §_-J2l§.§_-u2b§.show();
         }
         if(param1 == READY)
         {
            §_-J2l§.§_-u2b§.hide();
         }
      }
      
      override protected function §_-5K§(param1:uint) : void
      {
         super.§_-5K§(param1);
         if(param1 == §_-uv§)
         {
            if(this.§_-53v§())
            {
               this.§_-H2S§();
            }
         }
      }
      
      private function §_-J16§() : void
      {
         changeState(§_-uv§);
         this.§_-aN§();
         var _loc1_:CreateBattleRequest = §_-wv§(info.mapId,info.§_-oR§,this.wager,info.missionIds,§_-Av§,new <uint>[Application.userProfile.getId()]);
         §_-c1K§.send(_loc1_);
         §_-LG§();
         this.§_-kt§();
      }
      
      public function §_-aN§() : void
      {
         if(!this.§_-rG§)
         {
            this.§_-rG§ = new §_-Es§(§_-Es§.§_-kR§,§_-lm§,false);
            this.§_-rG§.addEventListener(§_-T1K§.CANCEL_BATTLE_REQUEST,this.§_-z13§);
         }
         this.§_-rG§.show();
      }
      
      private function §_-z13§(param1:Event) : void
      {
         cancelBattle();
      }
      
      override protected function §_-rn§(param1:§_-63i§) : void
      {
         var _loc2_:BattleCreated = null;
         changeState(§_-83l§);
         if(info != null)
         {
            _loc2_ = BattleCreated(param1.message);
            if(_loc2_.battleType.value == this.battleType.value)
            {
               if(Boolean(this.§_-rG§) && this.§_-rG§.§_-h1C§())
               {
                  this.§_-rG§.hide();
               }
               info.seed = _loc2_.seed;
               info.battleId = _loc2_.battleId;
               info.mapId = _loc2_.mapId;
               info.wager = _loc2_.wager;
               info.reagentsForBattle = §_-b1L§.§_-n2§(_loc2_.reagentsForBattle);
               info.preCalculatedPoints = _loc2_.preCalculatedPoints;
               §_-U2s§(_loc2_.playerStructs);
               §_-41G§.load(info.mapId,false,false,info.§_-Fx§(),this.§_-lt§,§_-QA§);
            }
         }
         else
         {
            this.§_-z1t§();
         }
      }
      
      override protected function §_-015§(param1:§_-63i§) : void
      {
         super.§_-015§(param1);
         if(Boolean(this.§_-rG§) && this.§_-rG§.§_-h1C§())
         {
            this.§_-rG§.hide();
         }
      }
      
      private function §_-lt§(param1:§_-03A§) : void
      {
         var _loc2_:§_-O2i§ = null;
         if(state == §_-83l§)
         {
            _loc2_ = info;
            _loc2_.mapRecord = param1.mapRecord;
            _loc2_.§_-u2Y§ = param1.§_-JV§();
            §_-j2n§ = false;
            changeState(READY);
            §_-X1j§.§_-12n§.§_-j4§(_loc2_,§_-c1K§);
         }
         else
         {
            this.§_-z1t§();
         }
      }
      
      private function §_-z1t§() : void
      {
         §_-J2l§.§_-u2b§.hide();
         §_-t16§();
      }
      
      private function §_-53v§() : Boolean
      {
         return this.§_-SB§ != null;
      }
      
      private function §_-kt§() : void
      {
         this.§_-SB§ = new Timer(§_-E3D§,§_-R1p§);
         this.§_-SB§.addEventListener(TimerEvent.TIMER,this.§_-A1X§);
         this.§_-SB§.start();
      }
      
      private function §_-H2S§() : void
      {
         this.§_-SB§.removeEventListener(TimerEvent.TIMER,this.§_-A1X§);
         this.§_-SB§.stop();
         this.§_-SB§ = null;
      }
      
      private function §_-A1X§(param1:TimerEvent) : void
      {
         §_-c1K§.send(new WidenSearch());
      }
      
      override protected function §_-nD§() : void
      {
         if(Boolean(this.§_-rG§) && this.§_-rG§.§_-h1C§())
         {
            this.§_-rG§.hide();
         }
         super.§_-nD§();
      }
   }
}


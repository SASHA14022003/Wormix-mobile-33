package §_-81r§
{
   import §_-12a§.§_-41b§;
   import §_-21p§.§_-4w§;
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-51M§.Cat;
   import §_-52V§.§_-R9§;
   import §_-5Y§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-T1y§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-a3§;
   import §_-73d§.§_-g1J§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Af§.§_-k1I§;
   import §_-C2t§.§_-Ui§;
   import §_-C3f§.§_-1Y§;
   import §_-Cl§.§_-L2z§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-V1Y§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-P1z§.*;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.ClanCreateView;
   import §_-Y1O§.§_-V23§;
   import §_-Y1O§.§_-y1o§;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Y1b§.§_-81l§;
   import §_-aM§.*;
   import §_-b1F§.*;
   import §_-bI§.*;
   import §_-g2e§.§_-q2Z§;
   import §_-g2r§.§_-03A§;
   import §_-gG§.§_-M2S§;
   import §_-gG§.§_-Z2z§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-kP§.CraftTreePanel;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-nE§.§_-p16§;
   import §_-q26§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-z1g§.§_-F4§;
   import §_-z1g§.§_-M2v§;
   import §_-zI§.§_-8D§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import com.distriqt.extension.inappbilling.events.InAppBillingEvent;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import com.hurlant.util.der.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.NumericStepper;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.TextInput;
   import feathers.controls.ToggleButton;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.controls.renderers.IListItemRenderer;
   import feathers.data.ListCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import feathers.themes.styles.AlternateScrollBarStyles;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.*;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.request.ClanSummaryRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.ClanSummaryResponse;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanEmblemResponse;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-O1f§;
   import ru.pragmatix.wormix.model.user.§_-m1x§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.model.user.§_-uH§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpEndTurnResponse;
   import ru.pragmatix.wormix.pvp.messages.structures.PositionStructure;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.core.Starling;
   import starling.display.Button;
   import starling.events.Event;
   import starling.textures.Texture;
   import starling.utils.AssetManager;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   import starlingbuilder.engine.UIBuilder;
   
   use namespace bi_internal;
   
   public class UserParamsMenu extends §_-V1Y§
   {
      
      public static const REACTION_INCREASE:String = "REACTION_INCREASE";
      
      public static const SAVE:String = "SAVE";
      
      public static const RESET:String = "RESET";
      
      private var binder:Binder;
      
      private var §_-U21§:int = 0;
      
      private var §_-3T§:int = 0;
      
      private var §_-e2c§:int = 0;
      
      public function UserParamsMenu()
      {
         super();
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("user_params_menu",this.binder);
         addChild(this.binder._panel);
         this.binder._ratingTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING);
         this.binder._reactionTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.REACTION);
         this.binder._attackTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.ATTACK);
         this.binder._armorTitle.text = §_-s2a§.§_-K3t§(§_-s2a§.ARMOR);
         this.binder._ratingDescription.text = §_-s2a§.§_-K3t§(§_-s2a§.RATING_DESCRIPTION);
         this.binder._reactionDescription.text = §_-s2a§.§_-K3t§(§_-s2a§.REACTION_DESCRIPTION);
         this.binder._attackDescription.text = §_-s2a§.§_-K3t§(§_-s2a§.ATTACK_DESCRIPTION);
         this.binder._armorDescription.text = §_-s2a§.§_-K3t§(§_-s2a§.ARMOR_DESCRIPTION);
         this.binder._saveButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BUTTON_SAVE);
         this.binder._resetButton.label = §_-s2a§.§_-y2o§(§_-s2a§.BUTTON_RESET_PARAMS);
         this.binder._resetButton.width *= 1.5;
         this.binder._reactionButton.label = "+";
         this.binder._attackButtonPlus.label = "+1";
         this.binder._armorButtonPlus.label = "+1";
         this.binder._attackButtonHalf.label = "50%";
         this.binder._armorButtonHalf.label = "50%";
         this.binder._attackButtonMax.label = "100%";
         this.binder._armorButtonMax.label = "100%";
         this.binder._attackButtonPlus.longPressDuration = 1;
         this.binder._armorButtonPlus.longPressDuration = 1;
         this.binder._attackButtonPlus.isLongPressEnabled = true;
         this.binder._armorButtonPlus.isLongPressEnabled = true;
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._reactionButton,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._attackButtonPlus,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._armorButtonPlus,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._attackButtonHalf,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._armorButtonHalf,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._attackButtonMax,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._armorButtonMax,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._resetButton,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._saveButton,Event.TRIGGERED,this.§_-y1l§);
         §_-J2N§(this.binder._attackButtonPlus,FeathersEventType.LONG_PRESS,this.§_-HZ§);
         §_-J2N§(this.binder._armorButtonPlus,FeathersEventType.LONG_PRESS,this.§_-HZ§);
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,Event.CLOSE);
         §_-jg§(this.binder._reactionButton,Event.TRIGGERED);
         §_-jg§(this.binder._attackButtonPlus,Event.TRIGGERED);
         §_-jg§(this.binder._armorButtonPlus,Event.TRIGGERED);
         §_-jg§(this.binder._resetButton,Event.TRIGGERED);
         §_-jg§(this.binder._saveButton,Event.TRIGGERED);
         §_-jg§(this.binder._attackButtonPlus,FeathersEventType.LONG_PRESS);
         §_-jg§(this.binder._armorButtonPlus,FeathersEventType.LONG_PRESS);
      }
      
      override protected function draw() : void
      {
         var _loc1_:UserProfile = null;
         var _loc2_:§_-uH§ = null;
         var _loc3_:int = 0;
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:int = 0;
         var _loc8_:int = 0;
         super.draw();
         if(isInvalid(INVALIDATION_FLAG_DATA))
         {
            _loc1_ = Application.userProfile;
            _loc2_ = new §_-uH§(_loc1_.getLevel());
            _loc2_.§_-eQ§(_loc1_.§_-w1p§());
            _loc2_.§_-q1H§(_loc1_.§_-h2m§());
            _loc3_ = int(_loc2_.§_-41C§);
            _loc4_ = int(_loc2_.§_-VY§);
            this.§_-e2c§ = Math.max(0,_loc3_ - this.§_-3T§ - this.§_-U21§);
            _loc5_ = _loc1_.§_-w1p§();
            _loc6_ = int(Math.max(_loc5_ + this.§_-U21§,0));
            _loc7_ = _loc1_.§_-h2m§();
            _loc8_ = int(Math.max(_loc7_ + this.§_-3T§,0));
            this.binder._attackButtonHalf.label = this.binder._armorButtonHalf.label = String(_loc2_.§_-VY§ / 2);
            this.binder._attackButtonMax.label = this.binder._armorButtonMax.label = _loc2_.§_-VY§.toString();
            this.binder._attackCount.text = §_-33r§.§_-jA§(_loc6_,_loc1_.stats.bonusAttack.value);
            this.binder._armorCount.text = §_-33r§.§_-jA§(_loc8_,_loc1_.stats.§_-v2n§.value);
            this.binder._reactionCount.text = _loc1_.§_-u2l§().toString();
            this.binder._ratingCount.text = _loc1_.§_-Zp§().toString();
            this.binder._panel.title = this.§_-e2c§ > 0 ? §_-s2a§.§_-K3t§(§_-s2a§.ALLOCATE_POINTS) + " " + this.§_-e2c§.toString() : §_-s2a§.§_-K3t§(§_-s2a§.NO_POINTS);
            this.binder._resetButton.isEnabled = _loc5_ + _loc7_ > 0;
            this.binder._saveButton.isEnabled = this.§_-3T§ + this.§_-U21§ > 0;
            this.binder._attackButtonPlus.isEnabled = _loc3_ > 0 && _loc6_ < _loc4_;
            this.binder._armorButtonPlus.isEnabled = _loc3_ > 0 && _loc8_ < _loc4_;
            this.binder._attackButtonHalf.isEnabled = _loc3_ > 0;
            this.binder._armorButtonHalf.isEnabled = _loc3_ > 0;
            this.binder._attackButtonMax.isEnabled = _loc3_ > 0;
            this.binder._armorButtonMax.isEnabled = _loc3_ > 0;
         }
      }
      
      private function §_-Q11§(param1:TextInput) : void
      {
         param1.isEditable = false;
         param1.isSelectable = false;
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         var _loc2_:Function = null;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         var _loc3_:EventDispatcher = param1.currentTarget;
         switch(_loc3_)
         {
            case this.binder._attackButtonPlus:
               §§push(0);
               break;
            case this.binder._armorButtonPlus:
               §§push(1);
               break;
            case this.binder._attackButtonHalf:
               §§push(2);
               break;
            case this.binder._armorButtonHalf:
               §§push(3);
               break;
            case this.binder._attackButtonMax:
               §§push(4);
               break;
            case this.binder._armorButtonMax:
               §§push(5);
               break;
            case this.binder._reactionButton:
               §§push(6);
               break;
            default:
               switch(_loc3_)
               {
                  case this.binder._saveButton:
                     §§push(7);
                     break;
                  case this.binder._resetButton:
                     §§push(8);
                     break;
                  default:
                     §§push(9);
               }
         }
         switch(§§pop())
         {
            case 0:
            case 1:
               _loc2_ = this.§_-E3A§(param1.currentTarget);
               if(_loc2_ != null)
               {
                  _loc2_();
               }
               break;
            case 2:
            case 3:
               this.§_-WI§();
               break;
            case 4:
               this.§_-S13§();
               break;
            case 5:
               this.§_-3S§();
               break;
            case 6:
               dispatchEventWith(REACTION_INCREASE);
               break;
            case 7:
               dispatchEventWith(SAVE);
               break;
            case 8:
               dispatchEventWith(RESET);
         }
      }
      
      private function §_-S13§() : void
      {
         var _loc1_:§_-m1x§ = Application.userProfile.stats;
         this.§_-U21§ = parseInt(this.binder._attackButtonMax.label) - _loc1_.§_-A3Z§.value;
         this.§_-3T§ = -1 * _loc1_.§_-Z2U§.value;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-3S§() : void
      {
         var _loc1_:§_-m1x§ = Application.userProfile.stats;
         this.§_-3T§ = parseInt(this.binder._armorButtonMax.label) - _loc1_.§_-Z2U§.value;
         this.§_-U21§ = -1 * _loc1_.§_-A3Z§.value;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-WI§() : void
      {
         var _loc1_:UserProfile = Application.userProfile;
         var _loc2_:int = int(parseInt(this.binder._attackButtonHalf.label));
         this.§_-U21§ = _loc2_ - _loc1_.stats.§_-A3Z§.value;
         this.§_-3T§ = _loc2_ - _loc1_.stats.§_-Z2U§.value;
         invalidate(INVALIDATION_FLAG_DATA);
      }
      
      private function §_-HZ§(param1:Event) : void
      {
         var increaseFunction:Function;
         var button:feathers.controls.Button = null;
         var repeatCallId:uint = 0;
         var e:Event = param1;
         §_-h2B§.play(§_-81L§.§_-o1Z§);
         button = e.currentTarget as feathers.controls.Button;
         increaseFunction = this.§_-E3A§(e.currentTarget);
         if(increaseFunction != null)
         {
            repeatCallId = Starling.juggler.repeatCall(increaseFunction,0.05);
            button.addEventListener(FeathersEventType.STATE_CHANGE,function(param1:Event):void
            {
               button.removeEventListener(FeathersEventType.STATE_CHANGE,arguments.callee);
               Starling.juggler.removeByID(repeatCallId);
            });
         }
      }
      
      private function §_-E3A§(param1:Object) : Function
      {
         switch(param1)
         {
            case this.binder._attackButtonPlus:
               return this.§_-a9§;
            case this.binder._armorButtonPlus:
               return this.§_-z2E§;
            default:
               return null;
         }
      }
      
      private function §_-a9§() : void
      {
         if(this.§_-e2c§ > 0 || this.§_-3T§ > 0)
         {
            ++this.§_-U21§;
            this.§_-3T§ = this.§_-e2c§ > 0 ? this.§_-3T§ : int(this.§_-3T§ - 1);
            invalidate(INVALIDATION_FLAG_DATA);
         }
      }
      
      private function §_-z2E§() : void
      {
         if(this.§_-e2c§ > 0 || this.§_-U21§ > 0)
         {
            ++this.§_-3T§;
            this.§_-U21§ = this.§_-e2c§ > 0 ? this.§_-U21§ : int(this.§_-U21§ - 1);
            invalidate(INVALIDATION_FLAG_DATA);
         }
      }
      
      public function get §_-Z13§() : int
      {
         return this.§_-U21§;
      }
      
      public function get §_-62a§() : int
      {
         return this.§_-3T§;
      }
      
      public function reset() : void
      {
         this.§_-U21§ = 0;
         this.§_-3T§ = 0;
         invalidate(INVALIDATION_FLAG_DATA);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.Panel;

class Binder
{
   
   public var _panel:Panel;
   
   public var _ratingTitle:Label;
   
   public var _ratingCount:Label;
   
   public var _ratingDescription:Label;
   
   public var _reactionTitle:Label;
   
   public var _reactionCount:Label;
   
   public var _reactionButton:Button;
   
   public var _reactionDescription:Label;
   
   public var _attackTitle:Label;
   
   public var _attackCount:Label;
   
   public var _attackButtonPlus:Button;
   
   public var _attackButtonHalf:Button;
   
   public var _attackButtonMax:Button;
   
   public var _attackDescription:Label;
   
   public var _armorTitle:Label;
   
   public var _armorCount:Label;
   
   public var _armorButtonPlus:Button;
   
   public var _armorButtonHalf:Button;
   
   public var _armorButtonMax:Button;
   
   public var _armorDescription:Label;
   
   public var _saveButton:Button;
   
   public var _resetButton:Button;
   
   public function Binder()
   {
      super();
   }
}

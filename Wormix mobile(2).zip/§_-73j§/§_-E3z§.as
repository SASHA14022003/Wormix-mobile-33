package §_-73j§
{
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-l1g§.§_-L3Q§;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.ChangeClanDescriptionResponse;
   import ru.pragmatix.wormix.model.items.craft.CraftedEquipFamily;
   import starling.events.Event;
   
   public class §_-E3z§ extends Event
   {
      
      public static const §_-GY§:String = "craftResult";
      
      private var _result:int;
      
      private var §_-e1K§:int;
      
      private var §_-C2y§:CraftedEquipFamily;
      
      public function §_-E3z§(param1:int, param2:int = -1, param3:CraftedEquipFamily = null, param4:Boolean = false, param5:Boolean = false)
      {
         super(§_-GY§,param4,param5);
         this._result = param1;
         this.§_-e1K§ = param2;
         this.§_-C2y§ = param3;
      }
      
      public function get result() : int
      {
         return this._result;
      }
      
      public function get equipId() : int
      {
         return this.§_-e1K§;
      }
      
      public function get §_-O1P§() : CraftedEquipFamily
      {
         return this.§_-C2y§;
      }
   }
}


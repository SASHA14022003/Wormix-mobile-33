package §_-l2r§
{
   import §_-62§.§_-G1p§;
   import §_-73d§.§_-pT§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-G16§.§_-33h§;
   import §_-H2g§.§_-di§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-l1K§.§_-W2f§;
   import §_-r1C§.§_-h2B§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import dragonBones.Armature;
   import dragonBones.core.BaseObject;
   import feathers.controls.ScrollPolicy;
   import feathers.core.FeathersControl;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.utils.id.UserIdType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-K1t§
   {
      
      public static const §_-Q2C§:Number = 2 / 3;
      
      public static const §_-31c§:Number = 2 / 3;
      
      public static const §_-h2z§:Number = 0.5 * §_-Q2C§;
      
      public static const §_-236§:Number = 1;
      
      public static const §_-A2u§:String = "_hands/";
      
      public static const §_-Im§:String = "_effects/";
      
      public static const §_-t1V§:String = "DragonbonedWeapons";
      
      public static const §_-IP§:String = "DragonbonedCharActions";
      
      public static const §_-82m§:String = "DragonbonedHats";
      
      public static const §_-vX§:String = "DragonbonedArtifacts";
      
      public static const §_-B1s§:String = "DragonbonedEffects";
      
      public static const §_-a1j§:String = "DragonbonedUI";
      
      public static const §_-yr§:String = "ClanBanner";
      
      public static const §_-Y1c§:String = "play";
      
      public static const §_-G1E§:String = "idle";
      
      public static const §_-J2e§:String = "activate";
      
      public static const §_-XN§:String = "appear";
      
      public static const §_-s1g§:String = "disappear";
      
      private static var pool:§_-33h§ = new §_-33h§(§_-di§);
      
      public function §_-K1t§()
      {
         super();
      }
      
      public static function buildArmature(param1:String, param2:String = null, param3:String = null) : §_-di§
      {
         var _loc4_:§_-di§ = null;
         var _loc5_:Armature = Application.factory.buildArmature(param1,param3);
         if(_loc5_)
         {
            _loc4_ = pool.get() as §_-di§;
            _loc4_.init(_loc5_);
            if(param2)
            {
               _loc4_.playAnimation(param2);
            }
         }
         return _loc4_;
      }
      
      public static function returnToPool(param1:§_-di§) : void
      {
         pool.put(param1);
      }
      
      public static function §_-LC§() : void
      {
         pool.empty();
         BaseObject.clearPool(Armature);
         BaseObject.setMaxCount(Armature,500);
      }
   }
}


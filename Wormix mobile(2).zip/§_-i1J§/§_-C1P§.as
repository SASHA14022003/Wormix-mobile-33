package §_-i1J§
{
   import §_-B1y§.§_-F1P§;
   import §_-DJ§.§_-fH§;
   import §_-L1H§.§_-C3e§;
   import §_-P2i§.§_-b7§;
   import §_-Y1O§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-sK§.§_-H2a§;
   import §_-z1g§.§_-C32§;
   import config.§_-vR§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.PvpBattleType;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.events.Event;
   
   public class §_-C1P§ extends §_-H2a§
   {
      
      public function §_-C1P§()
      {
         super();
      }
      
      protected function §_-J2T§(param1:UserProfile) : Boolean
      {
         var _loc3_:Boolean = false;
         if(!param1)
         {
            return false;
         }
         var _loc2_:Boolean = param1.§_-V1K§() == §_-X1j§.§_-It§.getPlatformType().servercode;
         if(!_loc2_ || !§_-vR§.§_-42H§)
         {
            _loc3_ = §_-C32§.getBoolean(§_-C32§.§_-G2S§);
            if(!_loc3_)
            {
               §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.OTHER_PLATFORM_CALLS_DISABLED));
               return false;
            }
         }
         return true;
      }
   }
}


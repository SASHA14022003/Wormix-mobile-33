package §_-i1J§
{
   import §_-n1w§.*;
   import §_-z1g§.§_-C32§;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-S8§ extends §_-C1P§
   {
      
      public function §_-S8§()
      {
         super();
      }
      
      override protected function §_-D2§(param1:UserProfile) : void
      {
         if(!param1)
         {
            return;
         }
         var _loc2_:Boolean = §_-C32§.getBoolean(§_-C32§.§_-G2S§);
         §_-X1j§.§_-NA§(this + ".executeAfterProfileLoaded:" + " getId=" + param1.getId() + " getPlatformId=" + param1.§_-V1K§() + " me.getPlatformId=" + Application.userProfile.§_-V1K§() + " my.servercode=" + §_-X1j§.§_-It§.getPlatformType().servercode + " me.getAvailablePlatformSocialId=" + Application.userProfile.§_-61H§() + " getTeamName=" + param1.§_-K3u§() + " getSocialId=" + param1.getSocialId() + " getAvailablePlatformSocialId=" + param1.§_-61H§() + " isGlobalCallsEnabled=" + _loc2_);
         if(!§_-J2T§(param1))
         {
            return;
         }
         §_-X1j§.§_-12n§.§_-N2s§(param1);
      }
   }
}


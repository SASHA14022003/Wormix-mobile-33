package §_-i1J§
{
   import §_-21p§.§_-4w§;
   import §_-31W§.§_-V26§;
   import feathers.controls.List;
   import feathers.controls.Scroller;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   
   public class §_-z27§ extends §_-C1P§
   {
      
      public function §_-z27§()
      {
         super();
      }
      
      override protected function §_-D2§(param1:UserProfile) : void
      {
         if(!§_-J2T§(param1))
         {
            return;
         }
         §_-X1j§.§_-12n§.§_-N1O§(param1);
      }
   }
}


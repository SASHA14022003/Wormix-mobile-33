package §_-i1J§
{
   import §_-DJ§.§_-J2l§;
   import §_-L1H§.§_-C3e§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-U2A§ extends §_-C1P§
   {
      
      public function §_-U2A§()
      {
         super();
      }
      
      override protected function §_-D2§(param1:UserProfile) : void
      {
         if(!§_-J2T§(param1))
         {
            return;
         }
         §_-X1j§.§_-A24§.§_-y1t§(param1,BossTypesTab.§_-i1p§);
      }
   }
}


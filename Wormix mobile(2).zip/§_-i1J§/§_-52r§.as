package §_-i1J§
{
   import §_-52L§.§_-u2x§;
   import §_-62§.§_-G1p§;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.arena.boss.BossTypesTab;
   import ru.pragmatix.wormix.model.items.craft.§_-13q§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-52r§ extends §_-C1P§
   {
      
      public function §_-52r§()
      {
         super();
      }
      
      override protected function §_-D2§(param1:UserProfile) : void
      {
         if(!§_-J2T§(param1))
         {
            return;
         }
         §_-X1j§.§_-A24§.§_-y1t§(param1,BossTypesTab.§_-B1u§);
      }
   }
}


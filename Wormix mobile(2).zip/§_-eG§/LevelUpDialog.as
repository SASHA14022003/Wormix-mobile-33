package §_-eG§
{
   import §_-21p§.§_-4w§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A2U§.§_-A23§;
   import §_-B2z§.§_-63i§;
   import §_-C3f§.§_-8B§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-V1Y§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-Ly§.§_-81L§;
   import §_-U1i§.§_-hK§;
   import §_-Y1b§.§_-OP§;
   import §_-b1F§.§_-G4§;
   import §_-k2s§.§_-b0§;
   import §_-l2r§.§_-K1t§;
   import §_-p24§.*;
   import §_-s20§.§_-d21§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.§_-13d§;
   import §_-z1g§.§_-lp§;
   import config.§_-x1p§;
   import dragonBones.animation.WorldClock;
   import dragonBones.objects.DragonBonesData;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalAlign;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-m1o§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-G1F§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.RepeatLevelUpAwardRequest;
   import ru.pragmatix.wormix.messages.server.RepeatLevelUpAwardResponse;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-A16§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.Pool;
   
   public class LevelUpDialog extends §_-V1Y§
   {
      
      private var resultInfo:§_-hK§;
      
      private var userProfile:UserProfile;
      
      private var §_-a2j§:§_-C§;
      
      private var §_-l22§:Boolean;
      
      private var binder:Binder;
      
      public function LevelUpDialog(param1:§_-hK§)
      {
         super();
         this.resultInfo = param1;
         this.userProfile = Application.userProfile;
      }
      
      override protected function initialize() : void
      {
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("level_up_dialog",this.binder);
         addChild(this.binder._content);
         this.§_-R1H§();
         this.binder._statsRewardsList.dataProvider = new ListCollection();
         this.binder._statsRewardsList.itemRendererType = §_-om§;
         this.binder._statsRewardsList.horizontalScrollPolicy = ScrollPolicy.OFF;
         this.binder._statsRewardsList.verticalScrollPolicy = ScrollPolicy.OFF;
         var _loc1_:HorizontalLayout = new HorizontalLayout();
         _loc1_.horizontalAlign = HorizontalAlign.CENTER;
         _loc1_.verticalAlign = VerticalAlign.TOP;
         _loc1_.paddingTop = 35;
         _loc1_.gap = 30;
         this.binder._statsRewardsList.layout = _loc1_;
         this.binder._levelLabel.text = this.resultInfo.§_-n2J§.toString();
         this.binder._titleLabel.text = §_-s2a§.§_-K3t§(§_-s2a§.LEVEL_UP_DIALOG_TITLE);
         this.binder._description.text = §_-s2a§.§_-K3t§(§_-s2a§.LEVEL_UP_DIALOG_BONUS_TEXT);
         this.binder._okButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BTN_GREAT);
         this.binder._postButton.label = §_-s2a§.§_-K3t§(§_-s2a§.BTN_SHARE_NAME);
         this.binder._adsButton.label = §_-s2a§.§_-K3t§(§_-s2a§.DOUBLE_LABEL);
         this.§_-w2Z§();
         if(§_-N1V§.postController.§_-hh§())
         {
            §_-J2N§(this.binder._postButton,Event.TRIGGERED,this.§_-y1l§,§_-81L§.§_-o1Z§);
         }
         else
         {
            this.binder._adsButton.parent.removeChild(this.binder._postButton);
         }
         §_-J2N§(this.binder._okButton,Event.TRIGGERED,this.§_-y1l§,§_-81L§.§_-o1Z§);
         this.binder._adsButton.parent.removeChild(this.binder._adsButton);
      }
      
      private function §_-R1H§() : void
      {
         var _loc2_:Array = null;
         var _loc3_:§_-b0§ = null;
         var _loc1_:Vector.<§_-b0§> = §_-x1p§.§_-32k§(this.resultInfo.§_-n2J§).§_-S1n§();
         this.§_-a2j§ = new §_-C§();
         if(_loc1_.length == 0)
         {
            this.§_-a2j§.visible = false;
         }
         else
         {
            _loc2_ = [];
            for each(_loc3_ in _loc1_)
            {
               if(this.§_-l22§ && _loc3_.getCount() > 0)
               {
                  _loc2_.push(new §_-b0§(_loc3_.getId(),_loc3_.getCount() * 2));
               }
               else
               {
                  _loc2_.push(_loc3_);
               }
            }
            this.§_-a2j§.§_-cf§(_loc2_);
            this.binder._rewardsContainer.addChild(this.§_-a2j§);
         }
      }
      
      private function §_-w2Z§() : void
      {
         var _loc1_:uint = §_-lp§.§_-L2a§(this.resultInfo.§_-n2J§) - §_-lp§.§_-L2a§(this.resultInfo.§_-n2J§ - 1);
         var _loc2_:int = this.resultInfo.§_-wj§ * (this.§_-l22§ ? 2 : 1);
         var _loc3_:int = int(this.resultInfo.§_-LB§);
         var _loc4_:uint = §_-lp§.§_-H§(this.resultInfo.§_-n2J§) - §_-lp§.§_-H§(this.resultInfo.§_-n2J§ - 1);
         §_-J2h§.§_-n1V§(this + ".updateAwards: fuzy=" + _loc2_ + " user.money=" + Application.userProfile.§_-51e§() + " => " + (_loc2_ + Application.userProfile.§_-51e§()));
         var _loc5_:ListCollection = this.binder._statsRewardsList.dataProvider as ListCollection;
         _loc5_.removeAll();
         if(_loc1_ > 0)
         {
            this.§_-G1T§(_loc5_,"+" + _loc1_.toString(),13172736,"HpIcon",16753740,§_-s2a§.HP);
         }
         if(_loc2_ > 0)
         {
            this.§_-G1T§(_loc5_,"+" + _loc2_.toString(),7975936,"icon_fuzy",11262790,§_-s2a§.COIN_QTIP);
         }
         if(_loc3_ > 0)
         {
            this.§_-G1T§(_loc5_,"+" + _loc3_.toString(),7975936,"icon_ruby",11262790,§_-s2a§.RUBY_QTIP);
         }
         if(_loc4_ > 0)
         {
            this.§_-G1T§(_loc5_,"+" + _loc4_.toString(),1480928,"TeamIcon",5554687,§_-s2a§.TEAM_LABEL);
         }
      }
      
      private function §_-G1T§(param1:ListCollection, param2:String, param3:uint, param4:String, param5:uint, param6:String) : void
      {
         param1.addItem({
            "value":param2,
            "textColor":param3,
            "icon":param4,
            "iconColor":param5,
            "hint":param6
         });
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._okButton,Event.TRIGGERED);
         §_-jg§(this.binder._postButton,Event.TRIGGERED);
         if(this.binder._adsButton)
         {
            §_-jg§(this.binder._adsButton,Event.TRIGGERED);
         }
      }
      
      private function §_-y1l§(param1:Event) : void
      {
         var _loc2_:§_-13d§ = null;
         var _loc3_:EventDispatcher = param1.currentTarget;
         switch(_loc3_)
         {
            case this.binder._okButton:
         }
         _loc2_ = §_-x1p§.§_-32k§(this.resultInfo.§_-n2J§);
         if(_loc2_ != null)
         {
            §_-m1o§.§_-f2M§(_loc2_.§_-S1n§());
         }
         hide();
      }
      
      private function §_-A14§() : void
      {
         §_-J2l§.§_-u2b§.show(§_-d21§.§_-51l§,new RepeatLevelUpAwardRequest(this.resultInfo.§_-n2J§),RepeatLevelUpAwardResponse,this.§_-Gf§,this.§_-C2B§);
      }
      
      private function §_-Gf§(param1:§_-63i§, ... rest) : void
      {
         var _loc5_:String = null;
         var _loc6_:§_-13d§ = null;
         §_-J2l§.§_-u2b§.hide();
         var _loc3_:RepeatLevelUpAwardResponse = RepeatLevelUpAwardResponse(param1.message);
         §_-J2h§.§_-n1V§(this + ".onRepeatLevelUpAwardSuccess: " + _loc3_ + ", args=" + rest);
         §_-J2h§.§_-n1V§(this + ".onRepeatLevelUpAwardSuccess: fuzyForNewLevel=" + this.resultInfo.§_-wj§ + " user.money=" + Application.userProfile.§_-51e§() + " => " + (this.resultInfo.§_-wj§ + Application.userProfile.§_-51e§()));
         var _loc4_:String = §_-s2a§.TITLE_ATTENTION;
         switch(_loc3_.status)
         {
            case §_-8B§.SUCCESS:
               _loc3_.awards;
               this.§_-w2Z§();
               this.§_-R1H§();
               _loc6_ = §_-x1p§.§_-32k§(this.resultInfo.§_-n2J§);
               if(_loc6_ != null)
               {
                  §_-m1o§.§_-f2M§(_loc6_.§_-S1n§());
               }
               if(this.resultInfo.§_-wj§)
               {
                  this.userProfile.§_-oA§(this.resultInfo.§_-wj§);
               }
               break;
            case §_-8B§.ERROR:
               _loc5_ = §_-s2a§.ERROR_SERVER;
               break;
            case §_-8B§.§_-Pf§:
               _loc5_ = §_-s2a§.ERROR_ADVERTISING_LIMIT_REACHED;
         }
         if(_loc5_)
         {
            §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(_loc4_),§_-s2a§.§_-K3t§(_loc5_),§_-fH§.§_-1B§);
         }
      }
      
      private function §_-C2B§(param1:* = null, ... rest) : void
      {
         §_-J2l§.§_-u2b§.hide();
         §_-fH§.§_-q1a§(§_-s2a§.§_-K3t§(§_-s2a§.TITLE_ATTENTION),§_-s2a§.§_-K3t§(§_-s2a§.ERROR_SERVER),§_-fH§.§_-1B§);
      }
      
      override public function show(param1:Boolean = true) : void
      {
         super.show(param1);
         §_-X1j§.§_-j14§.trackLevelup();
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.List;
import feathers.controls.Panel;

class Binder
{
   
   public var _content:LayoutGroup;
   
   public var _panel:Panel;
   
   public var _rewardsContainer:LayoutGroup;
   
   public var _titleLabel:Label;
   
   public var _levelLabel:Label;
   
   public var _description:Label;
   
   public var _statsRewardsList:List;
   
   public var _okButton:Button;
   
   public var _postButton:Button;
   
   public var _adsButton:Button;
   
   public function Binder()
   {
      super();
   }
}

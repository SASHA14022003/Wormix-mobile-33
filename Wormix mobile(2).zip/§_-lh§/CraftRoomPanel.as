package §_-lh§
{
   import §_-11L§.*;
   import §_-63M§.§_-F3f§;
   import §_-63U§.ProgressBarBoss;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-Bv§.§_-G3P§;
   import §_-C2t§.§_-92W§;
   import §_-CF§.§_-E19§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H3§.*;
   import §_-Om§.ReagentsPanel;
   import §_-S1N§.§_-R1U§;
   import §_-W§.§_-Ap§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-OP§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-e2r§.CraftEquipPanel;
   import §_-g2r§.§_-03A§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import §_-x2Q§.§_-dU§;
   import §_-y1s§.§_-a1i§;
   import §_-z1g§.§_-lp§;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.core.*;
   import com.hurlant.util.der.*;
   import feathers.controls.AutoSizeMode;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ToggleButton;
   import feathers.core.FeathersControl;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.ILayoutDisplayObject;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import flash.display.BitmapData;
   import flash.system.ApplicationDomain;
   import flash.system.Capabilities;
   import flash.system.LoaderContext;
   import flash.system.Security;
   import flash.system.SecurityDomain;
   import flash.text.TextField;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.messages.client.EndTurn;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.structures.SimpleProfileStructure;
   import ru.pragmatix.wormix.messages.structures.TurnStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.§_-73v§;
   import ru.pragmatix.wormix.weapons.ammo.GuardingBot;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public class CraftRoomPanel
   {
      
      public static var §_-T1I§:Object;
      
      public static const WIDTH:int = 940;
      
      public static const HEIGHT:int = 540;
      
      public static var §_-51X§:String = §_-s2a§.WEAPON_TAB;
      
      public static var §_-n2c§:String = §_-s2a§.WEAPON_TAB;
      
      private static const §_-026§:Array = [§_-s2a§.WEAPON_TAB,§_-s2a§.EQUIP_TAB,§_-s2a§.CRAFT_CRATE];
      
      private var §_-8T§:Boolean;
      
      private var §_-q2u§:ScreenNavigator;
      
      private var binder:Binder;
      
      public function CraftRoomPanel()
      {
         var contentBackImage:Image;
         var weaponSharedData:Object;
         var item:ScreenNavigatorItem;
         var equipSharedData:Object;
         var reagentsShareData:Object;
         super();
         this.binder = new Binder();
         §_-YQ§.§_-qM§("CraftRoomPanel",§_-q2v§.§_-A2T§,this.binder);
         this.binder._panel.validate();
         contentBackImage = this.binder._content.backgroundSkin as Image;
         contentBackImage.tileGrid = Pool.getRectangle(0,0,103,103);
         this.binder._tabBar.distributeTabSizes = false;
         this.binder._tabBar.horizontalAlign = HorizontalAlign.LEFT;
         this.binder._tabBar.verticalAlign = VerticalAlign.BOTTOM;
         this.binder._tabBar.tabFactory = function():ToggleButton
         {
            var _loc1_:ToggleButton = §_-YQ§.§_-L1A§("MenuTabButton") as ToggleButton;
            _loc1_.useHandCursor = true;
            return _loc1_;
         };
         this.binder._tabBar.tabInitializer = function(param1:ToggleButton, param2:Object):void
         {
            param1.label = §_-s2a§.§_-K3t§(param2.id.toString());
            param1.isEnabled = param2.isActive;
         };
         this.binder._tabBar.addEventListener(Event.TRIGGERED,this.§_-cR§);
         this.§_-q2u§ = new ScreenNavigator();
         this.binder._content.addChild(this.§_-q2u§);
         this.§_-q2u§.width = this.binder._content.width;
         this.§_-q2u§.height = this.binder._content.height;
         this.§_-q2u§.autoSizeMode = AutoSizeMode.CONTENT;
         weaponSharedData = {
            "index":0,
            "up":null
         };
         item = new ScreenNavigatorItem(new §_-a1i§());
         item.properties.sharedData = weaponSharedData;
         this.§_-q2u§.addScreen(§_-s2a§.WEAPON_TAB,item);
         equipSharedData = {
            "index":0,
            "up":null
         };
         item = new ScreenNavigatorItem(new CraftEquipPanel());
         item.properties.sharedData = equipSharedData;
         this.§_-q2u§.addScreen(§_-s2a§.EQUIP_TAB,item);
         reagentsShareData = {
            "index":0,
            "up":null
         };
         item = new ScreenNavigatorItem(ReagentsPanel);
         item.properties.sharedData = reagentsShareData;
         this.§_-q2u§.addScreen(§_-s2a§.CRAFT_CRATE,item);
      }
      
      public function get display() : FeathersControl
      {
         return this.binder._panel;
      }
      
      public function §_-82v§(param1:UserProfile, param2:Boolean) : void
      {
         this.§_-8T§ = param2;
         var _loc3_:String = param2 ? §_-n2c§ : §_-51X§;
         var _loc4_:ListCollection = new ListCollection();
         _loc4_.addItem({
            "id":§_-s2a§.WEAPON_TAB,
            "isActive":true,
            "up":param1
         });
         _loc4_.addItem({
            "id":§_-s2a§.EQUIP_TAB,
            "isActive":param2,
            "up":param1
         });
         _loc4_.addItem({
            "id":§_-s2a§.CRAFT_CRATE,
            "isActive":param2,
            "up":param1
         });
         this.binder._tabBar.dataProvider = _loc4_;
         var _loc5_:ScreenNavigatorItem = this.§_-q2u§.getScreen(_loc3_);
         _loc5_.properties.sharedData.up = §_-T1I§;
         this.§_-q2u§.showScreen(_loc3_);
         this.binder._tabBar.selectedIndex = _loc3_ ? int(§_-026§.indexOf(_loc3_)) : 0;
      }
      
      public function §_-O1W§() : Boolean
      {
         if(this.§_-q2u§.activeScreenID == §_-s2a§.WEAPON_TAB)
         {
            §_-h2B§.play(§_-d27§.§_-F1z§);
            return (this.§_-q2u§.activeScreen as §_-a1i§).§_-O1W§();
         }
         return false;
      }
      
      private function §_-cR§(param1:Event) : void
      {
         var _loc2_:String = param1.data.id;
         var _loc3_:ScreenNavigatorItem = this.§_-q2u§.getScreen(_loc2_);
         _loc3_.properties.sharedData.up = param1.data.up;
         §_-T1I§ = param1.data.up;
         if(this.§_-8T§)
         {
            §_-n2c§ = _loc2_;
         }
         this.§_-q2u§.showScreen(_loc2_);
      }
      
      public function dispose() : void
      {
         this.binder._tabBar.removeEventListener(Event.CHANGE,this.§_-cR§);
         this.binder = null;
         this.§_-q2u§.removeFromParent(true);
      }
   }
}

import feathers.controls.LayoutGroup;
import feathers.controls.TabBar;

class Binder
{
   
   public var _panel:LayoutGroup;
   
   public var _content:LayoutGroup;
   
   public var _tabBar:TabBar;
   
   public function Binder()
   {
      super();
   }
}

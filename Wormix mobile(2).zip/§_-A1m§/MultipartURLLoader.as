package §_-A1m§
{
   import §_-02q§.§_-11O§;
   import §_-12W§.*;
   import §_-21A§.*;
   import §_-31N§.§_-42G§;
   import §_-31N§.§_-Yy§;
   import §_-31W§.*;
   import §_-31Y§.§_-D3B§;
   import §_-51M§.Cat;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-ou§;
   import §_-62§.§_-zF§;
   import §_-73I§.§_-Z2e§;
   import §_-91A§.*;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B1y§.§_-ts§;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.MessageBox;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-G2H§.*;
   import §_-H16§.*;
   import §_-H3§.*;
   import §_-J31§.§_-R1h§;
   import §_-K3q§.§_-L3A§;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-P1z§.*;
   import §_-R2I§.*;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-S1N§.*;
   import §_-SP§.§_-M4§;
   import §_-Tm§.§_-RF§;
   import §_-U1Y§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-YF§.*;
   import §_-Z1K§.§_-A2n§;
   import §_-Z1K§.§_-q24§;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-dS§.§_-D3a§;
   import §_-g2e§.§_-q2Z§;
   import §_-gG§.§_-M2S§;
   import §_-j1w§.§_-B2i§;
   import §_-j22§.§_-5g§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-b0§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-n1w§.*;
   import §_-nE§.§_-p16§;
   import §_-p18§.§_-V14§;
   import §_-q26§.§_-Z25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1s§.*;
   import §_-s20§.§_-J2g§;
   import §_-vC§.§_-O1J§;
   import §_-w2W§.AchieveRoomScreenDesktop;
   import §_-w2W§.ArmoryScreenDesktop;
   import §_-w2W§.CraftRoomScreenDesktop;
   import §_-w2W§.DesktopRaceRoomScreen;
   import §_-w2W§.MainMenuScreenDesktop;
   import §_-w2W§.TeamRoomScreenDesktop;
   import §_-w2W§.WardrobeRoomScreen;
   import §_-w2W§.§_-21w§;
   import §_-w2W§.§_-72M§;
   import §_-w2W§.§_-HV§;
   import §_-w2W§.§_-I2R§;
   import §_-w2W§.§_-I3c§;
   import §_-w2W§.§_-h1Z§;
   import §_-w2i§.*;
   import §_-y1s§.*;
   import §_-z1g§.§_-5c§;
   import §_-z1g§.§_-M2v§;
   import §_-z1g§.§_-lp§;
   import §_-zI§.§_-92Q§;
   import §_-zI§.§_-A1s§;
   import §_-zI§.§_-F3q§;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.loading.*;
   import com.greensock.loading.core.LoaderItem;
   import com.greensock.plugins.*;
   import com.hurlant.math.*;
   import config.§_-V2w§;
   import config.§_-vR§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.Scroller;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import feathers.layout.VerticalLayoutData;
   import flash.display.BitmapData;
   import flash.display.DisplayObjectContainer;
   import flash.display.Shape;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.EventDispatcher;
   import flash.events.HTTPStatusEvent;
   import flash.events.IEventDispatcher;
   import flash.events.IOErrorEvent;
   import flash.events.MouseEvent;
   import flash.events.ProgressEvent;
   import flash.events.SecurityErrorEvent;
   import flash.filters.ColorMatrixFilter;
   import flash.geom.Point;
   import flash.net.SharedObject;
   import flash.net.URLLoader;
   import flash.net.URLLoaderDataFormat;
   import flash.net.URLRequest;
   import flash.net.URLRequestHeader;
   import flash.net.URLRequestMethod;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.Endian;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.clearInterval;
   import flash.utils.setTimeout;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.gui.controls.§_-NY§;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.controller.mobile.BaseMobileSocialController;
   import ru.pragmatix.flox.social.model.IUserProfile;
   import ru.pragmatix.wormix.controller.§_-C2c§;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fonts.FontColor;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanMemberStructure;
   import ru.pragmatix.wormix.messages.clans.request.treasury.CashMedalsClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.treasury.CashMedalsClanResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.CrashLog;
   import ru.pragmatix.wormix.messages.client.PumpReactionRate;
   import ru.pragmatix.wormix.messages.client.ResetParameters;
   import ru.pragmatix.wormix.messages.server.ShowSystemMessage;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.rewards.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-m1x§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreated;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-6A§;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-YD§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import ru.pragmatix.wormix.weapons.ammo.StaticCharge;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.extensions.PDParticleSystem;
   import starling.textures.Texture;
   import starling.textures.TextureSmoothing;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starlingbuilder.engine.UIBuilder;
   
   use namespace bi_internal;
   
   public class MultipartURLLoader extends flash.events.EventDispatcher
   {
      
      public static var §_-B33§:uint = 64 * 1024;
      
      private var _loader:URLLoader;
      
      private var §_-T4§:String;
      
      private var §_-fL§:Array;
      
      private var §_-A1p§:Array;
      
      private var §_-mI§:Dictionary;
      
      private var §_-X1l§:Dictionary;
      
      private var §_-LJ§:Boolean = false;
      
      private var §_-s2N§:String;
      
      private var _data:ByteArray;
      
      private var §_-w2o§:Boolean = false;
      
      private var §_-X1m§:Number;
      
      private var §_-e2l§:uint = 0;
      
      private var §_-72h§:uint = 0;
      
      private var §_-ND§:uint = 0;
      
      public var requestHeaders:Array;
      
      public function MultipartURLLoader()
      {
         super();
         this.§_-A1p§ = new Array();
         this.§_-X1l§ = new Dictionary();
         this.§_-fL§ = new Array();
         this.§_-mI§ = new Dictionary();
         this._loader = new URLLoader();
         this.requestHeaders = new Array();
      }
      
      public function load(param1:String, param2:Boolean = false) : void
      {
         if(param1 == null || param1 == "")
         {
            throw new IllegalOperationError("You cant load without specifing PATH");
         }
         this.§_-s2N§ = param1;
         this.§_-LJ§ = param2;
         if(this.§_-LJ§)
         {
            if(!this.§_-w2o§)
            {
               this.§_-u1N§();
            }
            else
            {
               this.§_-w1u§();
            }
         }
         else
         {
            this._data = this.§_-Oe§();
            this.§_-w1u§();
         }
      }
      
      public function §_-L1§() : void
      {
         if(this.§_-s2N§ == null || this.§_-s2N§ == "" || this.§_-LJ§ == false)
         {
            throw new IllegalOperationError("You can use this method only if loading asynchronous.");
         }
         if(!this.§_-w2o§ && this.§_-LJ§)
         {
            throw new IllegalOperationError("You should prepare data before sending when using asynchronous.");
         }
         this.§_-w1u§();
      }
      
      public function §_-R2F§() : void
      {
         this.§_-u1N§();
      }
      
      public function close() : void
      {
         try
         {
            this._loader.close();
         }
         catch(e:Error)
         {
         }
      }
      
      public function §_-62R§(param1:String, param2:Object = "") : void
      {
         if(this.§_-fL§.indexOf(param1) == -1)
         {
            this.§_-fL§.push(param1);
         }
         this.§_-mI§[param1] = param2;
         this.§_-w2o§ = false;
      }
      
      public function §_-pj§(param1:ByteArray, param2:String, param3:String = "Filedata", param4:String = "application/octet-stream") : void
      {
         var _loc5_:FilePart = null;
         if(this.§_-A1p§.indexOf(param2) == -1)
         {
            this.§_-A1p§.push(param2);
            this.§_-X1l§[param2] = new FilePart(param1,param2,param3,param4);
            this.§_-72h§ += param1.length;
         }
         else
         {
            _loc5_ = this.§_-X1l§[param2] as FilePart;
            this.§_-72h§ -= _loc5_.fileContent.length;
            _loc5_.fileContent = param1;
            _loc5_.fileName = param2;
            _loc5_.dataField = param3;
            _loc5_.contentType = param4;
            this.§_-72h§ += param1.length;
         }
         this.§_-w2o§ = false;
      }
      
      public function §_-A3I§() : void
      {
         this.§_-fL§ = new Array();
         this.§_-mI§ = new Dictionary();
         this.§_-w2o§ = false;
      }
      
      public function §_-h§() : void
      {
         var _loc1_:String = null;
         for each(_loc1_ in this.§_-A1p§)
         {
            (this.§_-X1l§[_loc1_] as FilePart).dispose();
         }
         this.§_-A1p§ = new Array();
         this.§_-X1l§ = new Dictionary();
         this.§_-72h§ = 0;
         this.§_-w2o§ = false;
      }
      
      public function dispose() : void
      {
         clearInterval(this.§_-X1m§);
         this.removeListener();
         this.close();
         this._loader = null;
         this.§_-T4§ = null;
         this.§_-fL§ = null;
         this.§_-mI§ = null;
         this.§_-A1p§ = null;
         this.§_-X1l§ = null;
         this.requestHeaders = null;
         this._data = null;
      }
      
      public function §_-tC§() : String
      {
         var _loc1_:int = 0;
         if(this.§_-T4§ == null)
         {
            this.§_-T4§ = "";
            _loc1_ = 0;
            while(_loc1_ < 32)
            {
               this.§_-T4§ += String.fromCharCode(int(97 + Math.random() * 25));
               _loc1_++;
            }
         }
         return this.§_-T4§;
      }
      
      public function get §_-L33§() : Boolean
      {
         return this.§_-LJ§;
      }
      
      public function get §_-P23§() : Boolean
      {
         return this.§_-w2o§;
      }
      
      public function get dataFormat() : String
      {
         return this._loader.dataFormat;
      }
      
      public function set dataFormat(param1:String) : void
      {
         if(param1 != URLLoaderDataFormat.BINARY && param1 != URLLoaderDataFormat.TEXT && param1 != URLLoaderDataFormat.VARIABLES)
         {
            throw new IllegalOperationError("Illegal URLLoader Data Format");
         }
         this._loader.dataFormat = param1;
      }
      
      public function get loader() : URLLoader
      {
         return this._loader;
      }
      
      private function §_-w1u§() : void
      {
         var _loc1_:URLRequest = new URLRequest();
         _loc1_.url = this.§_-s2N§;
         _loc1_.method = URLRequestMethod.POST;
         _loc1_.data = this._data;
         _loc1_.requestHeaders.push(new URLRequestHeader("Content-type","multipart/form-data; boundary=" + this.§_-tC§()));
         if(this.requestHeaders.length)
         {
            _loc1_.requestHeaders = _loc1_.requestHeaders.concat(this.requestHeaders);
         }
         this.addListener();
         this._loader.load(_loc1_);
      }
      
      private function §_-u1N§() : void
      {
         clearInterval(this.§_-X1m§);
         this._data = new ByteArray();
         this._data.endian = Endian.BIG_ENDIAN;
         this._data = this.§_-72L§(this._data);
         this.§_-e2l§ = 0;
         this.§_-ND§ = 0;
         this.§_-w2o§ = false;
         if(this.§_-A1p§.length)
         {
            this.§_-N2y§();
         }
         else
         {
            this._data = this.§_-U2J§(this._data);
            this.§_-w2o§ = true;
            dispatchEvent(new §_-O1J§(§_-O1J§.§_-q1V§));
         }
      }
      
      private function §_-Oe§() : ByteArray
      {
         var _loc1_:ByteArray = new ByteArray();
         _loc1_.endian = Endian.BIG_ENDIAN;
         _loc1_ = this.§_-72L§(_loc1_);
         _loc1_ = this.§_-J3O§(_loc1_);
         return this.§_-U2J§(_loc1_);
      }
      
      private function §_-U2J§(param1:ByteArray) : ByteArray
      {
         param1 = this.§_-A1E§(param1);
         return this.§_-B1W§(param1);
      }
      
      private function §_-72L§(param1:ByteArray) : ByteArray
      {
         var _loc2_:uint = 0;
         var _loc3_:String = null;
         var _loc4_:String = null;
         for each(_loc4_ in this.§_-fL§)
         {
            param1 = this.§_-A1E§(param1);
            param1 = this.§_-FU§(param1);
            _loc3_ = "Content-Disposition: form-data; name=\"" + _loc4_ + "\"";
            _loc2_ = 0;
            while(_loc2_ < _loc3_.length)
            {
               param1.writeByte(_loc3_.charCodeAt(_loc2_));
               _loc2_++;
            }
            param1 = this.§_-FU§(param1);
            param1 = this.§_-FU§(param1);
            param1.writeUTFBytes(this.§_-mI§[_loc4_]);
            param1 = this.§_-FU§(param1);
         }
         return param1;
      }
      
      private function §_-J3O§(param1:ByteArray) : ByteArray
      {
         var _loc2_:uint = 0;
         var _loc3_:String = null;
         var _loc4_:String = null;
         if(this.§_-A1p§.length)
         {
            for each(_loc4_ in this.§_-A1p§)
            {
               param1 = this.§_-V1S§(param1,this.§_-X1l§[_loc4_] as FilePart);
               param1 = this.§_-72c§(param1,this.§_-X1l§[_loc4_] as FilePart);
               if(_loc2_ != this.§_-A1p§.length - 1)
               {
                  param1 = this.§_-FU§(param1);
               }
               _loc2_++;
            }
            param1 = this.§_-G2J§(param1);
         }
         return param1;
      }
      
      private function §_-G2J§(param1:ByteArray) : ByteArray
      {
         var _loc2_:uint = 0;
         var _loc3_:String = null;
         param1 = this.§_-FU§(param1);
         param1 = this.§_-A1E§(param1);
         param1 = this.§_-FU§(param1);
         _loc3_ = "Content-Disposition: form-data; name=\"Upload\"";
         _loc2_ = 0;
         while(_loc2_ < _loc3_.length)
         {
            param1.writeByte(_loc3_.charCodeAt(_loc2_));
            _loc2_++;
         }
         param1 = this.§_-FU§(param1);
         param1 = this.§_-FU§(param1);
         _loc3_ = "Submit Query";
         _loc2_ = 0;
         while(_loc2_ < _loc3_.length)
         {
            param1.writeByte(_loc3_.charCodeAt(_loc2_));
            _loc2_++;
         }
         return this.§_-FU§(param1);
      }
      
      private function §_-V1S§(param1:ByteArray, param2:FilePart) : ByteArray
      {
         var _loc3_:uint = 0;
         var _loc4_:String = null;
         param1 = this.§_-A1E§(param1);
         param1 = this.§_-FU§(param1);
         _loc4_ = "Content-Disposition: form-data; name=\"Filename\"";
         _loc3_ = 0;
         while(_loc3_ < _loc4_.length)
         {
            param1.writeByte(_loc4_.charCodeAt(_loc3_));
            _loc3_++;
         }
         param1 = this.§_-FU§(param1);
         param1 = this.§_-FU§(param1);
         param1.writeUTFBytes(param2.fileName);
         param1 = this.§_-FU§(param1);
         param1 = this.§_-A1E§(param1);
         param1 = this.§_-FU§(param1);
         _loc4_ = "Content-Disposition: form-data; name=\"" + param2.dataField + "\"; filename=\"";
         _loc3_ = 0;
         while(_loc3_ < _loc4_.length)
         {
            param1.writeByte(_loc4_.charCodeAt(_loc3_));
            _loc3_++;
         }
         param1.writeUTFBytes(param2.fileName);
         param1 = this.§_-K2y§(param1);
         param1 = this.§_-FU§(param1);
         _loc4_ = "Content-Type: " + param2.contentType;
         _loc3_ = 0;
         while(_loc3_ < _loc4_.length)
         {
            param1.writeByte(_loc4_.charCodeAt(_loc3_));
            _loc3_++;
         }
         param1 = this.§_-FU§(param1);
         return this.§_-FU§(param1);
      }
      
      private function §_-72c§(param1:ByteArray, param2:FilePart) : ByteArray
      {
         param1.writeBytes(param2.fileContent,0,param2.fileContent.length);
         return param1;
      }
      
      private function onProgress(param1:ProgressEvent) : void
      {
         dispatchEvent(param1);
      }
      
      private function onComplete(param1:flash.events.Event) : void
      {
         this.removeListener();
         dispatchEvent(param1);
      }
      
      private function onIOError(param1:IOErrorEvent) : void
      {
         this.removeListener();
         dispatchEvent(param1);
      }
      
      private function onSecurityError(param1:SecurityErrorEvent) : void
      {
         this.removeListener();
         dispatchEvent(param1);
      }
      
      private function onHTTPStatus(param1:HTTPStatusEvent) : void
      {
         dispatchEvent(param1);
      }
      
      private function addListener() : void
      {
         this._loader.addEventListener(flash.events.Event.COMPLETE,this.onComplete,false,0,false);
         this._loader.addEventListener(ProgressEvent.PROGRESS,this.onProgress,false,0,false);
         this._loader.addEventListener(IOErrorEvent.IO_ERROR,this.onIOError,false,0,false);
         this._loader.addEventListener(HTTPStatusEvent.HTTP_STATUS,this.onHTTPStatus,false,0,false);
         this._loader.addEventListener(SecurityErrorEvent.SECURITY_ERROR,this.onSecurityError,false,0,false);
      }
      
      private function removeListener() : void
      {
         this._loader.removeEventListener(flash.events.Event.COMPLETE,this.onComplete);
         this._loader.removeEventListener(ProgressEvent.PROGRESS,this.onProgress);
         this._loader.removeEventListener(IOErrorEvent.IO_ERROR,this.onIOError);
         this._loader.removeEventListener(HTTPStatusEvent.HTTP_STATUS,this.onHTTPStatus);
         this._loader.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,this.onSecurityError);
      }
      
      private function §_-A1E§(param1:ByteArray) : ByteArray
      {
         var _loc2_:int = int(this.§_-tC§().length);
         param1 = this.§_-B1W§(param1);
         var _loc3_:int = 0;
         while(_loc3_ < _loc2_)
         {
            param1.writeByte(this.§_-T4§.charCodeAt(_loc3_));
            _loc3_++;
         }
         return param1;
      }
      
      private function §_-FU§(param1:ByteArray) : ByteArray
      {
         param1.writeShort(3338);
         return param1;
      }
      
      private function §_-K2y§(param1:ByteArray) : ByteArray
      {
         param1.writeByte(34);
         return param1;
      }
      
      private function §_-B1W§(param1:ByteArray) : ByteArray
      {
         param1.writeShort(11565);
         return param1;
      }
      
      private function §_-N2y§() : void
      {
         var _loc1_:FilePart = null;
         if(this.§_-e2l§ < this.§_-A1p§.length)
         {
            _loc1_ = this.§_-X1l§[this.§_-A1p§[this.§_-e2l§]] as FilePart;
            this._data = this.§_-V1S§(this._data,_loc1_);
            this.§_-X1m§ = setTimeout(this.§_-h2P§,10,this._data,_loc1_.fileContent,0);
            ++this.§_-e2l§;
         }
         else
         {
            this._data = this.§_-G2J§(this._data);
            this._data = this.§_-U2J§(this._data);
            this.§_-w2o§ = true;
            dispatchEvent(new §_-O1J§(§_-O1J§.§_-C1G§,this.§_-72h§,this.§_-72h§));
            dispatchEvent(new §_-O1J§(§_-O1J§.§_-q1V§));
         }
      }
      
      private function §_-h2P§(param1:ByteArray, param2:ByteArray, param3:uint = 0) : void
      {
         var _loc4_:uint = uint(Math.min(§_-B33§,param2.length - param3));
         param1.writeBytes(param2,param3,_loc4_);
         if(_loc4_ < §_-B33§ || param3 + _loc4_ >= param2.length)
         {
            param1 = this.§_-FU§(param1);
            this.§_-N2y§();
            return;
         }
         param3 += _loc4_;
         this.§_-ND§ += _loc4_;
         if(this.§_-ND§ % §_-B33§ * 2 == 0)
         {
            dispatchEvent(new §_-O1J§(§_-O1J§.§_-C1G§,this.§_-ND§,this.§_-72h§));
         }
         this.§_-X1m§ = setTimeout(this.§_-h2P§,10,param1,param2,param3);
      }
   }
}

import flash.utils.ByteArray;

class FilePart
{
   
   public var fileContent:ByteArray;
   
   public var fileName:String;
   
   public var dataField:String;
   
   public var contentType:String;
   
   public function FilePart(param1:ByteArray, param2:String, param3:String = "Filedata", param4:String = "application/octet-stream")
   {
      super();
      this.fileContent = param1;
      this.fileName = param2;
      this.dataField = param3;
      this.contentType = param4;
   }
   
   public function dispose() : void
   {
      this.fileContent = null;
      this.fileName = null;
      this.dataField = null;
      this.contentType = null;
   }
}

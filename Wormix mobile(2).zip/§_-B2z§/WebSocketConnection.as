package §_-B2z§
{
   import §_-03T§.§_-K3B§;
   import §_-62§.§_-O2H§;
   import §_-CF§.§_-x2t§;
   import §_-j22§.§_-5g§;
   import §_-rM§.§_-61j§;
   import com.worlize.websocket.§_-03n§;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import flash.events.DataEvent;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   
   public class WebSocketConnection extends §_-K3B§ implements §_-82u§
   {
      
      private static var log:§_-11S§ = new §_-11S§(WebSocketConnection);
      
      private static const §_-81F§:String = "WebSocketConnection";
      
      private var §_-T1N§:Timer;
      
      private var serializer:§_-616§ = §_-616§.getInstance();
      
      private var §_-C2e§:§_-03n§;
      
      private var server:Server;
      
      private var §_-d20§:ByteArray;
      
      private var §_-Rg§:Boolean = true;
      
      private var sessionId:String = null;
      
      private var §_-Sl§:Object;
      
      private var §_-a1U§:ByteArray;
      
      private var §_-61C§:Event;
      
      private var §_-y2E§:int;
      
      private var §_-Ib§:Boolean;
      
      private var header:§_-61j§;
      
      public function WebSocketConnection(param1:Server, param2:Object = null, param3:int = 30000, param4:Boolean = false)
      {
         super();
         this.server = param1;
         this.§_-Ib§ = param4;
         this.§_-d20§ = new ByteArray();
         this.§_-Sl§ = param2;
         this.§_-a1U§ = new ByteArray();
         this.serializer.serializeCommand(param2,this.§_-a1U§);
         this.§_-y2E§ = param3;
         this.§_-61C§ = new Event(DataEvent.DATA);
      }
      
      protected function §_-f1d§() : String
      {
         return this.server.§_-f1d§();
      }
      
      private function §_-K8§() : void
      {
         this.§_-C2e§ = new §_-03n§(this.§_-f1d§(),"*",null,100000);
         this.§_-C2e§.debug = this.§_-Ib§;
         this.§_-C2e§.addEventListener(§_-Y2T§.OPEN,this.§_-23q§);
         this.§_-C2e§.addEventListener(§_-Y2T§.§_-F32§,this.§_-A9§);
         this.§_-C2e§.addEventListener(§_-Y2T§.§_-P8§,this.§_-K30§);
         this.§_-C2e§.addEventListener(§_-ue§.§_-R2U§,this.§_-Qs§);
         this.§_-C2e§.addEventListener(§_-ue§.§_-M2G§,this.§_-V2j§);
      }
      
      private function §_-G1q§() : void
      {
         if(this.§_-C2e§)
         {
            this.§_-C2e§.removeEventListener(§_-Y2T§.OPEN,this.§_-23q§);
            this.§_-C2e§.removeEventListener(§_-Y2T§.§_-F32§,this.§_-A9§);
            this.§_-C2e§.removeEventListener(§_-Y2T§.§_-P8§,this.§_-K30§);
            this.§_-C2e§.removeEventListener(§_-ue§.§_-R2U§,this.§_-Qs§);
            this.§_-C2e§.removeEventListener(§_-ue§.§_-M2G§,this.§_-V2j§);
            this.§_-C2e§ = null;
         }
      }
      
      public function connect() : void
      {
         this.§_-K8§();
         log.info("Try connect to " + this.§_-C2e§.§_-K2P§,§_-81F§);
         this.§_-C2e§.connect();
      }
      
      public function §_-m1§() : void
      {
         if(Boolean(this.§_-Sl§) && this.§_-y2E§ > 0)
         {
            this.§_-l1c§();
            this.§_-T1N§ = new Timer(this.§_-y2E§);
            this.§_-T1N§.addEventListener(TimerEvent.TIMER,this.§_-727§);
            this.§_-T1N§.start();
         }
      }
      
      public function §_-Z2l§() : void
      {
         this.§_-l1c§();
      }
      
      private function §_-727§(param1:Event) : void
      {
         var e:Event = param1;
         try
         {
            this.§_-C2e§.ping(this.§_-a1U§);
         }
         catch(ex:Error)
         {
            log.error("Socket ping error: " + ex.toString(),§_-81F§);
         }
         if(this.§_-928§())
         {
            this.send(this.§_-Sl§);
         }
      }
      
      private function §_-l1c§() : void
      {
         if(this.§_-T1N§ != null)
         {
            this.§_-T1N§.stop();
            this.§_-T1N§.removeEventListener(TimerEvent.TIMER,this.§_-727§);
         }
         this.§_-T1N§ = null;
      }
      
      public function close() : void
      {
         if(this.§_-C2e§)
         {
            try
            {
               this.§_-C2e§.close();
            }
            catch(ex:Error)
            {
               log.error("Socket close error: " + ex.toString(),§_-81F§);
            }
            this.reset();
         }
      }
      
      private function reset() : void
      {
         this.§_-Z2l§();
         this.§_-G1q§();
         this.§_-d20§.length = 0;
      }
      
      protected function §_-A9§(param1:§_-Y2T§) : void
      {
         log.§_-M2b§("connection to " + this.§_-C2e§.§_-K2P§ + " was closed by server",§_-81F§);
         this.reset();
         super.dispatchEvent(param1);
      }
      
      protected function §_-23q§(param1:§_-Y2T§) : void
      {
         log.info("connected to " + this.§_-C2e§.§_-K2P§,§_-81F§);
         this.§_-m1§();
         dispatchEvent(param1);
      }
      
      protected function §_-Qs§(param1:§_-ue§) : void
      {
         log.error("onConnectionFail: " + param1.text,§_-81F§);
         dispatchEvent(param1);
      }
      
      protected function §_-V2j§(param1:§_-ue§) : void
      {
         log.error("onAbnormalClose: " + param1.text,§_-81F§);
         dispatchEvent(param1);
      }
      
      private function §_-K30§(param1:§_-Y2T§) : void
      {
         var data:ByteArray = null;
         var tail:ByteArray = null;
         var commandData:ByteArray = null;
         var msg:Object = null;
         var event:§_-Y2T§ = param1;
         if(event.message.§_-2b§.length > 0)
         {
            data = event.message.§_-2b§;
            log.debug("reading data from socket, length: " + data.length + " needHeaderRead: " + this.§_-Rg§,§_-81F§);
            if(this.§_-d20§.bytesAvailable == 0)
            {
               this.§_-d20§ = new ByteArray();
            }
            data.readBytes(this.§_-d20§,this.§_-d20§.length);
            tail = new ByteArray();
            try
            {
               do
               {
                  if(this.§_-Rg§)
                  {
                     this.header = new §_-5g§();
                     this.header.read(this.§_-d20§);
                     this.§_-Rg§ = false;
                     log.debug("header readed, header.commandId=" + this.header.getCommandId() + ", header.length=" + this.header.getLength() + ", try to read body",§_-81F§);
                  }
                  if(this.header != null && this.§_-d20§.bytesAvailable >= this.header.getLength())
                  {
                     commandData = new ByteArray();
                     if(this.header.getLength() > 0)
                     {
                        this.§_-d20§.readBytes(commandData,0,this.header.getLength());
                     }
                     log.debug("Command is readed fully, commandData.length: " + commandData.bytesAvailable,§_-81F§);
                     this.§_-Rg§ = true;
                     log.debug("try to read next command...",§_-81F§);
                     msg = this.serializer.deserializeCommand(commandData,this.header);
                     if(msg != null)
                     {
                        log.debug("====Command is deserialazed====",§_-81F§);
                        log.debug("msg: " + msg,§_-81F§);
                        dispatchEvent(new §_-63i§(msg,getQualifiedClassName(msg)));
                        dispatchEvent(this.§_-61C§);
                     }
                     else
                     {
                        log.error("error while deserialize command, commandId: " + this.header.getCommandId(),§_-81F§);
                     }
                  }
                  else
                  {
                     log.debug("waiting for other part of command, needByte:" + this.header.getLength() + ", available: " + this.§_-d20§.bytesAvailable,§_-81F§);
                     if(this.§_-d20§.bytesAvailable > 0)
                     {
                        this.§_-d20§.readBytes(tail);
                     }
                  }
               }
               while(this.§_-d20§.bytesAvailable > 0);
            }
            catch(ex:Error)
            {
               log.error("Deserialize ERROR: " + ex.toString(),§_-81F§);
               §_-Rg§ = true;
            }
            this.§_-d20§ = new ByteArray();
            tail.readBytes(this.§_-d20§);
         }
         else
         {
            log.error("deserialized data can\'t be empty",§_-81F§);
         }
      }
      
      public function send(param1:Object) : void
      {
         log.debug("connection status:" + this.§_-928§(),§_-81F§);
         if(!this.§_-928§())
         {
            this.§_-63h§();
         }
         log.debug("====try to send message [" + param1 + "] to server...===",§_-81F§);
         if(this.§_-T1N§ != null)
         {
            this.§_-T1N§.reset();
         }
         var _loc2_:ByteArray = new ByteArray();
         this.serializer.serializeCommand(param1,_loc2_);
         this.§_-22R§(_loc2_);
      }
      
      protected function §_-22R§(param1:ByteArray) : void
      {
         var stream:ByteArray = param1;
         try
         {
            this.§_-C2e§.§_-32s§(stream);
         }
         catch(ex:Error)
         {
            log.error("error: " + ex.message);
         }
         if(this.§_-T1N§ != null)
         {
            this.§_-T1N§.start();
         }
      }
      
      public function addListener(param1:Class, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void
      {
         log.debug("addMessageListener for message: " + getQualifiedClassName(param1),§_-81F§);
         addEventListener(getQualifiedClassName(param1),param2,param3,param4,param5);
      }
      
      public function removeListener(param1:Class, param2:Function) : void
      {
         log.debug("removeMessageListener for message: " + getQualifiedClassName(param1),§_-81F§);
         removeEventListener(getQualifiedClassName(param1),param2);
      }
      
      public function §_-w25§(param1:Class) : Boolean
      {
         return hasEventListener(getQualifiedClassName(param1));
      }
      
      protected function §_-63h§() : void
      {
      }
      
      public function §_-928§() : Boolean
      {
         return this.§_-C2e§ != null && this.§_-C2e§.connected;
      }
      
      public function §_-yt§() : String
      {
         return this.sessionId;
      }
      
      public function §_-zy§(param1:String) : void
      {
         this.sessionId = param1;
      }
   }
}


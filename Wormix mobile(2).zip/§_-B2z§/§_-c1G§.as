package §_-B2z§
{
   public class §_-c1G§
   {
      
      public static const MAIN:String = "MAIN";
      
      public static const PVP:String = "PVP";
      
      public function §_-c1G§()
      {
         super();
      }
   }
}


package §_-B2z§
{
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   
   public class §_-63i§ extends Event
   {
      
      public var message:Object;
      
      public function §_-63i§(param1:Object, param2:String, param3:Boolean = false, param4:Boolean = false)
      {
         super(param2,param3,param4);
         this.message = param1;
      }
      
      override public function clone() : Event
      {
         return new §_-63i§(this.message,type,bubbles,cancelable);
      }
   }
}


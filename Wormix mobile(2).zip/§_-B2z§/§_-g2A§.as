package §_-B2z§
{
   import §_-03T§.§_-2p§;
   import §_-03T§.§_-K3B§;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-j22§.§_-5g§;
   import §_-rM§.§_-61j§;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.ProgressEvent;
   import flash.events.SecurityErrorEvent;
   import flash.events.TimerEvent;
   import flash.net.Socket;
   import flash.system.Security;
   import flash.utils.ByteArray;
   import flash.utils.Timer;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   
   public class §_-g2A§ extends §_-K3B§ implements §_-82u§
   {
      
      private static const §_-02e§:uint = 5190;
      
      private static var log:§_-11S§ = new §_-11S§(§_-g2A§);
      
      private static const §_-81F§:String = "CMD";
      
      private var §_-d2b§:§_-2p§;
      
      private var §_-T1N§:Timer;
      
      private var serializer:§_-616§ = §_-616§.getInstance();
      
      private var socket:Socket;
      
      private var host:String;
      
      private var §_-q1X§:Array;
      
      private var port:int;
      
      private var §_-d20§:ByteArray;
      
      private var §_-M2g§:uint = 0;
      
      private var §_-Rg§:Boolean = true;
      
      private var §_-Sl§:Object;
      
      private var §_-y2E§:int;
      
      private var header:§_-61j§;
      
      public function §_-g2A§(param1:String, param2:Array, param3:Object, param4:int = 30000)
      {
         super();
         this.host = param1;
         this.§_-q1X§ = param2;
         this.§_-Sl§ = param3;
         this.§_-y2E§ = param4;
         this.§_-d20§ = new ByteArray();
         this.socket = new Socket();
         this.§_-d2b§ = new §_-2p§();
      }
      
      public function connect() : void
      {
         Security.loadPolicyFile("xmlsocket://" + this.host + ":" + §_-02e§);
         this.§_-13A§(this.§_-q1X§);
      }
      
      private function §_-13A§(param1:Array) : void
      {
         this.port = param1[0];
         var _loc2_:Function = §_-bs§.§_-d1Z§(this.§_-f2z§,this,[param1.slice(1)],true);
         §_-83E§.§_-C38§(this.socket,Event.CONNECT,this.§_-23q§,IOErrorEvent.IO_ERROR,_loc2_,SecurityErrorEvent.SECURITY_ERROR,_loc2_);
         log.info("Try connect to " + this.host + ":" + this.port,§_-81F§);
         this.socket.connect(this.host,this.port);
      }
      
      public function §_-m1§() : void
      {
         if(this.§_-y2E§ > 0)
         {
            this.§_-T1N§ = new Timer(this.§_-y2E§);
            this.§_-T1N§.addEventListener(TimerEvent.TIMER,this.§_-727§);
            this.§_-T1N§.start();
         }
      }
      
      private function §_-727§(param1:Event) : void
      {
         this.send(this.§_-Sl§);
      }
      
      public function §_-Z2l§() : void
      {
         if(this.§_-T1N§ != null)
         {
            this.§_-T1N§.stop();
            this.§_-T1N§.removeEventListener(TimerEvent.TIMER,this.§_-727§);
         }
         this.§_-T1N§ = null;
      }
      
      public function close() : void
      {
         if(this.socket)
         {
            try
            {
               this.socket.close();
            }
            catch(ex:Error)
            {
               log.error("Socket close error: " + ex.toString(),§_-81F§);
            }
            this.reset();
         }
      }
      
      private function reset() : void
      {
         this.§_-Z2l§();
         this.port = 0;
         this.§_-d2b§.destroy();
         this.socket = null;
         this.§_-d20§.length = 0;
         this.§_-M2g§ = 0;
      }
      
      protected function §_-A9§(param1:Event) : void
      {
         log.§_-M2b§("connection to " + this.host + ":" + this.port + " was closed by server",§_-81F§);
         this.reset();
         super.dispatchEvent(param1);
      }
      
      protected function §_-23q§(param1:Event) : void
      {
         log.info("connected to " + this.host + ":" + this.port,§_-81F§);
         this.§_-d2b§.addEventListener(this.socket,Event.CLOSE,this.§_-A9§);
         this.§_-d2b§.addEventListener(this.socket,ProgressEvent.SOCKET_DATA,this.§_-K30§);
         this.§_-d2b§.addEventListener(this.socket,IOErrorEvent.IO_ERROR,this.§_-Hs§);
         this.§_-d2b§.addEventListener(this.socket,SecurityErrorEvent.SECURITY_ERROR,this.§_-2c§);
         this.§_-m1§();
         dispatchEvent(param1);
      }
      
      protected function §_-f2z§(param1:Event, param2:Array) : void
      {
         log.error("Connection failed with error:" + param1.toString(),§_-81F§);
         if(param2.length)
         {
            this.§_-13A§(param2);
         }
         else
         {
            this.port = 0;
            dispatchEvent(param1);
         }
      }
      
      protected function §_-Hs§(param1:IOErrorEvent) : void
      {
         log.error("IoError: " + param1.toString(),§_-81F§);
         dispatchEvent(param1);
      }
      
      protected function §_-2c§(param1:SecurityErrorEvent) : void
      {
         log.error("SecurityError: " + param1.toString(),§_-81F§);
         dispatchEvent(param1);
      }
      
      private function §_-K30§(param1:Event) : void
      {
         var data:ByteArray = null;
         var tail:ByteArray = null;
         var commandData:ByteArray = null;
         var msg:Object = null;
         var event:Event = param1;
         if(this.socket.bytesAvailable > 0)
         {
            data = new ByteArray();
            this.socket.readBytes(data);
            log.debug("reading data from socket, length: " + data.length + " needHeaderRead: " + this.§_-Rg§,§_-81F§);
            if(this.§_-d20§.bytesAvailable == 0)
            {
               this.§_-d20§ = new ByteArray();
            }
            data.readBytes(this.§_-d20§,this.§_-d20§.length);
            tail = new ByteArray();
            try
            {
               do
               {
                  if(this.§_-Rg§)
                  {
                     this.header = new §_-5g§();
                     this.header.read(this.§_-d20§);
                     this.§_-Rg§ = false;
                     log.debug("header readed, header.commandId=" + this.header.getCommandId() + ", header.length=" + this.header.getLength() + ", try to read body",§_-81F§);
                  }
                  if(this.header != null && this.§_-d20§.bytesAvailable >= this.header.getLength())
                  {
                     commandData = new ByteArray();
                     if(this.header.getLength() > 0)
                     {
                        this.§_-d20§.readBytes(commandData,0,this.header.getLength());
                     }
                     log.debug("Command is readed fully, commandData.length: " + commandData.bytesAvailable,§_-81F§);
                     this.§_-Rg§ = true;
                     log.debug("try to read next command...",§_-81F§);
                     msg = this.serializer.deserializeCommand(commandData,this.header);
                     if(msg != null)
                     {
                        log.debug("====Command is deserialazed====",§_-81F§);
                        log.debug("msg: " + msg,§_-81F§);
                        dispatchEvent(new §_-63i§(msg,getQualifiedClassName(msg)));
                     }
                     else
                     {
                        log.error("error while deserialize command, commandId: " + this.header.getCommandId(),§_-81F§);
                     }
                  }
                  else
                  {
                     log.debug("waiting for other part of command, needByte:" + this.header.getLength() + ", available: " + this.§_-d20§.bytesAvailable,§_-81F§);
                     if(this.§_-d20§.bytesAvailable > 0)
                     {
                        this.§_-d20§.readBytes(tail);
                     }
                  }
               }
               while(this.§_-d20§.bytesAvailable > 0);
            }
            catch(ex:Error)
            {
               log.error("Deserialize ERROR: " + ex.toString(),§_-81F§);
               §_-Rg§ = true;
            }
            this.§_-d20§ = new ByteArray();
            tail.readBytes(this.§_-d20§);
         }
         else
         {
            log.error("deserialized data can\'t be empty",§_-81F§);
         }
      }
      
      public function send(param1:Object) : void
      {
         log.debug("connection status:" + this.§_-928§(),§_-81F§);
         if(!this.§_-928§())
         {
            this.§_-63h§();
         }
         log.debug("====try to send message [" + param1 + "] to server...===",§_-81F§);
         if(this.§_-T1N§ != null)
         {
            this.§_-T1N§.reset();
         }
         var _loc2_:ByteArray = new ByteArray();
         this.serializer.serializeCommand(param1,_loc2_);
         this.socket.writeBytes(_loc2_);
         this.socket.flush();
         if(this.§_-T1N§ != null)
         {
            this.§_-T1N§.start();
         }
      }
      
      public function addListener(param1:Class, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void
      {
         log.debug("addMessageListener for message: " + getQualifiedClassName(param1),§_-81F§);
         addEventListener(getQualifiedClassName(param1),param2,param3,param4,param5);
      }
      
      public function removeListener(param1:Class, param2:Function) : void
      {
         log.debug("removeMessageListener for message: " + getQualifiedClassName(param1),§_-81F§);
         removeEventListener(getQualifiedClassName(param1),param2);
      }
      
      public function §_-w25§(param1:Class) : Boolean
      {
         return hasEventListener(getQualifiedClassName(param1));
      }
      
      protected function §_-63h§() : void
      {
      }
      
      public function §_-928§() : Boolean
      {
         return this.socket != null && Boolean(this.socket.connected);
      }
      
      public function §_-H3L§() : String
      {
         return this.host;
      }
      
      public function §_-o2o§() : int
      {
         return this.port;
      }
      
      public function §_-22J§() : Socket
      {
         return this.socket;
      }
   }
}


package §_-B2z§
{
   import §_-r1C§.§_-h2B§;
   import §_-x2Q§.§_-dU§;
   import flash.utils.Dictionary;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.events.Event;
   
   public class Server
   {
      
      private static var §_-7S§:Dictionary;
      
      private var host:String;
      
      private var §_-q1X§:Array;
      
      private var §_-ZH§:String;
      
      private var §_-Ah§:String;
      
      private var path:String;
      
      private var §_-K2P§:String;
      
      public function Server(param1:String, param2:Array, param3:String, param4:String)
      {
         super();
         this.host = param1;
         this.§_-q1X§ = param2;
         this.§_-ZH§ = param3;
         this.§_-Ah§ = param4;
         this.path = param3 ? "/" + param3 + "/" + (this.§_-c1s§() ? "wss" : "ws") + "/" : "";
         this.§_-K2P§ = (this.§_-c1s§() ? "wss" : "ws") + "://" + param1 + this.path;
      }
      
      public static function §_-f1y§(param1:Server, param2:String) : void
      {
         if(§_-7S§ == null)
         {
            §_-7S§ = new Dictionary();
         }
         §_-7S§[param2] = param1;
      }
      
      public static function §_-O2A§(param1:String) : Server
      {
         if(§_-7S§)
         {
            return §_-7S§[param1];
         }
         return null;
      }
      
      public static function §_-WJ§() : void
      {
         var _loc1_:* = undefined;
         var _loc2_:Server = null;
         for(_loc1_ in §_-7S§)
         {
            _loc2_ = §_-7S§[_loc1_] as Server;
            if(_loc2_)
            {
               trace("Server.logServers: " + _loc1_ + " " + _loc2_.toString());
            }
         }
      }
      
      public function §_-H3L§() : String
      {
         return this.host;
      }
      
      public function §_-C3H§() : Array
      {
         return this.§_-q1X§;
      }
      
      public function §_-W1c§() : String
      {
         return this.§_-ZH§;
      }
      
      public function §_-F2m§() : String
      {
         return this.path;
      }
      
      public function §_-r3§() : String
      {
         return this.§_-Ah§;
      }
      
      public function §_-c1s§() : Boolean
      {
         return this.§_-Ah§ == "wss";
      }
      
      public function §_-f1d§() : String
      {
         return this.§_-K2P§;
      }
      
      public function toString() : String
      {
         return "Server { " + "host=" + this.host + ", availablePorts=" + String(this.§_-q1X§) + ", postfix=" + this.§_-ZH§ + ", protocol=" + this.§_-Ah§ + ", path=" + this.path + ", url=" + this.§_-K2P§ + " }";
      }
   }
}


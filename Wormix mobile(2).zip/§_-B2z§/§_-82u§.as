package §_-B2z§
{
   import flash.events.IEventDispatcher;
   
   public interface §_-82u§ extends IEventDispatcher
   {
      
      function connect() : void;
      
      function close() : void;
      
      function §_-m1§() : void;
      
      function §_-Z2l§() : void;
      
      function send(param1:Object) : void;
      
      function addListener(param1:Class, param2:Function, param3:Boolean = false, param4:int = 0, param5:Boolean = false) : void;
      
      function removeListener(param1:Class, param2:Function) : void;
      
      function §_-w25§(param1:Class) : Boolean;
      
      function §_-928§() : Boolean;
   }
}


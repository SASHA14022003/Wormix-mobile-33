package §_-gG§
{
   import §_-12a§.§_-E1Q§;
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-Ly§.§_-81L§;
   import §_-Y1O§.*;
   import §_-b1F§.§_-G4§;
   import §_-j2R§.§_-v1l§;
   import §_-k2s§.§_-Go§;
   import §_-k2s§.§_-b0§;
   import §_-l1g§.§_-L3Q§;
   import §_-m2s§.§_-R11§;
   import §_-r1C§.§_-h2B§;
   import §_-v2t§.§_-73F§;
   import §_-z1g§.§_-5c§;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.events.Event;
   import flash.filters.BlurFilter;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.§_-4V§;
   import ru.pragmatix.wormix.model.rewards.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   public class §_-8u§ extends §_-v1l§
   {
      
      public static const NAME:String = "POISON";
      
      public static const DURATION:int = 10;
      
      public static const §_-21U§:int = 5;
      
      private static const §_-I2Q§:§_-TA§ = new §_-TA§(20);
      
      public static const COLOR:int = 12517244;
      
      private var owner:§_-01J§;
      
      private var §_-x1t§:Boolean;
      
      private var §_-BP§:Function = null;
      
      public function §_-8u§(param1:§_-01J§, param2:int = 10)
      {
         super(NAME,param2,§_-21U§);
         this.owner = param1;
         this.§_-x1t§ = false;
      }
      
      override protected function §_-BK§() : void
      {
         §_-MN§.§_-D9§(unit,COLOR);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,this.trigger,§_-4V§.§_-DA§);
      }
      
      override protected function §_-QE§() : void
      {
         §_-MN§.§_-ZM§(unit,COLOR);
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,this.trigger);
         this.owner = null;
         super.§_-QE§();
         if(unit.stable)
         {
            unit.§_-l2A§();
         }
      }
      
      protected function trigger(param1:starling.events.Event) : void
      {
         var _loc2_:uint = 0;
         this.§_-x1t§ = true;
         if(Boolean(!§_-kG§) && Boolean(unit) && !unit.disposed)
         {
            if(!unit.buffs.hasBuff(§_-E1Q§.NAME) && unit.hp > §_-I2Q§.value)
            {
               _loc2_ = uint(Math.floor(value * unit.hp / 100));
               unit.stable = false;
               §_-G4§.§_-Ee§(this.owner,unit.x,unit.y + 10,unit as §_-F3o§,_loc2_,0,0,false,true,DamageType.POISON);
            }
         }
         this.§_-x1t§ = false;
         if(this.§_-BP§ != null)
         {
            this.§_-BP§();
            this.§_-BP§ = null;
         }
      }
      
      override public function clear() : void
      {
         if(this.§_-x1t§)
         {
            this.§_-BP§ = this.clear;
         }
         else
         {
            super.clear();
         }
      }
      
      override public function §_-U1s§(param1:§_-01J§) : void
      {
         param1.buffs.place(new §_-8u§(this.owner,§_-E15§()));
      }
   }
}


package §_-gG§
{
   import §_-12a§.§_-41b§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.Server;
   import §_-B2z§.§_-c1G§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-L1H§.§_-C3e§;
   import §_-RE§.§_-52p§;
   import §_-TF§.§_-y2n§;
   import §_-Ta§.*;
   import §_-U1i§.§_-81M§;
   import §_-U1i§.§_-O2i§;
   import §_-Vg§.*;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-Z1K§.§_-q24§;
   import §_-ZP§.§_-H1H§;
   import §_-j2R§.§_-v1l§;
   import §_-jF§.*;
   import §_-l1K§.*;
   import §_-l2r§.§_-K1t§;
   import §_-m1g§.§_-K2W§;
   import §_-z1g§.§_-82X§;
   import §_-zI§.§_-F3q§;
   import com.hurlant.util.der.*;
   import dragonBones.animation.WorldClock;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-M2S§ extends §_-v1l§
   {
      
      internal static const §_-H1h§:§_-TA§ = new §_-TA§(12);
      
      internal static const §_-C2s§:§_-TA§ = new §_-TA§(4);
      
      internal static const §_-w1P§:§_-TA§ = new §_-TA§(5);
      
      public static const NAME:String = "SLOW_SPEED";
      
      public static const DEFAULT_DURATION:int = 2;
      
      private var armature:§_-di§;
      
      public function §_-M2S§(param1:int = 2)
      {
         super(NAME,param1,0);
      }
      
      public static function createEffect() : §_-di§
      {
         var _loc1_:§_-di§ = Effects.createAnimationEffect(Effects.SLOW);
         _loc1_.display.y = -5;
         WorldClock.clock.add(_loc1_);
         _loc1_.playAnimation(§_-K1t§.§_-Y1c§);
         return _loc1_;
      }
      
      override protected function §_-BK§() : void
      {
         this.armature = createEffect();
         unit.§_-U8§(this.armature.display,0,0,false,true);
         unit.attributes.§_-kN§.§_-Y2z§(-§_-H1h§.value);
         unit.attributes.jump.§_-qX§(-§_-C2s§.value);
         unit.attributes.jump.§_-J3s§(-§_-w1P§.value);
         if(unit.bonuses.§_-yQ§(§_-x2M§.§_-NL§) || Boolean(unit.buffs.getBuff(§_-41b§.NAME)))
         {
            unit.buffs.§_-e1z§(NAME);
         }
      }
      
      override protected function §_-QE§() : void
      {
         if(!§_-kG§)
         {
            if(WorldClock.clock.contains(this.armature))
            {
               WorldClock.clock.remove(this.armature);
            }
            unit.§_-n28§(this.armature.display);
            this.armature.dispose();
            this.armature = null;
            unit.attributes.§_-kN§.§_-Y2z§(§_-H1h§.value);
            unit.attributes.jump.§_-qX§(§_-C2s§.value);
            unit.attributes.jump.§_-J3s§(§_-w1P§.value);
         }
      }
      
      override protected function onNextTurn(param1:starling.events.Event) : void
      {
         if(Boolean(§_-X1j§.§_-12n§.gameMaster) && §_-X1j§.§_-12n§.gameMaster.activeUnit == unit)
         {
            super.onNextTurn(param1);
         }
      }
      
      override public function §_-U1s§(param1:§_-01J§) : void
      {
         param1.buffs.place(new §_-M2S§(§_-E15§()));
      }
   }
}


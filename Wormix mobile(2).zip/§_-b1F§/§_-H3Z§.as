package §_-b1F§
{
   import §_-Tm§.§_-RF§;
   import §_-Z1K§.§_-q24§;
   import §_-hO§.§_-v24§;
   import com.distriqt.extension.inappbilling.Purchase;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.client.AppleVerifyReceipt;
   import ru.pragmatix.wormix.objects.Waypoint;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import starling.utils.Pool;
   
   public class §_-H3Z§
   {
      
      public var owner:§_-01J§;
      
      public var damageType:DamageType;
      
      public var §_-A3d§:Boolean;
      
      public var §_-w1U§:int;
      
      public var §_-i2D§:int;
      
      public var §_-53a§:int;
      
      public function §_-H3Z§()
      {
         super();
      }
      
      public function §_-Ku§(param1:§_-Qi§) : void
      {
         this.owner = param1.owner;
         this.damageType = param1.damageType;
         this.§_-A3d§ = param1.§_-A3d§;
         this.§_-w1U§ = param1.§_-w1U§;
         this.§_-i2D§ = param1.§_-i2D§;
         this.§_-53a§ = param1.§_-53a§;
      }
   }
}


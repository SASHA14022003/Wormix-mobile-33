package §_-b1F§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-F39§.*;
   import §_-L1H§.§_-C3e§;
   import §_-k1u§.§_-by§;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.§_-M2v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.events.Event;
   
   public class §_-v2Q§
   {
      
      private static var storage:Vector.<§_-v2Q§>;
      
      private static var §_-E2d§:Vector.<§_-v2Q§>;
      
      public var source:§_-Qi§;
      
      public var victim:§_-F3o§;
      
      public var power:Number;
      
      public function §_-v2Q§()
      {
         super();
      }
      
      public static function create(param1:§_-Qi§, param2:§_-F3o§, param3:Number) : §_-v2Q§
      {
         if(storage == null)
         {
            storage = new Vector.<§_-v2Q§>(0);
            §_-E2d§ = new Vector.<§_-v2Q§>(0);
            §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,§_-r2k§);
            §_-X1j§.§_-12n§.scene.addEventListener(Event.REMOVED_FROM_STAGE,§_-D22§);
         }
         var _loc4_:§_-v2Q§ = storage.pop();
         if(_loc4_ == null)
         {
            _loc4_ = new §_-v2Q§();
         }
         _loc4_.setData(param1,param2,param3);
         §_-E2d§.push(_loc4_);
         return _loc4_;
      }
      
      private static function §_-r2k§(param1:Event) : void
      {
         var _loc2_:§_-v2Q§ = §_-E2d§.pop();
         while(_loc2_)
         {
            _loc2_.§_-bV§();
            storage.push(_loc2_);
            _loc2_ = §_-E2d§.pop();
         }
      }
      
      private static function §_-D22§(param1:Event) : void
      {
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,§_-r2k§);
         §_-X1j§.§_-12n§.scene.removeEventListener(Event.REMOVED_FROM_STAGE,§_-D22§);
         storage = §_-E2d§ = null;
      }
      
      private function setData(param1:§_-Qi§, param2:§_-F3o§, param3:Number) : void
      {
         this.source = param1;
         this.victim = param2;
         this.power = param3;
      }
      
      private function §_-bV§() : void
      {
         this.source = null;
         this.victim = null;
         this.power = 0;
      }
   }
}


package §_-C3f§
{
   public class §_-Z1Y§
   {
      
      public static const NONE:§_-Z1Y§ = new §_-Z1Y§(0);
      
      public static const §_-Vi§:§_-Z1Y§ = new §_-Z1Y§(1);
      
      public static const §_-v2B§:§_-Z1Y§ = new §_-Z1Y§(2);
      
      public var id:uint;
      
      public function §_-Z1Y§(param1:uint = 0)
      {
         super();
         this.id = param1;
      }
      
      public function equals(param1:§_-Z1Y§) : Boolean
      {
         return this.id == param1.id;
      }
   }
}


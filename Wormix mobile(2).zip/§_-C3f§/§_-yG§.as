package §_-C3f§
{
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   
   public class §_-yG§
   {
      
      public var moneyType:§_-E19§;
      
      public var price:§_-x2t§;
      
      public var message:String;
      
      public var §_-c2z§:Boolean;
      
      public function §_-yG§(param1:§_-E19§, param2:§_-x2t§, param3:String = "", param4:Boolean = false)
      {
         super();
         this.moneyType = param1;
         this.price = param2;
         this.message = param3;
         this.§_-c2z§ = param4;
      }
      
      public function getValue() : int
      {
         var _loc1_:int = 0;
         var _loc2_:§_-E19§ = this.moneyType;
         switch(_loc2_)
         {
            case §_-E19§.§_-51D§:
         }
         return int(this.price.realPrice);
      }
   }
}


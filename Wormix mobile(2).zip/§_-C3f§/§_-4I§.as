package §_-C3f§
{
   import §_-23P§.§_-V2T§;
   import §_-23P§.§_-u1z§;
   import §_-CF§.§_-x2t§;
   import §_-Y1O§.§_-yA§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-4I§
   {
      
      public static const §_-DM§:int = 9999;
      
      public static const §_-MH§:int = 999999;
      
      public static const §_-vW§:§_-x2t§ = new §_-x2t§(100,1);
      
      public static const §_-P1a§:§_-x2t§ = new §_-x2t§(300,3);
      
      public static const §_-k1X§:§_-x2t§ = new §_-x2t§(0,5);
      
      public static const §_-y1F§:§_-x2t§ = new §_-x2t§(300,3);
      
      public static const §_-C39§:§_-x2t§ = new §_-x2t§(100,1);
      
      public static const §_-R10§:§_-x2t§ = new §_-x2t§(400,4);
      
      public static const REACTION:§_-x2t§ = new §_-x2t§(0,1);
      
      public static const ERROR:§_-x2t§ = new §_-x2t§(NaN,NaN);
      
      public static const §_-AZ§:§_-x2t§ = new §_-x2t§(0,10);
      
      public function §_-4I§()
      {
         super();
      }
      
      public static function §_-OB§(param1:UserProfile, param2:int) : §_-x2t§
      {
         var _loc3_:uint = 0;
         var _loc4_:§_-u1z§ = null;
         if(param2 == §_-yA§.§_-v2X§)
         {
            _loc3_ = 100 + 1500;
            return new §_-x2t§(_loc3_,Math.ceil(_loc3_ / §_-vW§.§_-R1T§));
         }
         if(param2 == §_-yA§.§_-uF§ || param2 == §_-yA§.§_-02F§)
         {
            _loc3_ = 600 + 2400;
            return new §_-x2t§(_loc3_,Math.ceil(_loc3_ / §_-vW§.§_-R1T§));
         }
         if(param2 == §_-yA§.§_-e2e§)
         {
            _loc4_ = §_-V2T§.§_-H2p§(param1.getId());
            if(_loc4_)
            {
               return new §_-x2t§(_loc4_.§_-91e§(),_loc4_.§_-gc§());
            }
            return ERROR;
         }
         throw new ArgumentError("Invalid team member type");
      }
   }
}


package §_-C3f§
{
   import §_-CF§.§_-x2t§;
   import §_-YF§.§_-g2W§;
   
   public class §_-1Y§ implements §_-g2W§
   {
      
      protected var id:int;
      
      protected var name:String = "";
      
      protected var description:String = "";
      
      private var note:String = "";
      
      private var price:§_-x2t§;
      
      private var §_-L5§:uint;
      
      protected var requiredFriends:uint;
      
      protected var requiredLevel:uint = 0;
      
      protected var requiredScenario:uint = 0;
      
      public var hideInShop:Boolean = false;
      
      protected var state:§_-Z1Y§ = §_-Z1Y§.NONE;
      
      protected var §_-T1f§:int = 0;
      
      public function §_-1Y§()
      {
         super();
      }
      
      public function initFromConfig(param1:Object) : void
      {
         if(Boolean(param1.price) || Boolean(param1.realprice))
         {
            this.§_-I1u§(param1.price,param1.realprice);
         }
         if(!this.§_-L5§)
         {
            if(param1.comparator)
            {
               this.§_-L5§ = param1.comparator;
            }
            else if(Boolean(param1.price) && param1.price != 9999)
            {
               this.§_-L5§ = param1.price;
            }
            else if(Boolean(param1.realprice) && param1.realprice != 9999)
            {
               this.§_-L5§ = param1.realprice * §_-4I§.§_-vW§.§_-R1T§;
            }
         }
      }
      
      public function getState() : §_-Z1Y§
      {
         return this.state;
      }
      
      public function setState(param1:§_-Z1Y§, param2:int = 0) : void
      {
         this.state = param1;
         this.§_-T1f§ = param2;
      }
      
      public function §_-ui§() : int
      {
         return this.§_-T1f§;
      }
      
      public function §_-F2d§() : Boolean
      {
         return this.hideInShop;
      }
      
      public function §_-z1T§(param1:Boolean) : void
      {
         this.hideInShop = param1;
      }
      
      public function getName() : String
      {
         return this.name;
      }
      
      public function setName(param1:String) : void
      {
         this.name = param1;
      }
      
      public function §_-p1§() : String
      {
         return this.description;
      }
      
      public function setDescription(param1:String) : void
      {
         this.description = param1;
      }
      
      public function §_-T1J§() : uint
      {
         return this.requiredLevel;
      }
      
      public function §_-l17§(param1:uint) : void
      {
         this.requiredScenario = param1;
      }
      
      public function §_-v2J§() : uint
      {
         return this.requiredScenario;
      }
      
      public function §_-s2g§(param1:uint) : void
      {
         this.requiredLevel = param1;
      }
      
      public function §_-91e§() : uint
      {
         return this.price.§_-R1T§;
      }
      
      public function §_-I1u§(param1:uint, param2:uint) : void
      {
         this.price = new §_-x2t§(param1,param2);
      }
      
      public function §_-W0§(param1:§_-x2t§) : void
      {
         this.price = param1;
      }
      
      public function §_-gc§() : uint
      {
         return this.price.realPrice;
      }
      
      public function getPrice() : §_-x2t§
      {
         return this.price;
      }
      
      public function §_-k12§(param1:uint) : void
      {
         this.requiredFriends = param1;
      }
      
      public function §_-P1m§() : uint
      {
         return this.requiredFriends;
      }
      
      public function §_-l1R§() : Boolean
      {
         return this.requiredFriends ? true : false;
      }
      
      public function getId() : int
      {
         return this.id;
      }
      
      public function setId(param1:int) : void
      {
         this.id = param1;
      }
      
      public function equals(param1:§_-1Y§) : Boolean
      {
         return param1 ? this.id == param1.getId() : false;
      }
      
      public function §_-r13§() : String
      {
         return this.note;
      }
      
      public function §_-j1n§(param1:String) : void
      {
         this.note = param1;
      }
      
      public function get comparator() : uint
      {
         return this.§_-L5§;
      }
      
      public function set comparator(param1:uint) : void
      {
         this.§_-L5§ = param1;
      }
      
      public function get §_-kE§() : Boolean
      {
         return false;
      }
   }
}


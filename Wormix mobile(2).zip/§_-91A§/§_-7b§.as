package §_-91A§
{
   import §_-03T§.§_-2p§;
   import §_-52V§.§_-031§;
   import §_-82a§.*;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-72p§;
   import §_-Cl§.§_-L2z§;
   import §_-F39§.*;
   import §_-H16§.*;
   import §_-K35§.§_-99§;
   import §_-TF§.§_-q1j§;
   import §_-Tm§.§_-RF§;
   import §_-U1Y§.*;
   import §_-Vg§.*;
   import §_-YF§.§_-q2v§;
   import §_-b1F§.§_-G4§;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-r1C§.*;
   import §_-zq§.§_-h1I§;
   import com.distriqt.extension.application.Application;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.data.ArrayCollection;
   import feathers.events.FeathersEventType;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import flash.net.Socket;
   import flash.system.ApplicationDomain;
   import flash.utils.ByteArray;
   import org.swiftsuspenders.§_-71M§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-eP§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.objects.§_-V1L§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.IPhysicModel;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.scene.camera.CameraRect;
   import ru.pragmatix.wormix.scene.tile.TileData;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.InvisibleGuardingBot;
   import starling.animation.IAnimatable;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.MathUtil;
   import starling.utils.Pool;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   public class §_-7b§ implements §_-Wy§, IAnimatable
   {
      
      private static const §_-Y1m§:Number = 10;
      
      private var §_-CJ§:Array = [];
      
      private var §_-S1r§:Array = [];
      
      private var cameraRect:CameraRect;
      
      public function §_-7b§()
      {
         super();
      }
      
      public function test(param1:§_-F3o§) : Boolean
      {
         return (param1 is §_-01J§ || param1 is §_-Qi§) && !(param1 is InvisibleGuardingBot);
      }
      
      public function addGameObject(param1:§_-F3o§) : void
      {
         if(param1 is §_-01J§ || param1 is §_-V1L§ || param1 is §_-Qi§ && param1.§_-92S§)
         {
            this.§_-CJ§.push(param1);
            this.§_-S1r§.push(null);
         }
      }
      
      public function §_-p1R§(param1:§_-F3o§) : void
      {
         var _loc2_:uint = uint(this.§_-CJ§.length);
         var _loc3_:uint = 0;
         while(_loc3_ < _loc2_)
         {
            if(this.§_-CJ§[_loc3_] == param1)
            {
               this.§_-CJ§[_loc3_] = null;
               this.§_-CJ§.splice(_loc3_,1);
               if(this.§_-S1r§[_loc3_])
               {
                  §_-X1j§.§_-12n§.scene.removeElement(this.§_-S1r§[_loc3_].arrow);
               }
               this.§_-S1r§[_loc3_] = null;
               this.§_-S1r§.splice(_loc3_,1);
               break;
            }
            _loc3_++;
         }
      }
      
      public function activate() : void
      {
         Starling.juggler.add(this);
         this.cameraRect = §_-X1j§.§_-12n§.scene.sceneCamera.cameraRect;
      }
      
      public function deactivate() : void
      {
         Starling.juggler.remove(this);
         this.cameraRect = null;
      }
      
      private function §_-G29§(param1:§_-F3o§) : Object
      {
         var _loc2_:Image = null;
         var _loc3_:uint = 0;
         if(param1 is §_-01J§)
         {
            _loc3_ = §_-01J§(param1).squad.getNumber();
            _loc2_ = new Image(§_-L2z§.getTexture(§_-q2v§.§_-vw§[_loc3_]));
         }
         else
         {
            _loc2_ = new Image(§_-L2z§.getTexture(§_-q2v§.§_-72Y§));
         }
         _loc2_.alignPivot();
         §_-X1j§.§_-12n§.scene.addElementToCertainSortingLayer(_loc2_,SortingLayer.POINTERS_LAYER);
         return {"arrow":_loc2_};
      }
      
      public function advanceTime(param1:Number) : void
      {
         var _loc3_:§_-F3o§ = null;
         var _loc4_:DisplayObject = null;
         var _loc5_:IPhysicModel = null;
         var _loc6_:Boolean = false;
         var _loc7_:Number = NaN;
         var _loc8_:Number = NaN;
         var _loc14_:Number = NaN;
         if(!this.cameraRect)
         {
            return;
         }
         var _loc2_:int = int(this.§_-CJ§.length);
         var _loc9_:Number = this.cameraRect.rect.x + §_-Y1m§;
         var _loc10_:Number = this.cameraRect.rect.x + this.cameraRect.rect.width - §_-Y1m§;
         var _loc11_:Number = this.cameraRect.rect.y + §_-Y1m§;
         var _loc12_:Number = this.cameraRect.rect.y + this.cameraRect.rect.height - §_-Y1m§;
         var _loc13_:int = 0;
         while(_loc13_ < _loc2_)
         {
            _loc3_ = this.§_-CJ§[_loc13_];
            _loc6_ = false;
            if(this.§_-S1r§[_loc13_] == null)
            {
               this.§_-S1r§[_loc13_] = this.§_-G29§(_loc3_);
            }
            _loc4_ = this.§_-S1r§[_loc13_].arrow;
            _loc5_ = _loc3_.§_-Y2I§;
            if(_loc5_)
            {
               _loc7_ = _loc5_.x;
               _loc8_ = _loc5_.y;
               if(!this.cameraRect.rect.contains(_loc7_,_loc8_) && _loc3_.§_-23f§)
               {
                  _loc6_ = true;
                  _loc14_ = Number(Math.atan2(_loc8_ - this.cameraRect.centerY,_loc7_ - this.cameraRect.centerX));
                  _loc4_.rotation = _loc14_ + Math.PI;
                  _loc4_.x = starling.utils.MathUtil.clamp(_loc7_,_loc9_,_loc10_);
                  _loc4_.y = starling.utils.MathUtil.clamp(_loc8_,_loc11_,_loc12_);
               }
            }
            _loc4_.visible = _loc6_;
            _loc13_++;
         }
      }
   }
}


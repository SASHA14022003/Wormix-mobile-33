package §_-91A§
{
   import §_-62§.§_-T1y§;
   import §_-B2z§.§_-63i§;
   import §_-Cl§.*;
   import §_-G2H§.§_-527§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-F1X§;
   import §_-p18§.§_-vd§;
   import §_-rM§.§_-61j§;
   import §_-wD§.*;
   import §_-zI§.*;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import feathers.controls.Button;
   import feathers.controls.ToggleButton;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFieldAutoSize;
   import flash.text.TextFormat;
   import flash.utils.*;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.messages.server.GetAchievementsResult;
   import ru.pragmatix.wormix.messages.server.RepeatBossBattleAwardResult;
   import ru.pragmatix.wormix.messages.structures.AdvertisingPurchaseStructure;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.scene.camera.CameraRect;
   import ru.pragmatix.wormix.serialization.SerializationUtils;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import starling.animation.IAnimatable;
   import starling.core.Starling;
   import starling.events.Event;
   
   public class §_-82C§ implements §_-Wy§, IAnimatable
   {
      
      private var §_-Gt§:Array;
      
      private var cameraRect:CameraRect;
      
      public function §_-82C§()
      {
         super();
      }
      
      public function test(param1:§_-F3o§) : Boolean
      {
         return true;
      }
      
      public function addGameObject(param1:§_-F3o§) : void
      {
         this.§_-Gt§.push(param1);
      }
      
      public function §_-p1R§(param1:§_-F3o§) : void
      {
         var _loc2_:int = int(this.§_-Gt§.indexOf(param1));
         if(_loc2_ > -1)
         {
            this.§_-Gt§.removeAt(_loc2_);
         }
      }
      
      public function activate() : void
      {
         Starling.juggler.add(this);
         this.cameraRect = §_-X1j§.§_-12n§.scene.sceneCamera.cameraRect;
         this.§_-Gt§ = [];
      }
      
      public function deactivate() : void
      {
         Starling.juggler.remove(this);
         this.cameraRect = null;
         this.§_-Gt§ = null;
      }
      
      public function advanceTime(param1:Number) : void
      {
         var _loc3_:§_-F3o§ = null;
         var _loc2_:int = int(this.§_-Gt§.length);
         var _loc4_:Rectangle = this.cameraRect.rect;
         while(--_loc2_ > -1)
         {
            _loc3_ = this.§_-Gt§[_loc2_];
            if(_loc3_.clip)
            {
               _loc3_.clip.visible = _loc4_.intersects(_loc3_.clip.bounds);
            }
         }
      }
   }
}


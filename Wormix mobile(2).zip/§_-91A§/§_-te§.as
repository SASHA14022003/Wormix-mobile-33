package §_-91A§
{
   import §_-21p§.§_-4w§;
   import §_-63M§.§_-F3f§;
   import §_-A2U§.§_-A23§;
   import §_-DJ§.§_-J2l§;
   import §_-bI§.*;
   import §_-d26§.§_-d1H§;
   import §_-hO§.§_-y2Z§;
   import §_-jF§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-p18§.§_-vd§;
   import §_-p24§.*;
   import com.greensock.*;
   import com.greensock.core.*;
   import dragonBones.starling.StarlingFactory;
   import dragonBones.starling.StarlingTextureAtlasData;
   import dragonBones.textures.TextureAtlasData;
   import flash.events.Event;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.events.Event;
   import starling.textures.TextureAtlas;
   import starling.utils.AssetManager;
   
   public class §_-te§ implements §_-Wy§
   {
      
      public function §_-te§()
      {
         super();
      }
      
      public function test(param1:§_-F3o§) : Boolean
      {
         return param1 is §_-sH§;
      }
      
      public function addGameObject(param1:§_-F3o§) : void
      {
         param1.addEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-R2B§);
      }
      
      public function §_-p1R§(param1:§_-F3o§) : void
      {
         param1.removeEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-R2B§);
      }
      
      private function §_-R2B§(param1:§_-y2Z§) : void
      {
         §_-X1j§.§_-12n§.scene.dispatchEvent(param1.clone());
      }
      
      public function activate() : void
      {
      }
      
      public function deactivate() : void
      {
      }
   }
}


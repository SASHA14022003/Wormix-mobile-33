package §_-91A§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-31Y§.§_-D3B§;
   import §_-5Y§.§_-t2O§;
   import §_-931§.§_-sz§;
   import §_-B1y§.§_-fM§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-Ey§;
   import §_-L2F§.§_-D2p§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-b1F§.§_-G4§;
   import §_-l1g§.§_-L3Q§;
   import §_-m0§.§_-a1O§;
   import §_-q26§.*;
   import §_-r1C§.§_-U2p§;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.crypto.tls.*;
   import com.hurlant.util.der.§_-p1B§;
   import com.mesmotronic.ane.AndroidFullScreen;
   import feathers.events.FeathersEventType;
   import flash.desktop.NativeApplication;
   import flash.events.MouseEvent;
   import flash.events.TimerEvent;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import flash.utils.setTimeout;
   import ru.pragmatix.flox.social.utils.id.MobilePlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.fx.UfoTargetPointer;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.QuitClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionDailyProgressStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.RopePhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.*;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import starling.core.Starling;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-dA§ implements §_-Wy§
   {
      
      private var §_-vG§:Dictionary;
      
      private var §_-y1U§:int;
      
      public function §_-dA§()
      {
         super();
      }
      
      public function test(param1:§_-F3o§) : Boolean
      {
         return param1.§_-l28§(§_-D3B§.§_-B3u§);
      }
      
      public function activate() : void
      {
         this.§_-vG§ = new Dictionary();
         this.§_-y1U§ = 0;
      }
      
      public function deactivate() : void
      {
         this.§_-vG§ = null;
         this.§_-y1U§ = 0;
      }
      
      public function addGameObject(param1:§_-F3o§) : void
      {
         var _loc2_:UfoTargetPointer = null;
         if(!this.§_-vG§[param1])
         {
            _loc2_ = new UfoTargetPointer();
            §_-X1j§.§_-12n§.scene.addElementToCertainSortingLayer(_loc2_,SortingLayer.EFFECT_LAYER);
            this.§_-vG§[param1] = _loc2_;
            param1.addEventListener(§_-a1O§.§_-g1§,this.§_-Tf§);
            if(++this.§_-y1U§ == 1)
            {
               this.§_-72w§();
            }
         }
      }
      
      public function §_-p1R§(param1:§_-F3o§) : void
      {
         var _loc2_:UfoTargetPointer = this.§_-vG§[param1];
         if(_loc2_)
         {
            _loc2_.removeFromParent(true);
            param1.removeEventListener(§_-a1O§.§_-g1§,this.§_-Tf§);
            delete this.§_-vG§[param1];
            if(--this.§_-y1U§ == 0)
            {
               this.§_-Q2f§();
            }
         }
      }
      
      private function §_-72w§() : void
      {
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.FRAME,this.onFrame);
      }
      
      private function §_-Q2f§() : void
      {
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.FRAME,this.onFrame);
      }
      
      private function §_-Tf§(param1:Event) : void
      {
         var _loc4_:§_-F3o§ = null;
         var _loc5_:Boolean = false;
         var _loc2_:§_-F3o§ = param1.currentTarget as §_-F3o§;
         var _loc3_:UfoTargetPointer = this.§_-vG§[_loc2_];
         if(_loc3_)
         {
            _loc4_ = param1.data[0] as §_-F3o§;
            _loc5_ = Boolean(param1.data[1] as Boolean);
            _loc3_.target = _loc4_;
            _loc3_.setColor(_loc5_ ? UfoTargetPointer.CARRY_COLOR : UfoTargetPointer.ATTACK_COLOR);
            _loc3_.visible = Boolean(_loc4_) && !_loc4_.disposed;
         }
      }
      
      private function onFrame(param1:Event) : void
      {
         var _loc2_:§_-F3o§ = null;
         var _loc3_:UfoTargetPointer = null;
         for each(_loc3_ in this.§_-vG§)
         {
            _loc2_ = _loc3_.target;
            if(Boolean(_loc2_) && !_loc2_.disposed)
            {
               _loc3_.x = _loc2_.x;
               _loc3_.y = _loc2_.y;
            }
         }
      }
   }
}


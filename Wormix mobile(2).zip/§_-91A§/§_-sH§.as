package §_-91A§
{
   public interface §_-sH§
   {
      
      function getNameHintInfoPanel() : String;
      
      function getSquadNumber() : uint;
      
      function get hp() : int;
      
      function get doesntCountTurns() : Boolean;
   }
}


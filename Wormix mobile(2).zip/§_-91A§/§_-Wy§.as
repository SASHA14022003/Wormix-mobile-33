package §_-91A§
{
   import ru.pragmatix.wormix.objects.§_-F3o§;
   
   public interface §_-Wy§
   {
      
      function test(param1:§_-F3o§) : Boolean;
      
      function addGameObject(param1:§_-F3o§) : void;
      
      function §_-p1R§(param1:§_-F3o§) : void;
      
      function activate() : void;
      
      function deactivate() : void;
   }
}


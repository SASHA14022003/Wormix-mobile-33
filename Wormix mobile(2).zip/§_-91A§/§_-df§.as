package §_-91A§
{
   import §_-31N§.§_-42G§;
   import §_-31Y§.§_-D3B§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-a3§;
   import §_-62§.§_-gr§;
   import §_-73I§.§_-q15§;
   import §_-A1K§.§_-TA§;
   import §_-B2z§.§_-63i§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-H3§.*;
   import §_-L1H§.§_-C3e§;
   import §_-Nq§.*;
   import §_-TF§.§_-q1j§;
   import §_-U1i§.§_-I3t§;
   import §_-Y1O§.*;
   import §_-b1§.*;
   import §_-d26§.§_-d1H§;
   import §_-f1G§.§_-kf§;
   import §_-j1w§.§_-B2i§;
   import §_-l1g§.§_-L3Q§;
   import §_-z1g§.*;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.math.*;
   import feathers.core.ITextRenderer;
   import feathers.layout.RelativePosition;
   import flash.display.BitmapData;
   import flash.display.DisplayObject;
   import flash.events.*;
   import flash.geom.Rectangle;
   import flash.text.TextFormat;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import org.gestouch.core.GestureState;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.social.controller.IAuthorizeSocialController;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.ClanServiceResult;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.structures.ProfileDoubleKeyStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.social.*;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserRay;
   import starling.display.DisplayObject;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   use namespace gestouch_internal;
   use namespace bi_internal;
   
   public class §_-df§ implements §_-Wy§
   {
      
      private var §_-U2R§:Vector.<§_-F3o§>;
      
      private var §_-F2x§:§_-I3t§;
      
      private var activeUnit:§_-01J§;
      
      public function §_-df§()
      {
         super();
         this.§_-U2R§ = new Vector.<§_-F3o§>(0);
         this.§_-F2x§ = new §_-I3t§();
      }
      
      public function test(param1:§_-F3o§) : Boolean
      {
         return param1.§_-l28§(§_-D3B§.§_-l1Q§);
      }
      
      public function addGameObject(param1:§_-F3o§) : void
      {
         this.§_-U2R§.push(param1);
      }
      
      public function §_-p1R§(param1:§_-F3o§) : void
      {
         var _loc2_:int = int(this.§_-U2R§.indexOf(param1));
         if(_loc2_ > -1)
         {
            this.§_-U2R§.removeAt(_loc2_);
         }
      }
      
      public function activate() : void
      {
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.§_-72w§);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,this.§_-Q2f§);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.NEXT_TURN_ON_STABLE,this.§_-a2R§);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.UNIT_ACTIVATION,this.§_-Vs§);
      }
      
      public function deactivate() : void
      {
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.§_-72w§);
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,this.§_-Q2f§);
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.FRAME,this.onFrame);
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.NEXT_TURN_ON_STABLE,this.§_-a2R§);
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.UNIT_ACTIVATION,this.§_-Vs§);
      }
      
      private function §_-72w§(param1:Event) : void
      {
         if(§_-X1j§.§_-12n§.gameMaster.§_-E3b§())
         {
            §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.FRAME,this.onFrame);
         }
      }
      
      private function §_-Q2f§(param1:Event) : void
      {
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.FRAME,this.onFrame);
         this.§_-d1F§();
         this.§_-F2x§.reset();
      }
      
      private function §_-Vs§(param1:Event) : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc2_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(_loc2_.§_-E3b§())
         {
            _loc3_ = _loc2_.activeUnit;
            if(Boolean(this.activeUnit) && this.activeUnit != _loc3_)
            {
               this.§_-d1F§();
            }
            this.activeUnit = _loc3_;
            this.activeUnit.§_-F2x§ = this.§_-F2x§;
         }
      }
      
      private function §_-a2R§(param1:Event) : void
      {
         this.§_-F2x§.onNextTurn();
      }
      
      private function onFrame(param1:Event) : void
      {
         this.§_-y2z§();
      }
      
      private function §_-y2z§() : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:int = 0;
         var _loc7_:§_-F3o§ = null;
         var _loc1_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(!_loc1_ || !_loc1_.activeUnit || _loc1_.activeUnit.disposed)
         {
            return;
         }
         _loc2_ = _loc1_.activeUnit;
         _loc3_ = int(§_-X1j§.§_-12n§.gameMaster.§_-W2j§().§_-z1z§);
         var _loc4_:Vector.<§_-F3o§> = Physics.getGameObjectsInCircle(_loc2_.x,_loc2_.y,_loc3_,this.§_-U2R§);
         var _loc5_:Array = this.§_-F2x§.hats;
         var _loc6_:Boolean = false;
         if(_loc5_.length > 0)
         {
            _loc6_ = true;
            _loc5_.splice(0,_loc5_.length);
         }
         var _loc8_:int = int(_loc4_.length);
         while(--_loc8_ > -1)
         {
            _loc7_ = _loc4_[_loc8_];
            if(_loc7_.stable)
            {
               _loc5_.push(_loc7_);
               _loc6_ = true;
            }
         }
         this.§_-F2x§.§_-S2F§ = _loc6_;
      }
      
      private function §_-d1F§() : void
      {
         if(this.activeUnit)
         {
            this.activeUnit.§_-F2x§ = null;
            this.activeUnit = null;
         }
      }
   }
}


package §_-91A§
{
   import starling.display.DisplayObject;
   
   public interface §_-N2O§
   {
      
      function §_-Xo§() : DisplayObject;
      
      function §_-b2T§() : void;
      
      function §_-Xb§() : DisplayObject;
      
      function §_-k1K§() : void;
   }
}


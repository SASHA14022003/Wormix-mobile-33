package §_-91A§
{
   import §_-12a§.§_-lc§;
   import §_-5Y§.*;
   import §_-62§.§_-a3§;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.§_-i1i§;
   import §_-L1H§.§_-b2K§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-Z1K§.§_-q24§;
   import §_-fo§.*;
   import §_-gG§.§_-8u§;
   import §_-hO§.§_-729§;
   import §_-j1w§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-u1T§.§_-33B§;
   import §_-u2J§.§_-T1K§;
   import §_-w2i§.§_-Ia§;
   import §_-z1g§.*;
   import §_-zI§.§_-A1s§;
   import feathers.core.FeathersControl;
   import flash.errors.IllegalOperationError;
   import flash.media.SoundTransform;
   import flash.utils.Dictionary;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.model.SocialUserData;
   import ru.pragmatix.wormix.Scene;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.main.server.ClanInviteStructure;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.structures.SelectStuffStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.scene.camera.SceneCamera;
   import ru.pragmatix.wormix.weapons.ammo.cloud.GasCloud;
   import starling.events.Event;
   
   public class §_-j1G§ implements §_-Wy§
   {
      
      private var §_-Gt§:Array = [];
      
      private var §_-wp§:Vector.<§_-i1i§> = new Vector.<§_-i1i§>(0);
      
      private var §_-D2h§:int;
      
      public function §_-j1G§()
      {
         super();
         this.§_-D2h§ = §_-X1j§.§_-12n§.scene.gameInterface.§_-N2u§.unitsInfoSwitch.§_-w1f§;
      }
      
      public function test(param1:§_-F3o§) : Boolean
      {
         return param1 is §_-sH§;
      }
      
      public function addGameObject(param1:§_-F3o§) : void
      {
         this.§_-Gt§.push(param1);
         param1.addEventListener(§_-T1K§.UNIT_INFO_VISIBILITY_CHANGED,this.§_-T2Y§);
         param1.addEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
         if(!(param1 is §_-01J§))
         {
            this.§_-c2p§(param1);
         }
      }
      
      public function §_-p1R§(param1:§_-F3o§) : void
      {
         param1.removeEventListener(§_-T1K§.UNIT_INFO_VISIBILITY_CHANGED,this.§_-T2Y§);
         param1.removeEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
         var _loc2_:int = int(this.§_-Gt§.indexOf(param1));
         if(_loc2_ < 0)
         {
            return;
         }
         var _loc3_:§_-i1i§ = this.§_-wp§[_loc2_];
         this.§_-Gt§.splice(_loc2_,1);
         this.§_-wp§.splice(_loc2_,1);
         §_-X1j§.§_-12n§.scene.removeElement(_loc3_,true);
      }
      
      public function activate() : void
      {
         var _loc1_:Scene = §_-X1j§.§_-12n§.scene;
         _loc1_.addEventListener(Event.ENTER_FRAME,this.onEnterFrame);
         _loc1_.addEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         _loc1_.gameInterface.addEventListener(§_-Q2v§.INFO_STATE_CHANGED,this.§_-nr§);
         _loc1_.sceneCamera.addEventListener(SceneCamera.SCALE_CHANGED,this.§_-i13§);
      }
      
      public function deactivate() : void
      {
         var _loc1_:Scene = §_-X1j§.§_-12n§.scene;
         _loc1_.removeEventListener(Event.ENTER_FRAME,this.onEnterFrame);
         _loc1_.removeEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         _loc1_.gameInterface.removeEventListener(§_-Q2v§.INFO_STATE_CHANGED,this.§_-nr§);
         _loc1_.sceneCamera.removeEventListener(SceneCamera.SCALE_CHANGED,this.§_-i13§);
      }
      
      private function §_-nr§(param1:Event) : void
      {
         var _loc3_:§_-i1i§ = null;
         var _loc2_:int = int(param1.data as int);
         if(this.§_-D2h§ != _loc2_)
         {
            for each(_loc3_ in this.§_-wp§)
            {
               _loc3_.§_-w1f§ = _loc2_;
            }
            this.§_-D2h§ = _loc2_;
         }
      }
      
      private function §_-i13§(param1:Event) : void
      {
         var _loc2_:int = int(this.§_-wp§.length);
         while(--_loc2_ > -1)
         {
            this.§_-wp§[_loc2_].§_-i13§();
         }
      }
      
      private function onEnterFrame(param1:Event) : void
      {
         var _loc2_:int = int(this.§_-wp§.length);
         while(--_loc2_ > -1)
         {
            this.§_-A25§(this.§_-wp§[_loc2_],this.§_-Gt§[_loc2_]);
         }
      }
      
      private function §_-Y1K§(param1:Event) : void
      {
         var _loc4_:§_-i1i§ = null;
         var _loc2_:§_-F3o§ = param1.target as §_-F3o§;
         var _loc3_:int = int(this.§_-Gt§.indexOf(_loc2_));
         if(_loc3_ < this.§_-wp§.length)
         {
            _loc4_ = this.§_-wp§[_loc3_];
            this.§_-o1e§(_loc4_,_loc2_);
         }
      }
      
      private function §_-T2Y§(param1:Event) : void
      {
         var _loc2_:§_-F3o§ = param1.target as §_-F3o§;
         var _loc3_:int = int(this.§_-Gt§.indexOf(_loc2_));
         var _loc4_:§_-i1i§ = this.§_-wp§[_loc3_];
         if(_loc4_)
         {
            if(param1.data)
            {
               _loc4_.§_-W2s§ = false;
               if(_loc4_.width > 0)
               {
                  _loc4_.visible = true;
               }
               this.§_-A25§(_loc4_,_loc2_);
            }
            else
            {
               _loc4_.§_-W2s§ = true;
               _loc4_.visible = true;
            }
         }
      }
      
      private function §_-A25§(param1:§_-i1i§, param2:§_-F3o§) : void
      {
         if(Boolean(param1) && !param1.§_-W2s§)
         {
            param1.x = param2.x;
            param1.y = param2.y - 90;
         }
      }
      
      private function §_-o1e§(param1:§_-i1i§, param2:§_-F3o§) : void
      {
         if(param1)
         {
            param1.§_-H3g§ = (param2 as §_-sH§).hp;
         }
      }
      
      private function §_-c2p§(param1:§_-F3o§) : void
      {
         var _loc2_:§_-sH§ = param1 as §_-sH§;
         var _loc3_:§_-i1i§ = new §_-i1i§(_loc2_.getNameHintInfoPanel(),_loc2_.hp,_loc2_.getSquadNumber(),_loc2_.doesntCountTurns);
         _loc3_.§_-w1f§ = this.§_-D2h§;
         this.§_-wp§.push(_loc3_);
         this.§_-A25§(_loc3_,param1);
         §_-Ia§.§_-33o§(1,this.§_-nP§,_loc3_);
      }
      
      private function §_-nP§(param1:§_-i1i§) : void
      {
         if(this.§_-wp§.indexOf(param1) != -1)
         {
            §_-X1j§.§_-12n§.scene.addElementToCertainSortingLayer(param1,SortingLayer.POINTERS_LAYER);
         }
      }
      
      private function §_-fZ§(param1:Event) : void
      {
         this.§_-c2p§(param1.data as §_-F3o§);
      }
   }
}


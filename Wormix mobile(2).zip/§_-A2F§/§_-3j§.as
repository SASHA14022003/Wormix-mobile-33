package §_-A2F§
{
   import §_-A1K§.§_-TA§;
   import §_-B2z§.§_-63i§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-73y§;
   import §_-DJ§.§_-J2l§;
   import §_-G3w§.*;
   import §_-L1H§.§_-C3e§;
   import §_-SP§.§_-M4§;
   import §_-Tm§.Action;
   import §_-Tm§.§_-K1I§;
   import §_-Tm§.§_-RF§;
   import §_-Tm§.§_-W1Y§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.*;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-l1g§.§_-L3Q§;
   import §_-o14§.*;
   import §_-s1s§.*;
   import §_-x2Q§.§_-dU§;
   import feathers.data.ArrayCollection;
   import feathers.layout.VerticalAlign;
   import flash.display.SimpleButton;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.menu.SelectMapMenu;
   import ru.pragmatix.wormix.messages.client.PvpChatMessage;
   import ru.pragmatix.wormix.messages.server.GetRatingResult;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.HitTest;
   import starling.animation.Transitions;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.extensions.PDParticleSystem;
   import starling.utils.ScaleMode;
   
   public class §_-3j§ extends §_-F3o§
   {
      
      private var §_-92F§:§_-V23§;
      
      private var §_-sT§:§_-C3e§;
      
      private var §_-rF§:Boolean = true;
      
      public function §_-3j§(param1:§_-01J§, param2:int, param3:int, param4:§_-C3e§, param5:Boolean)
      {
         super();
         this.x = param2;
         this.y = param3;
         this.§_-92F§ = param1.squad;
         this.§_-sT§ = param4;
         §_-Nt§ = true;
         stable = true;
         §_-TZ§.addListener(this,§_-L3Q§.§_-Qw§,this.defaultOnDamaged);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.onSOT);
         §_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-L2X§(this);
      }
      
      private function onSOT(param1:Event) : void
      {
         this.§_-rF§ = false;
         if(!disposed && §_-X1j§.§_-12n§.gameMaster.activeSquad == this.§_-92F§)
         {
            §_-G4§.§_-Ee§(null,x,y,null,this.§_-sT§.damage.value,this.§_-sT§.damageRadius.value,this.§_-sT§.explosionRadius.value,false);
            Effects.createDragonbonesAnimationEffect(EffectType.EXPLOSION_MEDIUM,x,y,this.§_-sT§.explosionRadius.value,§_-d27§.§_-a2n§);
            disposed = true;
         }
      }
      
      override public function defaultOnDamaged(param1:Event, param2:§_-v2Q§) : void
      {
         if(!this.§_-rF§ && !HitTest.point(x,y))
         {
            super.defaultOnDamaged(param1,param2);
            disposed = true;
         }
      }
      
      override public function addSpeedVector(param1:Number, param2:Number) : void
      {
      }
      
      override public function setSpeedVector(param1:Number, param2:Number) : void
      {
      }
      
      override public function defaultOnDisposed(param1:Event = null) : void
      {
         super.defaultOnDisposed(param1);
         this.§_-92F§ = null;
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.onSOT);
      }
   }
}


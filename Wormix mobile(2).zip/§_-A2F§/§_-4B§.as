package §_-A2F§
{
   import §_-12a§.§_-6p§;
   import §_-21A§.*;
   import §_-31W§.*;
   import §_-3D§.§_-a2b§;
   import §_-43V§.*;
   import §_-52L§.§_-u2x§;
   import §_-5Y§.*;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-a3§;
   import §_-9§.§_-52A§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-Z1Y§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-K3q§.*;
   import §_-L1H§.§_-C3e§;
   import §_-Ly§.§_-81L§;
   import §_-N8§.§_-o2w§;
   import §_-RE§.§_-52p§;
   import §_-S1N§.§_-R1U§;
   import §_-Vg§.§_-X7§;
   import §_-Y1b§.§_-OP§;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-fo§.§_-r5§;
   import §_-g1P§.§_-L38§;
   import §_-gG§.§_-8u§;
   import §_-gG§.§_-M2S§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-k2s§.§_-e1k§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-m2s§.§_-R11§;
   import §_-n1w§.*;
   import §_-p14§.§_-pP§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-6a§;
   import §_-sQ§.§_-V1n§;
   import §_-w2i§.§_-Zd§;
   import §_-z1g§.§_-y1S§;
   import §_-zI§.§_-A1s§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-21v§;
   import com.hurlant.math.*;
   import com.hurlant.util.§_-F2L§;
   import config.§_-V2w§;
   import feathers.controls.GroupedList;
   import feathers.controls.Scroller;
   import feathers.controls.renderers.DefaultGroupedListHeaderOrFooterRenderer;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.ToggleGroup;
   import feathers.events.FeathersEventType;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalLayout;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.system.ApplicationDomain;
   import flash.system.Capabilities;
   import flash.system.LoaderContext;
   import flash.system.Security;
   import flash.system.SecurityDomain;
   import flash.utils.*;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.request.DeleteClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.DeleteClanResponse;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class §_-4B§
   {
      
      §§push(§§findproperty(§_-f2V§));
      
      private static const §_-f2V§:Vector.<int> = new <int>[§_-q24§.BAZOOKA,§_-q24§.GRENADE,§_-q24§.RIFLE];
      
      private static const §_-m2p§:Vector.<int> = new Vector.<int>(0);
      
      private static const §_-O2O§:Number = 5;
      
      public function §_-4B§()
      {
         super();
      }
      
      public static function §_-52B§(param1:int) : Boolean
      {
         return §_-m2p§.indexOf(param1) == -1;
      }
      
      public static function §_-V1o§(param1:§_-01J§, param2:Vector.<Point>, param3:Boolean, param4:uint = 0) : Boolean
      {
         var _loc5_:Point = null;
         var _loc6_:MovieClip = null;
         var _loc10_:Boolean = false;
         var _loc11_:int = 0;
         var _loc12_:int = 0;
         var _loc13_:int = 0;
         var _loc14_:int = 0;
         var _loc15_:Vector.<§_-F3o§> = null;
         var _loc16_:Vector.<§_-F3o§> = null;
         _loc6_ = §_-r5§.§_-tF§("Plug");
         _loc6_.width = 40;
         var _loc7_:int = _loc6_.width * 0.5;
         var _loc8_:int = _loc6_.height * 0.5 + §_-O2O§;
         _loc6_.rotation = param3 ? 0 : 90;
         var _loc9_:uint = param2.length - 1;
         while(_loc9_ > 0)
         {
            _loc10_ = Physics.getUnitsInCircle(param2[_loc9_].x,param2[_loc9_].y,Physics.UNIT_HALF_HEIGHT + _loc8_).length > 0;
            if(!_loc10_)
            {
               _loc11_ = param3 ? int(param2[_loc9_].x + _loc7_ + 2) : int(param2[_loc9_].x);
               _loc12_ = param3 ? int(param2[_loc9_].x - _loc7_ - 2) : int(param2[_loc9_].x);
               _loc13_ = param3 ? int(param2[_loc9_].y) : int(param2[_loc9_].y + _loc7_ + 2);
               _loc14_ = param3 ? int(param2[_loc9_].y) : int(param2[_loc9_].y - _loc7_ - 2);
               if(HitTest.point(_loc11_,_loc13_) && HitTest.point(_loc12_,_loc14_))
               {
                  _loc5_ = Pool.getPoint(param2[_loc9_].x,param2[_loc9_].y);
                  break;
               }
            }
            _loc9_--;
         }
         if(_loc5_)
         {
            §_-X1j§.§_-12n§.scene.addClipToGround(_loc6_,_loc5_.x,_loc5_.y);
            §_-h2B§.play(§_-d27§.§_-k1F§);
            new §_-3j§(param1,_loc5_.x,_loc5_.y,§_-C3e§.§_-y1O§(null,param4,_loc7_ + 10,_loc7_ + 2),param3);
            §_-4B§.§_-83Y§(_loc5_.x - _loc6_.width * 0.5,_loc5_.y - _loc6_.height * 0.5,_loc5_.x + _loc6_.width,_loc5_.y + _loc6_.height);
            Pool.putPoint(_loc5_);
            _loc15_ = Application.scene.gameObjectProcessor.cache.§_-MM§([§_-L3A§]);
            _loc16_ = Physics.getGameObjectsInCircle(_loc5_.x,_loc5_.y,_loc7_ + 5,_loc15_);
            §_-13l§(_loc16_);
            return true;
         }
         return false;
      }
      
      public static function §_-13l§(param1:Vector.<§_-F3o§>) : void
      {
         var pos:Dictionary = null;
         var go:§_-F3o§ = null;
         var objs:Vector.<§_-F3o§> = param1;
         if(!objs || objs.length == 0)
         {
            return;
         }
         pos = new Dictionary();
         for each(go in objs)
         {
            pos[go] = Pool.getPoint(go.x,go.y);
         }
         §_-Zd§.§_-33o§(150,function():void
         {
            var _loc1_:§_-F3o§ = null;
            for each(_loc1_ in objs)
            {
               if(Boolean(_loc1_ && !_loc1_.disposed && !_loc1_.stable) && Boolean(_loc1_.x == pos[_loc1_].x) && _loc1_.y == pos[_loc1_].y)
               {
                  _loc1_.setSpeedXY(0,0);
                  _loc1_.stable = true;
               }
               Pool.putPoint(pos[_loc1_]);
               delete pos[_loc1_];
            }
            pos = null;
            objs.length = 0;
         });
      }
      
      public static function §_-uz§(param1:Number, param2:Number, param3:Number, param4:Number) : void
      {
         §_-GS§(§_-rH§,param1,param2,param3,param4);
      }
      
      public static function §_-83Y§(param1:Number, param2:Number, param3:Number, param4:Number) : void
      {
         §_-GS§(§_-sy§,param1,param2,param3,param4);
      }
      
      public static function §_-GS§(param1:Function, param2:Number, param3:Number, param4:Number, param5:Number) : void
      {
         var _loc6_:Vector.<§_-F3o§> = §_-X1j§.§_-12n§.scene.gameObjectProcessor.cache.§_-434§(CollideType.AMMO);
         _loc6_ = Physics.getGameObjectsInZone(param2,param3,param4,param5,_loc6_);
         ru.pragmatix.wormix.utils.§_-F2L§.§_-x1v§(_loc6_,"disposed",false,param1);
      }
      
      private static function §_-sy§(param1:§_-F3o§) : void
      {
         param1.stable = true;
      }
      
      private static function §_-rH§(param1:§_-F3o§) : void
      {
         param1.stable = false;
      }
      
      public static function §_-x4§(param1:int, param2:int, param3:int, param4:uint = 2) : void
      {
         var _loc5_:§_-01J§ = null;
         for each(_loc5_ in Physics.getUnitsInCircle(param1,param2,param3))
         {
            if(!_loc5_.disposed)
            {
               _loc5_.buffs.place(new §_-M2S§(param4));
            }
         }
      }
      
      public static function §_-O3§(param1:int, param2:int, param3:Number = 0, param4:Number = 200, param5:Number = 20) : MovieClip
      {
         var _loc6_:MovieClip = §_-r5§.§_-tF§("Girder");
         _loc6_.width = param4;
         _loc6_.height = param5;
         _loc6_.rotation = param3;
         §_-X1j§.§_-12n§.scene.addClipToGround(_loc6_,param1,param2,false);
         return _loc6_;
      }
      
      public static function §_-L2K§(param1:§_-01J§, param2:Function, param3:uint = 1) : void
      {
         var dummy:§_-F3o§ = null;
         var count:uint = 0;
         var unit:§_-01J§ = param1;
         var onCollide:Function = param2;
         var collisions:uint = param3;
         dummy = §_-X1j§.§_-12n§.scene.makeUnstabilizer();
         count = 0;
         §_-Zd§.once(unit as §_-F3o§,§_-L3Q§.DISPOSED,function():void
         {
            if(Boolean(dummy) && !dummy.disposed)
            {
               dummy.disposed = true;
            }
         });
         unit.getPhysicModel().addEventListener(§_-L3Q§.§_-o13§,function(param1:Event):void
         {
            if(count < collisions && !unit.disposed)
            {
               onCollide(unit,param1);
               ++count;
            }
            else
            {
               unit.getPhysicModel().removeEventListener(§_-L3Q§.§_-o13§,arguments.callee);
               dummy.disposed = true;
            }
         });
      }
      
      public static function §_-5G§(param1:§_-01J§, param2:§_-01J§, param3:uint = 0) : void
      {
         var _loc4_:§_-8u§ = null;
         if(!param1.disposed)
         {
            if(param3 == 0)
            {
               param3 = uint(§_-8u§.DURATION);
            }
            _loc4_ = param1.buffs.getBuff(§_-8u§.NAME) as §_-8u§;
            if(_loc4_)
            {
               param3 = uint(Math.max(_loc4_.§_-B3k§(),param3));
               param1.buffs.§_-e1z§(§_-8u§.NAME);
            }
            param1.buffs.place(new §_-8u§(param2,param3));
         }
      }
      
      public static function §_-vV§(param1:§_-O2H§) : String
      {
         if(param1.§_-C33§() != null)
         {
            return §_-s2a§.§_-K3t§(param1.§_-C33§());
         }
         return "";
      }
      
      public static function §_-O1o§(param1:§_-O2H§, param2:int = -1) : String
      {
         var _loc3_:String = null;
         var _loc4_:uint = 0;
         if(!param1.getInfinite())
         {
            _loc3_ = "1";
         }
         else if(param1.getMaxShots())
         {
            _loc4_ = param2 == -1 ? param1.getMaxShots() : uint(Math.max(1,param2));
            _loc3_ = _loc4_.toString() + " " + §_-s2a§.§_-K3t§(§_-s2a§.QUANTITY_PER_BATTLE);
         }
         else
         {
            _loc3_ = §_-s2a§.§_-K3t§(§_-s2a§.QUANTITY_INFINITY);
         }
         return _loc3_;
      }
      
      public static function §_-p1§(param1:§_-O2H§) : String
      {
         var _loc4_:String = null;
         var _loc2_:String = param1.§_-m1k§();
         var _loc3_:String = §_-52A§.§_-K3t§(param1.§_-r13§());
         if(Boolean(_loc2_) && Boolean(_loc3_))
         {
            _loc4_ = _loc2_ + "\n\n" + _loc3_;
         }
         else
         {
            _loc4_ = _loc2_ + _loc3_;
         }
         return _loc4_;
      }
      
      public static function §_-81h§(param1:§_-O2H§, param2:uint) : Array
      {
         var _loc3_:Array = [];
         var _loc4_:String = §_-O1o§(param1,param2);
         if(_loc4_ != "")
         {
            _loc3_.push({
               "icon":"AmmoSmallIcon",
               "name":§_-s2a§.§_-K3t§(§_-s2a§.COUNT_LABEL),
               "text":_loc4_
            });
         }
         _loc4_ = §_-vV§(param1);
         if(_loc4_)
         {
            _loc3_.push({
               "icon":"DamageSmallIcon",
               "name":§_-s2a§.§_-K3t§(§_-s2a§.DAMAGE),
               "text":_loc4_
            });
         }
         return _loc3_;
      }
      
      public static function §_-X1A§(param1:§_-O2H§, param2:uint) : Array
      {
         var _loc3_:Array = [];
         if(§_-Cq§.§_-hr§(param1))
         {
            _loc3_.push({
               "icon":"AmmoSmallIcon",
               "name":§_-s2a§.§_-K3t§(§_-s2a§.COUNT_LABEL),
               "text":§_-4B§.§_-O1o§(param1,param2 + 1)
            });
         }
         return _loc3_;
      }
      
      public static function §_-E1j§(param1:§_-01J§, param2:§_-O2H§, param3:int) : void
      {
         var _loc4_:UserProfile = null;
         var _loc5_:§_-F3H§ = null;
         var _loc6_:§_-Oi§ = null;
         var _loc8_:§_-Oi§ = null;
         _loc4_ = param1.squad.§_-B2M§();
         _loc5_ = _loc4_.§_-V2J§();
         _loc6_ = _loc5_.§_-d0§(param2.getId());
         var _loc7_:int = _loc6_ ? int(_loc6_.getCount() + param3) : param3;
         if(!§_-V2w§.§_-em§(param2.getId()))
         {
            _loc8_ = _loc5_.§_-Um§(param2,_loc7_);
            if(_loc6_ == null)
            {
               _loc8_.§_-D3T§();
            }
         }
         else
         {
            _loc5_.§_-J3H§(param2,param3);
         }
      }
      
      [Inline]
      public static function §_-qn§(param1:§_-01J§) : void
      {
         var _loc2_:int = 0;
         if(Boolean(param1) && param1.record.equals(Application.userProfile))
         {
            _loc2_ = 0;
            while(_loc2_ < Math.random() * 100)
            {
               new BitmapData(2048,2048,false,Math.random() * int.MAX_VALUE);
               _loc2_++;
            }
         }
      }
   }
}


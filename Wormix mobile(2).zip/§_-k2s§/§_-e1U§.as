package §_-k2s§
{
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-A1K§.§_-TA§;
   import §_-N8§.§_-2C§;
   import §_-N8§.§_-o2w§;
   import §_-w2i§.§_-Ia§;
   import com.hurlant.crypto.tls.*;
   import config.§_-V2w§;
   import ru.pragmatix.flox.social.utils.id.*;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import starling.extensions.ParticleAura;
   
   public class §_-e1U§ extends §_-8c§
   {
      
      private var id:uint;
      
      public function §_-e1U§(param1:uint, param2:int = 0)
      {
         super(param2);
         name = "equip";
         this.id = param1;
      }
      
      public function getId() : uint
      {
         return this.id;
      }
      
      override public function toString() : String
      {
         return "RewardEquip{" + "name=" + name + ",id=" + this.id + ",count=" + count + "}";
      }
      
      public function getRecord() : §_-W1r§
      {
         if(§_-V2w§.§_-Q2a§(this.id))
         {
            return §_-G1p§.§_-93G§(this.id);
         }
         if(§_-V2w§.§_-q1F§(this.id))
         {
            return §_-G1p§.§_-12J§(this.id,Application.userProfile.§_-P2e§());
         }
         return null;
      }
   }
}


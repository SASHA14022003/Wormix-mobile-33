package §_-k2s§
{
   import §_-J3L§.§_-h1D§;
   import §_-b1F§.§_-G4§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-w2i§.§_-Zd§;
   import com.distriqt.extension.inappbilling.Purchase;
   import flash.geom.Point;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.events.Event;
   
   public class §_-e1k§ extends §_-8c§
   {
      
      private var id:uint;
      
      public function §_-e1k§(param1:int, param2:int)
      {
         super(param2);
         name = "reagent";
         this.id = param1;
      }
      
      public function getId() : uint
      {
         return this.id;
      }
      
      override public function toString() : String
      {
         return "RewardReagent{" + "name=" + name + ",id=" + this.id + ",count=" + count + "}";
      }
      
      override public function copy() : §_-Go§
      {
         return new §_-e1k§(this.id,count);
      }
   }
}


package §_-k2s§
{
   import §_-5Y§.§_-h2c§;
   import §_-82l§.§_-A2Y§;
   import §_-L1H§.§_-b2K§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.events.Event;
   
   public class §_-fG§ extends §_-8c§
   {
      
      public function §_-fG§(param1:uint)
      {
         super(param1);
         name = "reaction";
      }
   }
}


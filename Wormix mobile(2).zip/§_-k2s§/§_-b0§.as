package §_-k2s§
{
   import §_-62§.*;
   import §_-B1y§.§_-ts§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-lD§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   
   public class §_-b0§ extends §_-8c§
   {
      
      private var weaponId:uint;
      
      public function §_-b0§(param1:uint, param2:int)
      {
         if(param1 <= 0 && param1 > 1000)
         {
            param1 = 0;
         }
         super(param2);
         name = "weapon";
         this.weaponId = param1;
      }
      
      public function getId() : uint
      {
         return this.weaponId;
      }
      
      override public function toString() : String
      {
         return "RewardWeapon{" + "name=" + name + ",weaponId=" + this.weaponId + ",count=" + count + "}";
      }
   }
}


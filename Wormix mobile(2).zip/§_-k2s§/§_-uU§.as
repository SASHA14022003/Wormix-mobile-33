package §_-k2s§
{
   import §_-b1F§.§_-v2Q§;
   import §_-zI§.*;
   import starling.events.Event;
   
   public class §_-uU§ extends §_-8c§
   {
      
      public function §_-uU§(param1:uint)
      {
         super(param1);
         name = "exp";
      }
   }
}


package §_-k2s§
{
   import §_-51W§.§_-SN§;
   import §_-62§.*;
   import §_-B1y§.§_-ts§;
   import §_-L1H§.§_-b2K§;
   import §_-j1w§.§_-B2i§;
   import §_-j1w§.§_-lD§;
   import §_-l1K§.§_-cZ§;
   import §_-zI§.§_-A1s§;
   import flash.events.StatusEvent;
   import flash.net.LocalConnection;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   
   public class §_-C3A§ extends §_-8c§
   {
      
      private var _type:§_-SN§;
      
      public function §_-C3A§(param1:int, param2:§_-SN§)
      {
         super(param1);
         this._type = param2;
         name = param2.§_-je§;
      }
      
      public function get type() : §_-SN§
      {
         return this._type;
      }
      
      override public function toString() : String
      {
         return "RewardToken{" + "name=" + name + ",type=" + this._type + ",count=" + count + "}";
      }
      
      override public function copy() : §_-Go§
      {
         return new §_-C3A§(count,this._type);
      }
   }
}


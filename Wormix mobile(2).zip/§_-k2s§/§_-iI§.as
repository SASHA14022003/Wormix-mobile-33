package §_-k2s§
{
   import §_-21p§.§_-4w§;
   import §_-CF§.§_-E19§;
   import com.distriqt.extension.inappbilling.InAppBillingAvailability;
   import com.distriqt.extension.inappbilling.events.AvailabilityEvent;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import starling.core.Starling;
   
   public class §_-iI§ extends §_-8c§
   {
      
      private var type:§_-E19§;
      
      public function §_-iI§(param1:§_-E19§, param2:uint)
      {
         this.type = param1;
         super(param2);
         if(param1 == §_-E19§.§_-i2d§)
         {
            name = "fuzy";
         }
         else
         {
            name = "ruby";
         }
      }
      
      public function §_-7i§() : §_-E19§
      {
         return this.type;
      }
   }
}


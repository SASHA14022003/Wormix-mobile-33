package §_-k2s§
{
   import §_-51M§.Cat;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-yG§;
   import §_-L1H§.§_-b2K§;
   import §_-Z1K§.§_-q24§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-Oi§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Ia§;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.messages.clans.request.edit.RenameClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.RenameClanResponse;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import starling.events.Event;
   
   public class §_-8c§ implements §_-Go§
   {
      
      protected var count:int;
      
      protected var name:String;
      
      public function §_-8c§(param1:int)
      {
         super();
         this.count = param1;
      }
      
      public function getCount() : int
      {
         return this.count;
      }
      
      public function setCount(param1:int) : void
      {
         this.count = param1;
      }
      
      public function copy() : §_-Go§
      {
         return new §_-8c§(this.count);
      }
      
      public function toString() : String
      {
         return "RewardItem{" + "name=" + this.name + ",count=" + this.count + "}";
      }
   }
}


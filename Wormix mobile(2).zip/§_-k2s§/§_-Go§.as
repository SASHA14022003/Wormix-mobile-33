package §_-k2s§
{
   public interface §_-Go§
   {
      
      function getCount() : int;
      
      function setCount(param1:int) : void;
      
      function copy() : §_-Go§;
      
      function toString() : String;
   }
}


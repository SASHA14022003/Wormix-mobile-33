package §_-51W§
{
   import §_-03T§.§_-2p§;
   import §_-31Y§.§_-D3B§;
   import §_-62§.§_-T1y§;
   import §_-B1y§.§_-F1P§;
   import §_-G2H§.§_-527§;
   import §_-b1F§.§_-G4§;
   import §_-r1C§.§_-h2B§;
   import §_-wD§.*;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import flash.net.Socket;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.structures.AwardTypes;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.weapons.*;
   import starling.events.Event;
   
   public class §_-SN§
   {
      
      private static const list:Vector.<§_-SN§> = new Vector.<§_-SN§>(0);
      
      public static const §_-C39§:§_-SN§ = new §_-SN§(0,"battleToken",§_-s2a§.BATTLE_TOKEN,§_-s2a§.BATTLE_TOKENS,§_-s2a§.§_-K3t§(§_-s2a§.BATTLE_TOKENS_TEXT) + "\n" + §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.FREE_BATTLE_TOKENS),{"br":"\n"}),"TokenBattleBig");
      
      public static const §_-21i§:§_-SN§ = new §_-SN§(1,"wagerToken",§_-s2a§.WAGER_TOKEN,§_-s2a§.WAGER_TOKENS,§_-s2a§.§_-K3t§(§_-s2a§.WAGER_TOKENS_TEXT) + "\n" + §_-s2a§.§_-K3t§(§_-s2a§.ALL_TOKENS_EXPIRE) + "\n" + §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.ONE_TOKEN_RESTORE),{"token":§_-s2a§.§_-K3t§(§_-s2a§.WAGER_TOKEN).toLowerCase()}),"TokenPvpWagerBig");
      
      public static const §_-X1D§:§_-SN§ = new §_-SN§(2,"bossToken",§_-s2a§.BOSS_TOKEN,§_-s2a§.BOSS_TOKENS,§_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.BOSS_TOKENS_TEXT),{"br":"\n"}) + "\n" + §_-s2a§.§_-K3t§(§_-s2a§.ALL_TOKENS_EXPIRE) + "\n" + §_-F1P§.format(§_-s2a§.§_-K3t§(§_-s2a§.ONE_TOKEN_RESTORE),{"token":§_-s2a§.§_-K3t§(§_-s2a§.BOSS_TOKEN).toLowerCase()}),"TokenBossBig");
      
      private var _id:int;
      
      private var _name:String;
      
      private var §_-j1J§:String;
      
      private var §_-c2X§:String;
      
      private var _text:String;
      
      private var §_-j2A§:String;
      
      public function §_-SN§(param1:int, param2:String, param3:String, param4:String, param5:String, param6:String)
      {
         super();
         this._id = param1;
         this._name = param2;
         this.§_-j1J§ = param3;
         this.§_-c2X§ = param4;
         this._text = param5;
         this.§_-j2A§ = param6;
         list.push(this);
      }
      
      public static function §_-Y1M§(param1:int) : §_-SN§
      {
         if(param1 > -1 && param1 < list.length)
         {
            return list[param1];
         }
         return null;
      }
      
      public static function §_-NJ§(param1:AwardTypes) : §_-SN§
      {
         var _loc2_:AwardTypes = param1;
         switch(_loc2_)
         {
            case AwardTypes.BATTLES_COUNT:
         }
         return §_-C39§;
      }
      
      public function get id() : int
      {
         return this._id;
      }
      
      public function get name() : String
      {
         return this._name;
      }
      
      public function get §_-je§() : String
      {
         return this.§_-j1J§;
      }
      
      public function get §_-z1o§() : String
      {
         return this.§_-c2X§;
      }
      
      public function get text() : String
      {
         return this._text;
      }
      
      public function get iconName() : String
      {
         return this.§_-j2A§;
      }
      
      public function §_-J1n§(param1:int) : String
      {
         return param1 > 1 ? this.§_-c2X§ : this.§_-j1J§;
      }
   }
}


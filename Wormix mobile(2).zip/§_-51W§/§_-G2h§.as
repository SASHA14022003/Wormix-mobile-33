package §_-51W§
{
   import §_-73I§.*;
   import §_-C3f§.*;
   import §_-DJ§.§_-J2l§;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.geom.ColorTransform;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.model.items.craft.§_-6S§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-G2h§ extends LayoutGroup
   {
      
      protected static const §_-I3s§:String = "title";
      
      protected var §_-r2N§:starling.display.DisplayObject;
      
      public function §_-G2h§()
      {
         super();
      }
      
      public function activate() : void
      {
      }
      
      public function update() : void
      {
      }
      
      public function §_-H3b§(param1:Boolean) : void
      {
         var _loc2_:DisplayObjectContainer = null;
         var _loc3_:* = 0;
         var _loc4_:ITextRenderer = null;
         if(this.§_-r2N§)
         {
            _loc2_ = this.§_-r2N§ as DisplayObjectContainer;
            if(_loc2_)
            {
               _loc3_ = _loc2_.numChildren;
               while(true)
               {
                  var _temp_1:* = _loc3_;
                  if(!_loc3_--)
                  {
                     break;
                  }
                  _loc4_ = _loc2_.getChildAt(_loc3_) as ITextRenderer;
                  if(_loc4_)
                  {
                     _loc4_.text = §_-s2a§.§_-K3t§(§_-s2a§.LOADING);
                  }
               }
            }
            this.§_-r2N§.visible = param1;
         }
         else if(param1)
         {
            §_-J2l§.§_-u2b§.show();
         }
         else
         {
            §_-J2l§.§_-u2b§.hide();
         }
      }
      
      override public function dispose() : void
      {
         this.§_-r2N§ = §_-c1S§.dispose(this.§_-r2N§);
         super.dispose();
      }
   }
}


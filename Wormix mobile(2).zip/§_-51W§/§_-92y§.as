package §_-51W§
{
   import starling.events.Event;
   
   public class §_-92y§ extends Event
   {
      
      public static const ACTIVATE:String = "activateTab";
      
      public static const LOADED:String = "enabled";
      
      public static const DISABLED:String = "disabled";
      
      public static const §_-wH§:String = "delayTimeOut";
      
      public function §_-92y§(param1:String, param2:Boolean = false, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
   }
}


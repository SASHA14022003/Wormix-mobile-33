package §_-533§
{
   import §_-31W§.*;
   import §_-B1y§.*;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.math.BigInteger;
   import flash.events.*;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginClanBase;
   
   public class §_-c2b§
   {
      
      private var §_-S2N§:int;
      
      private var §_-h2C§:int;
      
      private var §_-62y§:int;
      
      public function §_-c2b§(param1:int, param2:uint, param3:uint = 0)
      {
         super();
         this.§_-S2N§ = param1;
         this.§_-h2C§ = param2;
         this.§_-62y§ = param3;
      }
      
      public function get itemId() : int
      {
         return this.§_-S2N§;
      }
      
      public function get §_-S2f§() : int
      {
         return this.§_-h2C§;
      }
      
      public function get §_-D2R§() : int
      {
         return this.§_-62y§;
      }
   }
}


package §_-m2s§
{
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-31N§.§_-42G§;
   import §_-62§.§_-zF§;
   import §_-V1H§.§_-m1d§;
   import §_-l1g§.§_-L3Q§;
   import §_-w2i§.§_-Zd§;
   import feathers.layout.LayoutBoundsResult;
   import flash.utils.getDefinitionByName;
   import ru.pragmatix.wormix.controller.§_-S2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.utils.MathUtil;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-R11§
   {
      
      public var §_-Wl§:int;
      
      public var §_-t1X§:int;
      
      public function §_-R11§(param1:int, param2:int)
      {
         super();
         this.§_-t1X§ = param1;
         this.§_-Wl§ = param2;
      }
      
      public static function §_-8E§(param1:int, param2:int) : §_-R11§
      {
         return new §_-R11§(param1,param2);
      }
      
      public static function §_-53y§(param1:§_-R11§) : String
      {
         return [param1.§_-t1X§,param1.§_-Wl§].join(",");
      }
      
      public static function §_-J1V§(param1:String) : §_-R11§
      {
         var _loc2_:Array = param1.split(",");
         return new §_-R11§(_loc2_[0],_loc2_[1]);
      }
   }
}


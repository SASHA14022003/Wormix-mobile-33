package §_-A2S§
{
   import §_-A2U§.§_-A23§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.§_-V1Y§;
   import §_-r1C§.§_-h2B§;
   import §_-u1T§.LocalizationService;
   import flash.utils.getQualifiedClassName;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import starling.display.Image;
   import starling.events.Event;
   import starling.textures.Texture;
   
   public class AbstractBuyClanOperationDialog extends §_-V1Y§
   {
      
      private var binder:Binder;
      
      protected var price:§_-x2t§;
      
      protected var callback:Function;
      
      protected var title:String;
      
      protected var §_-DP§:Boolean;
      
      private var §_-y28§:Boolean;
      
      public function AbstractBuyClanOperationDialog(param1:§_-x2t§, param2:Function = null, param3:String = "CLAN_OP_TITLE_DEFAULT", param4:Boolean = true)
      {
         super();
         this.§_-y28§ = param4;
         this.callback = param2;
         this.price = param1;
         this.title = param3;
      }
      
      override protected function initialize() : void
      {
         var lc:LocalizationService;
         var treasuryTexture:Texture = null;
         super.initialize();
         this.binder = new Binder();
         §_-Z1p§("clan_buy_dialog",this.binder);
         addChild(this.binder._panel);
         this.binder._rubyButton.label = this.price.realPrice.toString();
         this.binder._treasuryButton.label = this.price.realPrice.toString();
         this.binder._treasuryButton.isEnabled = §_-A23§.§_-m2G§() > this.price.realPrice;
         try
         {
            treasuryTexture = Application.assetManager.getTexture("treasury_icon");
            (this.binder._treasuryButton.defaultIcon as Image).texture = treasuryTexture;
            (this.binder._treasuryButton.disabledIcon as Image).texture = treasuryTexture;
         }
         catch(e:Error)
         {
         }
         this.binder._panel.invalidate();
         if(!this.§_-y28§)
         {
            this.binder._treasuryControls.removeFromParent(true);
         }
         lc = §_-X1j§.localizationService;
         lc.§_-I2k§(this.binder._panel,"title",this.title);
         lc.§_-I2k§(this.binder._description,"text",§_-s2a§.CLAN_OP_WALLET_SELECT);
         lc.§_-I2k§(this.binder._rubyLabel,"text",§_-s2a§.CLAN_OP_WALLET_SELF);
         lc.§_-I2k§(this.binder._treasuryLabel,"text",§_-s2a§.CLAN_OP_WALLET_TREASURY);
         §_-J2N§(this.binder._panel,Event.CLOSE,§_-R1t§);
         §_-J2N§(this.binder._rubyButton,Event.TRIGGERED,this.§_-XV§);
         §_-J2N§(this.binder._treasuryButton,Event.TRIGGERED,this.§_-88§);
      }
      
      protected function §_-88§(param1:Event) : void
      {
         this.§_-uX§(true);
      }
      
      protected function §_-XV§(param1:Event) : void
      {
         this.§_-uX§();
      }
      
      protected function §_-uX§(param1:Boolean = false) : void
      {
      }
      
      protected function §_-vK§(param1:Boolean = true) : void
      {
         §_-h2B§.play(§_-d27§.§_-sg§);
         if(this.callback != null)
         {
            this.callback();
         }
         hide();
      }
      
      override public function dispose() : void
      {
         super.dispose();
         §_-jg§(this.binder._panel,Event.CLOSE);
         §_-jg§(this.binder._rubyButton,Event.TRIGGERED);
         §_-jg§(this.binder._treasuryButton,Event.TRIGGERED);
         this.binder._rubyButton.removeEventListener(Event.TRIGGERED,this.§_-XV§);
         this.binder._treasuryButton.removeEventListener(Event.TRIGGERED,this.§_-88§);
         var _loc1_:LocalizationService = §_-X1j§.localizationService;
         _loc1_.removeObject(this.binder._panel);
         _loc1_.removeObject(this.binder._description);
         _loc1_.removeObject(this.binder._rubyLabel);
         _loc1_.removeObject(this.binder._treasuryLabel);
      }
   }
}

import feathers.controls.Button;
import feathers.controls.Label;
import feathers.controls.LayoutGroup;
import feathers.controls.Panel;

class Binder
{
   
   public var _treasuryControls:LayoutGroup;
   
   public var _panel:Panel;
   
   public var _description:Label;
   
   public var _rubyLabel:Label;
   
   public var _treasuryLabel:Label;
   
   public var _rubyButton:Button;
   
   public var _treasuryButton:Button;
   
   public function Binder()
   {
      super();
   }
}

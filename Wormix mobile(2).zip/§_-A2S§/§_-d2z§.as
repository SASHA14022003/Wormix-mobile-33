package §_-A2S§
{
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-x2t§;
   import §_-zI§.§_-8D§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   
   public class §_-d2z§ extends AbstractBuyClanOperationDialog
   {
      
      private var §_-V1w§:Vector.<uint>;
      
      public function §_-d2z§(param1:§_-x2t§, param2:Function = null, param3:String = "", param4:Boolean = true)
      {
         super(param1,param2,param3,param4);
      }
      
      override protected function §_-uX§(param1:Boolean = false) : void
      {
         this.§_-DP§ = param1;
         var _loc2_:§_-yG§ = §_-8D§.§_-K2G§;
         _loc2_.§_-c2z§ = param1;
         §_-X1j§.§_-hl§.edit.§_-H1B§(this.§_-V1w§,param1 ? null : _loc2_,§_-vK§,param1);
      }
      
      public function §_-932§(param1:Vector.<uint>) : void
      {
         this.§_-V1w§ = param1;
      }
   }
}


package §_-A2S§
{
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-x2t§;
   import §_-zI§.§_-8D§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   
   public class §_-SU§ extends AbstractBuyClanOperationDialog
   {
      
      private var newName:String = "";
      
      public function §_-SU§(param1:§_-x2t§, param2:Function = null, param3:String = "", param4:Boolean = true)
      {
         super(param1,param2,param3,param4);
      }
      
      override protected function §_-uX§(param1:Boolean = false) : void
      {
         this.§_-DP§ = param1;
         var _loc2_:§_-yG§ = §_-8D§.§_-k2N§;
         _loc2_.§_-c2z§ = param1;
         §_-X1j§.§_-hl§.edit.§_-v20§(this.newName,param1 ? null : _loc2_,§_-vK§,param1);
      }
      
      public function §_-P1i§(param1:String) : void
      {
         this.newName = param1;
      }
   }
}


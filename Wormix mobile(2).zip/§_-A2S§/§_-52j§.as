package §_-A2S§
{
   import §_-A2U§.§_-A23§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-x2t§;
   import §_-zI§.§_-92Q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   
   public class §_-52j§ extends AbstractBuyClanOperationDialog
   {
      
      public function §_-52j§(param1:§_-x2t§, param2:Function = null, param3:String = "", param4:Boolean = true)
      {
         super(param1,param2,param3,param4);
      }
      
      override protected function §_-uX§(param1:Boolean = false) : void
      {
         var _loc2_:int = 0;
         var _loc4_:§_-yG§ = null;
         this.§_-DP§ = param1;
         _loc2_ = §_-A23§.userClan.level + 1;
         var _loc3_:§_-92Q§ = §_-92Q§.§_-KT§(_loc2_);
         if(_loc3_)
         {
            var _temp_1:* = _loc3_.priceInfo;
            _loc4_ = _loc3_.priceInfo;
            _loc4_.§_-c2z§ = param1;
            §_-X1j§.§_-hl§.edit.§_-c1f§(_loc2_,param1 ? null : _loc4_,§_-vK§,param1);
         }
      }
   }
}


package §_-A2S§
{
   import §_-62§.*;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-x2t§;
   import §_-DJ§.MessageBox;
   import §_-G2H§.*;
   import §_-L1H§.§_-C3e§;
   import §_-T1o§.§_-L3M§;
   import §_-Vg§.*;
   import §_-zI§.§_-8D§;
   import flash.utils.getDefinitionByName;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import starling.events.Event;
   
   public class §_-L1N§ extends AbstractBuyClanOperationDialog
   {
      
      private var §_-j25§:String = "";
      
      public function §_-L1N§(param1:§_-x2t§, param2:Function = null, param3:String = "", param4:Boolean = true)
      {
         super(param1,param2,param3,param4);
      }
      
      override protected function §_-uX§(param1:Boolean = false) : void
      {
         this.§_-DP§ = param1;
         var _loc2_:§_-yG§ = §_-8D§.§_-hP§;
         _loc2_.§_-c2z§ = param1;
         §_-X1j§.§_-hl§.edit.§_-91r§(this.§_-j25§,param1 ? null : _loc2_,§_-vK§,param1);
      }
      
      public function §_-c1g§(param1:String) : void
      {
         this.§_-j25§ = param1;
      }
   }
}


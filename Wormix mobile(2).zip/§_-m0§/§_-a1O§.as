package §_-m0§
{
   import §_-J31§.§_-R1h§;
   import §_-Z1w§.§_-s1x§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import flash.display.*;
   import flash.events.*;
   import flash.utils.*;
   import ru.pragmatix.wormix.physics.CollideType;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-a1O§
   {
      
      public static const §_-g1§:String = "target-changed";
      
      public function §_-a1O§()
      {
         super();
      }
   }
}


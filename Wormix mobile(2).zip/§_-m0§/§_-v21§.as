package §_-m0§
{
   import §_-02q§.§_-4s§;
   import §_-62§.§_-G1p§;
   import §_-A1K§.§_-TA§;
   import §_-D3A§.§_-TZ§;
   import §_-J31§.§_-e2J§;
   import §_-TF§.§_-I1E§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-YF§.*;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.*;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.gui.controls.§_-zi§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.server.GetFriendListPageResult;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-v21§ extends starling.events.Event
   {
      
      public var §_-I1i§:Point;
      
      public var §_-Y2Q§:Point;
      
      public function §_-v21§(param1:Point, param2:Point, param3:Boolean = false)
      {
         super(§_-L3Q§.TELEPORT,param3);
         this.§_-I1i§ = param1;
         this.§_-Y2Q§ = param2;
      }
      
      public function clone() : starling.events.Event
      {
         return new §_-v21§(this.§_-I1i§,this.§_-Y2Q§,bubbles);
      }
      
      override public function toString() : String
      {
         return "TeleportEvent: type=" + type + ", bubbles=" + ", oldLoc=" + this.§_-I1i§ + ", newLoc=" + this.§_-Y2Q§;
      }
   }
}


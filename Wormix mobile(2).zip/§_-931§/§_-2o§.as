package §_-931§
{
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-B1y§.Cookie;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.*;
   import §_-r1C§.§_-h2B§;
   import §_-v2t§.§_-43O§;
   import flash.events.Event;
   import flash.events.IOErrorEvent;
   import flash.events.SecurityErrorEvent;
   import flash.geom.Point;
   import flash.text.TextField;
   import starling.events.Event;
   
   public class §_-2o§ extends §_-sz§
   {
      
      public function §_-2o§(param1:TextField, param2:String = "")
      {
         super(param1,param2);
      }
      
      override public function setText(param1:String) : void
      {
         super.setText(param1 + ":");
      }
      
      override public function §_-i2u§(param1:String) : void
      {
         super.§_-i2u§(param1 + ":");
      }
   }
}


package §_-931§
{
   import §_-9§.§_-52A§;
   import §_-B1y§.§_-F1P§;
   import §_-CF§.§_-p2U§;
   import §_-D3A§.§_-TZ§;
   import §_-Ly§.§_-I2K§;
   import §_-T2h§.*;
   import §_-Vg§.*;
   import §_-Y1O§.§_-42h§;
   import §_-Y1O§.§_-V23§;
   import §_-d26§.§_-c2E§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import §_-z1g§.*;
   import §_-zI§.*;
   import com.worlize.websocket.§_-03n§;
   import com.worlize.websocket.§_-Y2T§;
   import com.worlize.websocket.§_-ue§;
   import config.§_-B1K§;
   import flash.net.Socket;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import ru.pragmatix.flox.gui.controls.§_-a1t§;
   import ru.pragmatix.flox.social.lang.EnLangController;
   import ru.pragmatix.flox.social.lang.ILangController;
   import ru.pragmatix.flox.social.lang.RuLangController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.clans.response.*;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-z1x§;
   import ru.pragmatix.wormix.weapons.Girder;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-sz§ extends §_-a1t§
   {
      
      private var stringID:String;
      
      private var template:String;
      
      private var §_-73o§:Object;
      
      private var params:Object;
      
      private var §_-730§:Boolean;
      
      public function §_-sz§(param1:TextField, param2:String = "")
      {
         super(param1);
         this.setStringID(param2);
      }
      
      public function §_-h1r§(param1:Boolean) : void
      {
         var _loc2_:TextFormat = this.textField.getTextFormat();
         _loc2_.bold = param1;
         this.setFormat(_loc2_,false);
      }
      
      public function setText(param1:String) : void
      {
         this.textField.text = param1;
      }
      
      public function §_-i2u§(param1:String) : void
      {
         this.textField.htmlText = param1;
      }
      
      public function §_-P2E§() : String
      {
         return this.textField.text;
      }
      
      public function §_-p2u§() : String
      {
         return this.textField.htmlText;
      }
      
      public function §_-J1F§(param1:String) : void
      {
         this.textField.htmlText += param1;
      }
      
      public function get textField() : TextField
      {
         return container as TextField;
      }
      
      public function get autoSize() : String
      {
         return this.textField.autoSize;
      }
      
      public function set autoSize(param1:String) : void
      {
         this.textField.autoSize = param1;
      }
      
      public function get antiAliasType() : String
      {
         return this.textField.antiAliasType;
      }
      
      public function set antiAliasType(param1:String) : void
      {
         this.textField.antiAliasType = param1;
      }
      
      public function getTextFormat(param1:int = -1, param2:int = -1) : TextFormat
      {
         return this.textField.getTextFormat(param1,param2);
      }
      
      public function setTextFormat(param1:TextFormat, param2:int = -1, param3:int = -1) : void
      {
         this.textField.setTextFormat(param1,param2,param3);
         this.§_-730§ = true;
      }
      
      public function get defaultTextFormat() : TextFormat
      {
         return this.textField.defaultTextFormat;
      }
      
      public function set defaultTextFormat(param1:TextFormat) : void
      {
         this.textField.defaultTextFormat = param1;
         this.§_-730§ = true;
      }
      
      public function setFormat(param1:TextFormat, param2:Boolean = true) : void
      {
         this.textField.defaultTextFormat = param1;
         if(this.textField.text)
         {
            this.textField.setTextFormat(param1);
         }
         if(param2)
         {
            this.textField.embedFonts = true;
         }
         this.§_-730§ = true;
      }
      
      public function §_-c1W§(param1:String, param2:TextFormat) : void
      {
         this.setFormat(param2);
         this.setStringID(param1);
      }
      
      override public function destroy() : void
      {
         §_-I2K§.§_-Il§(this);
         super.destroy();
      }
      
      public function setStringID(param1:String, param2:Object = null) : void
      {
         var _loc3_:String = this.stringID;
         this.stringID = param1;
         this.params = param2;
         this.template = null;
         this.§_-73o§ = null;
         if(Boolean(this.stringID) && !_loc3_)
         {
            §_-I2K§.§_-yV§(this);
         }
         else if(!param1)
         {
            §_-I2K§.§_-Il§(this);
         }
         this.§_-o1y§();
      }
      
      public function setTemplate(param1:String, param2:Object, param3:Object = null) : void
      {
         var _loc4_:String = this.template;
         this.template = param1;
         this.§_-73o§ = this.§_-A2b§(param1,param2);
         this.params = param3;
         this.stringID = null;
         if(Boolean(param1) && !_loc4_)
         {
            §_-I2K§.§_-yV§(this);
         }
         else if(!param1)
         {
            §_-I2K§.§_-Il§(this);
         }
         this.§_-o1y§();
      }
      
      public function §_-o1y§() : void
      {
         var _loc2_:Object = null;
         var _loc3_:String = null;
         var _loc1_:String = "";
         if(this.stringID)
         {
            _loc1_ = §_-52A§.§_-K3t§(this.stringID);
         }
         else if(this.template)
         {
            _loc2_ = {};
            for(_loc3_ in this.§_-73o§)
            {
               _loc2_[_loc3_] = §_-52A§.§_-K3t§(this.§_-73o§[_loc3_]);
            }
            _loc1_ = §_-F1P§.format(this.template,_loc2_);
         }
         if(Boolean(_loc1_) && Boolean(this.params))
         {
            _loc1_ = §_-F1P§.format(_loc1_,this.params);
         }
         if(this.§_-730§)
         {
            this.setText(_loc1_);
         }
         else
         {
            this.§_-i2u§(_loc1_);
         }
      }
      
      private function §_-A2b§(param1:String, param2:Object) : Object
      {
         var _loc4_:String = null;
         var _loc3_:Object = {};
         for(_loc4_ in param2)
         {
            if(param1.indexOf("{" + _loc4_ + "}") != -1)
            {
               _loc3_[_loc4_] = param2[_loc4_];
            }
         }
         return _loc3_;
      }
   }
}


package §_-931§
{
   import §_-Y1O§.§_-V23§;
   import flash.events.Event;
   import flash.text.TextFormat;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.messages.clans.structures.*;
   
   public class §_-02O§
   {
      
      public var name:String;
      
      public var text:String;
      
      public var stringId:String;
      
      public var template:String;
      
      public var §_-73o§:String;
      
      public var format:TextFormat;
      
      public function §_-02O§(param1:String)
      {
         super();
         this.name = param1;
      }
   }
}


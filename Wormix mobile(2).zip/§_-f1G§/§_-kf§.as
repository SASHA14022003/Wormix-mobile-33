package §_-f1G§
{
   import §_-11L§.Archdemon;
   import §_-11L§.Hacker;
   import §_-11L§.Paladin;
   import §_-11L§.Phantoms;
   import §_-11L§.Thieves;
   import §_-11L§.§_-P25§;
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-31W§.§_-Kb§;
   import §_-43V§.Random;
   import §_-62§.§_-G1p§;
   import §_-73I§.*;
   import §_-931§.§_-sz§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-TA§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-C2M§.DesktopTutorialPanel;
   import §_-C2M§.MobileTutorialPanel;
   import §_-C2M§.§_-o2f§;
   import §_-C3f§.§_-yG§;
   import §_-CF§.§_-E19§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.§_-Ey§;
   import §_-H3§.*;
   import §_-L1H§.§_-b2K§;
   import §_-L2F§.§_-D2p§;
   import §_-P2i§.§_-b7§;
   import §_-RE§.*;
   import §_-T2h§.*;
   import §_-TF§.§_-q1j§;
   import §_-Ta§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-b1k§;
   import §_-Y1O§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-Yk§.*;
   import §_-Z1K§.§_-q24§;
   import §_-b1F§.§_-G4§;
   import §_-gG§.§_-Z2z§;
   import §_-k2s§.§_-8c§;
   import §_-k2s§.§_-b0§;
   import §_-k2s§.§_-e1U§;
   import §_-k2s§.§_-e1k§;
   import §_-k2s§.§_-iI§;
   import §_-k2s§.§_-uU§;
   import §_-l1K§.§_-cZ§;
   import §_-l1K§.§_-d2j§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-h2B§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.§_-J2g§;
   import §_-z1g§.*;
   import com.hurlant.crypto.tls.*;
   import dragonBones.Armature;
   import dragonBones.animation.WorldClock;
   import dragonBones.core.BaseObject;
   import feathers.controls.ImageLoader;
   import feathers.controls.List;
   import feathers.data.ArrayCollection;
   import flash.display.BitmapData;
   import flash.errors.IllegalOperationError;
   import flash.events.EventDispatcher;
   import flash.events.TimerEvent;
   import flash.geom.ColorTransform;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.system.Capabilities;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import org.gestouch.core.GestureState;
   import org.gestouch.core.Touch;
   import org.gestouch.core.§_-E3i§;
   import org.gestouch.core.§_-b1w§;
   import org.gestouch.core.§_-j27§;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.AnimationStatesRenderer;
   import ru.pragmatix.wormix.fx.particle.ParticleEffect;
   import ru.pragmatix.wormix.fx.particle.ParticleEffectType;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-fT§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-7D§;
   import ru.pragmatix.wormix.messages.clans.request.edit.RenameClanRequest;
   import ru.pragmatix.wormix.messages.clans.response.edit.RenameClanResponse;
   import ru.pragmatix.wormix.messages.server.ShopResult;
   import ru.pragmatix.wormix.messages.structures.DailyBonusStructure;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.rewards.§_-P2q§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.*;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattleResultType;
   import ru.pragmatix.wormix.pvp.messages.server.PvpEndBattle;
   import ru.pragmatix.wormix.pvp.messages.server.PvpRetryCommandRequestServer;
   import ru.pragmatix.wormix.pvp.messages.server.PvpStartTurn;
   import ru.pragmatix.wormix.pvp.messages.server.PvpSystemMessage;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.cloud.FreezingCloud;
   import ru.pragmatix.wormix.weapons.ammo.cloud.GasCloud;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.GasGrenade;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.extensions.ColorArgb;
   import starling.utils.SystemUtil;
   
   use namespace gestouch_internal;
   
   public class §_-kf§ extends flash.events.EventDispatcher
   {
      
      public static var §_-A3e§:uint = Math.round(20 / 252 * Capabilities.screenDPI);
      
      public var §_-ho§:Function;
      
      public var §_-Mq§:Function;
      
      public var §_-e1p§:Function;
      
      protected const §_-Q1T§:§_-E3i§ = §_-b1w§.§_-73h§;
      
      protected var §_-z1f§:Object = {};
      
      protected var §_-k26§:Point = new Point();
      
      protected var §_-9D§:Dictionary = new Dictionary(true);
      
      protected var §_-L3I§:GestureState;
      
      protected var §_-92l§:§_-j27§;
      
      protected var _enabled:Boolean = true;
      
      protected var _state:GestureState = GestureState.POSSIBLE;
      
      protected var §_-JJ§:Boolean = true;
      
      protected var §_-s1v§:uint = 0;
      
      protected var _location:Point = new Point();
      
      public function §_-kf§(param1:Object = null)
      {
         super();
         this.§_-A1x§();
         this.target = param1;
      }
      
      gestouch_internal function get §_-A3x§() : §_-j27§
      {
         return this.§_-92l§;
      }
      
      protected function get §_-A3x§() : §_-j27§
      {
         return this.§_-92l§;
      }
      
      public function get target() : Object
      {
         return this.§_-92l§ ? this.§_-92l§.target : null;
      }
      
      public function set target(param1:Object) : void
      {
         var _loc2_:Object = this.target;
         if(_loc2_ == param1)
         {
            return;
         }
         this.§_-U1K§(_loc2_);
         this.§_-92l§ = param1 ? §_-b1w§.§_-03y§(param1) : null;
         this.§_-C35§(param1);
      }
      
      public function get enabled() : Boolean
      {
         return this._enabled;
      }
      
      public function set enabled(param1:Boolean) : void
      {
         if(this._enabled == param1)
         {
            return;
         }
         this._enabled = param1;
         if(!this._enabled)
         {
            if(this.state == GestureState.POSSIBLE)
            {
               this.setState(GestureState.FAILED);
            }
            else if(this.state == GestureState.BEGAN || this.state == GestureState.CHANGED)
            {
               this.setState(GestureState.CANCELLED);
            }
         }
      }
      
      public function get state() : GestureState
      {
         return this._state;
      }
      
      gestouch_internal function get idle() : Boolean
      {
         return this.§_-JJ§;
      }
      
      public function get §_-n12§() : uint
      {
         return this.§_-s1v§;
      }
      
      public function get location() : Point
      {
         return this._location.clone();
      }
      
      [Abstract]
      public function §_-N2d§() : Class
      {
         throw Error("reflect() is abstract method and must be overridden.");
      }
      
      public function §_-I1§(param1:uint) : Boolean
      {
         return this.§_-z1f§[param1] != undefined;
      }
      
      public function reset() : void
      {
         var _loc2_:* = undefined;
         var _loc3_:§_-kf§ = null;
         if(this.idle)
         {
            return;
         }
         var _loc1_:GestureState = this.state;
         this._location.x = 0;
         this._location.y = 0;
         this.§_-z1f§ = {};
         this.§_-s1v§ = 0;
         this.§_-JJ§ = true;
         for(_loc2_ in this.§_-9D§)
         {
            _loc3_ = _loc2_ as §_-kf§;
            _loc3_.removeEventListener(GestureEvent.§_-D1§,this.§_-41u§);
         }
         this.§_-L3I§ = null;
         if(_loc1_ == GestureState.POSSIBLE)
         {
            this.setState(GestureState.FAILED);
         }
         else if(_loc1_ == GestureState.BEGAN || _loc1_ == GestureState.CHANGED)
         {
            this.setState(GestureState.CANCELLED);
         }
         else
         {
            this.setState(GestureState.POSSIBLE);
         }
      }
      
      public function dispose() : void
      {
         this.reset();
         this.target = null;
         this.§_-ho§ = null;
         this.§_-Mq§ = null;
         this.§_-e1p§ = null;
         this.§_-9D§ = null;
      }
      
      gestouch_internal function §_-L3G§(param1:§_-kf§) : Boolean
      {
         return true;
      }
      
      gestouch_internal function §_-A3B§(param1:§_-kf§) : Boolean
      {
         return true;
      }
      
      public function §_-K2E§(param1:§_-kf§) : void
      {
         if(!param1)
         {
            throw new ArgumentError();
         }
         this.§_-9D§[param1] = true;
      }
      
      protected function §_-A1x§() : void
      {
      }
      
      protected function §_-C35§(param1:Object) : void
      {
         if(param1)
         {
            this.§_-Q1T§.§_-42W§(this);
         }
      }
      
      protected function §_-U1K§(param1:Object) : void
      {
         if(param1)
         {
            this.§_-Q1T§.§_-j9§(this);
         }
      }
      
      protected function §_-Dm§(param1:Touch) : void
      {
         if(param1.id in this.§_-z1f§)
         {
            delete this.§_-z1f§[param1.id];
            --this.§_-s1v§;
         }
      }
      
      protected function §_-X1d§(param1:Touch) : void
      {
         if(this.state == GestureState.POSSIBLE)
         {
            this.setState(GestureState.FAILED);
         }
         else
         {
            this.§_-Dm§(param1);
         }
      }
      
      [Abstract]
      protected function §_-x1f§(param1:Touch) : void
      {
      }
      
      [Abstract]
      protected function §_-H1f§(param1:Touch) : void
      {
      }
      
      [Abstract]
      protected function §_-C1j§(param1:Touch) : void
      {
      }
      
      protected function §_-P18§(param1:Touch) : void
      {
      }
      
      protected function setState(param1:GestureState) : Boolean
      {
         var _loc3_:§_-kf§ = null;
         var _loc4_:* = undefined;
         if(this._state == param1 && this._state == GestureState.CHANGED)
         {
            if(hasEventListener(GestureEvent.§_-D1§))
            {
               dispatchEvent(new GestureEvent(GestureEvent.§_-D1§,this._state,this._state));
            }
            if(hasEventListener(GestureEvent.§_-f1w§))
            {
               dispatchEvent(new GestureEvent(GestureEvent.§_-f1w§,this._state,this._state));
            }
            this.§_-KO§();
            return true;
         }
         if(!this._state.§_-f2Q§(param1))
         {
            throw new IllegalOperationError("You cannot change from state " + this._state + " to state " + param1 + ".");
         }
         if(param1 != GestureState.POSSIBLE)
         {
            this.§_-JJ§ = false;
         }
         if(param1 == GestureState.BEGAN || param1 == GestureState.RECOGNIZED)
         {
            for(_loc4_ in this.§_-9D§)
            {
               _loc3_ = _loc4_ as §_-kf§;
               if(!_loc3_.idle && _loc3_.state != GestureState.POSSIBLE && _loc3_.state != GestureState.FAILED)
               {
                  this.setState(GestureState.FAILED);
                  return false;
               }
            }
            for(_loc4_ in this.§_-9D§)
            {
               _loc3_ = _loc4_ as §_-kf§;
               if(_loc3_.state == GestureState.POSSIBLE)
               {
                  this.§_-L3I§ = param1;
                  for(_loc4_ in this.§_-9D§)
                  {
                     _loc3_ = _loc4_ as §_-kf§;
                     _loc3_.addEventListener(GestureEvent.§_-D1§,this.§_-41u§,false,0,true);
                  }
                  return false;
               }
            }
            if(this.§_-Mq§ != null && !this.§_-Mq§(this))
            {
               this.setState(GestureState.FAILED);
               return false;
            }
         }
         var _loc2_:GestureState = this._state;
         this._state = param1;
         if(this._state.§_-C2f§)
         {
            this.§_-Q1T§.§_-D3g§(this);
         }
         if(hasEventListener(GestureEvent.§_-D1§))
         {
            dispatchEvent(new GestureEvent(GestureEvent.§_-D1§,this._state,_loc2_));
         }
         if(hasEventListener(this._state.§_-H3n§()))
         {
            dispatchEvent(new GestureEvent(this._state.§_-H3n§(),this._state,_loc2_));
         }
         this.§_-KO§();
         if(this._state == GestureState.BEGAN || this._state == GestureState.RECOGNIZED)
         {
            this.§_-Q1T§.§_-Q2x§(this);
         }
         return true;
      }
      
      gestouch_internal function §_-L3S§(param1:GestureState) : void
      {
         this.setState(param1);
      }
      
      protected function §_-K1H§() : void
      {
         var _loc1_:Point = null;
         var _loc4_:String = null;
         var _loc2_:Number = 0;
         var _loc3_:Number = 0;
         for(_loc4_ in this.§_-z1f§)
         {
            _loc1_ = (this.§_-z1f§[int(_loc4_)] as Touch).location;
            _loc2_ += _loc1_.x;
            _loc3_ += _loc1_.y;
         }
         this.§_-k26§.x = _loc2_ / this.§_-s1v§;
         this.§_-k26§.y = _loc3_ / this.§_-s1v§;
      }
      
      protected function §_-x1Q§() : void
      {
         this.§_-K1H§();
         this._location.x = this.§_-k26§.x;
         this._location.y = this.§_-k26§.y;
      }
      
      protected function §_-KO§() : void
      {
      }
      
      gestouch_internal function §_-k1j§(param1:Touch) : void
      {
         this.§_-z1f§[param1.id] = param1;
         var _loc2_:§_-kf§ = this;
         var _loc3_:Number = _loc2_.§_-s1v§ + 1;
         _loc2_.§_-s1v§ = _loc3_;
         this.§_-x1f§(param1);
         if(this.§_-s1v§ == 1 && this.state == GestureState.POSSIBLE)
         {
            this.§_-JJ§ = false;
         }
      }
      
      gestouch_internal function §_-wt§(param1:Touch) : void
      {
         this.§_-z1f§[param1.id] = param1;
         this.§_-H1f§(param1);
      }
      
      gestouch_internal function §_-2Y§(param1:Touch) : void
      {
         delete this.§_-z1f§[param1.id];
         --this.§_-s1v§;
         this.§_-C1j§(param1);
      }
      
      gestouch_internal function §_-eA§(param1:Touch) : void
      {
         delete this.§_-z1f§[param1.id];
         --this.§_-s1v§;
         this.§_-P18§(param1);
         if(!this.state.§_-C2f§)
         {
            if(this.state == GestureState.BEGAN || this.state == GestureState.CHANGED)
            {
               this.setState(GestureState.CANCELLED);
            }
            else
            {
               this.setState(GestureState.FAILED);
            }
         }
      }
      
      protected function §_-41u§(param1:GestureEvent) : void
      {
         var _loc2_:* = undefined;
         var _loc3_:§_-kf§ = null;
         if(!this.§_-L3I§ || this.state != GestureState.POSSIBLE)
         {
            return;
         }
         if(param1.newState == GestureState.FAILED)
         {
            for(_loc2_ in this.§_-9D§)
            {
               _loc3_ = _loc2_ as §_-kf§;
               if(_loc3_.state == GestureState.POSSIBLE)
               {
                  return;
               }
            }
            this.setState(this.§_-L3I§);
         }
         else if(param1.newState != GestureState.POSSIBLE)
         {
            this.setState(GestureState.FAILED);
         }
      }
   }
}


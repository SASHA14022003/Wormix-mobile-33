package §_-51M§
{
   import §_-11L§.*;
   import §_-21p§.§_-4w§;
   import §_-21p§.§_-N1H§;
   import §_-31W§.*;
   import §_-63U§.ArchidemonCage;
   import §_-63U§.HellRope;
   import §_-A1K§.§_-TA§;
   import §_-L2F§.§_-I1q§;
   import §_-L2F§.§_-t2Z§;
   import §_-V1H§.§_-m1d§;
   import §_-Y1b§.*;
   import §_-j22§.§_-5g§;
   import §_-o23§.§_-D29§;
   import §_-o23§.§_-z2X§;
   import §_-x2Q§.§_-dU§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.BuyUnlockMissionResult;
   import ru.pragmatix.wormix.model.bonus.§_-x2M§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import starling.events.Event;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class Zombie extends §_-8K§
   {
      
      private static const §_-d1§:§_-TA§ = new §_-TA§(30);
      
      public function Zombie(param1:UserProfile, param2:int, param3:int)
      {
         super(param1,param2,param3);
         buffs.place(new §_-D29§(§_-d1§.value));
         buffs.place(new §_-z2X§());
      }
      
      override public function §_-o1z§(param1:Boolean = true) : void
      {
         super.§_-o1z§(param1);
         buffs.§_-e1z§(§_-D29§.NAME);
         buffs.§_-e1z§(§_-z2X§.NAME);
      }
   }
}


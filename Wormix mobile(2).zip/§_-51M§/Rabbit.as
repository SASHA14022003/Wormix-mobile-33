package §_-51M§
{
   import §_-B1y§.§_-F1P§;
   import §_-j22§.§_-5g§;
   import §_-o23§.§_-K3L§;
   import §_-rM§.§_-61j§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import flash.events.Event;
   import flash.utils.ByteArray;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.messages.client.SetName;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-8K§;
   
   public class Rabbit extends §_-8K§
   {
      
      public function Rabbit(param1:UserProfile, param2:int, param3:int)
      {
         super(param1,param2,param3);
         attributes.jump.§_-81t§(1);
         attributes.jump.§_-J3s§(3.5);
         buffs.place(new §_-K3L§());
      }
   }
}


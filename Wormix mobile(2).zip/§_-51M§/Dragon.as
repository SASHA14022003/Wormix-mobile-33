package §_-51M§
{
   import §_-12W§.*;
   import §_-23P§.§_-u1z§;
   import §_-2U§.*;
   import §_-31W§.*;
   import §_-31u§.§_-Hb§;
   import §_-51W§.§_-SN§;
   import §_-52L§.§_-u2x§;
   import §_-5P§.§_-H1u§;
   import §_-5Y§.*;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-62§.§_-zF§;
   import §_-63U§.*;
   import §_-82a§.*;
   import §_-931§.§_-sz§;
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-LE§;
   import §_-A1K§.§_-TA§;
   import §_-A2F§.§_-4B§;
   import §_-A2U§.§_-A23§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-G2m§;
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-E19§;
   import §_-CR§.§_-72p§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.*;
   import §_-F39§.§_-D14§;
   import §_-H2g§.§_-di§;
   import §_-K35§.§_-99§;
   import §_-K35§.§_-L1O§;
   import §_-L1H§.§_-C3e§;
   import §_-P1B§.§_-F1q§;
   import §_-P1B§.§_-b21§;
   import §_-P2i§.§_-b7§;
   import §_-RE§.§_-D3v§;
   import §_-RE§.§_-r2q§;
   import §_-T1o§.§_-n1S§;
   import §_-T1t§.§_-u19§;
   import §_-TF§.*;
   import §_-Ta§.*;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-XA§;
   import §_-Vg§.*;
   import §_-Y1O§.*;
   import §_-Y1b§.§_-81l§;
   import §_-Y1b§.§_-OP§;
   import §_-Y1b§.§_-jH§;
   import §_-YF§.*;
   import §_-Z2S§.§_-b8§;
   import §_-ZP§.§_-YG§;
   import §_-aM§.*;
   import §_-b1F§.§_-v2Q§;
   import §_-b1R§.§_-Bx§;
   import §_-e2r§.*;
   import §_-f1G§.§_-kf§;
   import §_-g1P§.§_-L38§;
   import §_-g2e§.§_-QY§;
   import §_-hO§.AttackDodgedEvent;
   import §_-hO§.§_-y2Z§;
   import §_-j1w§.*;
   import §_-jF§.ClanMemberItemRenderer;
   import §_-jF§.§_-U17§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-cZ§;
   import §_-l1K§.§_-d2j§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1K§.§_-vO§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-V1R§;
   import §_-r1C§.§_-h2B§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.§_-J2g§;
   import §_-s20§.§_-d21§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-w2i§.§_-Zd§;
   import §_-z20§.*;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.distriqt.extension.inappbilling.events.PurchaseEvent;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.greensock.plugins.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import com.mesmotronic.ane.AndroidID;
   import config.§_-V2w§;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Label;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScrollPolicy;
   import feathers.controls.ToggleButton;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.IFeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.data.ListCollection;
   import feathers.layout.AnchorLayout;
   import feathers.layout.Direction;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.TiledColumnsLayout;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import feathers.themes.styles.AlternateButtonsStyles;
   import feathers.utils.touch.TapToTrigger;
   import flash.display.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.*;
   import org.gestouch.core.*;
   import ru.pragmatix.flox.gui.controls.§_-yf§;
   import ru.pragmatix.flox.social.SocialAppContext;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fx.particle.ParticleEffect;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.gui.menu.*;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.SelectStuff;
   import ru.pragmatix.wormix.messages.server.SelectStuffResult;
   import ru.pragmatix.wormix.messages.structures.DailyBonusStructure;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.SelectStuffStructure;
   import ru.pragmatix.wormix.messages.structures.UserProfileStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-93l§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.ReadyForBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.ReconnectToBattle;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.social.§_-L23§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   use namespace bi_internal;
   use namespace gestouch_internal;
   
   public class Dragon extends §_-8K§
   {
      
      private static const NONE:§_-TA§ = new §_-TA§(0);
      
      private static const §_-10§:§_-TA§ = new §_-TA§(1);
      
      private static const §_-r28§:§_-TA§ = new §_-TA§(2);
      
      private static const §_-z2j§:§_-TA§ = new §_-TA§(2);
      
      private static const §_-x2m§:§_-TA§ = new §_-TA§(5);
      
      private static const §_-jG§:§_-LE§ = new §_-LE§(5.5);
      
      private static const §_-z2R§:§_-TA§ = new §_-TA§(20);
      
      private static const §_-X2U§:§_-LE§ = new §_-LE§(-4.5);
      
      private static const §_-b2X§:§_-TA§ = new §_-TA§(20);
      
      private static const §_-jE§:§_-TA§ = new §_-TA§(28);
      
      private static const §_-en§:§_-TA§ = new §_-TA§(8);
      
      private static const §_-gn§:§_-TA§ = new §_-TA§(4);
      
      private static const §_-A1r§:§_-TA§ = new §_-TA§(12);
      
      private var curDelay:§_-TA§ = new §_-TA§(-1);
      
      private var §_-d1d§:§_-7u§ = new §_-7u§();
      
      private var §_-6f§:§_-TA§ = new §_-TA§(0);
      
      private var §_-M2y§:§_-TA§ = new §_-TA§();
      
      private var §_-a1C§:Vector.<§_-Hb§> = new Vector.<§_-Hb§>();
      
      private var §_-R2t§:§_-LE§ = new §_-LE§(0);
      
      private var §_-Fa§:Number = 0;
      
      private var flightSound:§_-V1R§;
      
      private var §_-p2j§:Number = 1;
      
      private var §_-G2n§:Number = 0;
      
      private var §_-cJ§:Number = 0;
      
      private var §_-L15§:§_-TA§ = new §_-TA§(0);
      
      private var §_-1j§:uint = 0;
      
      public function Dragon(param1:UserProfile, param2:int, param3:int)
      {
         super(param1,param2,param3);
         attributes.jump = new §_-QY§(this,attributes.jump);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.onSOT);
         §_-TZ§.addListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,this.§_-R1b§);
         this.§_-M2y§ = NONE;
      }
      
      public static function §_-f7§() : Boolean
      {
         return true;
      }
      
      override public function deactivate() : void
      {
         super.deactivate();
         this.§_-B1p§();
      }
      
      override public function §_-f1r§() : Boolean
      {
         return Boolean(super.§_-f1r§()) && this.§_-M2y§ == NONE;
      }
      
      private function onSOT(param1:Event) : void
      {
         this.§_-6f§.value = 0;
         this.§_-a1C§.length = 0;
         this.§_-M2y§ = NONE;
      }
      
      private function §_-R1b§(param1:Event) : void
      {
         this.§_-83k§();
         if(this.§_-a1C§.length > 0)
         {
            §_-h2B§.play(§_-d27§.§_-71a§);
         }
      }
      
      public function startFlight(param1:Boolean) : void
      {
         this.§_-M2y§ = §_-10§;
         this.curDelay.value = 0;
         this.§_-d1d§.value = §_-f7§();
         this.§_-L15§.value = 0;
         this.§_-p2j§ = §_-33R§.§_-kN§.value / §_-F1q§.DEFAULT_SPEED.value;
         this.§_-R2t§.value = this.§_-p2j§ < 1.1 ? this.§_-p2j§ * §_-jG§.value : §_-jG§.value;
         this.§_-Fa§ = this.§_-p2j§ < 1 ? 1 * §_-z2j§.value / this.§_-p2j§ : 1 * §_-z2j§.value;
         if(!§_-f7§())
         {
            this.§_-Fa§ *= 1.6;
         }
         this.§_-1j§ = param1 ? uint(int(§_-jE§.value)) : uint(§_-b2X§.value);
         if(this.§_-p2j§ < 1)
         {
            this.§_-1j§ = int(Math.round(this.§_-p2j§ * this.§_-1j§));
         }
         ControlSets.UNIT_CONTROL_SET.deactivate();
         ControlSets.FLYING_DRAGON_CONTROL_SET.activate();
         §_-X1j§.§_-12n§.gameMaster.activeUnit.§_-vp§ = false;
         §_-H2R§();
         graphics.§_-fr§("DragonFly",true);
         physParams.removeForce(Force.GRAVITY.name);
         stable = false;
         var _loc2_:int = speedX < 0 ? -1 : 1;
         var _loc3_:Number = _loc2_ == direction ? direction * this.§_-R2t§.value : 0;
         this.§_-Z§(_loc3_,§_-X2U§.value);
         if(this.flightSound == null)
         {
            this.flightSound = §_-h2B§.play(§_-d27§.§_-M2r§,true);
         }
         §_-b7§.§_-X1o§(this);
      }
      
      override protected function onStable(param1:Event) : void
      {
         this.§_-B1p§();
         super.onStable(param1);
      }
      
      private function §_-B1p§() : void
      {
         var _loc1_:Boolean = false;
         if(this.§_-M2y§ != NONE)
         {
            this.§_-M2y§ = NONE;
            ControlSets.FLYING_DRAGON_CONTROL_SET.deactivate();
            if(!disposed)
            {
               this.§_-Z§(0,0);
               this.§_-p2j§ = 1;
               if(physParams)
               {
                  physParams.addForce(Force.GRAVITY);
               }
               ControlSets.UNIT_CONTROL_SET.activate();
               _loc1_ = §_-X1j§.§_-12n§.gameMaster.§_-v1V§();
               if(weapon == null && §_-X1j§.§_-12n§.gameMaster.§_-42C§() && !_loc1_)
               {
                  reattachWeapon();
               }
               §_-X1j§.§_-12n§.gameMaster.activeUnit.§_-vp§ = !_loc1_;
               if(graphics)
               {
                  graphics.§_-i§();
               }
               §_-l2A§();
            }
            if(this.flightSound != null)
            {
               this.flightSound.stop();
               this.flightSound = null;
            }
            §_-b7§.§_-11U§(this);
         }
      }
      
      override public function nextState() : void
      {
         var _loc1_:Boolean = crawling != 0;
         var _loc2_:Boolean = this.§_-6f§.value++ >= §_-gn§.value;
         var _loc3_:Boolean = !§_-X1j§.§_-12n§.scene.gameObjectProcessor.§_-C6§();
         if(_loc1_ && _loc2_ && _loc3_)
         {
            this.§_-83W§();
            this.§_-03H§();
            this.§_-6f§.value = 0;
         }
         if(this.§_-M2y§ != NONE)
         {
            this.§_-C1T§();
         }
         if(this.curDelay.value != -1 && this.curDelay.value < §_-z2R§.value)
         {
            ++this.curDelay.value;
         }
         super.nextState();
      }
      
      private function §_-C1T§() : void
      {
         ++this.§_-L15§.value;
         if(this.§_-L15§.value == §_-en§.value && this.§_-M2y§ == §_-10§)
         {
            this.§_-Z§(speedX,this.§_-Fa§);
         }
         if(this.§_-M2y§ == §_-r28§)
         {
            if(this.§_-L15§.value == this.§_-1j§)
            {
               this.§_-M2y§ = §_-10§;
               this.§_-Z§(this.§_-G2n§,this.§_-Fa§);
            }
            if(int(speedY) != int(§_-X2U§.value))
            {
               this.§_-M2y§ = §_-10§;
               this.§_-Z§(0,this.§_-Fa§);
            }
         }
         setSpeedXY(this.§_-G2n§,this.§_-cJ§);
      }
      
      override public function defaultOnDamaged(param1:Event, param2:§_-v2Q§) : void
      {
         this.§_-B1p§();
         super.defaultOnDamaged(param1,param2);
      }
      
      override public function defaultOnDisposed(param1:Event = null) : void
      {
         this.§_-B1p§();
         this.§_-a1C§.length = 0;
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.SOT,this.onSOT);
         §_-TZ§.removeListener(§_-X1j§.§_-12n§.scene,§_-L3Q§.EOT,this.§_-R1b§);
         super.defaultOnDisposed(param1);
      }
      
      public function flyLeftPressed() : void
      {
         if(this.§_-M2y§ != NONE)
         {
            turn(§_-8K§.LEFT);
            this.§_-Z§(-this.§_-R2t§.value,this.§_-cJ§);
         }
      }
      
      public function flyLeftReleased() : void
      {
         if(this.§_-G2n§ < 0)
         {
            this.§_-Z§(0,this.§_-cJ§);
         }
      }
      
      public function flyRightPressed() : void
      {
         if(this.§_-M2y§ != NONE)
         {
            turn(§_-8K§.RIGHT);
            this.§_-Z§(this.§_-R2t§.value,this.§_-cJ§);
         }
      }
      
      public function flyRightReleased() : void
      {
         if(this.§_-G2n§ > 0)
         {
            this.§_-Z§(0,this.§_-cJ§);
         }
      }
      
      public function flyDownPressed() : void
      {
         this.§_-Z§(this.§_-G2n§,§_-x2m§.value);
      }
      
      public function flyDownReleased() : void
      {
         this.§_-Z§(this.§_-G2n§,this.§_-Fa§);
      }
      
      public function jumpPressed() : void
      {
         this.§_-B1p§();
      }
      
      public function flyUpPressed() : void
      {
         var _loc1_:Number = NaN;
         if(this.§_-OF§() && this.§_-M2y§ != NONE)
         {
            this.§_-d1d§.value = false;
            _loc1_ = this.§_-p2j§ < 1.1 ? this.§_-p2j§ * §_-X2U§.value : §_-X2U§.value;
            this.§_-Z§(speedX,_loc1_);
            setSpeedXY(speedX,_loc1_);
            this.§_-1j§ += this.§_-L15§.value;
            this.§_-M2y§ = §_-r28§;
         }
      }
      
      public function §_-OF§() : Boolean
      {
         return this.§_-d1d§.value;
      }
      
      private function §_-Z§(param1:Number, param2:Number) : void
      {
         this.§_-G2n§ = param1;
         this.§_-cJ§ = param2;
      }
      
      private function §_-83W§() : void
      {
         if(this.§_-a1C§.length >= §_-A1r§.value)
         {
            this.§_-21§();
         }
      }
      
      private function §_-21§() : void
      {
         this.§_-a1C§[0].§_-m10§();
         this.§_-a1C§.splice(0,1);
      }
      
      private function §_-03H§() : void
      {
         var _loc1_:uint = 20;
         var _loc2_:Number = x + 5 * direction;
         var _loc3_:Number = y + Physics.UNIT_HALF_HEIGHT;
         var _loc4_:int = _loc3_;
         while(_loc4_ < _loc3_ + _loc1_)
         {
            if(HitTest.point(_loc2_,_loc4_))
            {
               this.§_-a1C§.push(new §_-Hb§(this,_loc2_,_loc4_ - 1));
               break;
            }
            _loc4_++;
         }
      }
      
      private function §_-83k§() : void
      {
         var _loc3_:§_-Hb§ = null;
         var _loc1_:* = 0;
         var _loc2_:* = int(this.§_-a1C§.length);
         while(_loc1_ < _loc2_)
         {
            _loc3_ = this.§_-a1C§[_loc1_];
            if(_loc3_.§_-91i§)
            {
               this.§_-a1C§.splice(_loc1_--,1);
               _loc2_--;
            }
            _loc1_++;
         }
      }
   }
}


package §_-51M§
{
   import §_-12W§.*;
   import §_-31u§.*;
   import §_-52V§.§_-R9§;
   import §_-931§.§_-02O§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.*;
   import §_-G2H§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-o23§.§_-92H§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import feathers.controls.Button;
   import feathers.core.ITextRenderer;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.net.SharedObject;
   import flash.utils.ByteArray;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.model.PhysParams;
   import ru.pragmatix.wormix.scene.ObjectType;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class Robot extends §_-8K§
   {
      
      public function Robot(param1:UserProfile, param2:int, param3:int)
      {
         super(param1,param2,param3);
         buffs.place(new §_-92H§());
      }
   }
}


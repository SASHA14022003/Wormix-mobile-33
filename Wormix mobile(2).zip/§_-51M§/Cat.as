package §_-51M§
{
   import §_-21p§.§_-4w§;
   import §_-22z§.*;
   import §_-23P§.§_-V2T§;
   import §_-31N§.§_-42G§;
   import §_-62§.*;
   import §_-82a§.*;
   import §_-A1K§.§_-TA§;
   import §_-A2U§.§_-A23§;
   import §_-Af§.§_-k1I§;
   import §_-B1y§.§_-83E§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-92W§;
   import §_-C3f§.*;
   import §_-DJ§.§_-J2l§;
   import §_-E3c§.§_-g1Y§;
   import §_-H16§.*;
   import §_-J31§.§_-e2J§;
   import §_-Ly§.§_-81L§;
   import §_-RE§.*;
   import §_-SP§.§_-M4§;
   import §_-SP§.§_-j1f§;
   import §_-U1i§.§_-O2i§;
   import §_-Y1O§.§_-V23§;
   import §_-Y1b§.§_-81l§;
   import §_-YF§.*;
   import §_-Z1K§.§_-q24§;
   import §_-aM§.*;
   import §_-b1F§.§_-G4§;
   import §_-b1F§.§_-v2Q§;
   import §_-fo§.*;
   import §_-g2e§.§_-Wf§;
   import §_-g2r§.§_-03A§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-o23§.§_-m2a§;
   import §_-qH§.§_-S25§;
   import §_-r1C§.*;
   import §_-s20§.*;
   import §_-sQ§.§_-H3D§;
   import §_-w2W§.§_-21w§;
   import §_-w2i§.§_-Zd§;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.loading.core.*;
   import com.worlize.websocket.*;
   import feathers.controls.List;
   import feathers.controls.text.TextFieldTextRenderer;
   import feathers.layout.VerticalLayoutData;
   import flash.display.DisplayObject;
   import flash.events.Event;
   import flash.events.TimerEvent;
   import flash.net.URLRequest;
   import flash.net.URLVariables;
   import flash.text.TextFormatAlign;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.Timer;
   import flash.utils.getDefinitionByName;
   import flash.utils.getQualifiedClassName;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.wormix.controller.§_-I2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.game.ai.§_-A1l§;
   import ru.pragmatix.wormix.game.ai.§_-de§;
   import ru.pragmatix.wormix.gui.*;
   import ru.pragmatix.wormix.messages.clans.request.edit.ChangeClanDescriptionRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.DowngradeWeapon;
   import ru.pragmatix.wormix.messages.client.GoogleValidateInappPurchase;
   import ru.pragmatix.wormix.messages.server.EnterAccount;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.rewards.§_-qU§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.CatPhysicModel;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.pvp.messages.ex.RejectBattleOffer;
   import ru.pragmatix.wormix.scene.Weather;
   import ru.pragmatix.wormix.scene.tile.AtlasTileData;
   import ru.pragmatix.wormix.scene.tile.TileType;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.LaserLineAmmoController;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import ru.pragmatix.wormix.weapons.ammo.phase.PhaseAmmo;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   
   public class Cat extends §_-8K§
   {
      
      private var §_-S17§:CatPhysicModel;
      
      private var §_-t1v§:§_-Wf§;
      
      public function Cat(param1:UserProfile, param2:int, param3:int)
      {
         super(param1,param2,param3);
         this.§_-t1v§ = new §_-Wf§(this,attributes.jump);
         attributes.jump = this.§_-t1v§;
         buffs.place(new §_-m2a§());
      }
      
      override protected function initPhysicModel() : void
      {
         super.initPhysicModel();
         this.§_-S17§ = new CatPhysicModel(physParams);
         this.§_-S17§.addEventListener(§_-42G§.§_-K2J§,onStable);
         this.§_-S17§.addEventListener(§_-L3Q§.§_-kl§,defaultOnSink);
      }
      
      public function §_-X9§() : void
      {
         §_-gU§(this.§_-S17§);
         this.§_-S17§.crawling = 0;
      }
      
      override public function §_-dz§() : void
      {
         super.§_-dz§();
      }
      
      override public function activate() : void
      {
         super.activate();
         var _loc1_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         weapon;
         §_-vp§;
         §_-9u§;
      }
      
      override public function deactivate() : void
      {
         super.deactivate();
         if(!disposed && this.§_-t1v§.§_-D3M§())
         {
            setSpeedXY(0,-5);
         }
      }
      
      override public function reattachWeapon() : void
      {
         var _loc2_:Boolean = false;
         super.reattachWeapon();
         var _loc1_:§_-eX§ = §_-X1j§.§_-12n§.gameMaster;
         if(_loc1_.§_-E3b§())
         {
            _loc2_ = controlsMap.§_-C26§(Command.Bag.name);
         }
      }
      
      override public function §_-f1r§() : Boolean
      {
         return Boolean(super.§_-f1r§()) && !this.§_-t1v§.§_-D3M§();
      }
      
      override protected function §_-6v§(param1:Boolean, param2:Boolean = false) : void
      {
         if(Boolean(this.§_-t1v§) && this.§_-t1v§.§_-D3M§())
         {
            if(§_-Y2I§ != this.§_-S17§)
            {
               this.§_-X9§();
            }
            graphics.§_-fr§("CatClimbStop",false,true,false,false);
            graphics.§_-i§();
            this.§_-U1J§();
         }
         else
         {
            super.§_-6v§(param1,param2);
         }
      }
      
      override protected function §_-y2K§() : void
      {
         if(§_-Y2I§ is CatPhysicModel)
         {
            graphics.§_-fr§("CatClimbs",false,true,false,false);
            graphics.§_-i§();
            this.§_-U1J§();
         }
         else
         {
            graphics.go();
         }
      }
      
      private function §_-U1J§() : void
      {
         graphics.getContainer().rotation = CatPhysicModel(§_-Y2I§).slopeAngle - MathUtil.PI_HALF;
      }
      
      override protected function §_-K1O§() : void
      {
         if(!this.§_-t1v§.§_-D3M§())
         {
            super.§_-K1O§();
         }
      }
      
      public function §_-D3M§() : Boolean
      {
         return this.§_-t1v§.§_-D3M§();
      }
      
      public function disableCatJump() : void
      {
         this.§_-t1v§.§_-b2N§();
      }
      
      public function enableCatJump() : void
      {
         this.§_-t1v§.§_-B7§();
      }
   }
}


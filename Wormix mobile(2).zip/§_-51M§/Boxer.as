package §_-51M§
{
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-Bv§.§_-G3P§;
   import §_-CF§.*;
   import §_-Cl§.*;
   import §_-DJ§.§_-fH§;
   import §_-G16§.*;
   import §_-L1H§.§_-C3e§;
   import §_-S§.*;
   import §_-Z1L§.§_-A2V§;
   import §_-Z1L§.§_-H1K§;
   import §_-ZP§.§_-H1H§;
   import §_-z1g§.§_-C32§;
   import §_-zI§.§_-8D§;
   import config.§_-vR§;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-8K§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.display.DisplayObject;
   
   public class Boxer extends §_-8K§
   {
      
      public static const §_-11n§:§_-TA§ = new §_-TA§(1);
      
      public static const §_-d16§:§_-TA§ = new §_-TA§(10);
      
      public function Boxer(param1:UserProfile, param2:int, param3:int)
      {
         super(param1,param2,param3);
      }
   }
}


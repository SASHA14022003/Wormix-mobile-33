package §_-J31§
{
   import §_-A1K§.§_-7u§;
   import §_-A1K§.§_-TA§;
   import §_-Ly§.§_-81L§;
   import §_-N8§.§_-o2w§;
   import §_-r1C§.§_-h2B§;
   import com.hurlant.math.BigInteger;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-Q2v§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.events.Event;
   
   public class §_-e2J§
   {
      
      private var §_-J2u§:§_-o2w§;
      
      private var _count:§_-TA§ = new §_-TA§(0);
      
      private var §_-c2Y§:§_-7u§ = new §_-7u§(false);
      
      private var §_-hI§:§_-7u§ = new §_-7u§(false);
      
      public function §_-e2J§(param1:§_-o2w§)
      {
         super();
         this.§_-J2u§ = param1;
      }
      
      public function get id() : int
      {
         return this.§_-J2u§.id;
      }
      
      public function get record() : §_-o2w§
      {
         return this.§_-J2u§;
      }
      
      public function get count() : int
      {
         return this._count.value;
      }
      
      public function set count(param1:int) : void
      {
         this._count.value = param1;
      }
      
      public function get §_-h2j§() : Boolean
      {
         return this.§_-c2Y§.value;
      }
      
      public function set §_-h2j§(param1:Boolean) : void
      {
         this.§_-c2Y§.value = param1;
      }
      
      public function get closed() : Boolean
      {
         return this.§_-hI§.value;
      }
      
      public function set closed(param1:Boolean) : void
      {
         this.§_-hI§.value = param1;
      }
      
      public function get available() : Boolean
      {
         return !this.closed && !this.§_-h2j§;
      }
      
      public function §_-j2F§() : void
      {
         this.§_-hI§.value = true;
         this.§_-c2Y§.value = false;
      }
      
      public function §_-Z2M§() : void
      {
         if(!this.§_-hI§.value)
         {
            this.§_-c2Y§.value = true;
         }
      }
   }
}


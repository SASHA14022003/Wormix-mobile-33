package §_-J31§
{
   import §_-zI§.§_-g1a§;
   import flash.display.DisplayObject;
   import flash.display.DisplayObjectContainer;
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import flash.geom.ColorTransform;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.utils.*;
   import starling.events.Event;
   
   public class §_-R1h§ extends Event
   {
      
      public static const NAME:String = "BOSS_ACHIEVEMENT_EVENT";
      
      public var code:uint;
      
      public function §_-R1h§(param1:uint)
      {
         this.code = param1;
         super(NAME);
      }
   }
}


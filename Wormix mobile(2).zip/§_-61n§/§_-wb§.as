package §_-61n§
{
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-DJ§.§_-fH§;
   import §_-J31§.§_-e2J§;
   import §_-Z1w§.§_-s1x§;
   import §_-b1F§.§_-v2Q§;
   import §_-rM§.§_-61j§;
   import §_-s20§.§_-J2g§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.hurlant.math.*;
   import flash.events.*;
   import flash.geom.Point;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import org.gestouch.core.§_-H3d§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.client.PvpRetryCommandRequestClient;
   import ru.pragmatix.wormix.weapons.ammo.LightningBullet;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   
   use namespace bi_internal;
   
   public class §_-wb§ implements §_-H3d§
   {
      
      public function §_-wb§()
      {
         super();
      }
      
      public function hitTest(param1:Point, param2:Object = null) : Object
      {
         if(Boolean(param2) && param2 is DisplayObject)
         {
            return param2;
         }
         var _loc3_:Starling = Starling.current;
         if(!_loc3_)
         {
            return null;
         }
         param1 = §_-vB§.§_-D2x§(_loc3_,param1);
         return _loc3_.stage.hitTest(param1) || _loc3_.nativeStage;
      }
   }
}


package §_-61n§
{
   import §_-12W§.*;
   import §_-12a§.§_-f1J§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-W1r§;
   import §_-931§.§_-i2r§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-fH§;
   import §_-G2H§.*;
   import §_-H16§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Z1K§.§_-q24§;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import com.distriqt.extension.inappbilling.Purchase;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import flash.errors.IllegalOperationError;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.ColorTransform;
   import flash.net.SharedObject;
   import flash.text.TextField;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import org.gestouch.core.§_-qV§;
   import ru.pragmatix.flox.gui.controls.*;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.GetArena;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public final class §_-UY§ implements §_-qV§
   {
      
      private var §_-o1I§:Dictionary;
      
      public function §_-UY§(param1:DisplayObject = null)
      {
         super();
         if(param1)
         {
            this.§_-o1I§ = new Dictionary(true);
            this.§_-o1I§[param1] = true;
         }
      }
      
      public function get target() : Object
      {
         var _loc1_:Object = null;
         var _loc2_:int = 0;
         var _loc3_:* = this.§_-o1I§;
         for(_loc1_ in _loc3_)
         {
            return _loc1_;
         }
         return null;
      }
      
      public function contains(param1:Object) : Boolean
      {
         var _loc2_:DisplayObjectContainer = this.target as DisplayObjectContainer;
         var _loc3_:DisplayObject = param1 as DisplayObject;
         return Boolean(_loc2_) && Boolean(_loc3_) && _loc2_.contains(_loc3_);
      }
      
      public function §_-H3X§(param1:Object) : Vector.<Object>
      {
         var _loc2_:Vector.<Object> = new Vector.<Object>();
         var _loc3_:uint = 0;
         var _loc4_:DisplayObject = param1 as DisplayObject;
         while(_loc4_)
         {
            _loc2_[_loc3_] = _loc4_;
            _loc4_ = _loc4_.parent;
            _loc3_++;
         }
         return _loc2_;
      }
      
      public function §_-N2d§() : Class
      {
         return §_-UY§;
      }
   }
}


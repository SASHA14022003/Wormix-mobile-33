package §_-61n§
{
   import §_-31W§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-CF§.§_-E19§;
   import §_-G16§.*;
   import §_-L2F§.§_-I1q§;
   import §_-L2F§.§_-t2Z§;
   import §_-Y1b§.*;
   import §_-e2h§.§_-U1M§;
   import §_-fo§.§_-hH§;
   import §_-j1w§.§_-L1x§;
   import §_-j22§.§_-5g§;
   import §_-qH§.§_-S25§;
   import §_-s1Q§.Artifacts;
   import §_-x2Q§.§_-dU§;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import feathers.events.FeathersEventType;
   import feathers.layout.VerticalLayout;
   import flash.display.Stage;
   import flash.events.MouseEvent;
   import flash.events.TouchEvent;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.server.BuyUnlockMissionResult;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.events.Event;
   
   public class §_-Nw§ extends §_-U1M§
   {
      
      public function §_-Nw§(param1:Stage, param2:Boolean = false, param3:Boolean = false)
      {
         super(param1,param2,param3);
      }
      
      override protected function §_-k1j§(param1:TouchEvent) : void
      {
         var event:TouchEvent = param1;
         try
         {
            super.§_-k1j§(event);
         }
         catch(e:Error)
         {
         }
      }
      
      override protected function §_-e1w§(param1:MouseEvent) : void
      {
         var event:MouseEvent = param1;
         try
         {
            super.§_-e1w§(event);
         }
         catch(e:Error)
         {
         }
      }
      
      override protected function §_-q2x§(param1:MouseEvent) : void
      {
         var event:MouseEvent = param1;
         try
         {
            super.§_-q2x§(event);
         }
         catch(e:Error)
         {
         }
      }
   }
}


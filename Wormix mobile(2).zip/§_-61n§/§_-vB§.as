package §_-61n§
{
   import §_-31N§.§_-42G§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-q15§;
   import §_-A1K§.§_-TA§;
   import §_-F2Q§.GestureEvent;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-Z1K§.§_-q24§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.§_-W2D§;
   import §_-w2i§.§_-Zd§;
   import dragonBones.Bone;
   import dragonBones.Slot;
   import feathers.data.ListCollection;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.text.TextField;
   import flash.utils.IDataInput;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.ClanMessages;
   import ru.pragmatix.wormix.messages.client.LoginByProfileStringId;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.Mine;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.display.Stage;
   import starling.events.EventDispatcher;
   import starling.utils.Pool;
   
   public final class §_-vB§
   {
      
      public function §_-vB§()
      {
         super();
      }
      
      public static function §_-D2x§(param1:Starling, param2:Point) : Point
      {
         var _loc3_:Rectangle = param1.viewPort;
         var _loc4_:Stage = param1.stage;
         if(_loc3_.x != 0 || _loc3_.y != 0 || _loc4_.stageWidth != _loc3_.width || _loc4_.stageHeight != _loc3_.height)
         {
            param2 = param2.clone();
            param2.x = _loc4_.stageWidth * (param2.x - _loc3_.x) / _loc3_.width;
            param2.y = _loc4_.stageHeight * (param2.y - _loc3_.y) / _loc3_.height;
         }
         return param2;
      }
   }
}


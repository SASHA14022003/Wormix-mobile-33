package §_-hO§
{
   import §_-l1g§.§_-L3Q§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   
   public class §_-h2f§
   {
      
      public static const §_-a1F§:String = "tick";
      
      public static const CLEAR:String = "clear";
      
      public function §_-h2f§()
      {
         super();
      }
   }
}


package §_-hO§
{
   import §_-31N§.§_-Yy§;
   import §_-31W§.§_-r26§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-G1p§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-G2H§.*;
   import §_-P2i§.§_-G3J§;
   import §_-Tm§.§_-RF§;
   import §_-Vu§.*;
   import §_-jF§.*;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-sQ§.§_-H3D§;
   import §_-z1g§.§_-5c§;
   import com.distriqt.extension.inappbilling.Product;
   import com.distriqt.extension.inappbilling.SubscriptionOffer;
   import com.distriqt.extension.inappbilling.SubscriptionPhase;
   import com.distriqt.extension.inappbilling.events.ProductEvent;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import flash.geom.Point;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.utils.§_-F2L§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   
   public class §_-02h§ extends Event
   {
      
      public var §_-225§:uint;
      
      public function §_-02h§(param1:uint)
      {
         super(§_-L3Q§.NEXT_TURN,false,true);
         this.§_-225§ = param1;
      }
      
      public function clone() : Event
      {
         return new §_-02h§(this.§_-225§);
      }
      
      override public function toString() : String
      {
         return "NextTurnEvent: type=" + type + ", bubbles=" + bubbles + ", lastTurn=" + this.§_-225§;
      }
   }
}


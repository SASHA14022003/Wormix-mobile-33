package §_-hO§
{
   import §_-d2p§.*;
   import §_-l1K§.§_-cZ§;
   import §_-l1g§.§_-L3Q§;
   import com.greensock.*;
   import com.greensock.core.*;
   import com.greensock.plugins.*;
   import feathers.core.ITextRenderer;
   import ru.pragmatix.wormix.objects.Direction;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import starling.events.Event;
   
   public class §_-y2Z§ extends Event
   {
      
      public var obj:§_-F3o§;
      
      public var amount:int;
      
      public var §_-AG§:Boolean;
      
      public function §_-y2Z§(param1:§_-F3o§, param2:int, param3:Boolean = false, param4:Boolean = false)
      {
         super(§_-L3Q§.GAME_OBJECT_HP_CHANGE,param4);
         this.obj = param1;
         this.amount = param2;
         this.§_-AG§ = param3;
      }
      
      public function clone() : Event
      {
         return new §_-y2Z§(this.obj,this.amount,this.§_-AG§);
      }
      
      override public function toString() : String
      {
         return "WormHpChangeEvent: type = " + type + ", bubbles = " + bubbles + ", worm = " + this.obj + ", amount = " + this.amount + ", isHeal = " + this.§_-AG§;
      }
   }
}


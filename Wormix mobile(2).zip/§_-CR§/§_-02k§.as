package §_-CR§
{
   import §_-91B§.§_-QK§;
   import §_-eG§.§_-02w§;
   import §_-l1g§.§_-L3Q§;
   import feathers.controls.Callout;
   import feathers.controls.List;
   import feathers.controls.ScrollPolicy;
   import feathers.data.ArrayCollection;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.VerticalLayout;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.desktop.DesktopShopnfoRequirementRenderer;
   
   public class §_-02k§ extends Callout
   {
      
      public function §_-02k§()
      {
         super();
      }
      
      override public function set x(param1:Number) : void
      {
         super.x = Math.floor(param1);
      }
      
      override public function set y(param1:Number) : void
      {
         super.y = Math.floor(param1);
      }
      
      override protected function positionRelativeToOrigin() : void
      {
         if(this._origin.stage)
         {
            super.positionRelativeToOrigin();
         }
      }
   }
}


package §_-CR§
{
   import §_-21p§.§_-4w§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.Cookie;
   import §_-C2t§.*;
   import §_-CF§.§_-x2t§;
   import §_-K35§.§_-S18§;
   import §_-L1H§.§_-b2K§;
   import §_-TF§.§_-y2n§;
   import §_-Tm§.§_-RF§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-u1T§.*;
   import §_-zI§.§_-X1q§;
   import §_-zI§.§_-sI§;
   import com.distriqt.extension.inappbilling.events.ApplicationReceiptEvent;
   import feathers.controls.Callout;
   import feathers.controls.LayoutGroup;
   import feathers.controls.List;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.PopUpManager;
   import feathers.events.FeathersEventType;
   import feathers.layout.Direction;
   import flash.display.StageDisplayState;
   import flash.display.StageOrientation;
   import flash.events.StageOrientationEvent;
   import flash.geom.Point;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.ToggleTeamMemberResult;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-Qi§;
   import ru.pragmatix.wormix.physics.CollideType;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-72p§
   {
      
      private var _disposed:Boolean;
      
      private var §_-Y1§:Callout;
      
      private var _list:List;
      
      private var §_-h2t§:§_-t1R§;
      
      private var §_-H1m§:Function;
      
      private var §_-r29§:Function;
      
      private var §_-H10§:DefaultListItemRenderer;
      
      private var _target:LayoutGroup;
      
      private var _supportedDirections:Vector.<String>;
      
      private var §_-12s§:String;
      
      private var §_-a12§:Boolean;
      
      private var §_-Jq§:§_-S18§;
      
      public function §_-72p§(param1:List, param2:Function, param3:Array, param4:Boolean = true, param5:String = "")
      {
         var _loc6_:String = null;
         super();
         this._list = param1;
         this.§_-a12§ = param4;
         this.§_-h2t§ = §_-d27§.§_-S29§;
         this.§_-H1m§ = param2;
         this.§_-12s§ = param5;
         this._disposed = false;
         this._supportedDirections = new Vector.<String>(0);
         for each(_loc6_ in param3)
         {
            this._supportedDirections.push(_loc6_);
         }
         if(param5)
         {
            this._target = new LayoutGroup();
            this._target.alignPivot();
            this._target.touchable = false;
         }
         this._list.addEventListener(Event.CHANGE,this.§_-31w§);
         this._list.addEventListener(FeathersEventType.RENDERER_ADD,this.§_-f1O§);
         this._list.addEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-u2M§);
         this.§_-Jq§ = new §_-S18§(0);
      }
      
      public function §_-k1§(param1:Array) : void
      {
         this.§_-Jq§.§_-y1y§ = param1;
      }
      
      public function §_-ju§(param1:Boolean) : void
      {
         this.§_-Jq§.§_-x21§ = param1;
      }
      
      public function dispose() : void
      {
         if(!this._disposed)
         {
            this._disposed = true;
            this.§_-d1e§();
            this._list.removeEventListener(Event.CHANGE,this.§_-31w§);
            this._list.removeEventListener(FeathersEventType.RENDERER_ADD,this.§_-f1O§);
            this._list.removeEventListener(FeathersEventType.RENDERER_REMOVE,this.§_-u2M§);
            this._list = null;
            this._target = null;
            this.§_-H10§ = null;
            this.§_-Jq§.dispose();
         }
      }
      
      private function playSound() : void
      {
         if(this.§_-h2t§)
         {
            §_-h2B§.play(this.§_-h2t§);
         }
      }
      
      private function §_-f1O§(param1:Event) : void
      {
         var _loc2_:DefaultListItemRenderer = param1.data as DefaultListItemRenderer;
         _loc2_.addEventListener(Event.TRIGGERED,this.§_-x2L§);
         if(this._target)
         {
            _loc2_.addEventListener(TouchEvent.TOUCH,this.§_-u2s§);
         }
      }
      
      private function §_-u2M§(param1:Event) : void
      {
         var _loc2_:DefaultListItemRenderer = param1.data as DefaultListItemRenderer;
         _loc2_.removeEventListener(Event.TRIGGERED,this.§_-x2L§);
         if(this._target)
         {
            _loc2_.removeEventListener(TouchEvent.TOUCH,this.§_-u2s§);
         }
      }
      
      private function §_-x2L§(param1:Event) : void
      {
         this.§_-H10§ = param1.currentTarget as DefaultListItemRenderer;
      }
      
      private function §_-u2s§(param1:TouchEvent) : void
      {
         var _loc3_:Touch = null;
         var _loc4_:Point = null;
         var _loc2_:FeathersControl = param1.currentTarget as FeathersControl;
         if(_loc2_)
         {
            _loc3_ = param1.getTouch(_loc2_,TouchPhase.BEGAN);
            if(_loc3_)
            {
               _loc2_.addChild(this._target);
               _loc4_ = _loc3_.getLocation(_loc2_);
               if(this.§_-12s§ == Direction.VERTICAL)
               {
                  this._target.height = _loc2_.height;
                  this._target.x = _loc4_.x;
                  this._target.y = 0;
               }
               else if(this.§_-12s§ == Direction.HORIZONTAL)
               {
                  this._target.width = _loc2_.width;
                  this._target.x = 0;
                  this._target.y = _loc4_.y;
               }
               Pool.putPoint(_loc4_);
            }
         }
      }
      
      private function §_-31w§(param1:Event) : void
      {
         var _loc2_:int = 0;
         var _loc3_:int = 0;
         var _loc4_:DisplayObject = null;
         if(this._list.selectedItem)
         {
            if(this.§_-H1m§ == null)
            {
               return;
            }
            _loc2_ = this.§_-H1m§(this._list.selectedItem);
            if(_loc2_ == 0)
            {
               return;
            }
            _loc3_ = this.§_-r29§ != null ? int(this.§_-r29§(this._list.selectedItem)) : 0;
            this.playSound();
            _loc4_ = this._target ? this._target : this.§_-H10§;
            if(_loc4_)
            {
               this.§_-Jq§.profileId = _loc2_;
               this.§_-Jq§.platformId = _loc3_;
               this.§_-Y1§ = §_-S2o§.§_-02T§(this.§_-Jq§,_loc4_,this._supportedDirections,true);
               if(this.§_-Y1§)
               {
                  this.§_-Y1§.addEventListener(Event.REMOVED_FROM_STAGE,this.§_-32i§);
               }
            }
         }
         else
         {
            this.§_-d1e§();
         }
      }
      
      private function §_-32i§(param1:Event) : void
      {
         if(!this._disposed && this.§_-a12§)
         {
            this._list.selectedIndex = -1;
         }
      }
      
      public function §_-d1e§() : void
      {
         if(this.§_-Y1§)
         {
            if(PopUpManager.isPopUp(this.§_-Y1§))
            {
               PopUpManager.removePopUp(this.§_-Y1§);
            }
            this.§_-Y1§ = null;
         }
      }
      
      public function get §_-H2L§() : Function
      {
         return this.§_-r29§;
      }
      
      public function set §_-H2L§(param1:Function) : void
      {
         this.§_-r29§ = param1;
      }
      
      public function addEventListener(param1:String, param2:Function) : void
      {
         this.§_-Jq§.addEventListener(param1,param2);
      }
      
      public function removeEventListener(param1:String, param2:Function) : void
      {
         this.§_-Jq§.removeEventListener(param1,param2);
      }
   }
}


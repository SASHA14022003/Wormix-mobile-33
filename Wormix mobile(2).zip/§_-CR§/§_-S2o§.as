package §_-CR§
{
   import §_-931§.*;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-F1P§;
   import §_-B1y§.§_-bs§;
   import §_-B2z§.§_-63i§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-F2Q§.GestureEvent;
   import §_-F39§.*;
   import §_-U1i§.§_-XA§;
   import §_-l1K§.*;
   import §_-l1g§.§_-L3Q§;
   import §_-r1C§.§_-h2B§;
   import §_-s20§.§_-J2g§;
   import §_-u1T§.*;
   import §_-z1g§.*;
   import §_-z2S§.SafeAreaUtils;
   import com.greensock.TweenLite;
   import com.greensock.easing.Linear;
   import feathers.controls.Callout;
   import feathers.controls.LayoutGroup;
   import feathers.controls.ScreenNavigator;
   import feathers.controls.ScreenNavigatorItem;
   import feathers.core.ITextRenderer;
   import feathers.core.PopUpManager;
   import flash.display.Bitmap;
   import flash.display.BitmapData;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.geom.Rectangle;
   import flash.utils.IDataOutput;
   import flash.utils.clearTimeout;
   import flash.utils.setTimeout;
   import org.gestouch.core.GestureState;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.menu.shop.*;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-WU§;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginError;
   import ru.pragmatix.wormix.pvp.messages.server.BattleLoginErrorType;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.utils.Pool;
   import starling.utils.SystemUtil;
   
   public class §_-S2o§
   {
      
      private static var §_-D2T§:Callout;
      
      private static var §_-F3y§:DisplayObject;
      
      private static var §_-j2y§:DisplayObject;
      
      private static var §_-71x§:DisplayObject;
      
      private static var §_-Y2p§:uint;
      
      private static var §_-I3Q§:Object;
      
      private static var §_-z1y§:DisplayObjectContainer;
      
      private static var §_-r2D§:Rectangle;
      
      private static var §_-M1k§:Boolean = false;
      
      public function §_-S2o§()
      {
         super();
      }
      
      public static function §_-02T§(param1:DisplayObject, param2:DisplayObject, param3:Object = null, param4:Boolean = true, param5:Boolean = false, param6:Rectangle = null) : Callout
      {
         var _loc7_:Rectangle = null;
         if(!param2 || !param2.stage)
         {
            return §_-D2T§;
         }
         if(!§_-M1k§)
         {
            Application.§_-E1k§.addEventListener(starling.events.Event.CHANGE,§_-c1k§);
         }
         if(§_-m2b§(param2) && §_-53s§())
         {
            if(SystemUtil.isDesktop)
            {
               §_-F3y§ = null;
               if(§_-D2T§)
               {
                  §_-D2T§.close(true);
                  §_-D2T§ = null;
               }
            }
         }
         else
         {
            _loc7_ = SafeAreaUtils.§_-C29§();
            Callout.stagePadding = 0;
            Callout.stagePaddingLeft = param6 ? Number(param6.left) : Number(_loc7_.left);
            Callout.stagePaddingRight = param6 ? Number(param6.right) : Number(_loc7_.right);
            if(param3 is Function)
            {
               param3 = param3.call();
            }
            param1.alpha = 0;
            §_-D2T§ = Callout.show(param1,param2,param3,param4,defaultCalloutFactory);
            §_-D2T§.disposeOnSelfClose = true;
            §_-D2T§.disposeContent = param5;
            §_-F3y§ = param2;
            PopUpManager.root = Application.§_-YB§;
            TweenLite.to(param1,0.3,{
               "alpha":1,
               "ease":Linear.easeNone
            });
         }
         return §_-D2T§;
      }
      
      public static function §_-ao§(param1:DisplayObject, param2:DisplayObject, param3:DisplayObjectContainer, param4:Object = null, param5:Boolean = true, param6:Function = null, param7:Function = null) : Callout
      {
         PopUpManager.root = param3;
         var _loc8_:Callout = Callout.show(param1,param2,param4,param5,param6,param7);
         PopUpManager.root = Application.§_-YB§;
         return _loc8_;
      }
      
      private static function §_-c1k§(param1:starling.events.Event) : void
      {
         if(§_-D2T§)
         {
            §_-x6§();
            §_-D2T§ = null;
         }
      }
      
      public static function §_-x6§() : void
      {
         if(§_-D2T§)
         {
            §_-D2T§.close(true);
         }
      }
      
      private static function §_-m2b§(param1:DisplayObject) : Boolean
      {
         return §_-F3y§ == param1;
      }
      
      public static function §_-53s§() : Boolean
      {
         return Boolean(§_-D2T§) && §_-D2T§.parent != null;
      }
      
      public static function §_-B1D§(param1:DisplayObject) : void
      {
         if(Boolean(param1) && Boolean(§_-D2T§) && §_-D2T§.origin == param1)
         {
            §_-D2T§.close();
         }
      }
      
      private static function defaultCalloutFactory() : Callout
      {
         var _loc1_:Callout = new §_-02k§();
         _loc1_.closeOnTouchBeganOutside = true;
         return _loc1_;
      }
      
      public static function §_-v2I§(param1:DisplayObject, param2:DisplayObject, param3:Object, param4:DisplayObjectContainer = null, param5:Rectangle = null) : void
      {
         if(!§_-m2b§(param2) || !§_-53s§())
         {
            §_-o2L§();
            §_-j2y§ = param1;
            §_-71x§ = param2;
            §_-Y2p§ = setTimeout(§_-L2r§,300);
            §_-I3Q§ = param3;
            §_-z1y§ = param4;
            §_-r2D§ = param5;
         }
      }
      
      public static function §_-o2L§() : void
      {
         clearTimeout(§_-Y2p§);
         §_-x6§();
      }
      
      private static function §_-L2r§() : void
      {
         var _loc1_:Callout = null;
         §_-x6§();
         if(!§_-j2y§)
         {
            return;
         }
         §_-j2y§.touchable = false;
         if(§_-z1y§)
         {
            _loc1_ = §_-ao§(§_-j2y§,§_-71x§,§_-z1y§,§_-I3Q§,false);
            _loc1_.disposeContent = true;
         }
         else
         {
            §_-02T§(§_-j2y§,§_-71x§,§_-I3Q§,false,true);
         }
         §_-h2B§.play(§_-d27§.§_-k2x§);
      }
      
      public static function §_-uc§(param1:DisplayObject) : Boolean
      {
         return !§_-D2T§ || §_-D2T§.origin != param1;
      }
   }
}


package §_-416§
{
   import §_-12W§.*;
   import §_-62§.§_-L1r§;
   import §_-A1K§.§_-TA§;
   import §_-L1H§.§_-b2K§;
   import §_-Tm§.§_-RF§;
   import §_-Vg§.*;
   import §_-fo§.AbstractConfigLoader;
   import §_-fo§.§_-v2P§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-Oi§;
   import §_-k2s§.§_-e1U§;
   import §_-l1g§.§_-L3Q§;
   import §_-x2Q§.§_-dU§;
   import com.hurlant.util.§_-a2P§;
   import feathers.data.IListCollection;
   import feathers.layout.HorizontalLayout;
   import flash.system.LoaderContext;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.messages.client.PostToChat;
   import ru.pragmatix.wormix.messages.structures.WeaponStructure;
   import ru.pragmatix.wormix.utils.§_-2t§;
   import starling.events.Event;
   import starling.utils.Pool;
   
   public class §_-YS§ extends AbstractConfigLoader
   {
      
      private static const _log:§_-11S§ = new §_-11S§(§_-YS§);
      
      private var §_-b1o§:Array = [];
      
      public function §_-YS§(param1:String, param2:String, param3:Vector.<String>, param4:LoaderContext)
      {
         super(param1,param2,param3,§_-v2P§.XML,param4);
      }
      
      override protected function §_-v1c§(param1:XML, param2:String) : void
      {
         var xmlList:XMLList = null;
         var sortLengthWord:Function = null;
         var xml:XML = param1;
         var path:String = param2;
         sortLengthWord = function(param1:String, param2:String):Number
         {
            if(param1.length > param2.length)
            {
               return -1;
            }
            if(param1.length < param2.length)
            {
               return 1;
            }
            return 0;
         };
         xmlList = xml.*;
         var i:uint = 0;
         while(i < xmlList.length())
         {
            this.§_-b1o§.push(xmlList[i][0].toString());
            i++;
         }
         this.§_-b1o§.sort(sortLengthWord);
      }
      
      public function §_-gO§(param1:String) : String
      {
         var _loc5_:String = null;
         var _loc6_:int = 0;
         var _loc7_:uint = 0;
         var _loc8_:RegExp = null;
         var _loc9_:int = 0;
         var _loc10_:uint = 0;
         var _loc11_:String = null;
         var _loc12_:String = null;
         var _loc13_:String = null;
         var _loc2_:String = "";
         var _loc3_:Array = param1.split(" ");
         var _loc4_:Array = [];
         for each(_loc5_ in this.§_-b1o§)
         {
            _loc8_ = new RegExp(_loc5_,"igx");
            _loc9_ = int(_loc3_.length);
            _loc10_ = 0;
            while(_loc10_ < _loc9_)
            {
               _loc11_ = _loc3_[_loc10_].toLowerCase();
               _loc12_ = _loc11_.replace(_loc8_,"***");
               _loc4_[_loc10_] = _loc12_;
               if(_loc12_ != _loc11_)
               {
                  _loc3_[_loc10_] = _loc12_;
               }
               _loc10_++;
            }
         }
         _loc6_ = int(_loc4_.length);
         _loc7_ = 0;
         while(_loc7_ < _loc6_)
         {
            _loc13_ = _loc3_[_loc7_];
            if(_loc13_.toLowerCase() == _loc13_)
            {
               _loc4_.splice(_loc7_,1,_loc13_);
            }
            _loc2_ += _loc13_ + (_loc7_ < _loc6_ - 1 ? " " : "");
            _loc7_++;
         }
         return _loc2_;
      }
      
      override protected function get log() : §_-11S§
      {
         return _log;
      }
   }
}


package §_-F39§
{
   import §_-B1y§.§_-bs§;
   import §_-H2g§.§_-di§;
   import §_-L1H§.§_-C3e§;
   import §_-L1H§.§_-b2K§;
   import §_-YF§.§_-q2v§;
   import §_-j22§.§_-5g§;
   import §_-l1g§.§_-L3Q§;
   import §_-l2r§.§_-K1t§;
   import §_-w2i§.§_-52k§;
   import dragonBones.animation.WorldClock;
   import flash.utils.ByteArray;
   import flash.utils.IDataOutput;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.system.ControlSystems;
   import ru.pragmatix.wormix.messages.server.WipeProfileResult;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.scene.SortingLayer;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.ammo.type.grenade.cluster.ShellBurst;
   import starling.core.Starling;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-43a§ extends EventDispatcher
   {
      
      private var arrow:§_-di§;
      
      public function §_-43a§()
      {
         super();
      }
      
      public function showArrowOnUnit(param1:§_-01J§) : void
      {
         this.§_-g15§();
         if(param1 == null)
         {
            return;
         }
         var _loc2_:Boolean = !param1.squad.isLocal();
         this.arrow = §_-K1t§.buildArmature(§_-q2v§.§_-Z2K§[param1.squad.getNumber()]);
         this.arrow.display.x = param1.x;
         this.arrow.display.y = param1.y - 70;
         WorldClock.clock.add(this.arrow);
         §_-X1j§.§_-12n§.scene.addElementToCertainSortingLayer(this.arrow.display,SortingLayer.POINTERS_LAYER);
         this.arrow.playAnimation(§_-K1t§.§_-Y1c§,0,-1,0);
         var _loc3_:Function = §_-bs§.§_-d1Z§(this.§_-g15§,this);
         var _loc4_:Object = {};
         if(_loc2_)
         {
            Starling.juggler.delayCall(_loc3_,4);
            _loc4_[§_-L3Q§.DISPOSED] = {
               "disp":param1,
               "fn":_loc3_
            };
         }
         else
         {
            _loc4_[§_-L3Q§.NEXT_TURN] = {
               "disp":this,
               "fn":_loc3_
            };
            _loc4_[§_-L3Q§.DISPOSED] = {
               "disp":param1,
               "fn":_loc3_
            };
            _loc4_[§_-L3Q§.COMMAND_CONTROL_CHANGED] = {
               "disp":ControlSystems.instance,
               "fn":_loc3_
            };
         }
         §_-52k§.§_-xC§(_loc4_);
      }
      
      private function §_-g15§(param1:Event = null) : void
      {
         if(this.arrow)
         {
            §_-X1j§.§_-12n§.scene.removeElement(this.arrow.display);
            WorldClock.clock.remove(this.arrow);
            this.arrow.dispose();
            this.arrow = null;
         }
      }
      
      public function dispose() : void
      {
         this.§_-g15§();
      }
   }
}


package §_-F39§
{
   import §_-62§.§_-O2H§;
   import §_-73I§.§_-q15§;
   import §_-73d§.§_-V19§;
   import §_-9e§.§_-73e§;
   import §_-9e§.§_-8O§;
   import §_-9e§.§_-A18§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C3f§.§_-4I§;
   import §_-CF§.§_-x2t§;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-H2g§.§_-di§;
   import §_-HD§.*;
   import §_-K35§.§_-S18§;
   import §_-K35§.§_-gY§;
   import §_-Nq§.*;
   import §_-TF§.§_-F1B§;
   import §_-TF§.§_-b2c§;
   import §_-TF§.§_-q1j§;
   import §_-W§.§_-z2Q§;
   import §_-Y1O§.*;
   import §_-b1F§.§_-G4§;
   import §_-hO§.§_-y2Z§;
   import §_-j1y§.§_-i1b§;
   import §_-l1K§.§_-N1Z§;
   import §_-l1K§.§_-W2f§;
   import §_-l1g§.§_-L3Q§;
   import §_-l1g§.§_-T2N§;
   import §_-l2r§.§_-K1t§;
   import §_-rM§.§_-61j§;
   import §_-v2t§.§_-73F§;
   import §_-x2Q§.§_-dU§;
   import com.greensock.loading.core.*;
   import dragonBones.animation.WorldClock;
   import feathers.controls.LayoutGroup;
   import feathers.controls.NumericStepper;
   import feathers.core.ITextRenderer;
   import feathers.layout.AnchorLayoutData;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.HorizontalLayout;
   import feathers.layout.HorizontalLayoutData;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import flash.errors.IllegalOperationError;
   import flash.geom.Rectangle;
   import flash.text.TextFormatAlign;
   import flash.utils.IDataInput;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-D8§;
   import ru.pragmatix.wormix.controller.§_-W2C§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-s1V§;
   import ru.pragmatix.wormix.messages.clans.response.TopClansResponse;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.server.AwardGrantedMessage;
   import ru.pragmatix.wormix.messages.structures.GenericAwardStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.physics.Force;
   import ru.pragmatix.wormix.physics.HitTest;
   import ru.pragmatix.wormix.serialization.server.*;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.DamageType;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.interfaces.§_-y2Q§;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Quad;
   import starling.display.Sprite;
   import starling.events.Event;
   import starling.utils.Color;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   import starlingbuilder.extensions.uicomponents.CustomLabel;
   
   public class §_-D14§ extends §_-E2w§ implements §_-b2c§
   {
      
      private static const ARMATURE_NAME:String = "ArrowWhosTurnAnimation";
      
      private static const §_-ji§:Array = ["green","red","yellow","blue"];
      
      private var avatar:§_-gY§;
      
      private var lifeBar:§_-GP§;
      
      private var group:ITextRenderer;
      
      private var §_-QL§:DisplayObject;
      
      private var arrow:§_-di§;
      
      private var team:§_-V23§;
      
      private var §_-Vt§:uint;
      
      private var §_-h2h§:uint;
      
      private var §_-K2B§:EmojiShower;
      
      private var §_-mi§:Boolean = false;
      
      private var hint:§_-S18§;
      
      public var index:int;
      
      public function §_-D14§(param1:DisplayObjectContainer, param2:int, param3:Boolean, param4:int, param5:Sprite)
      {
         super(param1);
         this.index = param2;
         this.§_-b1d§(param2);
         var _loc6_:DisplayObjectContainer = getChildByName("lifeBar") as DisplayObjectContainer;
         this.§_-819§(_loc6_,param2);
         this.lifeBar = new §_-GP§(_loc6_,getChildByName("text") as ITextRenderer,null,false,1,param3);
         this.§_-Vt§ = this.lifeBar.width;
         this.group = getChildByName("group") as ITextRenderer;
         this.§_-QL§ = getChildByName("arrow");
         this.§_-QL§.visible = false;
         this.setActive(false);
         this.§_-K2B§ = new EmojiShower(this.avatar.getContainer(),param5,param3,param4 == 0);
         §_-X1j§.§_-12n§.scene.addEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         §_-q1j§.register(this,§_-F1B§.§_-e25§);
      }
      
      private function §_-b1d§(param1:int) : void
      {
         var _loc3_:Sprite = null;
         var _loc4_:DisplayObjectContainer = null;
         this.avatar = new §_-gY§(§_-j2l§().getChildByName("avatar") as DisplayObjectContainer,false);
         var _loc2_:DisplayObject = this.avatar.getContainer();
         _loc2_.touchable = true;
         if(Boolean(§_-X1j§.§_-12n§.scene) && Boolean(§_-X1j§.§_-12n§.scene.gameInterface))
         {
            _loc3_ = new Sprite();
            _loc4_ = §_-X1j§.§_-12n§.scene.gameInterface.§_-j2l§();
            _loc4_.addChildAt(_loc3_,2);
         }
      }
      
      private function §_-AR§(param1:DisplayObject) : §_-di§
      {
         var _loc2_:§_-di§ = null;
         _loc2_ = §_-K1t§.buildArmature(ARMATURE_NAME);
         _loc2_.display.x = param1.x;
         _loc2_.display.y = param1.y;
         _loc2_.display.rotation = param1.rotation;
         param1.parent.addChild(_loc2_.display);
         WorldClock.clock.add(_loc2_);
         _loc2_.playAnimation(§_-K1t§.§_-Y1c§,0,-1,0);
         return _loc2_;
      }
      
      private function §_-819§(param1:DisplayObjectContainer, param2:int) : void
      {
         var _loc4_:DisplayObject = null;
         var _loc3_:* = param1.numChildren;
         while(_loc3_--)
         {
            _loc4_ = param1.getChildAt(_loc3_);
            _loc4_.visible = _loc4_.name == "color" + §_-ji§[param2];
         }
      }
      
      public function §_-fR§(param1:§_-V23§) : void
      {
         var _loc3_:§_-01J§ = null;
         this.team = param1;
         this.§_-o2C§();
         var _loc2_:uint = param1.§_-r2g§();
         this.lifeBar.§_-E2N§(_loc2_);
         this.lifeBar.setValue(_loc2_);
         for each(_loc3_ in param1.getUnits())
         {
            _loc3_.addEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
         }
         this.§_-h2h§ = param1.§_-Z2G§();
         this.group.text = this.§_-h2h§ + "/" + this.§_-h2h§;
      }
      
      private function §_-Y1K§(param1:§_-y2Z§) : void
      {
         if(param1.obj is §_-01J§ && §_-01J§(param1.obj).hp <= 0)
         {
            param1.obj.removeEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
         }
         this.update();
      }
      
      private function §_-o2C§() : void
      {
         var _loc2_:§_-01J§ = null;
         var _loc3_:§_-01J§ = null;
         var _loc1_:UserProfile = this.team.getOwnerProfile();
         for each(_loc3_ in this.team.getUnits(true))
         {
            if(_loc3_.record.equals(_loc1_) && _loc3_.record.getCharName() == _loc1_.getCharName())
            {
               _loc2_ = _loc3_;
               break;
            }
         }
         this.avatar.§_-82v§(_loc1_,_loc3_);
         this.hint = new §_-S18§(_loc1_.getId(),_loc1_);
      }
      
      public function update() : void
      {
         var _loc3_:§_-01J§ = null;
         var _loc1_:uint = 0;
         var _loc2_:uint = 0;
         for each(_loc3_ in this.team.getUnits())
         {
            if(_loc3_.hp <= 0)
            {
               _loc3_.removeEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
            }
            else
            {
               _loc1_++;
               _loc2_ += _loc3_.hp;
            }
         }
         this.group.text = _loc1_ + "/" + this.§_-h2h§;
         this.lifeBar.setValue(_loc2_);
      }
      
      public function setActive(param1:Boolean) : void
      {
         if(param1)
         {
            if(!this.arrow)
            {
               this.arrow = this.§_-AR§(this.§_-QL§);
            }
            else
            {
               this.arrow.display.visible = true;
            }
         }
         else if(Boolean(this.arrow) && Boolean(this.arrow.display))
         {
            this.arrow.display.visible = false;
         }
      }
      
      public function §_-C2k§(param1:String) : void
      {
         var _loc2_:§_-D8§ = §_-X1j§.§_-12n§;
         if(Boolean(!this.§_-mi§ && _loc2_ && _loc2_.scene) && Boolean(_loc2_.scene.gameInterface) && _loc2_.scene.gameInterface.isVisible())
         {
            this.§_-K2B§.§_-C2k§(param1);
         }
      }
      
      override public function §_-c1v§(param1:Boolean) : void
      {
         var _loc2_:Boolean = §_-q1j§.§_-VJ§(this);
         if(param1 && !_loc2_)
         {
            §_-q1j§.register(this,§_-F1B§.§_-e25§);
         }
         else if(!param1 && _loc2_)
         {
            §_-q1j§.remove(this);
         }
         super.§_-c1v§(param1);
         this.§_-K2B§.§_-c1v§(param1);
      }
      
      private function §_-z29§() : void
      {
         if(this.arrow)
         {
            this.arrow.display.removeFromParent();
            WorldClock.clock.remove(this.arrow);
            this.arrow.dispose();
            this.arrow = null;
         }
      }
      
      public function §_-A1U§() : §_-V23§
      {
         return this.team;
      }
      
      public function getOrigin() : DisplayObject
      {
         if(this.avatar)
         {
            return this.avatar.getContainer();
         }
         return null;
      }
      
      public function §_-8I§() : DisplayObject
      {
         var _loc1_:UserProfile = this.team.getOwnerProfile();
         this.hint.userProfile = _loc1_;
         return this.hint;
      }
      
      public function §_-52e§() : Object
      {
         return new <String>[RelativePosition.BOTTOM];
      }
      
      public function getHintAreaPaddings() : Rectangle
      {
         var _loc1_:LayoutGroup = container.parent.parent as LayoutGroup;
         _loc1_.parent;
         _loc1_.name;
         var _loc2_:AnchorLayoutData = _loc1_.layoutData as AnchorLayoutData;
         return new Rectangle(((this.index % 2 == 0 ? _loc2_.left : _loc2_.right) || 0) + this.avatar.width,0,0,0);
      }
      
      override public function dispose() : void
      {
         var _loc1_:§_-01J§ = null;
         §_-X1j§.§_-12n§.scene.removeEventListener(§_-L3Q§.NEW_UNIT_ADDED,this.§_-fZ§);
         if(this.avatar)
         {
            this.avatar.dispose();
            this.avatar = null;
         }
         §_-q1j§.remove(this);
         if(this.hint)
         {
            this.hint.dispose();
            this.hint = null;
         }
         for each(_loc1_ in this.team.getUnits())
         {
            _loc1_.removeEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
         }
         this.team = null;
         this.§_-z29§();
         if(this.lifeBar)
         {
            this.lifeBar.dispose();
            this.lifeBar = null;
         }
         if(this.group)
         {
            this.group.dispose();
            this.group = null;
         }
         this.§_-QL§ = null;
         this.§_-K2B§.dispose();
         super.dispose();
      }
      
      private function §_-fZ§(param1:Event) : void
      {
         var _loc2_:§_-01J§ = param1.data as §_-01J§;
         if(_loc2_)
         {
            if(_loc2_.squad == this.§_-A1U§())
            {
               _loc2_.addEventListener(§_-L3Q§.GAME_OBJECT_HP_CHANGE,this.§_-Y1K§);
            }
            this.update();
         }
      }
      
      public function get §_-k21§() : Boolean
      {
         return this.§_-mi§;
      }
      
      public function set §_-k21§(param1:Boolean) : void
      {
         this.§_-mi§ = param1;
      }
   }
}


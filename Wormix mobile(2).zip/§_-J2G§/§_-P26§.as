package §_-J2G§
{
   import feathers.core.DefaultPopUpManager;
   import feathers.core.IPopUpManager;
   import starling.display.DisplayObjectContainer;
   
   public class §_-P26§ extends DefaultPopUpManager
   {
      
      public function §_-P26§()
      {
         super();
      }
      
      public static function factory() : IPopUpManager
      {
         return new §_-P26§();
      }
      
      override public function set root(param1:DisplayObjectContainer) : void
      {
         if(this._root == param1)
         {
            return;
         }
         this._root = param1;
      }
   }
}


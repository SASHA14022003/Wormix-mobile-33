package §_-J2G§
{
   import §_-DJ§.§_-fH§;
   import §_-G2H§.*;
   import §_-Y1Q§.§_-61Z§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.inappbilling.Purchase;
   import flash.net.SharedObject;
   import flash.text.TextField;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import starling.display.DisplayObject;
   import starling.display.Sprite;
   import starling.events.Event;
   
   public class §_-og§ extends Sprite
   {
      
      public function §_-og§()
      {
         super();
      }
      
      override public function addChildAt(param1:DisplayObject, param2:int) : DisplayObject
      {
         var _loc3_:DisplayObject = super.addChildAt(param1,param2);
         sortChildren(this.§_-83h§);
         return _loc3_;
      }
      
      private function §_-83h§(param1:DisplayObject, param2:DisplayObject) : int
      {
         var _loc3_:Boolean = param1 is §_-fH§;
         var _loc4_:Boolean = param2 is §_-fH§;
         if(_loc3_ || _loc4_)
         {
            if(_loc3_ && _loc4_)
            {
               return 0;
            }
            if(_loc3_)
            {
               return 1;
            }
            return -1;
         }
         return 0;
      }
   }
}


package §_-E3c§
{
   import §_-51W§.§_-SN§;
   import §_-5Y§.§_-h2c§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-B1y§.*;
   import §_-C3f§.*;
   import §_-H16§.*;
   import §_-Om§.*;
   import §_-Vg§.*;
   import §_-Y1b§.*;
   import §_-YF§.§_-q2v§;
   import §_-ZB§.§_-A10§;
   import §_-eW§.§_-S21§;
   import §_-eW§.§_-V2n§;
   import §_-eW§.§_-g2b§;
   import §_-j22§.§_-5g§;
   import §_-k1u§.§_-Oi§;
   import §_-rM§.§_-61j§;
   import config.§_-V2w§;
   import feathers.controls.LayoutGroup;
   import feathers.core.ITextRenderer;
   import feathers.data.ListCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.VerticalAlign;
   import feathers.layout.VerticalLayout;
   import flash.events.IOErrorEvent;
   import flash.events.TimerEvent;
   import flash.geom.Rectangle;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.clearTimeout;
   import org.swiftsuspenders.Injector;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.ISocialController;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.wormix.controller.§_-I2Y§;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controller.§_-Xh§;
   import ru.pragmatix.wormix.fonts.BitmapFonts;
   import ru.pragmatix.wormix.gui.§_-E2w§;
   import ru.pragmatix.wormix.gui.menu.§_-3m§;
   import ru.pragmatix.wormix.messages.clans.request.PostToClanChatRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanMemberTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.client.BuyShopItems;
   import ru.pragmatix.wormix.messages.client.CheatDetected;
   import ru.pragmatix.wormix.messages.server.Pong;
   import ru.pragmatix.wormix.messages.structures.ShopItemStructure;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.serialization.*;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.utils.*;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.KeyboardEvent;
   import starling.utils.Pool;
   import starling.utils.RectangleUtil;
   import starling.utils.ScaleMode;
   
   public class §_-8W§ extends §_-E2w§
   {
      
      private var items:Vector.<§_-g1Y§> = new Vector.<§_-g1Y§>(0);
      
      private var §_-1s§:§_-g1Y§;
      
      private var §_-P1A§:§_-g1Y§;
      
      public function §_-8W§(param1:DisplayObject)
      {
         super(param1);
         this.§_-q2a§();
      }
      
      override protected function §_-q2a§() : void
      {
         var _loc2_:DisplayObjectContainer = null;
         var _loc3_:§_-g1Y§ = null;
         if(this.items.length > 0)
         {
            return;
         }
         super.§_-q2a§();
         var _loc1_:int = 0;
         while(_loc1_ < 3)
         {
            _loc2_ = §_-j2l§().getChildAt(_loc1_) as DisplayObjectContainer;
            _loc3_ = new §_-g1Y§(_loc2_,_loc1_);
            this.items.push(_loc3_);
            _loc1_++;
         }
         this.§_-1s§ = this.items[§_-SN§.§_-21i§.id];
         this.§_-P1A§ = this.items[§_-SN§.§_-X1D§.id];
      }
      
      public function §_-r2J§() : void
      {
         var _loc1_:§_-g1Y§ = null;
         for each(_loc1_ in this.items)
         {
            _loc1_.§_-r2J§();
         }
      }
      
      override public function dispose() : void
      {
         var _loc1_:§_-g1Y§ = null;
         super.dispose();
         for each(_loc1_ in this.items)
         {
            _loc1_.dispose();
         }
      }
      
      public function update() : void
      {
         var _loc2_:§_-g1Y§ = null;
         var _loc3_:§_-SN§ = null;
         var _loc4_:int = 0;
         if(!this.items.length)
         {
            return;
         }
         var _loc1_:int = 0;
         while(_loc1_ < this.items.length)
         {
            _loc2_ = this.items[_loc1_];
            _loc3_ = §_-SN§.§_-Y1M§(_loc1_);
            _loc4_ = §_-Xh§.§_-418§(_loc3_);
            _loc2_.§_-j1K§(_loc4_);
            _loc1_++;
         }
         if(!this.§_-1s§.isVisible() && Boolean(this.§_-1s§.getContainer().parent))
         {
            §_-k6§(this.§_-1s§.getContainer());
         }
         else if(this.§_-1s§.isVisible() && !this.§_-1s§.getContainer().parent)
         {
            §_-13K§(this.§_-1s§.getContainer(),1);
         }
      }
   }
}


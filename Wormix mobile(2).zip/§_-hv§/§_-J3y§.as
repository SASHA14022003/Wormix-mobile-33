package §_-hv§
{
   import §_-12W§.*;
   import §_-21p§.§_-4w§;
   import §_-52V§.§_-031§;
   import §_-52V§.§_-Xq§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-zF§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-C2t§.§_-C1i§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-E1I§.§_-b2n§;
   import §_-F2Q§.GestureEvent;
   import §_-G2H§.*;
   import §_-P2i§.§_-G3J§;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-Y1O§.§_-yA§;
   import §_-Y1Q§.§_-61Z§;
   import §_-YF§.§_-q2v§;
   import §_-Z1K§.§_-q24§;
   import §_-jF§.*;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-F3H§;
   import §_-k1u§.§_-Oi§;
   import §_-k1u§.§_-Vr§;
   import §_-l1g§.§_-L3Q§;
   import §_-n1w§.*;
   import §_-q2b§.§_-S2L§;
   import §_-zI§.§_-X1q§;
   import com.distriqt.extension.inappbilling.Purchase;
   import feathers.controls.ImageLoader;
   import feathers.controls.List;
   import feathers.controls.TabBar;
   import feathers.controls.renderers.DefaultListItemRenderer;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.layout.Direction;
   import flash.events.Event;
   import flash.events.IEventDispatcher;
   import flash.geom.Point;
   import flash.net.SharedObject;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.getQualifiedClassName;
   import org.gestouch.core.Touch;
   import ru.pragmatix.flox.logger.§_-93v§;
   import ru.pragmatix.flox.social.controller.SocialType;
   import ru.pragmatix.flox.social.utils.id.IPlatformAccountController;
   import ru.pragmatix.flox.social.utils.storage.StorageType;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.Command;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.clans.chat.§_-D2t§;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.utils.Result;
   import ru.pragmatix.wormix.model.§_-kQ§;
   import ru.pragmatix.wormix.model.items.craft.*;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.CollideType;
   import ru.pragmatix.wormix.utils.§_-Cq§;
   import ru.pragmatix.wormix.utils.§_-YQ§;
   import ru.pragmatix.wormix.weapons.Weapon;
   import ru.pragmatix.wormix.weapons.interfaces.§_-O1c§;
   import starling.animation.Tween;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.Touch;
   import starling.events.TouchEvent;
   import starling.events.TouchPhase;
   import starling.utils.Pool;
   
   public class §_-J3y§ extends §_-x2W§ implements §_-Xq§
   {
      
      protected var §_-G2c§:Array;
      
      protected var §_-L2d§:Dictionary;
      
      protected var §_-U2C§:Dictionary;
      
      public function §_-J3y§(param1:DisplayObjectContainer, param2:§_-031§)
      {
         super(param1,param2);
         this.§_-G2c§ = new Array();
         this.§_-L2d§ = new Dictionary(false);
         this.§_-U2C§ = new Dictionary(true);
      }
      
      public function §_-s2F§(param1:String) : void
      {
         if(this.§_-G2c§.indexOf(param1) == -1)
         {
            this.§_-G2c§.push(param1);
            ++§_-Q1P§;
            if(§_-Q1P§ == 1)
            {
               this.§_-93D§();
            }
         }
      }
      
      public function §_-Q1d§(param1:String) : void
      {
         var _loc2_:int = int(this.§_-G2c§.indexOf(param1));
         if(_loc2_ > -1)
         {
            this.§_-G2c§.splice(_loc2_,1);
            --§_-Q1P§;
            if(§_-Q1P§ == 0)
            {
               this.§_-Oo§();
            }
         }
      }
      
      public function §_-K10§(param1:Class) : void
      {
         if(this.§_-L2d§[param1])
         {
            return;
         }
         this.§_-L2d§[param1] = param1;
         ++§_-Q1P§;
         if(§_-Q1P§ == 1)
         {
            this.§_-93D§();
         }
         if(Boolean(§_-v2Z§) && §_-v2Z§ is param1)
         {
            this.§_-61p§(§_-v2Z§);
         }
      }
      
      public function §_-61D§(param1:Class) : void
      {
         var _loc2_:Class = this.§_-L2d§[param1];
         delete this.§_-L2d§[param1];
         if(_loc2_)
         {
            --§_-Q1P§;
            if(§_-Q1P§ == 0)
            {
               this.§_-Oo§();
            }
         }
      }
      
      public function §_-34§(param1:Class) : Boolean
      {
         return this.§_-L2d§[param1] != null;
      }
      
      public function §_-q1u§(param1:String) : Boolean
      {
         return this.§_-G2c§.indexOf(param1) > -1;
      }
      
      override protected function §_-93D§() : void
      {
         if(Boolean(§_-v2Z§) && enabled)
         {
            §_-v2Z§.addEventListener(starling.events.Event.ADDED_TO_STAGE,this.§_-h27§);
         }
      }
      
      override protected function §_-Oo§() : void
      {
         if(§_-v2Z§)
         {
            §_-v2Z§.removeEventListener(starling.events.Event.ADDED_TO_STAGE,this.§_-h27§);
         }
      }
      
      override protected function §_-h27§(param1:starling.events.Event) : void
      {
         var _loc3_:Class = null;
         var _loc4_:int = 0;
         var _loc5_:String = null;
         var _loc6_:int = 0;
         var _loc7_:String = null;
         var _loc2_:DisplayObject = DisplayObject(param1.target);
         if(this.§_-U2C§[_loc2_])
         {
            return;
         }
         for each(_loc3_ in this.§_-L2d§)
         {
            if(_loc2_ is _loc3_)
            {
               this.§_-61p§(_loc2_);
               return;
            }
         }
         _loc4_ = int(this.§_-G2c§.length);
         if(_loc4_ > 0)
         {
            _loc5_ = getQualifiedClassName(_loc2_);
            _loc6_ = 0;
            while(_loc6_ < _loc4_)
            {
               _loc7_ = this.§_-G2c§[_loc6_];
               if(_loc5_.indexOf(_loc7_) == 0)
               {
                  this.§_-61p§(_loc2_);
                  return;
               }
               _loc6_++;
            }
         }
      }
      
      protected function §_-61p§(param1:DisplayObject) : void
      {
         injector.§_-61p§(param1);
         this.§_-U2C§[param1] = true;
      }
   }
}


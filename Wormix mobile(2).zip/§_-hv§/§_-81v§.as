package §_-hv§
{
   import §_-62§.§_-G1p§;
   import §_-B1y§.§_-83E§;
   import §_-Y23§.*;
   import flash.errors.IllegalOperationError;
   import flash.events.IEventDispatcher;
   
   public class §_-81v§
   {
      
      public static const §_-x24§:String = "startup";
      
      public static const §_-Kh§:String = "startupComplete";
      
      public static const §_-i1e§:String = "shutdown";
      
      public static const §_-o2A§:String = "shutdownComplete";
      
      public function §_-81v§()
      {
         super();
      }
   }
}


package §_-hv§
{
   import §_-52V§.§_-031§;
   import §_-52V§.§_-71f§;
   import §_-52V§.§_-b2z§;
   import §_-5Y§.§_-h2c§;
   import §_-62§.§_-F1D§;
   import §_-62§.§_-G1p§;
   import §_-73d§.§_-pT§;
   import §_-82a§.SwitchedRenderTextures;
   import §_-82a§.§_-yb§;
   import §_-82l§.§_-A2Y§;
   import §_-931§.§_-sz§;
   import §_-A1K§.§_-6L§;
   import §_-A1K§.§_-U11§;
   import §_-DJ§.§_-J2l§;
   import §_-G16§.*;
   import §_-L1H§.§_-C3e§;
   import §_-T1t§.§_-u19§;
   import §_-U1i§.§_-81M§;
   import §_-dS§.§_-D3a§;
   import §_-e1e§.§_-CG§;
   import §_-j22§.§_-5g§;
   import §_-l1K§.§_-W2f§;
   import §_-l1K§.§_-vO§;
   import §_-m2s§.*;
   import §_-qH§.§_-S25§;
   import §_-r1C§.§_-V1R§;
   import §_-r1C§.§_-t1R§;
   import §_-rM§.§_-61j§;
   import §_-s1Q§.Artifacts;
   import §_-s20§.§_-J2g§;
   import §_-u13§.MD5;
   import §_-u13§.SHA1;
   import §_-u2J§.§_-T1K§;
   import §_-z20§.*;
   import com.hurlant.crypto.tls.§_-F16§;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import flash.media.SoundTransform;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.describeType;
   import flash.utils.getDefinitionByName;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.social.controller.SocialApiSettings;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.controls.sets.ControlSets;
   import ru.pragmatix.wormix.messages.clans.structures.ClanChatMessageTO;
   import ru.pragmatix.wormix.messages.clans.structures.ClanNewsTO;
   import ru.pragmatix.wormix.messages.client.Login;
   import ru.pragmatix.wormix.messages.client.PostToChat;
   import ru.pragmatix.wormix.messages.structures.ChatMessage;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.model.user.§_-33r§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.pvp.messages.ex.CallToBattle;
   import ru.pragmatix.wormix.serialization.client.*;
   import ru.pragmatix.wormix.weapons.§_-7o§;
   import ru.pragmatix.wormix.weapons.ammo.Ufo;
   import ru.pragmatix.wormix.weapons.render.IRenderer;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   
   public class §_-m1z§ implements §_-71f§
   {
      
      protected var eventDispatcher:EventDispatcher;
      
      protected var injector:§_-031§;
      
      protected var §_-o1i§:§_-b2z§;
      
      protected var §_-v2v§:Dictionary;
      
      protected var §_-c2G§:Dictionary;
      
      protected var §_-n1C§:Dictionary;
      
      public function §_-m1z§(param1:EventDispatcher, param2:§_-031§, param3:§_-b2z§)
      {
         super();
         this.eventDispatcher = param1;
         this.injector = param2;
         this.§_-o1i§ = param3;
         this.§_-v2v§ = new Dictionary(false);
         this.§_-c2G§ = new Dictionary(false);
         this.§_-n1C§ = new Dictionary(false);
      }
      
      public function §_-f2X§(param1:String, param2:Class, param3:Class = null, param4:Boolean = false) : void
      {
         var eventClassMap:Dictionary;
         var callbacksByCommandClass:Dictionary;
         var callback:Function;
         var eventType:String = param1;
         var commandClass:Class = param2;
         var eventClass:Class = param3;
         var oneshot:Boolean = param4;
         this.§_-g1s§(commandClass);
         eventClass ||= Event;
         eventClassMap = this.§_-v2v§[eventType];
         if(!eventClassMap)
         {
            eventClassMap = new Dictionary(false);
            this.§_-v2v§[eventType] = eventClassMap;
         }
         callbacksByCommandClass = eventClassMap[eventClass];
         if(!callbacksByCommandClass)
         {
            callbacksByCommandClass = new Dictionary(false);
            eventClassMap[eventClass] = callbacksByCommandClass;
         }
         if(callbacksByCommandClass[commandClass] != null)
         {
            throw new §_-E3a§(§_-E3a§.§_-F34§ + " - eventType (" + eventType + ") and Command (" + commandClass + ")");
         }
         callback = function(param1:Event):void
         {
            routeEventToCommand(param1,commandClass,oneshot,eventClass);
         };
         this.eventDispatcher.addEventListener(eventType,callback);
         callbacksByCommandClass[commandClass] = callback;
      }
      
      public function §_-9P§(param1:String, param2:Class, param3:Class = null) : void
      {
         var _loc4_:Dictionary = this.§_-v2v§[param1];
         if(_loc4_ == null)
         {
            return;
         }
         var _loc5_:Dictionary = _loc4_[param3 || Event];
         if(_loc5_ == null)
         {
            return;
         }
         var _loc6_:Function = _loc5_[param2];
         if(_loc6_ == null)
         {
            return;
         }
         this.eventDispatcher.removeEventListener(param1,_loc6_);
         delete _loc5_[param2];
      }
      
      public function §_-R2M§() : void
      {
         var _loc1_:String = null;
         var _loc2_:Dictionary = null;
         var _loc3_:Dictionary = null;
         var _loc4_:Function = null;
         for(_loc1_ in this.§_-v2v§)
         {
            _loc2_ = this.§_-v2v§[_loc1_];
            for each(_loc3_ in _loc2_)
            {
               for each(_loc4_ in _loc3_)
               {
                  this.eventDispatcher.removeEventListener(_loc1_,_loc4_);
               }
            }
         }
         this.§_-v2v§ = new Dictionary(false);
      }
      
      public function §_-iE§(param1:String, param2:Class, param3:Class = null) : Boolean
      {
         var _loc4_:Dictionary = this.§_-v2v§[param1];
         if(_loc4_ == null)
         {
            return false;
         }
         var _loc5_:Dictionary = _loc4_[param3 || Event];
         if(_loc5_ == null)
         {
            return false;
         }
         return _loc5_[param2] != null;
      }
      
      public function execute(param1:Class, param2:Object = null, param3:Class = null, param4:String = "") : void
      {
         this.§_-g1s§(param1);
         if(param2 != null || param3 != null)
         {
            if(!param3)
            {
               param3 = this.§_-o1i§.getClass(param2);
            }
            if(param2 is Event && param3 != Event)
            {
               this.injector.§_-r2M§(Event,param2);
            }
            this.injector.§_-r2M§(param3,param2,param4);
         }
         var _loc5_:Object = this.injector.§_-s15§(param1);
         if(param2 !== null || param3 != null)
         {
            if(param2 is Event && param3 != Event)
            {
               this.injector.§_-g2K§(Event);
            }
            this.injector.§_-g2K§(param3,param4);
         }
         _loc5_.execute();
      }
      
      public function §_-JL§(param1:Object) : void
      {
         this.§_-n1C§[param1] = true;
      }
      
      public function §_-53x§(param1:Object) : void
      {
         if(this.§_-n1C§[param1])
         {
            delete this.§_-n1C§[param1];
         }
      }
      
      protected function §_-g1s§(param1:Class) : void
      {
         var commandClass:Class = param1;
         if(!this.§_-c2G§[commandClass])
         {
            this.§_-c2G§[commandClass] = describeType(commandClass).factory.method.(@name == "execute").length();
            if(!this.§_-c2G§[commandClass])
            {
               throw new §_-E3a§(§_-E3a§.§_-O2x§ + " - " + commandClass);
            }
         }
      }
      
      protected function routeEventToCommand(param1:Event, param2:Class, param3:Boolean, param4:Class) : Boolean
      {
         if(!(param1 is param4))
         {
            return false;
         }
         this.execute(param2,param1);
         if(param3)
         {
            this.§_-9P§(param1.type,param2,param4);
         }
         return true;
      }
   }
}


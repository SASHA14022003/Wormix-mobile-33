package §_-hv§
{
   import §_-12W§.§_-X2w§;
   import §_-12W§.§_-l23§;
   import §_-52V§.§_-I2i§;
   import §_-62§.§_-P14§;
   import §_-82l§.§_-A2Y§;
   import §_-CF§.§_-E19§;
   import §_-F39§.§_-D14§;
   import §_-H3§.*;
   import §_-P1B§.§_-b21§;
   import §_-Ta§.*;
   import §_-g2r§.§_-03A§;
   import §_-o14§.§_-Dd§;
   import §_-z1g§.§_-4l§;
   import §_-z1g§.§_-522§;
   import config.§_-B1K§;
   import feathers.data.ArrayCollection;
   import flash.events.SecurityErrorEvent;
   import flash.events.TimerEvent;
   import flash.utils.Timer;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.model.user.UserProfile;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import starling.display.DisplayObject;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   use namespace gestouch_internal;
   
   public class §_-32W§ implements §_-I2i§
   {
      
      protected var eventDispatcher:EventDispatcher;
      
      protected var §_-01c§:Boolean = true;
      
      protected var listeners:Array;
      
      public function §_-32W§(param1:EventDispatcher)
      {
         super();
         this.listeners = new Array();
         this.eventDispatcher = param1;
      }
      
      public function get §_-K29§() : Boolean
      {
         return this.§_-01c§;
      }
      
      public function set §_-K29§(param1:Boolean) : void
      {
         this.§_-01c§ = param1;
      }
      
      public function §_-IF§(param1:EventDispatcher, param2:String, param3:Function, param4:Class = null) : void
      {
         var i:int;
         var callback:Function;
         var params:Object = null;
         var dispatcher:EventDispatcher = param1;
         var type:String = param2;
         var listener:Function = param3;
         var eventClass:Class = param4;
         if(this.§_-K29§ == false && dispatcher == this.eventDispatcher)
         {
            throw new §_-E3a§(§_-E3a§.§_-72l§);
         }
         if(!eventClass)
         {
            eventClass = Event;
         }
         i = int(this.listeners.length);
         while(i--)
         {
            params = this.listeners[i];
            if(params.dispatcher == dispatcher && params.type == type && params.listener == listener && params.eventClass == eventClass)
            {
               return;
            }
         }
         callback = function(param1:Event):void
         {
            routeEventToListener(param1,listener,eventClass);
         };
         params = {
            "dispatcher":dispatcher,
            "type":type,
            "listener":listener,
            "eventClass":eventClass,
            "callback":callback
         };
         this.listeners.push(params);
         dispatcher.addEventListener(type,callback);
      }
      
      public function §_-Hy§(param1:EventDispatcher, param2:String, param3:Function, param4:Class = null) : void
      {
         var _loc5_:Object = null;
         if(!param4)
         {
            param4 = Event;
         }
         var _loc6_:* = int(this.listeners.length);
         while(_loc6_--)
         {
            _loc5_ = this.listeners[_loc6_];
            if(_loc5_.dispatcher == param1 && _loc5_.type == param2 && _loc5_.listener == param3 && _loc5_.eventClass == param4)
            {
               param1.removeEventListener(param2,_loc5_.callback);
               this.listeners.splice(_loc6_,1);
               return;
            }
         }
      }
      
      public function §_-E1Y§() : void
      {
         var _loc1_:Object = null;
         var _loc2_:EventDispatcher = null;
         _loc1_ = this.listeners.pop();
         while(_loc1_)
         {
            _loc2_ = _loc1_.dispatcher;
            _loc2_.removeEventListener(_loc1_.type,_loc1_.callback);
            _loc1_ = this.listeners.pop();
         }
      }
      
      protected function routeEventToListener(param1:Event, param2:Function, param3:Class) : void
      {
         var _loc4_:int = 0;
         if(param1 is param3)
         {
            _loc4_ = int(param2.length);
            if(_loc4_ == 0)
            {
               param2();
            }
            else if(_loc4_ == 1)
            {
               param2(param1);
            }
            else
            {
               param2(param1,param1.data);
            }
         }
      }
   }
}


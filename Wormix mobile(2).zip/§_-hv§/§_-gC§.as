package §_-hv§
{
   import §_-31W§.*;
   import §_-52V§.§_-R9§;
   import §_-5Y§.§_-h2c§;
   import §_-79§.§_-11E§;
   import §_-82l§.§_-A2Y§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-Ly§.§_-81L§;
   import §_-P1B§.§_-b21§;
   import §_-RE§.*;
   import §_-TF§.§_-y2n§;
   import §_-Vg§.ClanEditView;
   import §_-Y1Q§.§_-aG§;
   import §_-Y1Q§.§_-tc§;
   import §_-b1F§.§_-v2Q§;
   import §_-l1g§.§_-L3Q§;
   import §_-m2s§.§_-R11§;
   import §_-o14§.§_-Dd§;
   import §_-r1C§.§_-h2B§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.cloudstorage.CloudStorage;
   import com.distriqt.extension.cloudstorage.events.KeyValueStoreEvent;
   import com.greensock.events.LoaderEvent;
   import com.greensock.loading.LoaderMax;
   import com.greensock.loading.LoaderStatus;
   import com.greensock.loading.core.*;
   import com.hurlant.math.BigInteger;
   import com.hurlant.math.bi_internal;
   import dragonBones.animation.WorldClock;
   import feathers.controls.Button;
   import feathers.core.FeathersControl;
   import feathers.core.ITextRenderer;
   import flash.events.Event;
   import flash.geom.Point;
   import flash.utils.getDefinitionByName;
   import flash.utils.getTimer;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.game.§_-eX§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.user.§_-r1d§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.scene.interaction.SceneInteractionData;
   import ru.pragmatix.wormix.utils.*;
   import ru.pragmatix.wormix.weapons.Weapon;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.display.Image;
   import starling.events.Event;
   import starling.events.EventDispatcher;
   import starling.textures.Texture;
   import starling.utils.Align;
   import starling.utils.Pool;
   
   use namespace bi_internal;
   
   public class §_-gC§ implements §_-R9§
   {
      
      protected static var §_-JS§:Class;
      
      protected static const §_-Vy§:Boolean = §_-n1K§();
      
      protected var §_-71k§:Object;
      
      protected var removed:Boolean;
      
      public function §_-gC§()
      {
         super();
      }
      
      protected static function §_-n1K§() : Boolean
      {
         try
         {
            §_-JS§ = getDefinitionByName("feathers.core::IFeathersControl") as Class;
         }
         catch(error:Error)
         {
         }
         return §_-JS§ != null;
      }
      
      public function §_-d1h§() : void
      {
         this.removed = false;
         if(§_-Vy§ && this.§_-71k§ is §_-JS§ && !this.§_-71k§["isCreated"])
         {
            EventDispatcher(this.§_-71k§).addEventListener("creationComplete",this.§_-Uh§);
         }
         else
         {
            this.§_-b2M§();
         }
      }
      
      public function §_-b2M§() : void
      {
      }
      
      public function §_-YM§() : void
      {
         if(§_-Vy§ && this.§_-71k§ is §_-JS§)
         {
            EventDispatcher(this.§_-71k§).removeEventListener("creationComplete",this.§_-Uh§);
         }
         this.removed = true;
         this.onRemove();
      }
      
      public function onRemove() : void
      {
      }
      
      public function §_-JY§() : Object
      {
         return this.§_-71k§;
      }
      
      public function §_-n1f§(param1:Object) : void
      {
         this.§_-71k§ = param1;
      }
      
      protected function §_-Uh§(param1:starling.events.Event) : void
      {
         param1.target.removeEventListener("creationComplete",this.§_-Uh§);
         if(!this.removed)
         {
            this.§_-b2M§();
         }
      }
   }
}


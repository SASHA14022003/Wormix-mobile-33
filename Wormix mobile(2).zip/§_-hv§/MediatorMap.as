package §_-hv§
{
   import §_-03T§.§_-2p§;
   import §_-12W§.*;
   import §_-52V§.§_-031§;
   import §_-52V§.§_-R9§;
   import §_-52V§.§_-b2z§;
   import §_-52V§.§_-iC§;
   import §_-62§.§_-G1p§;
   import §_-62§.§_-O2H§;
   import §_-62§.§_-W1r§;
   import §_-931§.§_-02O§;
   import §_-937§.§_-n1b§;
   import §_-A1K§.§_-TA§;
   import §_-B1y§.§_-bs§;
   import §_-B1y§.§_-o2k§;
   import §_-C3f§.§_-1Y§;
   import §_-CF§.§_-E19§;
   import §_-CF§.§_-x2t§;
   import §_-Cl§.*;
   import §_-D3A§.§_-TZ§;
   import §_-DJ§.§_-J2l§;
   import §_-DJ§.§_-fH§;
   import §_-F39§.*;
   import §_-H2g§.§_-di§;
   import §_-H3§.*;
   import §_-HD§.*;
   import §_-RE§.§_-D3v§;
   import §_-S1N§.§_-R1U§;
   import §_-T2h§.*;
   import §_-Tm§.§_-RF§;
   import §_-U1i§.§_-J1§;
   import §_-U1i§.§_-b1k§;
   import §_-Vg§.§_-M11§;
   import §_-Y1b§.§_-jH§;
   import §_-Z1K§.§_-q24§;
   import §_-a19§.*;
   import §_-b1F§.§_-G4§;
   import §_-b1R§.§_-Bx§;
   import §_-bI§.*;
   import §_-d26§.§_-c2E§;
   import §_-d26§.§_-d1H§;
   import §_-f1G§.*;
   import §_-g2r§.§_-03A§;
   import §_-j22§.§_-5g§;
   import §_-jF§.§_-82f§;
   import §_-k1u§.§_-2m§;
   import §_-k1u§.§_-H2M§;
   import §_-k1u§.§_-Oi§;
   import §_-l1K§.§_-E1n§;
   import §_-l1K§.§_-m2§;
   import §_-l1K§.§_-n2T§;
   import §_-l1g§.§_-L3Q§;
   import §_-q26§.*;
   import §_-r1C§.*;
   import §_-sQ§.§_-H3D§;
   import §_-z1g§.§_-5c§;
   import §_-zI§.§_-F3q§;
   import com.distriqt.extension.application.Application;
   import com.distriqt.extension.application.events.DeviceOrientationEvent;
   import com.distriqt.extension.inappbilling.InAppBilling;
   import com.distriqt.extension.inappbilling.Purchase;
   import com.greensock.*;
   import com.greensock.plugins.*;
   import com.hurlant.crypto.tls.§_-Tx§;
   import com.hurlant.crypto.tls.§_-a2D§;
   import com.hurlant.math.BigInteger;
   import com.mesmotronic.ane.AndroidID;
   import feathers.controls.Button;
   import feathers.controls.ImageLoader;
   import feathers.controls.LayoutGroup;
   import feathers.controls.NumericStepper;
   import feathers.controls.ScrollPolicy;
   import feathers.core.ITextRenderer;
   import feathers.data.ArrayCollection;
   import feathers.data.VectorCollection;
   import feathers.layout.HorizontalAlign;
   import feathers.layout.RelativePosition;
   import feathers.layout.VerticalAlign;
   import feathers.utils.textures.TextureCache;
   import flash.events.Event;
   import flash.filters.BlurFilter;
   import flash.geom.Point;
   import flash.net.Socket;
   import flash.text.TextFormat;
   import flash.utils.ByteArray;
   import flash.utils.Dictionary;
   import flash.utils.IDataInput;
   import flash.utils.IDataOutput;
   import flash.utils.getQualifiedClassName;
   import flash.utils.getTimer;
   import org.gestouch.core.Touch;
   import org.gestouch.core.gestouch_internal;
   import ru.pragmatix.flox.logger.§_-11S§;
   import ru.pragmatix.flox.serialization.§_-616§;
   import ru.pragmatix.flox.social.controller.*;
   import ru.pragmatix.flox.social.controller.mobile.FbMobileSocialController;
   import ru.pragmatix.flox.social.model.PaymentOption;
   import ru.pragmatix.flox.social.response.SocialResponse;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.fx.EffectType;
   import ru.pragmatix.wormix.fx.Effects;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.gui.menu.§_-738§;
   import ru.pragmatix.wormix.gui.menu.shop.§_-s1V§;
   import ru.pragmatix.wormix.gui.menu.shop.mobile.*;
   import ru.pragmatix.wormix.gui.screenOverlay.view.§_-B1m§;
   import ru.pragmatix.wormix.messages.clans.request.ClanSummaryRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginCreateClanRequest;
   import ru.pragmatix.wormix.messages.clans.request.login.LoginJoinClanRequest;
   import ru.pragmatix.wormix.messages.clans.structures.ClanTO;
   import ru.pragmatix.wormix.messages.client.StartBattle;
   import ru.pragmatix.wormix.messages.server.DistributePointsResult;
   import ru.pragmatix.wormix.messages.server.VerifyPaymentResult;
   import ru.pragmatix.wormix.messages.structures.HeroicMissionStructure;
   import ru.pragmatix.wormix.messages.structures.RatingProfileStructure;
   import ru.pragmatix.wormix.messages.structures.TemporalStuffStructure;
   import ru.pragmatix.wormix.model.§_-d27§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.model.rewards.§_-d2F§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.physics.Physics;
   import ru.pragmatix.wormix.physics.model.UnitPhysicModel;
   import ru.pragmatix.wormix.platform.§_-WK§;
   import ru.pragmatix.wormix.social.§_-N1V§;
   import ru.pragmatix.wormix.utils.MathUtil;
   import ru.pragmatix.wormix.utils.StringUtil;
   import ru.pragmatix.wormix.utils.§_-71v§;
   import ru.pragmatix.wormix.utils.§_-72u§;
   import ru.pragmatix.wormix.utils.§_-MN§;
   import ru.pragmatix.wormix.utils.§_-YD§;
   import ru.pragmatix.wormix.utils.§_-c1S§;
   import ru.pragmatix.wormix.weapons.*;
   import ru.pragmatix.wormix.weapons.ammo.Bullet;
   import starling.core.Starling;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   import starling.utils.ScaleMode;
   import starling.utils.SystemUtil;
   import starlingbuilder.extensions.uicomponents.ContainerButtonWithStates;
   
   use namespace gestouch_internal;
   
   public class MediatorMap extends §_-x2W§ implements §_-iC§
   {
      
      protected var §_-z1I§:Dictionary;
      
      protected var §_-mQ§:Dictionary;
      
      protected var §_-d2u§:Dictionary;
      
      protected var §_-G10§:Dictionary;
      
      protected var §_-C1M§:Boolean;
      
      protected var §_-o1i§:§_-b2z§;
      
      public function MediatorMap(param1:DisplayObjectContainer, param2:§_-031§, param3:§_-b2z§)
      {
         super(param1,param2);
         this.§_-o1i§ = param3;
         this.§_-z1I§ = new Dictionary(true);
         this.§_-mQ§ = new Dictionary(true);
         this.§_-d2u§ = new Dictionary(false);
         this.§_-G10§ = new Dictionary(false);
      }
      
      public function §_-H2T§(param1:*, param2:Class, param3:* = null, param4:Boolean = true, param5:Boolean = true) : void
      {
         var _loc6_:String = this.§_-o1i§.§_-518§(param1);
         if(this.§_-d2u§[_loc6_] != null)
         {
            throw new §_-E3a§(§_-E3a§.§_-93Y§ + " - " + param2);
         }
         if(this.§_-o1i§.§_-T2j§(param2,§_-R9§) == false)
         {
            throw new §_-E3a§(§_-E3a§.§_-42l§ + " - " + param2);
         }
         var _loc7_:MappingConfig = new MappingConfig();
         _loc7_.mediatorClass = param2;
         _loc7_.autoCreate = param4;
         _loc7_.autoRemove = param5;
         if(param3)
         {
            if(param3 is Array)
            {
               _loc7_.typedViewClasses = (param3 as Array).concat();
            }
            else if(param3 is Class)
            {
               _loc7_.typedViewClasses = [param3];
            }
         }
         else if(param1 is Class)
         {
            _loc7_.typedViewClasses = [param1];
         }
         this.§_-d2u§[_loc6_] = _loc7_;
         if(param4 || param5)
         {
            ++§_-Q1P§;
            if(§_-Q1P§ == 1)
            {
               this.§_-93D§();
            }
         }
         if(Boolean(param4) && Boolean(§_-v2Z§) && _loc6_ == getQualifiedClassName(§_-v2Z§))
         {
            this.§_-cL§(§_-v2Z§,_loc6_,_loc7_);
         }
      }
      
      public function §_-Cw§(param1:*) : void
      {
         var _loc2_:String = this.§_-o1i§.§_-518§(param1);
         var _loc3_:MappingConfig = this.§_-d2u§[_loc2_];
         if(Boolean(_loc3_) && (_loc3_.autoCreate || _loc3_.autoRemove))
         {
            --§_-Q1P§;
            if(§_-Q1P§ == 0)
            {
               this.§_-Oo§();
            }
         }
         delete this.§_-d2u§[_loc2_];
      }
      
      public function §_-K1e§(param1:Object) : §_-R9§
      {
         return this.§_-cL§(param1);
      }
      
      public function §_-KM§(param1:Object, param2:§_-R9§) : void
      {
         var _loc3_:Class = this.§_-o1i§.getClass(param2);
         injector.§_-t2Q§(_loc3_) && injector.§_-g2K§(_loc3_);
         injector.§_-r2M§(_loc3_,param2);
         this.§_-z1I§[param1] = param2;
         this.§_-mQ§[param1] = this.§_-d2u§[getQualifiedClassName(param1)];
         param2.§_-n1f§(param1);
         param2.§_-d1h§();
      }
      
      public function §_-SA§(param1:§_-R9§) : §_-R9§
      {
         var _loc2_:Object = null;
         var _loc3_:Class = null;
         if(param1)
         {
            _loc2_ = param1.§_-JY§();
            _loc3_ = this.§_-o1i§.getClass(param1);
            delete this.§_-z1I§[_loc2_];
            delete this.§_-mQ§[_loc2_];
            param1.§_-YM§();
            param1.§_-n1f§(null);
            injector.§_-t2Q§(_loc3_) && injector.§_-g2K§(_loc3_);
         }
         return param1;
      }
      
      public function §_-119§(param1:Object) : §_-R9§
      {
         return this.§_-SA§(this.§_-HY§(param1));
      }
      
      public function §_-HY§(param1:Object) : §_-R9§
      {
         return this.§_-z1I§[param1];
      }
      
      public function §_-t2Q§(param1:*) : Boolean
      {
         var _loc2_:String = this.§_-o1i§.§_-518§(param1);
         return this.§_-d2u§[_loc2_] != null;
      }
      
      public function §_-BF§(param1:Object) : Boolean
      {
         return this.§_-z1I§[param1] != null;
      }
      
      public function §_-C3G§(param1:§_-R9§) : Boolean
      {
         var _loc2_:§_-R9§ = null;
         for each(_loc2_ in this.§_-z1I§)
         {
            if(_loc2_ == param1)
            {
               return true;
            }
         }
         return false;
      }
      
      override protected function §_-93D§() : void
      {
         if(Boolean(§_-v2Z§) && enabled)
         {
            §_-v2Z§.addEventListener(starling.events.Event.ADDED,this.§_-h27§);
            §_-v2Z§.addEventListener(starling.events.Event.REMOVED,this.§_-j1W§);
            §_-v2Z§.addEventListener(starling.events.Event.ADDED_TO_STAGE,this.§_-h27§);
            §_-v2Z§.addEventListener(starling.events.Event.REMOVED_FROM_STAGE,this.§_-j1W§);
         }
      }
      
      override protected function §_-Oo§() : void
      {
         if(§_-v2Z§)
         {
            §_-v2Z§.removeEventListener(starling.events.Event.ADDED,this.§_-h27§);
            §_-v2Z§.removeEventListener(starling.events.Event.REMOVED,this.§_-j1W§);
            §_-v2Z§.removeEventListener(starling.events.Event.ADDED_TO_STAGE,this.§_-h27§);
            §_-v2Z§.removeEventListener(starling.events.Event.REMOVED_FROM_STAGE,this.§_-j1W§);
         }
      }
      
      protected function §_-D12§(param1:DisplayObject) : void
      {
         var _loc3_:String = null;
         var _loc4_:MappingConfig = null;
         var _loc5_:int = 0;
         var _loc6_:int = 0;
         var _loc7_:DisplayObject = null;
         if(this.§_-G10§[param1])
         {
            delete this.§_-G10§[param1];
         }
         else
         {
            _loc3_ = getQualifiedClassName(param1);
            _loc4_ = this.§_-d2u§[_loc3_];
            if((Boolean(_loc4_)) && _loc4_.autoCreate)
            {
               this.§_-cL§(param1,_loc3_,_loc4_);
            }
         }
         var _loc2_:DisplayObjectContainer = param1 as DisplayObjectContainer;
         if(_loc2_)
         {
            _loc5_ = _loc2_.numChildren;
            _loc6_ = 0;
            while(_loc6_ < _loc5_)
            {
               _loc7_ = _loc2_.getChildAt(_loc6_);
               this.§_-D12§(_loc7_);
               _loc6_++;
            }
         }
      }
      
      protected function §_-NU§(param1:DisplayObject) : void
      {
         var _loc4_:int = 0;
         var _loc5_:int = 0;
         var _loc6_:DisplayObject = null;
         var _loc2_:MappingConfig = this.§_-mQ§[param1];
         if(Boolean(_loc2_) && _loc2_.autoRemove)
         {
            this.§_-G10§[param1] = param1;
            if(!this.§_-C1M§)
            {
               this.§_-C1M§ = true;
               Starling.current.stage.addEventListener(starling.events.Event.ENTER_FRAME,this.§_-oU§);
            }
         }
         var _loc3_:DisplayObjectContainer = param1 as DisplayObjectContainer;
         if(_loc3_)
         {
            _loc4_ = _loc3_.numChildren;
            _loc5_ = 0;
            while(_loc5_ < _loc4_)
            {
               _loc6_ = _loc3_.getChildAt(_loc5_);
               this.§_-NU§(_loc6_);
               _loc5_++;
            }
         }
      }
      
      override protected function §_-h27§(param1:starling.events.Event) : void
      {
         var _loc2_:DisplayObject = DisplayObject(param1.target);
         this.§_-D12§(_loc2_);
      }
      
      protected function §_-cL§(param1:Object, param2:String = null, param3:MappingConfig = null) : §_-R9§
      {
         var _loc5_:Class = null;
         var _loc6_:Class = null;
         var _loc4_:§_-R9§ = this.§_-z1I§[param1];
         if(_loc4_ == null)
         {
            if(!param2)
            {
               param2 = getQualifiedClassName(param1);
            }
            if(!param3)
            {
               param3 = this.§_-d2u§[param2];
            }
            if(param3)
            {
               for each(_loc5_ in param3.typedViewClasses)
               {
                  injector.§_-r2M§(_loc5_,param1);
               }
               _loc4_ = injector.§_-s15§(param3.mediatorClass);
               for each(_loc6_ in param3.typedViewClasses)
               {
                  injector.§_-g2K§(_loc6_);
               }
               this.§_-KM§(param1,_loc4_);
            }
         }
         return _loc4_;
      }
      
      protected function §_-j1W§(param1:starling.events.Event) : void
      {
         var _loc2_:DisplayObject = DisplayObject(param1.target);
         this.§_-NU§(_loc2_);
      }
      
      protected function §_-oU§(param1:starling.events.Event) : void
      {
         var _loc2_:DisplayObject = null;
         Starling.current.stage.removeEventListener(starling.events.Event.ENTER_FRAME,this.§_-oU§);
         for each(_loc2_ in this.§_-G10§)
         {
            if(!_loc2_.stage)
            {
               this.§_-119§(_loc2_);
            }
            delete this.§_-G10§[_loc2_];
         }
         this.§_-C1M§ = false;
      }
   }
}

class MappingConfig
{
   
   public var mediatorClass:Class;
   
   public var typedViewClasses:Array;
   
   public var autoCreate:Boolean;
   
   public var autoRemove:Boolean;
   
   public function MappingConfig()
   {
      super();
   }
}

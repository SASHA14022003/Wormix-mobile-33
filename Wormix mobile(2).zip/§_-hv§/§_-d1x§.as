package §_-hv§
{
   import §_-52V§.§_-23C§;
   import §_-Y1O§.*;
   import §_-z1g§.§_-lp§;
   import feathers.core.ITextRenderer;
   import flash.geom.Point;
   import flash.text.TextFormat;
   import ru.pragmatix.wormix.utils.§_-R2g§;
   import starling.events.EventDispatcher;
   
   public class §_-d1x§ extends EventDispatcher implements §_-23C§
   {
      
      public function §_-d1x§()
      {
         super();
      }
      
      public function get eventDispatcher() : EventDispatcher
      {
         return this;
      }
   }
}


package §_-hv§
{
   import §_-62§.*;
   import §_-9§.§_-52A§;
   import §_-j1w§.§_-lD§;
   import §_-jF§.*;
   import §_-l1g§.§_-L3Q§;
   import flash.events.Event;
   import ru.pragmatix.wormix.controller.§_-X1j§;
   import ru.pragmatix.wormix.gui.§_-s2a§;
   import ru.pragmatix.wormix.model.user.*;
   import ru.pragmatix.wormix.pvp.messages.ex.BattleCreationFailure;
   import ru.pragmatix.wormix.pvp.messages.ex.StartPvpBattle;
   import ru.pragmatix.wormix.utils.§_-J2h§;
   import starling.events.Event;
   import starling.utils.SystemUtil;
   
   public class §_-E3a§ extends Error
   {
      
      public static const §_-O2x§:String = "Command Class does not implement an execute() method";
      
      public static const §_-F34§:String = "Cannot overwrite map";
      
      public static const §_-42l§:String = "Mediator Class does not implement IMediator";
      
      public static const §_-93Y§:String = "Mediator Class has already been mapped to a View Class in this context";
      
      public static const §_-72l§:String = "Listening to the context eventDispatcher is not enabled for this EventMap";
      
      public static const §_-D1Y§:String = "The ContextBase does not specify a concrete IInjector. Please override the injector getter in your concrete or abstract Context.";
      
      public static const §_-z2§:String = "The ContextBase does not specify a concrete IReflector. Please override the reflector getter in your concrete or abstract Context.";
      
      public static const §_-D3L§:String = "Context contextView must only be set once";
      
      public function §_-E3a§(param1:String = "", param2:int = 0)
      {
         super(param1,param2);
      }
   }
}


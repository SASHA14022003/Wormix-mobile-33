package §_-hv§
{
   import §_-52V§.§_-031§;
   import §_-73d§.§_-x2C§;
   import §_-A1K§.§_-TA§;
   import §_-DJ§.§_-J2l§;
   import §_-b1F§.§_-G4§;
   import §_-l1K§.§_-d2j§;
   import config.§_-V2w§;
   import ru.pragmatix.wormix.model.items.craft.§_-IE§;
   import ru.pragmatix.wormix.model.items.craft.§_-Y2u§;
   import ru.pragmatix.wormix.objects.§_-01J§;
   import ru.pragmatix.wormix.objects.§_-F3o§;
   import ru.pragmatix.wormix.utils.*;
   import starling.display.DisplayObject;
   import starling.display.DisplayObjectContainer;
   import starling.events.Event;
   
   public class §_-x2W§
   {
      
      protected var _enabled:Boolean = true;
      
      protected var §_-93x§:DisplayObjectContainer;
      
      protected var injector:§_-031§;
      
      protected var useCapture:Boolean;
      
      protected var §_-Q1P§:uint;
      
      public function §_-x2W§(param1:DisplayObjectContainer, param2:§_-031§)
      {
         super();
         this.injector = param2;
         this.useCapture = true;
         this.§_-v2Z§ = param1;
      }
      
      public function get §_-v2Z§() : DisplayObjectContainer
      {
         return this.§_-93x§;
      }
      
      public function set §_-v2Z§(param1:DisplayObjectContainer) : void
      {
         if(param1 != this.§_-93x§)
         {
            this.§_-Oo§();
            this.§_-93x§ = param1;
            if(this.§_-Q1P§ > 0)
            {
               this.§_-93D§();
            }
         }
      }
      
      public function get enabled() : Boolean
      {
         return this._enabled;
      }
      
      public function set enabled(param1:Boolean) : void
      {
         if(param1 != this._enabled)
         {
            this.§_-Oo§();
            this._enabled = param1;
            if(this.§_-Q1P§ > 0)
            {
               this.§_-93D§();
            }
         }
      }
      
      protected function §_-93D§() : void
      {
      }
      
      protected function §_-Oo§() : void
      {
      }
      
      protected function §_-h27§(param1:Event) : void
      {
      }
   }
}

